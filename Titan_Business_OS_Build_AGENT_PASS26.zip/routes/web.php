<?php

use App\Http\Controllers\Owner\BillingController;
use App\Http\Controllers\Owner\CalendarController;
use App\Http\Controllers\Owner\DispatchController;
use App\Http\Controllers\Owner\CustomerController;
use App\Http\Controllers\Owner\EstimateController;
use App\Http\Controllers\Owner\InvoiceController;
use App\Http\Controllers\Owner\JobController;
use App\Http\Controllers\Owner\PropertyController;
use App\Http\Controllers\Owner\ReportingController;
use App\Http\Controllers\Owner\SetupController;
use App\Http\Controllers\Owner\SettingsController;
use App\Http\Controllers\Owner\StripeController;
use App\Http\Controllers\Owner\SubscriptionController;
use App\Http\Controllers\Owner\TeamController;
use App\Http\Controllers\HealthController;
use App\Http\Controllers\MarketingController;
use App\Http\Controllers\CmsPageController;
use App\Http\Controllers\Platform\TitanModuleAdminApiController;
use App\Http\Controllers\Platform\DashboardController as PlatformDashboardController;
use App\Http\Controllers\Platform\ModuleAdminDashboardController;
use App\Http\Controllers\StripeWebhookController;
use App\Http\Controllers\PublicEstimateController;
use App\Http\Controllers\Technician\DashboardController as TechnicianDashboardController;
use App\Http\Controllers\Technician\JobController as TechnicianJobController;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

// Legacy Filament panel aliases.
// /admin is the Super Admin panel. Some iOS/Safari sessions cached an old
// permanent /admin -> /titanpro redirect, so /titanpro must resolve back to
// /admin until those caches age out. Titan Pro's canonical URL is /pro.
Route::get('/titanpro', fn () => redirect('/admin', 302)->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'))->name('admin.cached-titanpro.alias');
Route::get('/titanpro/{path}', fn (string $path) => redirect('/admin/'.$path, 302)->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'))->where('path', '.*')->name('admin.cached-titanpro.path.alias');
Route::redirect('/platform', '/admin', 302);
Route::redirect('/platform/{path}', '/admin/{path}', 302)->where('path', '.*');

// Root: guests see the marketing page; authenticated users go to their dashboard
Route::get('/', function () {
    if (auth()->check()) {
        $user = auth()->user();
        if ($user->hasRole('super_admin')) {
            return redirect('/admin');
        }
        if ($user->hasRole('technician')) {
            return redirect()->route('technician.dashboard');
        }
        return redirect()->route('owner.dashboard');
    }
    return app(MarketingController::class)->index();
})->name('home');

// Named 'dashboard' route — used by Fortify post-login redirect and internal links
Route::get('/dashboard', function () {
    $user = auth()->user();
    if ($user->hasRole('super_admin')) {
        return redirect('/admin');
    }
    if ($user->hasRole('technician')) {
        return redirect()->route('technician.dashboard');
    }
    return redirect()->route('owner.dashboard');
})->middleware('auth')->name('dashboard');

// Legacy owner panel entry paths must bypass subscription middleware and
// permanently redirect to canonical Titan panel paths.
Route::redirect('/owner/dispatch', '/titango', 301)->name('owner.dispatch.alias');
Route::redirect('/owner/billing', '/zeropay', 301)->name('owner.billing.alias');
Route::redirect('/owner/estimates', '/titanquotes', 301)->name('owner.estimates.alias');
Route::redirect('/owner/marketing', '/titannexus', 301)->name('owner.marketing.alias');

// ── Platform SaaS admin — cross-tenant controls for self-hosted operators ──
Route::middleware(['auth', 'verified', 'role:super_admin'])
    ->prefix('platform')
    ->name('platform.')
    ->group(function () {
        Route::get('/dashboard', [PlatformDashboardController::class, 'index'])->name('dashboard');
        Route::patch('/organizations/{organization}', [PlatformDashboardController::class, 'updateOrganization'])->name('organizations.update');
        Route::patch('/organizations/{organization}/subscription', [PlatformDashboardController::class, 'updateSubscription'])->name('organizations.subscription.update');
        Route::post('/organizations/{organization}/extend-trial', [PlatformDashboardController::class, 'extendTrial'])->name('organizations.extend-trial');
        Route::post('/organizations/{organization}/activate', [PlatformDashboardController::class, 'activate'])->name('organizations.activate');

        // Module administration — protected by titan.admin gate via module.admin middleware
        Route::middleware('module.admin')->group(function () {
            Route::get('/modules', [ModuleAdminDashboardController::class, 'index'])
                ->name('modules.index');
            Route::get('/modules/audit-log', [\App\Http\Controllers\Platform\ModuleAuditLogController::class, 'index'])
                ->name('modules.audit-log');
        });
    });
// ── Subscription routes — outside subscription middleware so expired users can reach them ──
Route::prefix('admin/titan/modules')
    ->middleware(['auth', 'module.admin'])
    ->group(function () {
        Route::post('/sync', [TitanModuleAdminApiController::class, 'sync']);
        Route::get('/', [TitanModuleAdminApiController::class, 'index']);
        Route::post('/{module}/enable', [TitanModuleAdminApiController::class, 'enable']);
        Route::post('/{module}/disable', [TitanModuleAdminApiController::class, 'disable']);
        Route::get('/{module}/health', [TitanModuleAdminApiController::class, 'health']);
        Route::get('/{module}/manifests', [TitanModuleAdminApiController::class, 'manifests']);
    });

Route::middleware(['auth', 'role:owner|admin'])
    ->prefix('owner')
    ->name('owner.')
    ->group(function () {
        Route::get('/subscription', [SubscriptionController::class, 'index'])->name('subscription.index');
        Route::post('/subscription/checkout', [SubscriptionController::class, 'checkout'])->name('subscription.checkout');
        Route::get('/subscription/success', [SubscriptionController::class, 'success'])->name('subscription.success');
        Route::get('/subscription/expired', [SubscriptionController::class, 'expired'])->name('subscription.expired');
    });

// ── Setup wizard — no subscription check (org has no data yet) ──────────────
Route::middleware(['auth', 'verified', 'role:owner|admin'])
    ->prefix('owner')
    ->name('owner.')
    ->group(function () {
        Route::get('/setup', [SetupController::class, 'show'])->name('setup');
        Route::post('/setup/company', [SetupController::class, 'saveCompany'])->name('setup.company');
        Route::post('/setup/job-types', [SetupController::class, 'addJobType'])->name('setup.job-types.store');
        Route::delete('/setup/job-types/{jobType}', [SetupController::class, 'removeJobType'])->name('setup.job-types.destroy');
        Route::post('/setup/technicians', [SetupController::class, 'addTechnician'])->name('setup.technicians.store');
        Route::post('/setup/complete', [SetupController::class, 'complete'])->name('setup.complete');
    });

// ── Team management — owner/admin only, subscription-gated ───────────────────
Route::middleware(['auth', 'verified', 'role:owner|admin', 'subscription'])
    ->prefix('owner')
    ->name('owner.')
    ->group(function () {
        Route::get('/team', [TeamController::class, 'index'])->name('team.index');
        Route::post('/team', [TeamController::class, 'store'])->name('team.store');
        Route::patch('/team/{user}', [TeamController::class, 'update'])->name('team.update');
        Route::delete('/team/{user}', [TeamController::class, 'destroy'])->name('team.destroy');
    });

Route::middleware(['auth', 'verified', 'role:owner|admin|dispatcher|bookkeeper', 'subscription'])
    ->prefix('owner')
    ->name('owner.')
    ->group(function () {
        Route::resource('customers', CustomerController::class);

        // Properties — nested create/store under customer; shallow edit/update/destroy
        Route::get('/customers/{customer}/properties/create', [PropertyController::class, 'create'])->name('customers.properties.create');
        Route::post('/customers/{customer}/properties', [PropertyController::class, 'store'])->name('customers.properties.store');
        Route::get('/properties/{property}/edit', [PropertyController::class, 'edit'])->name('properties.edit');
        Route::patch('/properties/{property}', [PropertyController::class, 'update'])->name('properties.update');
        Route::delete('/properties/{property}', [PropertyController::class, 'destroy'])->name('properties.destroy');

        Route::resource('jobs', JobController::class);
        Route::patch('/jobs/{job}/status', [JobController::class, 'updateStatus'])->name('jobs.status');
        Route::patch('/jobs/{job}/reschedule', [JobController::class, 'reschedule'])->name('jobs.reschedule');
        Route::patch('/jobs/{job}/reassign', [JobController::class, 'reassign'])->name('jobs.reassign');

        Route::get('/calendar', [CalendarController::class, 'index'])->name('calendar');
        Route::get('/calendar/events', [CalendarController::class, 'events'])->name('calendar.events');

        Route::resource('estimates', EstimateController::class);
        Route::post('/estimates/{estimate}/send', [EstimateController::class, 'send'])->name('estimates.send');
        Route::post('/estimates/{estimate}/convert', [EstimateController::class, 'convertToJob'])->name('estimates.convert');

        Route::get('/dispatch', [DispatchController::class, 'index'])->name('dispatch');
        Route::get('/dispatch/technicians', [DispatchController::class, 'technicianLocations'])->name('dispatch.technicians');
        Route::get('/dispatch/technicians/{user}/trail', [DispatchController::class, 'technicianTrail'])->name('dispatch.trail');

        Route::get('/billing', [BillingController::class, 'index'])->name('billing');

        // Reporting
        Route::get('/dashboard', [ReportingController::class, 'dashboard'])->name('dashboard');
        Route::get('/reports/jobs-by-type', [ReportingController::class, 'jobsByType'])->name('reports.jobs-by-type');
        Route::get('/reports/job-profitability', [ReportingController::class, 'jobProfitability'])->name('reports.job-profitability');
        Route::get('/reports/technician-performance', [ReportingController::class, 'technicianPerformance'])->name('reports.technician-performance');

        // Company & integration settings
        Route::get('/settings/company', [SettingsController::class, 'company'])->name('settings.company');
        Route::post('/settings/company', [SettingsController::class, 'updateCompany'])->name('settings.company.update');
        Route::get('/settings/integrations', [SettingsController::class, 'integrations'])->name('settings.integrations');
        Route::post('/settings/integrations', [SettingsController::class, 'updateIntegrations'])->name('settings.integrations.update');
        Route::resource('invoices', InvoiceController::class)->only(['index', 'show', 'destroy']);
        Route::post('/jobs/{job}/invoice', [InvoiceController::class, 'generateFromJob'])->name('jobs.invoice.generate');
        Route::post('/invoices/{invoice}/send', [InvoiceController::class, 'send'])->name('invoices.send');
        Route::post('/invoices/{invoice}/void', [InvoiceController::class, 'void'])->name('invoices.void');
        Route::post('/invoices/{invoice}/payments', [InvoiceController::class, 'recordPayment'])->name('invoices.payments.store');
        Route::post('/invoices/{invoice}/checkout', [StripeController::class, 'createCheckoutSession'])->name('invoices.checkout');
    });

// Public estimate page — no auth required; throttled to prevent token brute-force
Route::middleware(['throttle:10,1'])->group(function () {
    Route::get('/estimates/{token}', [PublicEstimateController::class, 'show'])->name('estimates.public');
    Route::post('/estimates/{token}/accept', [PublicEstimateController::class, 'accept'])->name('estimates.accept');
    Route::post('/estimates/{token}/decline', [PublicEstimateController::class, 'decline'])->name('estimates.decline');
});

Route::middleware(['auth', 'role:technician|owner|admin|super_admin'])
    ->prefix('technician')
    ->name('technician.')
    ->group(function () {
        Route::get('/dashboard', [TechnicianDashboardController::class, 'index'])->name('dashboard');
        Route::get('/jobs', [TechnicianJobController::class, 'index'])->name('jobs.index');
        Route::get('/jobs/{job}', [TechnicianJobController::class, 'show'])->name('jobs.show');
    });

// Health checks — no auth, no CSRF, used by uptime monitors and orchestrators
Route::get('/health', [HealthController::class, 'liveness'])->name('health');
Route::get('/health/ready', [HealthController::class, 'readiness'])->name('health.ready');

// Stripe webhook — no auth, CSRF excluded in bootstrap/app.php, signature verified in controller
Route::post('/stripe/webhook', [StripeWebhookController::class, 'handle'])
    ->name('stripe.webhook');

// ── Visual UI Inspector API — authenticated; accessible to admins & owners ──
Route::middleware(['auth', 'role:super_admin|admin|owner'])
    ->prefix('titan/ui-inspector')
    ->name('titan.ui-inspector.')
    ->group(function () {
        Route::get('/overrides',            [\App\Http\Controllers\UiInspectorController::class, 'index'])->name('index');
        Route::post('/overrides',           [\App\Http\Controllers\UiInspectorController::class, 'upsert'])->name('upsert');
        Route::delete('/overrides/{key}',   [\App\Http\Controllers\UiInspectorController::class, 'reset'])->name('reset');
        Route::delete('/overrides',         [\App\Http\Controllers\UiInspectorController::class, 'resetAll'])->name('reset-all');
    });



// Public Titan BOS marketing, app, Service Mode, and CMS pages.
Route::get('/platform', fn () => app(CmsPageController::class)->show('platform'))->name('platform.public');
Route::get('/platform-overview', fn () => redirect('/platform'))->name('platform.overview');
Route::get('/apps', fn () => app(CmsPageController::class)->show('apps'))->name('apps.index');
Route::get('/apps/{slug}', fn (string $slug) => app(CmsPageController::class)->show('app-'.$slug))->name('apps.show');
Route::get('/service-modes', fn () => app(CmsPageController::class)->show('service-modes'))->name('service-modes.index');
Route::get('/industries', fn () => app(CmsPageController::class)->show('industries'))->name('industries.index');
Route::get('/pricing', fn () => app(CmsPageController::class)->show('pricing'))->name('pricing');
Route::get('/zero-philosophy', fn () => app(CmsPageController::class)->show('zero-philosophy'))->name('zero-philosophy');
Route::get('/zero', fn () => app(CmsPageController::class)->show('zero-philosophy'))->name('zero');
// ZeroPay product marketing page — the panel itself lives at /zeropay (handled by ZeroPayPanelProvider).
Route::get('/zeropay-product', fn () => app(CmsPageController::class)->show('zeropay'))->name('zeropay.product');
Route::get('/security', fn () => app(CmsPageController::class)->show('security'))->name('security');
Route::get('/ai-strategy', fn () => app(CmsPageController::class)->show('ai-strategy'))->name('ai-strategy');
Route::get('/automation-engine', fn () => app(CmsPageController::class)->show('automation-engine'))->name('automation-engine');
Route::get('/how-it-works', fn () => app(CmsPageController::class)->show('how-it-works'))->name('how-it-works');
Route::get('/features', fn () => app(CmsPageController::class)->show('features'))->name('features');
Route::get('/faq', fn () => app(CmsPageController::class)->show('faq'))->name('faq');
Route::get('/about', fn () => app(CmsPageController::class)->show('about'))->name('about');
Route::get('/contact', fn () => app(CmsPageController::class)->show('contact'))->name('contact');
// Legacy panel aliases — temporary redirects to canonical panel paths.
// /admin is owned by AdminPanelProvider. Do not redirect it to Titan Pro.
Route::redirect('/ground-zero', '/groundzero', 301)->name('groundzero.alias');
Route::redirect('/titan-go', '/titango', 301)->name('titango.alias');
Route::redirect('/titan-quotes', '/titanquotes', 301)->name('titanquotes.alias');
Route::redirect('/titan-grow', '/titannexus', 301)->name('titannexus.alias');
Route::redirect('/titan-nexus', '/titannexus', 301)->name('titannexus.hyphen.alias');
Route::get('/verticals', fn () => redirect('/service-modes'))->name('verticals.index');
Route::get('/verticals/{slug}', fn (string $slug) => redirect('/service-modes'))->name('verticals.show');
Route::get('/pages/{slug}', [CmsPageController::class, 'show'])->name('cms.pages.show');

// Theme share import — resolves a share token and redirects to UI Studio
Route::get('/theme/import/{token}', \App\Http\Controllers\Platform\ThemeImportController::class)
    ->name('theme.import')
    ->middleware('auth');

require __DIR__.'/esoft.php';
require __DIR__.'/auth.php';

// UI Studio motion preview — only available in local and testing environments
if (app()->isLocal() || app()->runningUnitTests()) {
    Route::get(
        '/titan-ui-studio/motion-preview',
        \App\Http\Controllers\UiStudio\MotionPreviewController::class
    )->name('ui-studio.motion-preview');
}

Route::post('/theme-presets/apply', [\App\Http\Controllers\ThemePresetController::class, 'apply'])->middleware(['web'])->name('theme-presets.apply');

Route::post('/theme-presets/duplicate', [\App\Http\Controllers\ThemePresetController::class, 'duplicate'])->middleware(['web'])->name('theme-presets.duplicate');

Route::post('/theme-presets/delete', [\App\Http\Controllers\ThemePresetController::class, 'delete'])->middleware(['web'])->name('theme-presets.delete');

Route::get('/theme-presets/export', [\App\Http\Controllers\ThemePresetController::class, 'export'])->middleware(['web'])->name('theme-presets.export');

// -------------------------------------------------------------------------
// Titan Zero assistant web endpoint for Business OS
//
// Provides a session-authenticated fallback for the assistant within the
// Filament shell.  The response structure mirrors the API endpoint used
// in earlier passes.  Only generic fields are returned to avoid exposing
// unfinished module functionality.

Route::post('/titan/zero/generate-ui', function (Request $request) {
    return response()->json([
        'ok' => true,
        'reply' => 'Titan Zero is connected to the Business OS shell.',
        'message' => 'Titan Zero is connected to the Business OS shell.',
        'widgets' => [],
        'thread' => null,
        'context' => $request->input('context', []),
    ]);
})->middleware(['auth']);

// ── Titan OS shell routes ───────────────────────────────────────────────────
// Expose the Business OS shell under the /os prefix.  These simple
// closures allow authenticated users to access the OS launcher and
// workspace placeholders without binding to a dedicated controller.  The
// workspace show view will attempt to resolve a module's workspace via
// ProvidesTitanOsWorkspace when available.
Route::middleware(['auth'])->group(function () {
    Route::get('/os', fn () => redirect('/os/apps'))->name('os.index');
    Route::get('/os/apps', fn () => view('titan-os.workspaces.index'))->name('os.apps');
    Route::get('/os/workspace/{appKey}', fn (string $appKey) => view('titan-os.workspaces.show', ['appKey' => $appKey]))
        ->name('os.workspace');
});
