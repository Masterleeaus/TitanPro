
<style>
    .fi-layout,
    .fi-main,
    .fi-page,
    .fi-page-content {
        visibility: visible;
        opacity: 1;
    }
</style>
<?php /**PATH /home/saassmar/domains/tradiesm.art/public_html/resources/views/vendor/filament/theme-panel-dashboard-leak-guard.blade.php ENDPATH**/ ?>