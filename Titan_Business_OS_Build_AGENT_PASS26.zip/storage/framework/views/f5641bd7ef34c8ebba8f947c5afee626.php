<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'icon',
    'darkIcon' => null,
    'renderAsImage' => false,
    'label',
    'topbar' => false,
    'collapsibleSidebar' => false,
    'showChevron' => false,
    'modalId' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'icon',
    'darkIcon' => null,
    'renderAsImage' => false,
    'label',
    'topbar' => false,
    'collapsibleSidebar' => false,
    'showChevron' => false,
    'modalId' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($topbar): ?>
    <span x-data="{ get isDark() { return $store.theme === 'dark' || ($store.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches) } }" class="contents">
        <?php if (isset($component)) { $__componentOriginalf0029cce6d19fd6d472097ff06a800a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf0029cce6d19fd6d472097ff06a800a1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon-button','data' => ['icon' => $icon,'iconAlias' => 'panels::panel-switch-trigger','iconSize' => 'lg','label' => $label,'class' => 'bg-gray-100 rounded-full! dark:bg-custom-500/20','style' => ''.e(\Filament\Support\get_color_css_variables('primary', shades: [100, 500])).'; min-width: 36px;','xShow' => '!isDark','xOn:click' => '\''.e(filled($modalId)).'\' && $dispatch(\'open-modal\', { id: \''.e($modalId).'\' })']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'icon-alias' => 'panels::panel-switch-trigger','icon-size' => 'lg','label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($label),'class' => 'bg-gray-100 rounded-full! dark:bg-custom-500/20','style' => ''.e(\Filament\Support\get_color_css_variables('primary', shades: [100, 500])).'; min-width: 36px;','x-show' => '!isDark','x-on:click' => '\''.e(filled($modalId)).'\' && $dispatch(\'open-modal\', { id: \''.e($modalId).'\' })']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf0029cce6d19fd6d472097ff06a800a1)): ?>
<?php $attributes = $__attributesOriginalf0029cce6d19fd6d472097ff06a800a1; ?>
<?php unset($__attributesOriginalf0029cce6d19fd6d472097ff06a800a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf0029cce6d19fd6d472097ff06a800a1)): ?>
<?php $component = $__componentOriginalf0029cce6d19fd6d472097ff06a800a1; ?>
<?php unset($__componentOriginalf0029cce6d19fd6d472097ff06a800a1); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalf0029cce6d19fd6d472097ff06a800a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf0029cce6d19fd6d472097ff06a800a1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon-button','data' => ['icon' => $darkIcon ?? $icon,'iconAlias' => 'panels::panel-switch-trigger','iconSize' => 'lg','label' => $label,'class' => 'bg-gray-100 rounded-full! dark:bg-custom-500/20','style' => ''.e(\Filament\Support\get_color_css_variables('primary', shades: [100, 500])).'; min-width: 36px;','xShow' => 'isDark','xCloak' => true,'xOn:click' => '\''.e(filled($modalId)).'\' && $dispatch(\'open-modal\', { id: \''.e($modalId).'\' })']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($darkIcon ?? $icon),'icon-alias' => 'panels::panel-switch-trigger','icon-size' => 'lg','label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($label),'class' => 'bg-gray-100 rounded-full! dark:bg-custom-500/20','style' => ''.e(\Filament\Support\get_color_css_variables('primary', shades: [100, 500])).'; min-width: 36px;','x-show' => 'isDark','x-cloak' => true,'x-on:click' => '\''.e(filled($modalId)).'\' && $dispatch(\'open-modal\', { id: \''.e($modalId).'\' })']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf0029cce6d19fd6d472097ff06a800a1)): ?>
<?php $attributes = $__attributesOriginalf0029cce6d19fd6d472097ff06a800a1; ?>
<?php unset($__attributesOriginalf0029cce6d19fd6d472097ff06a800a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf0029cce6d19fd6d472097ff06a800a1)): ?>
<?php $component = $__componentOriginalf0029cce6d19fd6d472097ff06a800a1; ?>
<?php unset($__componentOriginalf0029cce6d19fd6d472097ff06a800a1); ?>
<?php endif; ?>
    </span>
<?php else: ?>
    <button
        x-data="{ tooltip: false }"
        x-effect="
            tooltip = $store.sidebar.isOpen
                ? false
                : {
                      content: <?php echo \Illuminate\Support\Js::from($label)->toHtml() ?>,
                      placement: document.dir === 'rtl' ? 'left' : 'right',
                      theme: $store.theme,
                  }
        "
        x-tooltip.html="tooltip"
        type="button"
        class="fi-sidebar-database-notifications-btn"
    >
        <?php if (isset($component)) { $__componentOriginaled19177085e146347d917c72f0bf076f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled19177085e146347d917c72f0bf076f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panel-switch::components.panel-icon','data' => ['icon' => $icon,'darkIcon' => $darkIcon,'renderAsImage' => $renderAsImage,'class' => 'h-6 w-6 shrink-0 rounded-full object-cover','alt' => $label]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panel-switch::panel-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'dark-icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($darkIcon),'render-as-image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($renderAsImage),'class' => 'h-6 w-6 shrink-0 rounded-full object-cover','alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($label)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled19177085e146347d917c72f0bf076f)): ?>
<?php $attributes = $__attributesOriginaled19177085e146347d917c72f0bf076f; ?>
<?php unset($__attributesOriginaled19177085e146347d917c72f0bf076f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled19177085e146347d917c72f0bf076f)): ?>
<?php $component = $__componentOriginaled19177085e146347d917c72f0bf076f; ?>
<?php unset($__componentOriginaled19177085e146347d917c72f0bf076f); ?>
<?php endif; ?>

        <span
            <?php if($collapsibleSidebar): ?>
                x-show="$store.sidebar.isOpen"
                x-transition:enter="fi-transition-enter"
                x-transition:enter-start="fi-transition-enter-start"
                x-transition:enter-end="fi-transition-enter-end"
            <?php endif; ?>
            class="fi-sidebar-database-notifications-btn-label"
        >
            <?php echo e($label); ?>

        </span>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showChevron): ?>
            <x-filament::icon
                icon="heroicon-m-chevron-up"
                <?php if($collapsibleSidebar): ?>
                    x-show="$store.sidebar.isOpen"
                    x-transition:enter="fi-transition-enter"
                    x-transition:enter-start="fi-transition-enter-start"
                    x-transition:enter-end="fi-transition-enter-end"
                <?php endif; ?>
                class="ms-auto h-5 w-5 shrink-0 text-gray-400 dark:text-gray-500"
            />
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </button>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /home/saassmar/domains/tradiesm.art/public_html/vendor/bezhansalleh/filament-panel-switch/resources/views/components/panel-trigger.blade.php ENDPATH**/ ?>