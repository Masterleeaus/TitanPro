<?php echo \App\Support\ThemeRuntime::css(); ?>

<?php /**PATH /home/saassmar/domains/tradiesm.art/public_html/resources/views/filament/theme-manager-runtime.blade.php ENDPATH**/ ?>