
<?php
    $pageUiEnabled = request()->boolean('page_ui_edit') || request()->boolean('ui_inspector');
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pageUiEnabled): ?>
    <?php if ($__env->exists('filament.ui-inspector')) echo $__env->make('filament.ui-inspector', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /home/saassmar/domains/tradiesm.art/public_html/resources/views/vendor/filament/page-ui-inspector-optin.blade.php ENDPATH**/ ?>