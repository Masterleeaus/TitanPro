<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'panels',
    'currentPanel',
    'labels' => [],
    'icons' => [],
    'darkIcons' => [],
    'iconSize' => 32,
    'renderIconAsImage' => false,
    'slideOver' => false,
    'appMeta' => [],
    'categories' => [],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'panels',
    'currentPanel',
    'labels' => [],
    'icons' => [],
    'darkIcons' => [],
    'iconSize' => 32,
    'renderIconAsImage' => false,
    'slideOver' => false,
    'appMeta' => [],
    'categories' => [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $normalize = fn (string $value): string => strtolower(preg_replace('/[^a-z0-9]/i', '', $value));


    $defaultAppMeta = [
        'admin' => ['title' => 'ADMIN', 'description' => 'System Administration', 'icon' => 'heroicon-o-shield-check', 'tone' => 'blue', 'categories' => ['Tools', 'Admin'], 'badge' => 'PRO', 'keywords' => 'admin control settings users system'],
        'pro' => ['title' => 'TITAN PRO', 'description' => 'Full Admin System Control', 'icon' => 'heroicon-o-trophy', 'fallbackIcon' => 'heroicon-o-trophy', 'tone' => 'violet', 'categories' => ['Tools', 'Admin'], 'badge' => 'PRO', 'keywords' => 'full admin system control owner'],
        'titanpro' => ['title' => 'TITAN PRO', 'description' => 'Full Admin System Control', 'icon' => 'heroicon-o-trophy', 'fallbackIcon' => 'heroicon-o-trophy', 'tone' => 'violet', 'categories' => ['Tools', 'Admin'], 'badge' => 'PRO', 'keywords' => 'full admin system control owner'],
        'groundzero' => ['title' => 'GROUND ZERO', 'description' => 'AI Business Chatbot OS', 'icon' => 'heroicon-o-chat-bubble-left-right', 'tone' => 'emerald', 'categories' => ['AI & Automation', 'Operations'], 'badge' => 'NEW', 'keywords' => 'business chatbot operating system overview ai'],
        'titanquotes' => ['title' => 'QUOTE ASSISTANT', 'description' => 'AI Quotes, Estimates & Proposals', 'icon' => 'heroicon-o-chat-bubble-bottom-center-text', 'tone' => 'orange', 'categories' => ['AI & Automation', 'Finance', 'Operations'], 'badge' => 'AI', 'keywords' => 'quote assistant quotes estimating proposals sales ai'],
        'quoteassistant' => ['title' => 'QUOTE ASSISTANT', 'description' => 'AI Quotes, Estimates & Proposals', 'icon' => 'heroicon-o-chat-bubble-bottom-center-text', 'tone' => 'orange', 'categories' => ['AI & Automation', 'Finance', 'Operations'], 'badge' => 'UPGRADE', 'keywords' => 'quote assistant quotes estimating proposals sales ai'],
        'zeropay' => ['title' => 'ZERO PAY', 'description' => 'Payments & Invoicing', 'icon' => 'heroicon-o-credit-card', 'tone' => 'amber', 'categories' => ['Finance', 'Operations'], 'badge' => 'PRO', 'keywords' => 'payments invoicing invoices transactions'],
        'titango' => ['title' => 'TITAN GO', 'description' => 'Field Jobs & Operations', 'icon' => 'heroicon-o-paper-airplane', 'tone' => 'pink', 'categories' => ['Operations', 'Team'], 'badge' => 'NEW', 'keywords' => 'field mobile jobs operations tradies'],
        'titanstudio' => ['title' => 'TITAN STUDIO', 'description' => 'Marketing Ads & Campaigns', 'icon' => 'heroicon-o-megaphone', 'tone' => 'red', 'categories' => ['Marketing'], 'keywords' => 'marketing adverts ads campaigns creative'],
        'titannexus' => ['title' => 'TITAN NEXUS', 'description' => 'Vertical Expansion & Lead Finder', 'icon' => 'heroicon-o-arrow-trending-up', 'tone' => 'cyan', 'categories' => ['Marketing', 'Operations'], 'keywords' => 'vertical expansion leads lead finder marketing'],
        'titanzero' => ['title' => 'TITAN ZERO', 'description' => 'AI Automation, Settings & Agents', 'icon' => 'heroicon-o-cpu-chip', 'tone' => 'teal', 'categories' => ['AI & Automation', 'Admin'], 'keywords' => 'ai automation settings agents workflows'],
        'titanecho' => ['title' => 'TITAN ECHO', 'description' => 'Front Desk Calls, Texts & Communications', 'icon' => 'heroicon-o-phone-arrow-down-left', 'tone' => 'purple', 'categories' => ['Communication', 'Customer', 'Operations'], 'badge' => 'BETA', 'keywords' => 'front desk missed calls texts sms communications reception'],
        'titanlocker' => ['title' => 'TITAN LOCKER', 'description' => 'Business Documents & Digital Vault', 'icon' => 'heroicon-o-lock-closed', 'tone' => 'lime', 'categories' => ['Assets', 'Admin', 'Tools'], 'keywords' => 'documents vault records assets inventory suppliers stock equipment locker'],
        'titanmoney' => ['title' => 'TITAN MONEY', 'description' => 'Finance & Accounting', 'icon' => 'heroicon-o-banknotes', 'tone' => 'sky', 'categories' => ['Finance', 'Operations'], 'keywords' => 'finance accounting cash money reports'],
        'titanpixel' => ['title' => 'TITAN PIXEL', 'description' => 'Design & Branding Studio', 'icon' => 'heroicon-o-paint-brush', 'tone' => 'indigo', 'categories' => ['Marketing'], 'keywords' => 'design branding studio graphics creative pixel'],
        'titansocial' => ['title' => 'TITAN SOCIAL', 'description' => 'Social Media Management', 'icon' => 'heroicon-o-share', 'tone' => 'rose', 'categories' => ['Marketing', 'Communication'], 'keywords' => 'social media posts channels marketing'],
        'titanteam' => ['title' => 'TITAN TEAM', 'description' => 'Team Management & HR', 'icon' => 'heroicon-o-user-group', 'tone' => 'slate', 'categories' => ['Team', 'Operations'], 'keywords' => 'team hr staff people management'],
        'zeroissues' => ['title' => 'ZERO ISSUES', 'description' => 'Issue Tracking & Tickets', 'icon' => 'heroicon-o-exclamation-triangle', 'tone' => 'orangeDark', 'categories' => ['Operations', 'Team', 'Compliance'], 'keywords' => 'issues tickets safety defects problems'],
        'zerofuss' => ['title' => 'ZERO FUSS', 'description' => 'Customer Chatbot Portal', 'icon' => 'heroicon-o-chat-bubble-oval-left-ellipsis', 'tone' => 'cyanDark', 'categories' => ['Communication', 'AI & Automation', 'Customer'], 'keywords' => 'customer chatbot portal support client'],
        'titansolo' => ['title' => 'TITAN SOLO', 'description' => 'Solo Operator Business Management', 'icon' => 'heroicon-o-briefcase', 'tone' => 'gold', 'categories' => ['Operations', 'Finance', 'Team'], 'badge' => 'PRO', 'keywords' => 'solo operator business management owner'],
        'titanbookings' => ['title' => 'TITAN BOOKINGS', 'description' => 'Bookings, Calendar & Scheduling', 'icon' => 'heroicon-o-calendar-days', 'tone' => 'blueSteel', 'categories' => ['Operations', 'Team'], 'badge' => 'UPGRADE', 'keywords' => 'bookings calendar scheduling appointments dispatch jobs'],
        'bookingsassistant' => ['title' => 'BOOKINGS ASSISTANT', 'description' => 'AI Scheduling & Dispatch Support', 'icon' => 'heroicon-o-calendar-date-range', 'tone' => 'neonBlue', 'categories' => ['AI & Automation', 'Operations', 'Team'], 'badge' => 'UPGRADE', 'keywords' => 'bookings assistant scheduling dispatch ai calendar'],
        'siteinspectorassistant' => ['title' => 'SITE INSPECTOR ASSISTANT', 'description' => 'Camera-Based Job Completion Checks', 'icon' => 'heroicon-o-camera', 'tone' => 'steel', 'categories' => ['AI & Automation', 'Operations', 'Compliance'], 'badge' => 'UPGRADE', 'keywords' => 'site inspector camera analyse jobs completed photos quality ai'],
        'trainingassistant' => ['title' => 'ON THE JOB TRAINING ASSISTANT', 'description' => 'Guided Training While Staff Work', 'icon' => 'heroicon-o-academic-cap', 'tone' => 'greenMint', 'categories' => ['AI & Automation', 'Team', 'Operations'], 'badge' => 'UPGRADE', 'keywords' => 'on the job training assistant staff guidance ai'],
        'chemicalsassistant' => ['title' => 'CHEMICALS ASSISTANT', 'description' => 'Chemical Use, Safety & Guidance', 'icon' => 'heroicon-o-beaker', 'tone' => 'forest', 'categories' => ['AI & Automation', 'Compliance', 'Operations'], 'badge' => 'UPGRADE', 'keywords' => 'chemicals assistant safety usage cleaning chemicals ai'],
        'titanpayroll' => ['title' => 'TITAN PAYROLL', 'description' => 'Payroll, Timesheets & Wages', 'icon' => 'heroicon-o-receipt-percent', 'tone' => 'greenMint', 'categories' => ['Finance', 'Team'], 'badge' => 'UPGRADE', 'keywords' => 'payroll timesheets wages staff pay salary team staff hr'],
        'budgeting' => ['title' => 'BUDGETING', 'description' => 'Budgets, Forecasts & Cost Control', 'icon' => 'heroicon-o-chart-pie', 'tone' => 'gold', 'categories' => ['Finance', 'Operations'], 'badge' => 'UPGRADE', 'keywords' => 'budgeting budgets forecasts cost control finance'],
        'titanassets' => ['title' => 'TITAN ASSETS & EQUIPMENT', 'description' => 'Assets, Equipment & Service Logs', 'icon' => 'heroicon-o-cube-transparent', 'tone' => 'bronze', 'categories' => ['Assets', 'Operations'], 'badge' => 'UPGRADE', 'keywords' => 'assets equipment tools maintenance service logs machinery'],
        'titanfleet' => ['title' => 'TITAN FLEET', 'description' => 'Vehicles, Rego, Fuel & Inspections', 'icon' => 'heroicon-o-truck', 'tone' => 'steel', 'categories' => ['Assets', 'Operations', 'Compliance'], 'badge' => 'UPGRADE', 'keywords' => 'fleet vehicles trucks rego fuel inspections service assets'],
        'titaninventory' => ['title' => 'TITAN SUPPLIERS & INVENTORY', 'description' => 'Suppliers, Stock & Purchasing', 'icon' => 'heroicon-o-archive-box', 'tone' => 'forest', 'categories' => ['Operations', 'Finance', 'Assets'], 'badge' => 'UPGRADE', 'keywords' => 'inventory suppliers stock parts materials purchase orders vendors procurement'],
        'training' => ['title' => 'TRAINING', 'description' => 'Staff Learning, SOPs & Skills', 'icon' => 'heroicon-o-book-open', 'tone' => 'indigo', 'categories' => ['Team', 'Operations', 'Compliance'], 'badge' => 'UPGRADE', 'keywords' => 'training staff learning sop skills induction'],
        'qualityaudits' => ['title' => 'QUALITY AUDITS', 'description' => 'Audits, Checks & Quality Standards', 'icon' => 'heroicon-o-clipboard-document-check', 'tone' => 'cyan', 'categories' => ['Compliance', 'Operations', 'Customer'], 'badge' => 'UPGRADE', 'keywords' => 'quality audits checks inspections standards compliance'],
        'docscontracts' => ['title' => 'DOCS & CONTRACTS', 'description' => 'Documents, Contracts & Agreements', 'icon' => 'heroicon-o-document-text', 'tone' => 'graphite', 'categories' => ['Admin', 'Finance', 'Operations'], 'badge' => 'UPGRADE', 'keywords' => 'documents docs contracts agreements files admin'],
        'facilitymanagement' => ['title' => 'FACILITY MANAGEMENT', 'description' => 'Sites, Facilities & Service Delivery', 'icon' => 'heroicon-o-building-office-2', 'tone' => 'blueSteel', 'categories' => ['Operations', 'Assets', 'Team'], 'badge' => 'UPGRADE', 'keywords' => 'facility management sites buildings facilities service delivery'],
        'compliancesafety' => ['title' => 'COMPLIANCE & SAFETY', 'description' => 'Safety, Compliance & Risk Controls', 'icon' => 'heroicon-o-shield-exclamation', 'tone' => 'red', 'categories' => ['Compliance', 'Team', 'Operations'], 'badge' => 'UPGRADE', 'keywords' => 'compliance safety risk incidents checks whs'],
        'feedbackcomplaints' => ['title' => 'FEEDBACK & COMPLAINTS', 'description' => 'Customer Feedback, Complaints & Incidents', 'icon' => 'heroicon-o-face-smile', 'tone' => 'rose', 'categories' => ['Customer', 'Compliance', 'Operations'], 'badge' => 'UPGRADE', 'keywords' => 'feedback complaints incidents customer satisfaction issues'],
        'titanwebsites' => ['title' => 'TITAN WEBSITES', 'description' => 'Marketing & Landing Pages', 'icon' => 'heroicon-o-globe-alt', 'tone' => 'neonBlue', 'categories' => ['Marketing'], 'badge' => 'UPGRADE', 'keywords' => 'websites landing pages web funnels pages seo marketing'],
        'seo' => ['title' => 'SEO', 'description' => 'Search Rankings, Metadata & Visibility', 'icon' => 'heroicon-o-magnifying-glass-circle', 'tone' => 'lime', 'categories' => ['Marketing'], 'badge' => 'UPGRADE', 'keywords' => 'seo rankings metadata local seo analytics search visibility'],
        'customermarketing' => ['title' => 'CUSTOMER MARKETING', 'description' => 'Newsletters, Offers & Retention Campaigns', 'icon' => 'heroicon-o-envelope-open', 'tone' => 'pink', 'categories' => ['Marketing', 'Customer', 'Communication'], 'badge' => 'UPGRADE', 'keywords' => 'customer marketing newsletters offers campaigns retention promotions'],
        'integrations' => ['title' => 'INTEGRATIONS', 'description' => 'APIs, Automations & Webhooks', 'icon' => 'heroicon-o-puzzle-piece', 'tone' => 'purple', 'categories' => ['Operations', 'AI & Automation', 'Admin', 'Tools'], 'badge' => 'UPGRADE', 'keywords' => 'integrations api automations webhooks external platforms'],
        'revenueforecast' => ['title' => 'REVENUE FORECAST', 'description' => 'Monthly & Quarterly Income Forecasts', 'icon' => 'heroicon-o-presentation-chart-line', 'tone' => 'electricBlue', 'categories' => ['AI & Automation', 'Finance', 'Analytics'], 'badge' => 'AI', 'keywords' => 'revenue forecast income bookings crew capacity seasonality zeropay settlement forecasting predictive analytical ai'],
        'jobprofitabilityanalyzer' => ['title' => 'JOB PROFITABILITY ANALYZER', 'description' => 'Post-Job Profit, Labor & Overhead Insights', 'icon' => 'heroicon-o-calculator', 'tone' => 'profitGreen', 'categories' => ['AI & Automation', 'Finance', 'Analytics', 'Operations'], 'badge' => 'AI', 'keywords' => 'job profitability analyzer material cost labor overhead pricing strategy margins clients'],
        'crewoptimizer' => ['title' => 'CREW OPTIMIZER', 'description' => 'Optimal Crew Size & Skill Mix Suggestions', 'icon' => 'heroicon-o-users', 'tone' => 'teamBlue', 'categories' => ['AI & Automation', 'Team', 'Operations', 'Analytics'], 'badge' => 'AI', 'keywords' => 'crew optimizer crew size skill mix job type staffing overstaffing understaffing'],
        'routedispatchai' => ['title' => 'ROUTE & DISPATCH AI', 'description' => 'Smart Job Clustering, Routing & Sequencing', 'icon' => 'heroicon-o-map', 'tone' => 'routeCyan', 'categories' => ['AI & Automation', 'Dispatch', 'Operations', 'Assets'], 'badge' => 'AI', 'keywords' => 'route dispatch ai geographic clustering optimal sequence travel time fuel jobs field'],
        'complianceassistant' => ['title' => 'COMPLIANCE ASSISTANT', 'description' => 'Regulation, Insurance & Licensing Checks', 'icon' => 'heroicon-o-scale', 'tone' => 'complianceIndigo', 'categories' => ['AI & Automation', 'Compliance', 'Safety', 'Operations'], 'badge' => 'AI', 'keywords' => 'compliance assistant regulations insurance requirements licensing trades local laws'],
        'safetyauditbot' => ['title' => 'SAFETY AUDIT BOT', 'description' => 'Photo-Based Safety Checklists & Hazard Detection', 'icon' => 'heroicon-o-shield-exclamation', 'tone' => 'hazardRed', 'categories' => ['AI & Automation', 'Safety', 'Compliance', 'Operations'], 'badge' => 'AI', 'keywords' => 'safety audit bot job site checklist photo hazard detection risks inspections'],
        'leadscorer' => ['title' => 'LEAD SCORER', 'description' => 'Ranks Leads by Fit, Value & Conversion Chance', 'icon' => 'heroicon-o-funnel', 'tone' => 'growthPink', 'categories' => ['AI & Automation', 'Marketing', 'Customer', 'Analytics'], 'badge' => 'AI', 'keywords' => 'lead scorer inbound leads convert project size fit nexus sales'],
        'churnearlywarning' => ['title' => 'CHURN EARLY WARNING', 'description' => 'Detects At-Risk Customers Before They Leave', 'icon' => 'heroicon-o-bell-alert', 'tone' => 'warningAmber', 'categories' => ['AI & Automation', 'Customer', 'Marketing', 'Analytics'], 'badge' => 'AI', 'keywords' => 'churn early warning at risk customers declining frequency negative feedback outreach retention'],
        'knowledgebasebuilder' => ['title' => 'KNOWLEDGE BASE BUILDER', 'description' => 'Turns Job Notes, Photos & Voice Into SOPs', 'icon' => 'heroicon-o-book-open', 'tone' => 'knowledgeSlate', 'categories' => ['AI & Automation', 'Learning', 'Team', 'Admin'], 'badge' => 'AI', 'keywords' => 'knowledge base builder sop documents photo voice notes jobs training material'],
        'skillgapanalyzer' => ['title' => 'SKILL GAP ANALYZER', 'description' => 'Recommends Training From Crew Performance Data', 'icon' => 'heroicon-o-chart-bar', 'tone' => 'skillViolet', 'categories' => ['AI & Automation', 'Learning', 'Team', 'Analytics'], 'badge' => 'AI', 'keywords' => 'skill gap analyzer training crew performance data job requirements skills'],
        'cashflowforecaster' => ['title' => 'CASH FLOW FORECASTER', 'description' => '30/60/90-Day Cash Position Projections', 'icon' => 'heroicon-o-arrow-trending-up', 'tone' => 'cashGreen', 'categories' => ['AI & Automation', 'Finance', 'Analytics'], 'badge' => 'AI', 'keywords' => 'cash flow forecaster 30 60 90 day cash position payment lag service operations'],
        'laborcosttracker' => ['title' => 'LABOR COST TRACKER', 'description' => 'Real-Time Labor Cost vs Revenue Alerts', 'icon' => 'heroicon-o-clock', 'tone' => 'laborOrange', 'categories' => ['AI & Automation', 'Finance', 'Team', 'Analytics', 'Operations'], 'badge' => 'AI', 'keywords' => 'labor cost tracker real time labor cost percent revenue job crew threshold alerts'],
    ];

    $appMeta = array_replace_recursive($defaultAppMeta, $appMeta ?? []);

    $toneClasses = [
        'blue' => 'titan-tone-blue',
        'violet' => 'titan-tone-violet',
        'emerald' => 'titan-tone-emerald',
        'orange' => 'titan-tone-orange',
        'amber' => 'titan-tone-amber',
        'pink' => 'titan-tone-pink',
        'red' => 'titan-tone-red',
        'cyan' => 'titan-tone-cyan',
        'teal' => 'titan-tone-teal',
        'purple' => 'titan-tone-purple',
        'lime' => 'titan-tone-lime',
        'sky' => 'titan-tone-sky',
        'indigo' => 'titan-tone-indigo',
        'rose' => 'titan-tone-rose',
        'slate' => 'titan-tone-slate',
        'orangeDark' => 'titan-tone-orange-dark',
        'cyanDark' => 'titan-tone-cyan-dark',
        'gold' => 'titan-tone-gold',
        'graphite' => 'titan-tone-graphite',
        'blueSteel' => 'titan-tone-blue-steel',
        'greenMint' => 'titan-tone-green-mint',
        'bronze' => 'titan-tone-bronze',
        'forest' => 'titan-tone-forest',
        'steel' => 'titan-tone-steel',
        'neonBlue' => 'titan-tone-neon-blue',
        'electricBlue' => 'titan-tone-electric-blue',
        'profitGreen' => 'titan-tone-profit-green',
        'teamBlue' => 'titan-tone-team-blue',
        'routeCyan' => 'titan-tone-route-cyan',
        'complianceIndigo' => 'titan-tone-compliance-indigo',
        'hazardRed' => 'titan-tone-hazard-red',
        'growthPink' => 'titan-tone-growth-pink',
        'warningAmber' => 'titan-tone-warning-amber',
        'knowledgeSlate' => 'titan-tone-knowledge-slate',
        'skillViolet' => 'titan-tone-skill-violet',
        'cashGreen' => 'titan-tone-cash-green',
        'laborOrange' => 'titan-tone-labor-orange',
    ];

    $categories = filled($categories ?? [])
        ? $categories
        : ['All Apps', 'Operations', 'AI & Automation', 'Finance', 'Marketing', 'Communication', 'Customer', 'Team', 'Assets', 'Compliance', 'Admin', 'Tools', 'Analytics', 'Dispatch', 'Learning', 'Safety'];

    $categoryIcons = [
        'All Apps' => 'heroicon-o-squares-2x2',
        'Operations' => 'heroicon-o-briefcase',
        'AI & Automation' => 'heroicon-o-sparkles',
        'Finance' => 'heroicon-o-currency-dollar',
        'Marketing' => 'heroicon-o-megaphone',
        'Communication' => 'heroicon-o-chat-bubble-left-right',
        'Customer' => 'heroicon-o-heart',
        'Team' => 'heroicon-o-user-group',
        'Assets' => 'heroicon-o-cube-transparent',
        'Compliance' => 'heroicon-o-shield-check',
        'Admin' => 'heroicon-o-cog-6-tooth',
        'Tools' => 'heroicon-o-wrench-screwdriver',
        'Analytics' => 'heroicon-o-chart-bar-square',
        'Dispatch' => 'heroicon-o-map',
        'Learning' => 'heroicon-o-academic-cap',
        'Safety' => 'heroicon-o-shield-exclamation',
    ];
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($slideOver): ?>
    <ul class="space-y-2">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $panels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $isCurrentPanel = $id === $currentPanel->getId();
                $panelLabel = $labels[$id] ?? str($id)->headline()->toString();
                $key = $normalize($panelLabel);
                $idKey = $normalize($id);
                $meta = $appMeta[$idKey] ?? $appMeta[$key] ?? null;
                $title = $meta['title'] ?? str($panelLabel)->headline()->upper()->toString();
                $description = $meta['description'] ?? 'Open app workspace';
                $panelIcon = $icons[$id] ?? ($meta['icon'] ?? 'heroicon-o-squares-2x2');
                $panelDarkIcon = $darkIcons[$id] ?? null;
                $isUpgrade = blank($url);
            ?>

            <li>
                <a
                    <?php if(! $isUpgrade): ?> href="<?php echo e($url); ?>" <?php endif; ?>
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'flex items-center gap-x-3 rounded-xl border border-white/10 bg-white/5 p-3 transition',
                        'opacity-75' => $isUpgrade,
                        'ring-1 ring-primary-400' => $isCurrentPanel,
                    ]); ?>"
                >
                    <?php if (isset($component)) { $__componentOriginaled19177085e146347d917c72f0bf076f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled19177085e146347d917c72f0bf076f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panel-switch::components.panel-icon','data' => ['icon' => $panelIcon,'darkIcon' => $panelDarkIcon,'renderAsImage' => $renderIconAsImage,'class' => 'h-6 w-6 shrink-0 text-white','alt' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panel-switch::panel-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($panelIcon),'dark-icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($panelDarkIcon),'render-as-image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($renderIconAsImage),'class' => 'h-6 w-6 shrink-0 text-white','alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled19177085e146347d917c72f0bf076f)): ?>
<?php $attributes = $__attributesOriginaled19177085e146347d917c72f0bf076f; ?>
<?php unset($__attributesOriginaled19177085e146347d917c72f0bf076f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled19177085e146347d917c72f0bf076f)): ?>
<?php $component = $__componentOriginaled19177085e146347d917c72f0bf076f; ?>
<?php unset($__componentOriginaled19177085e146347d917c72f0bf076f); ?>
<?php endif; ?>
                    <span class="min-w-0 flex-1">
                        <span class="block truncate text-sm font-bold text-white"><?php echo e($title); ?></span>
                        <span class="block truncate text-xs text-white/65"><?php echo e($description); ?></span>
                    </span>
                    <span class="text-xs font-bold text-white/70"><?php echo e($isUpgrade ? 'UPGRADE' : 'OPEN'); ?></span>
                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </ul>
<?php else: ?>
    <section class="titan-launcher" x-data="{ q: '', category: 'All Apps' }" x-init="$nextTick(() => { const input = $el.querySelector('[data-titan-search]'); window.addEventListener('keydown', (event) => { if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); input?.focus(); } }); })">
        <div class="titan-launcher-brand" aria-hidden="true">
            <div class="titan-launcher-logo">T</div>
            <div><strong>TITAN</strong><span>ECOSYSTEM</span></div>
        </div>

        <div class="titan-launcher-search-wrap">
            <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => 'heroicon-o-magnifying-glass','class' => 'titan-launcher-search-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'heroicon-o-magnifying-glass','class' => 'titan-launcher-search-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
            <input data-titan-search x-model.debounce.100ms="q" type="search" placeholder="Search apps..." class="titan-launcher-search" />
            <span class="titan-launcher-shortcut">⌘ K</span>
        </div>

        <div class="titan-launcher-tabs" aria-label="App categories">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button
                    type="button"
                    x-on:click="category = <?php echo \Illuminate\Support\Js::from($category)->toHtml() ?>"
                    x-bind:class="category === <?php echo \Illuminate\Support\Js::from($category)->toHtml() ?> ? 'is-active' : ''"
                    class="titan-launcher-tab"
                >
                    <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => $categoryIcons[$category] ?? 'heroicon-o-square-3-stack-3d','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categoryIcons[$category] ?? 'heroicon-o-square-3-stack-3d'),'class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
                    <span><?php echo e($category); ?></span>
                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="titan-launcher-scroll">
            <div class="titan-launcher-grid">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $panels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $isCurrentPanel = $id === $currentPanel->getId();
                        $panelLabel = $labels[$id] ?? str($id)->headline()->toString();
                        $key = $normalize($panelLabel);
                        $idKey = $normalize($id);
                        $meta = $appMeta[$idKey] ?? $appMeta[$key] ?? null;
                        $title = $meta['title'] ?? str($panelLabel)->headline()->upper()->toString();
                        $description = $meta['description'] ?? 'Open app workspace';
                        $appCategories = (array) ($meta['categories'] ?? ($meta['category'] ?? 'Tools'));
                        $category = $appCategories[0] ?? 'Tools';
                        $panelIcon = $icons[$id] ?? ($meta['icon'] ?? 'heroicon-o-squares-2x2');
                        $panelDarkIcon = $darkIcons[$id] ?? null;
                        $tone = $toneClasses[$meta['tone'] ?? 'blue'] ?? 'titan-tone-blue';
                        $badge = $meta['badge'] ?? null;
                        $categoryText = implode(' ', $appCategories);
                        $keywords = strtolower($title . ' ' . $description . ' ' . $categoryText . ' ' . ($meta['keywords'] ?? '') . ' ' . $id);
                        $isUpgrade = blank($url);
                    ?>

                    <a
                        <?php if(! $isUpgrade): ?> href="<?php echo e($url); ?>" <?php endif; ?>
                        x-show="(category === 'All Apps' || <?php echo \Illuminate\Support\Js::from($appCategories)->toHtml() ?>.includes(category)) && (<?php echo \Illuminate\Support\Js::from($keywords)->toHtml() ?>.includes(q.toLowerCase()))"
                        x-transition.opacity.scale.95
                        data-titan-app-card
                        data-title="<?php echo e($title); ?>"
                        data-category="<?php echo e($categoryText); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'titan-app-card group',
                            $tone,
                            'is-current' => $isCurrentPanel,
                            'is-upgrade' => $isUpgrade,
                        ]); ?>"
                    >
                        <div class="titan-app-card-bg"></div>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($badge || $isUpgrade): ?>
                            <span class="titan-app-badge"><?php echo e($isUpgrade ? 'UPGRADE' : $badge); ?></span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <div class="titan-app-icon-wrap">
                            <?php if (isset($component)) { $__componentOriginaled19177085e146347d917c72f0bf076f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled19177085e146347d917c72f0bf076f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panel-switch::components.panel-icon','data' => ['icon' => $panelIcon,'darkIcon' => $panelDarkIcon,'renderAsImage' => $renderIconAsImage,'class' => 'titan-app-icon','alt' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panel-switch::panel-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($panelIcon),'dark-icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($panelDarkIcon),'render-as-image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($renderIconAsImage),'class' => 'titan-app-icon','alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled19177085e146347d917c72f0bf076f)): ?>
<?php $attributes = $__attributesOriginaled19177085e146347d917c72f0bf076f; ?>
<?php unset($__attributesOriginaled19177085e146347d917c72f0bf076f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled19177085e146347d917c72f0bf076f)): ?>
<?php $component = $__componentOriginaled19177085e146347d917c72f0bf076f; ?>
<?php unset($__componentOriginaled19177085e146347d917c72f0bf076f); ?>
<?php endif; ?>
                        </div>

                        <h3 class="titan-app-title"><?php echo e($title); ?></h3>
                        <p class="titan-app-description"><?php echo e($description); ?></p>

                        <span class="titan-app-action">
                            <?php echo e($isUpgrade ? 'Upgrade' : 'Open'); ?>

                            <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => $isUpgrade ? 'heroicon-m-arrow-up-right' : 'heroicon-m-arrow-right','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isUpgrade ? 'heroicon-m-arrow-up-right' : 'heroicon-m-arrow-right'),'class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <div class="titan-launcher-footer">
            <div><strong>TITAN ECOSYSTEM</strong><span>All your tools. One powerful platform.</span></div>
            <div><strong>MORE APPS COMING SOON</strong><span>Built for scale, speed, and control.</span></div>
            <div><strong>UNLOCK ALL APPS</strong><span>Upgrade your plan to access everything.</span></div>
        </div>
    </section>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /home/saassmar/domains/tradiesm.art/public_html/vendor/bezhansalleh/filament-panel-switch/resources/views/components/panel-list.blade.php ENDPATH**/ ?>