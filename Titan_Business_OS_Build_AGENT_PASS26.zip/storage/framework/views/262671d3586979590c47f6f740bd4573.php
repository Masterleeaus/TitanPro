<?php
    $hasTopbar = $currentPanel->hasTopbar();
    $isSidebarCollapsibleOnDesktop = filament()->isSidebarCollapsibleOnDesktop();
    $currentLabel = $labels[$currentPanel->getId()] ?? str($currentPanel->getId())->ucfirst();
    $currentIcon = $icons[$currentPanel->getId()] ?? 'heroicon-o-square-2-stack';
    $currentDarkIcon = $darkIcons[$currentPanel->getId()] ?? $currentIcon;
    $defaultIcon = 'heroicon-o-square-2-stack';
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isSimple): ?>
    
    <?php if (isset($component)) { $__componentOriginal22ab0dbc2c6619d5954111bba06f01db = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal22ab0dbc2c6619d5954111bba06f01db = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.dropdown.index','data' => ['teleport' => true,'placement' => $hasTopbar ? 'bottom-end' : 'top-start']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['teleport' => true,'placement' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($hasTopbar ? 'bottom-end' : 'top-start')]); ?>
         <?php $__env->slot('trigger', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal4ad65391a22d7afc3b26be387c4fa851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ad65391a22d7afc3b26be387c4fa851 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panel-switch::components.panel-trigger','data' => ['icon' => $currentIcon,'darkIcon' => $currentDarkIcon,'renderAsImage' => $renderIconAsImage,'label' => $currentLabel,'topbar' => $hasTopbar,'collapsibleSidebar' => $isSidebarCollapsibleOnDesktop,'showChevron' => ! $hasTopbar]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panel-switch::panel-trigger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentIcon),'dark-icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentDarkIcon),'render-as-image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($renderIconAsImage),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentLabel),'topbar' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($hasTopbar),'collapsible-sidebar' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSidebarCollapsibleOnDesktop),'show-chevron' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(! $hasTopbar)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ad65391a22d7afc3b26be387c4fa851)): ?>
<?php $attributes = $__attributesOriginal4ad65391a22d7afc3b26be387c4fa851; ?>
<?php unset($__attributesOriginal4ad65391a22d7afc3b26be387c4fa851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ad65391a22d7afc3b26be387c4fa851)): ?>
<?php $component = $__componentOriginal4ad65391a22d7afc3b26be387c4fa851; ?>
<?php unset($__componentOriginal4ad65391a22d7afc3b26be387c4fa851); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>

        
        <?php if (isset($component)) { $__componentOriginal66687bf0670b9e16f61e667468dc8983 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66687bf0670b9e16f61e667468dc8983 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.dropdown.list.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::dropdown.list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $panels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isCurrentPanel = $id === $currentPanel->getId();
                    $panelLabel = $labels[$id] ?? str($id)->ucfirst();
                    $panelIcon = $icons[$id] ?? $defaultIcon;
                    $panelDarkIcon = $darkIcons[$id] ?? null;
                ?>

                <span x-data="{ get isDark() { return $store.theme === 'dark' || ($store.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches) } }" class="contents">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isCurrentPanel): ?>
                        <?php if (isset($component)) { $__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.dropdown.list.item','data' => ['icon' => $panelIcon,'iconColor' => 'primary','color' => 'primary','tag' => 'div','class' => 'pointer-events-none','xShow' => '!isDark']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::dropdown.list.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($panelIcon),'icon-color' => 'primary','color' => 'primary','tag' => 'div','class' => 'pointer-events-none','x-show' => '!isDark']); ?>
                            <span class="flex items-center justify-between gap-x-2 w-full">
                                <span class="text-primary-600 dark:text-primary-400"><?php echo e($panelLabel); ?></span>
                                <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => 'heroicon-m-check','class' => 'h-4 w-4 text-primary-600 dark:text-primary-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'heroicon-m-check','class' => 'h-4 w-4 text-primary-600 dark:text-primary-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
                            </span>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78)): ?>
<?php $attributes = $__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78; ?>
<?php unset($__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78)): ?>
<?php $component = $__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78; ?>
<?php unset($__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.dropdown.list.item','data' => ['icon' => $panelDarkIcon ?? $panelIcon,'iconColor' => 'primary','color' => 'primary','tag' => 'div','class' => 'pointer-events-none','xShow' => 'isDark','xCloak' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::dropdown.list.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($panelDarkIcon ?? $panelIcon),'icon-color' => 'primary','color' => 'primary','tag' => 'div','class' => 'pointer-events-none','x-show' => 'isDark','x-cloak' => true]); ?>
                            <span class="flex items-center justify-between gap-x-2 w-full">
                                <span class="text-primary-600 dark:text-primary-400"><?php echo e($panelLabel); ?></span>
                                <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => 'heroicon-m-check','class' => 'h-4 w-4 text-primary-600 dark:text-primary-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'heroicon-m-check','class' => 'h-4 w-4 text-primary-600 dark:text-primary-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
                            </span>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78)): ?>
<?php $attributes = $__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78; ?>
<?php unset($__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78)): ?>
<?php $component = $__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78; ?>
<?php unset($__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78); ?>
<?php endif; ?>
                    <?php else: ?>
                        <?php if (isset($component)) { $__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.dropdown.list.item','data' => ['href' => $url,'icon' => $panelIcon,'tag' => 'a','xShow' => '!isDark']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::dropdown.list.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($url),'icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($panelIcon),'tag' => 'a','x-show' => '!isDark']); ?>
                            <?php echo e($panelLabel); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78)): ?>
<?php $attributes = $__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78; ?>
<?php unset($__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78)): ?>
<?php $component = $__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78; ?>
<?php unset($__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.dropdown.list.item','data' => ['href' => $url,'icon' => $panelDarkIcon ?? $panelIcon,'tag' => 'a','xShow' => 'isDark','xCloak' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::dropdown.list.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($url),'icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($panelDarkIcon ?? $panelIcon),'tag' => 'a','x-show' => 'isDark','x-cloak' => true]); ?>
                            <?php echo e($panelLabel); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78)): ?>
<?php $attributes = $__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78; ?>
<?php unset($__attributesOriginal1bd4d8e254cc40cdb05bd99df3e63f78); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78)): ?>
<?php $component = $__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78; ?>
<?php unset($__componentOriginal1bd4d8e254cc40cdb05bd99df3e63f78); ?>
<?php endif; ?>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66687bf0670b9e16f61e667468dc8983)): ?>
<?php $attributes = $__attributesOriginal66687bf0670b9e16f61e667468dc8983; ?>
<?php unset($__attributesOriginal66687bf0670b9e16f61e667468dc8983); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66687bf0670b9e16f61e667468dc8983)): ?>
<?php $component = $__componentOriginal66687bf0670b9e16f61e667468dc8983; ?>
<?php unset($__componentOriginal66687bf0670b9e16f61e667468dc8983); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal22ab0dbc2c6619d5954111bba06f01db)): ?>
<?php $attributes = $__attributesOriginal22ab0dbc2c6619d5954111bba06f01db; ?>
<?php unset($__attributesOriginal22ab0dbc2c6619d5954111bba06f01db); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal22ab0dbc2c6619d5954111bba06f01db)): ?>
<?php $component = $__componentOriginal22ab0dbc2c6619d5954111bba06f01db; ?>
<?php unset($__componentOriginal22ab0dbc2c6619d5954111bba06f01db); ?>
<?php endif; ?>

<?php else: ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasTopbar): ?>
        <div>
            <?php if (isset($component)) { $__componentOriginal4ad65391a22d7afc3b26be387c4fa851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ad65391a22d7afc3b26be387c4fa851 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panel-switch::components.panel-trigger','data' => ['icon' => $currentIcon,'darkIcon' => $currentDarkIcon,'renderAsImage' => $renderIconAsImage,'label' => $heading,'topbar' => true,'modalId' => 'panel-switch']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panel-switch::panel-trigger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentIcon),'dark-icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentDarkIcon),'render-as-image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($renderIconAsImage),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($heading),'topbar' => true,'modal-id' => 'panel-switch']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ad65391a22d7afc3b26be387c4fa851)): ?>
<?php $attributes = $__attributesOriginal4ad65391a22d7afc3b26be387c4fa851; ?>
<?php unset($__attributesOriginal4ad65391a22d7afc3b26be387c4fa851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ad65391a22d7afc3b26be387c4fa851)): ?>
<?php $component = $__componentOriginal4ad65391a22d7afc3b26be387c4fa851; ?>
<?php unset($__componentOriginal4ad65391a22d7afc3b26be387c4fa851); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal0942a211c37469064369f887ae8d1cef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0942a211c37469064369f887ae8d1cef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.modal.index','data' => ['id' => 'panel-switch','width' => $isSlideOver ? 'md' : $modalWidth,'alignment' => $isSlideOver ? null : 'center','slideOver' => $isSlideOver,'stickyHeader' => $isSlideOver,'displayClasses' => 'block','class' => $isSlideOver ? '' : 'panel-switch-modal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'panel-switch','width' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSlideOver ? 'md' : $modalWidth),'alignment' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSlideOver ? null : 'center'),'slide-over' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSlideOver),'sticky-header' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSlideOver),'display-classes' => 'block','class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSlideOver ? '' : 'panel-switch-modal')]); ?>
                 <?php $__env->slot('heading', null, []); ?> 
                    APP LAUNCHER
                 <?php $__env->endSlot(); ?>

                <?php if (isset($component)) { $__componentOriginal46f2d918a9dfa088f68e3370bf2410c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal46f2d918a9dfa088f68e3370bf2410c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panel-switch::components.panel-list','data' => ['panels' => $panels,'currentPanel' => $currentPanel,'labels' => $labels,'icons' => $icons,'darkIcons' => $darkIcons,'iconSize' => $iconSize,'renderIconAsImage' => $renderIconAsImage,'slideOver' => $isSlideOver,'appMeta' => $appMeta,'categories' => $categories]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panel-switch::panel-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['panels' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($panels),'current-panel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentPanel),'labels' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($labels),'icons' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icons),'dark-icons' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($darkIcons),'icon-size' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($iconSize),'render-icon-as-image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($renderIconAsImage),'slide-over' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSlideOver),'app-meta' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($appMeta),'categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal46f2d918a9dfa088f68e3370bf2410c4)): ?>
<?php $attributes = $__attributesOriginal46f2d918a9dfa088f68e3370bf2410c4; ?>
<?php unset($__attributesOriginal46f2d918a9dfa088f68e3370bf2410c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46f2d918a9dfa088f68e3370bf2410c4)): ?>
<?php $component = $__componentOriginal46f2d918a9dfa088f68e3370bf2410c4; ?>
<?php unset($__componentOriginal46f2d918a9dfa088f68e3370bf2410c4); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $attributes = $__attributesOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__attributesOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $component = $__componentOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__componentOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
        </div>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginal0942a211c37469064369f887ae8d1cef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0942a211c37469064369f887ae8d1cef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.modal.index','data' => ['id' => 'panel-switch','slideOver' => $isSlideOver,'stickyHeader' => $isSlideOver,'width' => $isSlideOver ? 'md' : $modalWidth,'teleport' => 'body','alignment' => $isSlideOver ? null : 'center','class' => $isSlideOver ? '' : 'panel-switch-modal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'panel-switch','slide-over' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSlideOver),'sticky-header' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSlideOver),'width' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSlideOver ? 'md' : $modalWidth),'teleport' => 'body','alignment' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSlideOver ? null : 'center'),'class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSlideOver ? '' : 'panel-switch-modal')]); ?>
             <?php $__env->slot('trigger', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginal4ad65391a22d7afc3b26be387c4fa851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ad65391a22d7afc3b26be387c4fa851 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panel-switch::components.panel-trigger','data' => ['icon' => $currentIcon,'darkIcon' => $currentDarkIcon,'renderAsImage' => $renderIconAsImage,'label' => $heading,'collapsibleSidebar' => $isSidebarCollapsibleOnDesktop]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panel-switch::panel-trigger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentIcon),'dark-icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentDarkIcon),'render-as-image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($renderIconAsImage),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($heading),'collapsible-sidebar' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSidebarCollapsibleOnDesktop)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ad65391a22d7afc3b26be387c4fa851)): ?>
<?php $attributes = $__attributesOriginal4ad65391a22d7afc3b26be387c4fa851; ?>
<?php unset($__attributesOriginal4ad65391a22d7afc3b26be387c4fa851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ad65391a22d7afc3b26be387c4fa851)): ?>
<?php $component = $__componentOriginal4ad65391a22d7afc3b26be387c4fa851; ?>
<?php unset($__componentOriginal4ad65391a22d7afc3b26be387c4fa851); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>

             <?php $__env->slot('heading', null, []); ?> 
                APP LAUNCHER
             <?php $__env->endSlot(); ?>

            <?php if (isset($component)) { $__componentOriginal46f2d918a9dfa088f68e3370bf2410c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal46f2d918a9dfa088f68e3370bf2410c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panel-switch::components.panel-list','data' => ['panels' => $panels,'currentPanel' => $currentPanel,'labels' => $labels,'icons' => $icons,'darkIcons' => $darkIcons,'iconSize' => $iconSize,'renderIconAsImage' => $renderIconAsImage,'slideOver' => $isSlideOver,'appMeta' => $appMeta,'categories' => $categories]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panel-switch::panel-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['panels' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($panels),'current-panel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentPanel),'labels' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($labels),'icons' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icons),'dark-icons' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($darkIcons),'icon-size' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($iconSize),'render-icon-as-image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($renderIconAsImage),'slide-over' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isSlideOver),'app-meta' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($appMeta),'categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal46f2d918a9dfa088f68e3370bf2410c4)): ?>
<?php $attributes = $__attributesOriginal46f2d918a9dfa088f68e3370bf2410c4; ?>
<?php unset($__attributesOriginal46f2d918a9dfa088f68e3370bf2410c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46f2d918a9dfa088f68e3370bf2410c4)): ?>
<?php $component = $__componentOriginal46f2d918a9dfa088f68e3370bf2410c4; ?>
<?php unset($__componentOriginal46f2d918a9dfa088f68e3370bf2410c4); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $attributes = $__attributesOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__attributesOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $component = $__componentOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__componentOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if (! $__env->hasRenderedOnce('844dfbfe-e798-4b0b-8973-ed371f0c7270')): $__env->markAsRenderedOnce('844dfbfe-e798-4b0b-8973-ed371f0c7270'); ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! ($isSlideOver)): ?>
        <style>
            .panel-switch-modal .fi-modal,
            .panel-switch-modal .fi-modal-window {
                max-height: 100svh !important;
            }

            .panel-switch-modal .fi-modal-window {
                width: min(98vw, 1480px) !important;
                height: min(96svh, 1040px) !important;
                border-radius: 1.25rem !important;
                border: 1px solid rgba(96, 165, 250, .22) !important;
                background:
                    radial-gradient(circle at 18% 0%, rgba(37, 99, 235, .22), transparent 28%),
                    radial-gradient(circle at 86% 12%, rgba(168, 85, 247, .18), transparent 30%),
                    linear-gradient(135deg, #020617 0%, #07111f 54%, #030712 100%) !important;
                box-shadow: 0 30px 90px rgba(0, 0, 0, .6), inset 0 1px 0 rgba(255,255,255,.08) !important;
                overflow: hidden !important;
                display: flex !important;
                flex-direction: column !important;
            }

            .panel-switch-modal .fi-modal-header {
                flex: 0 0 auto !important;
                padding: clamp(1rem, 2.2svh, 1.65rem) 1.75rem .45rem !important;
                border-bottom: 0 !important;
            }

            .panel-switch-modal .fi-modal-heading {
                width: 100% !important;
                text-align: center !important;
                font-size: clamp(2rem, 4svw, 4rem) !important;
                line-height: 1 !important;
                letter-spacing: .18em !important;
                font-weight: 900 !important;
                color: #fff !important;
                text-shadow: 0 0 34px rgba(59,130,246,.38) !important;
            }

            .panel-switch-modal .fi-modal-heading::after {
                content: 'Switch between your apps';
                display: block;
                margin-top: .65rem;
                font-size: clamp(.9rem, 1.45svw, 1.25rem);
                letter-spacing: .02em;
                font-weight: 500;
                color: rgba(255,255,255,.72);
                text-shadow: none;
            }

            .panel-switch-modal .fi-modal-content {
                flex: 1 1 auto !important;
                min-height: 0 !important;
                padding: .2rem clamp(.65rem, 1.8svw, 2rem) clamp(.65rem, 1.5svh, 1rem) !important;
                overflow: hidden !important;
                display: flex !important;
                flex-direction: column !important;
            }

            .titan-launcher {
                position: relative;
                display: flex;
                flex: 1 1 auto;
                min-height: 0;
                height: 100%;
                flex-direction: column;
                gap: clamp(.55rem, 1.1svh, .85rem);
                color: white;
            }

            .titan-launcher-brand {
                position: absolute;
                left: clamp(.25rem, 1.5svw, 1rem);
                top: -3.35rem;
                display: flex;
                align-items: center;
                gap: .7rem;
                color: white;
                opacity: .92;
            }
            .titan-launcher-logo { display: grid; place-items: center; height: 2.4rem; width: 2.4rem; border-radius: .7rem; background: linear-gradient(135deg, #2563eb, #020617); color: white; font-weight: 950; box-shadow: 0 0 30px rgba(37,99,235,.34); }
            .titan-launcher-brand strong { display:block; font-size: .95rem; letter-spacing: .18em; line-height: 1; }
            .titan-launcher-brand span { display:block; margin-top:.2rem; color: rgba(255,255,255,.65); font-size:.68rem; letter-spacing:.16em; }

            .titan-launcher-search-wrap {
                position: relative;
                margin-inline: auto;
                width: min(760px, 100%);
                flex: 0 0 auto;
            }

            .titan-launcher-search {
                width: 100%;
                border-radius: .85rem;
                border: 1px solid rgba(255,255,255,.16);
                background: rgba(15,23,42,.72);
                padding: .78rem 3.1rem .78rem 3rem;
                color: white;
                outline: none;
                box-shadow: inset 0 1px 0 rgba(255,255,255,.05);
            }

            .titan-launcher-search::placeholder { color: rgba(255,255,255,.42); }
            .titan-launcher-search:focus { border-color: rgba(96,165,250,.7); box-shadow: 0 0 0 3px rgba(59,130,246,.18); }
            .titan-launcher-search-icon { position: absolute; left: 1rem; top: 50%; height: 1.15rem; width: 1.15rem; transform: translateY(-50%); color: rgba(255,255,255,.62); }
            .titan-launcher-shortcut { position: absolute; right: .8rem; top: 50%; transform: translateY(-50%); border: 1px solid rgba(255,255,255,.13); border-radius: .45rem; padding: .18rem .5rem; color: rgba(255,255,255,.62); font-size: .78rem; }

            .titan-launcher-tabs {
                display: flex;
                gap: .65rem;
                overflow-x: auto;
                flex: 0 0 auto;
                padding: .1rem .15rem .35rem;
                scrollbar-width: thin;
                -webkit-overflow-scrolling: touch;
            }

            .titan-launcher-tab {
                flex: 0 0 auto;
                display: inline-flex;
                align-items: center;
                gap: .45rem;
                border-radius: .75rem;
                border: 1px solid rgba(255,255,255,.12);
                background: rgba(15,23,42,.7);
                padding: .58rem .9rem;
                color: rgba(255,255,255,.8);
                font-weight: 750;
                transition: .18s ease;
                white-space: nowrap;
            }

            .titan-launcher-tab:hover,
            .titan-launcher-tab.is-active {
                border-color: rgba(96,165,250,.75);
                background: rgba(37,99,235,.26);
                color: white;
                box-shadow: 0 0 0 1px rgba(59,130,246,.2), 0 10px 35px rgba(37,99,235,.18);
            }

            .titan-launcher-scroll {
                flex: 1 1 auto;
                min-height: 0;
                overflow-y: auto !important;
                overflow-x: hidden;
                overscroll-behavior: contain;
                -webkit-overflow-scrolling: touch;
                padding: .2rem .5rem .85rem .15rem;
                scrollbar-color: rgba(148,163,184,.66) rgba(15,23,42,.55);
                scrollbar-width: thin;
            }

            .titan-launcher-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(clamp(150px, 14svw, 210px), 1fr));
                gap: clamp(.7rem, 1.2svw, 1rem);
                align-items: stretch;
            }

            .titan-app-card {
                position: relative;
                display: flex;
                min-height: clamp(166px, 20svh, 220px);
                flex-direction: column;
                align-items: center;
                justify-content: center;
                overflow: hidden;
                border-radius: 1rem;
                border: 1px solid rgba(255,255,255,.14);
                padding: clamp(.72rem, 1.2svw, 1rem);
                text-align: center;
                color: white;
                text-decoration: none;
                box-shadow: inset 0 1px 0 rgba(255,255,255,.12), 0 16px 42px rgba(0,0,0,.28);
                transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
                isolation: isolate;
            }

            .titan-app-card:hover,
            .titan-app-card.is-current {
                transform: translateY(-2px);
                border-color: rgba(255,255,255,.36);
                box-shadow: inset 0 1px 0 rgba(255,255,255,.18), 0 24px 54px rgba(0,0,0,.38), 0 0 0 2px var(--titan-glow-soft), 0 0 45px var(--titan-glow);
            }

            .titan-app-card.is-upgrade { cursor: default; }
            .titan-app-card-bg { position: absolute; inset: 0; z-index: -1; background: radial-gradient(circle at 22% 10%, rgba(255,255,255,.2), transparent 25%), radial-gradient(circle at 90% 80%, rgba(0,0,0,.18), transparent 28%), linear-gradient(135deg, var(--titan-from), var(--titan-to)); opacity: .97; }
            .titan-app-card-bg::after { content: ''; position: absolute; inset: 0; background-image: radial-gradient(rgba(255,255,255,.16) 1px, transparent 1px); background-size: 9px 9px; mask-image: linear-gradient(135deg, black 0 28%, transparent 58%); opacity: .45; }
            .titan-app-badge { position: absolute; right: .65rem; top: .55rem; z-index: 2; border-radius: .45rem; border: 1px solid rgba(255,255,255,.25); background: rgba(2,6,23,.3); padding: .16rem .42rem; font-size: .66rem; font-weight: 900; letter-spacing: .08em; }
            .titan-app-icon-wrap { position: relative; z-index: 1; display: grid; place-items: center; margin-bottom: .75rem; height: clamp(3.25rem, 5.4svw, 4.25rem); width: clamp(3.25rem, 5.4svw, 4.25rem); border-radius: 1rem; background: rgba(255,255,255,.08); box-shadow: inset 0 1px 0 rgba(255,255,255,.2), 0 0 30px var(--titan-glow); }
            .titan-app-icon { height: clamp(2rem, 3.45svw, 2.75rem) !important; width: clamp(2rem, 3.45svw, 2.75rem) !important; color: white; filter: drop-shadow(0 0 10px rgba(255,255,255,.36)); }
            .titan-app-title { position: relative; z-index: 1; margin: 0; font-size: clamp(.95rem, 1.25svw, 1.18rem); font-weight: 900; letter-spacing: .08em; line-height: 1.08; }
            .titan-app-description { position: relative; z-index: 1; margin: .42rem 0 .65rem; min-height: 2.45em; color: rgba(255,255,255,.86); font-size: clamp(.76rem, 1.04svw, .94rem); line-height: 1.25; }
            .titan-app-action { position: relative; z-index: 1; display: inline-flex; align-items: center; justify-content: center; gap: .45rem; width: 100%; border-radius: .55rem; border: 1px solid rgba(255,255,255,.16); background: rgba(15,23,42,.22); padding: .48rem .62rem; font-size: .86rem; font-weight: 800; }

            .titan-launcher-footer {
                display: grid;
                grid-template-columns: repeat(3, minmax(0, 1fr));
                gap: .8rem;
                flex: 0 0 auto;
            }
            .titan-launcher-footer > div { border: 1px solid rgba(255,255,255,.1); border-radius: .85rem; background: rgba(15,23,42,.48); padding: .75rem 1rem; }
            .titan-launcher-footer strong { display: block; color: #60a5fa; font-size: .82rem; letter-spacing: .06em; }
            .titan-launcher-footer span { display: block; margin-top: .2rem; color: rgba(255,255,255,.68); font-size: .8rem; }

            .titan-tone-blue { --titan-from:#0f5df5; --titan-to:#061b58; --titan-glow:rgba(59,130,246,.45); --titan-glow-soft:rgba(59,130,246,.28); }
            .titan-tone-violet { --titan-from:#8b2de2; --titan-to:#24104f; --titan-glow:rgba(168,85,247,.45); --titan-glow-soft:rgba(168,85,247,.28); }
            .titan-tone-emerald { --titan-from:#10b981; --titan-to:#064e3b; --titan-glow:rgba(16,185,129,.48); --titan-glow-soft:rgba(16,185,129,.28); }
            .titan-tone-orange { --titan-from:#fb7b14; --titan-to:#6d2503; --titan-glow:rgba(249,115,22,.45); --titan-glow-soft:rgba(249,115,22,.28); }
            .titan-tone-amber { --titan-from:#f59e0b; --titan-to:#451a03; --titan-glow:rgba(245,158,11,.48); --titan-glow-soft:rgba(245,158,11,.28); }
            .titan-tone-pink { --titan-from:#f43f8f; --titan-to:#5f1245; --titan-glow:rgba(244,63,148,.45); --titan-glow-soft:rgba(244,63,148,.28); }
            .titan-tone-red { --titan-from:#ef4444; --titan-to:#4b1111; --titan-glow:rgba(239,68,68,.45); --titan-glow-soft:rgba(239,68,68,.28); }
            .titan-tone-cyan { --titan-from:#06b6d4; --titan-to:#083344; --titan-glow:rgba(6,182,212,.45); --titan-glow-soft:rgba(6,182,212,.28); }
            .titan-tone-teal { --titan-from:#14b8a6; --titan-to:#053c38; --titan-glow:rgba(20,184,166,.45); --titan-glow-soft:rgba(20,184,166,.28); }
            .titan-tone-purple { --titan-from:#a855f7; --titan-to:#3b1265; --titan-glow:rgba(168,85,247,.45); --titan-glow-soft:rgba(168,85,247,.28); }
            .titan-tone-lime { --titan-from:#65a30d; --titan-to:#1a2e05; --titan-glow:rgba(132,204,22,.45); --titan-glow-soft:rgba(132,204,22,.28); }
            .titan-tone-sky { --titan-from:#0284c7; --titan-to:#082f49; --titan-glow:rgba(14,165,233,.45); --titan-glow-soft:rgba(14,165,233,.28); }
            .titan-tone-indigo { --titan-from:#4f46e5; --titan-to:#1e1b4b; --titan-glow:rgba(99,102,241,.45); --titan-glow-soft:rgba(99,102,241,.28); }
            .titan-tone-rose { --titan-from:#e11d48; --titan-to:#4c0519; --titan-glow:rgba(225,29,72,.45); --titan-glow-soft:rgba(225,29,72,.28); }
            .titan-tone-slate { --titan-from:#64748b; --titan-to:#0f172a; --titan-glow:rgba(148,163,184,.45); --titan-glow-soft:rgba(148,163,184,.28); }
            .titan-tone-orange-dark { --titan-from:#ea580c; --titan-to:#431407; --titan-glow:rgba(234,88,12,.45); --titan-glow-soft:rgba(234,88,12,.28); }
            .titan-tone-cyan-dark { --titan-from:#0891b2; --titan-to:#164e63; --titan-glow:rgba(8,145,178,.45); --titan-glow-soft:rgba(8,145,178,.28); }
            .titan-tone-gold { --titan-from:#d97706; --titan-to:#422006; --titan-glow:rgba(251,191,36,.45); --titan-glow-soft:rgba(251,191,36,.28); }
            .titan-tone-graphite { --titan-from:#475569; --titan-to:#020617; --titan-glow:rgba(100,116,139,.45); --titan-glow-soft:rgba(100,116,139,.28); }
            .titan-tone-blue-steel { --titan-from:#2563eb; --titan-to:#0f172a; --titan-glow:rgba(37,99,235,.48); --titan-glow-soft:rgba(37,99,235,.28); }
            .titan-tone-green-mint { --titan-from:#22c55e; --titan-to:#052e16; --titan-glow:rgba(34,197,94,.48); --titan-glow-soft:rgba(34,197,94,.28); }
            .titan-tone-bronze { --titan-from:#b45309; --titan-to:#292524; --titan-glow:rgba(180,83,9,.48); --titan-glow-soft:rgba(180,83,9,.28); }
            .titan-tone-forest { --titan-from:#15803d; --titan-to:#064e3b; --titan-glow:rgba(21,128,61,.48); --titan-glow-soft:rgba(21,128,61,.28); }
            .titan-tone-steel { --titan-from:#334155; --titan-to:#020617; --titan-glow:rgba(71,85,105,.48); --titan-glow-soft:rgba(71,85,105,.28); }
            .titan-tone-neon-blue { --titan-from:#0ea5e9; --titan-to:#1e1b4b; --titan-glow:rgba(14,165,233,.5); --titan-glow-soft:rgba(14,165,233,.3); }
            .titan-tone-electric-blue { --titan-from:#2563eb; --titan-to:#172554; --titan-glow:rgba(37,99,235,.52); --titan-glow-soft:rgba(37,99,235,.3); }
            .titan-tone-profit-green { --titan-from:#16a34a; --titan-to:#14532d; --titan-glow:rgba(22,163,74,.52); --titan-glow-soft:rgba(22,163,74,.3); }
            .titan-tone-team-blue { --titan-from:#3b82f6; --titan-to:#1e3a8a; --titan-glow:rgba(59,130,246,.52); --titan-glow-soft:rgba(59,130,246,.3); }
            .titan-tone-route-cyan { --titan-from:#22d3ee; --titan-to:#155e75; --titan-glow:rgba(34,211,238,.52); --titan-glow-soft:rgba(34,211,238,.3); }
            .titan-tone-compliance-indigo { --titan-from:#6366f1; --titan-to:#312e81; --titan-glow:rgba(99,102,241,.52); --titan-glow-soft:rgba(99,102,241,.3); }
            .titan-tone-hazard-red { --titan-from:#dc2626; --titan-to:#450a0a; --titan-glow:rgba(220,38,38,.52); --titan-glow-soft:rgba(220,38,38,.3); }
            .titan-tone-growth-pink { --titan-from:#db2777; --titan-to:#500724; --titan-glow:rgba(219,39,119,.52); --titan-glow-soft:rgba(219,39,119,.3); }
            .titan-tone-warning-amber { --titan-from:#f97316; --titan-to:#7c2d12; --titan-glow:rgba(249,115,22,.52); --titan-glow-soft:rgba(249,115,22,.3); }
            .titan-tone-knowledge-slate { --titan-from:#64748b; --titan-to:#1e293b; --titan-glow:rgba(100,116,139,.52); --titan-glow-soft:rgba(100,116,139,.3); }
            .titan-tone-skill-violet { --titan-from:#7c3aed; --titan-to:#2e1065; --titan-glow:rgba(124,58,237,.52); --titan-glow-soft:rgba(124,58,237,.3); }
            .titan-tone-cash-green { --titan-from:#059669; --titan-to:#064e3b; --titan-glow:rgba(5,150,105,.52); --titan-glow-soft:rgba(5,150,105,.3); }
            .titan-tone-labor-orange { --titan-from:#ea580c; --titan-to:#7c2d12; --titan-glow:rgba(234,88,12,.52); --titan-glow-soft:rgba(234,88,12,.3); }

            @media (max-width: 1180px) {
                .titan-launcher-brand { display:none; }
                .titan-launcher-grid { grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); }
                .titan-app-card { min-height: 176px; }
            }

            @media (max-width: 900px) {
                .panel-switch-modal .fi-modal-window { width: 100vw !important; height: 100dvh !important; max-height: 100dvh !important; border-radius: 0 !important; }
                .panel-switch-modal .fi-modal-header { padding-top: 1rem !important; }
                .panel-switch-modal .fi-modal-heading { font-size: clamp(1.85rem, 7.5vw, 3rem) !important; letter-spacing: .12em !important; }
                .panel-switch-modal .fi-modal-content { padding-inline: .75rem !important; }
                .titan-launcher-grid { grid-template-columns: repeat(auto-fill, minmax(142px, 1fr)); }
                .titan-app-card { min-height: 158px; padding: .75rem; }
                .titan-launcher-footer { display: none; }
                .titan-app-description { min-height: 2.35em; }
            }

            @media (max-width: 520px) {
                .titan-launcher-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
                .titan-app-card { min-height: 150px; }
                .titan-app-icon-wrap { height: 3rem; width: 3rem; margin-bottom: .5rem; }
                .titan-app-icon { height: 1.9rem !important; width: 1.9rem !important; }
                .titan-app-description { font-size: .72rem; }
                .titan-app-action { padding-block: .38rem; }
            }
        </style>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php endif; ?>
<?php /**PATH /home/saassmar/domains/tradiesm.art/public_html/vendor/bezhansalleh/filament-panel-switch/resources/views/panel-switch-menu.blade.php ENDPATH**/ ?>