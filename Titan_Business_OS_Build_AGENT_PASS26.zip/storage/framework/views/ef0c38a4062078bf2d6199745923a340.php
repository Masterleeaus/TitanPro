<?php
    use App\Support\CleaningAdminMetrics;
    $totals = CleaningAdminMetrics::dashboardTotals();
    $upcomingJobs = CleaningAdminMetrics::upcomingJobs();
?>

<?php if (isset($component)) { $__componentOriginalb525200bfa976483b4eaa0b7685c6e24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-widgets::components.widget','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-widgets::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('heading', null, []); ?> Operations Overview <?php $__env->endSlot(); ?>
         <?php $__env->slot('description', null, []); ?> Today's jobs with scheduled vs completed progress and active technician coverage. <?php $__env->endSlot(); ?>

        <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-700 dark:bg-gray-900">
                <div class="text-sm text-gray-500 dark:text-gray-400">Today's Jobs</div>
                <div class="mt-2 text-3xl font-bold text-gray-950 dark:text-white"><?php echo e($totals['jobs_today']); ?></div>
            </div>
            <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-700 dark:bg-gray-900">
                <div class="text-sm text-gray-500 dark:text-gray-400">Scheduled Today</div>
                <div class="mt-2 text-3xl font-bold text-gray-950 dark:text-white"><?php echo e($totals['scheduled_jobs_today']); ?></div>
            </div>
            <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-700 dark:bg-gray-900">
                <div class="text-sm text-gray-500 dark:text-gray-400">Completed Today</div>
                <div class="mt-2 text-3xl font-bold text-gray-950 dark:text-white"><?php echo e($totals['completed_jobs_today']); ?></div>
            </div>
            <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-700 dark:bg-gray-900">
                <div class="text-sm text-gray-500 dark:text-gray-400">Active Technicians</div>
                <div class="mt-2 text-3xl font-bold text-gray-950 dark:text-white"><?php echo e($totals['active_technicians']); ?></div>
            </div>
        </div>

        <div class="mt-6 grid gap-6 lg:grid-cols-2">
            <div>
                <h3 class="text-base font-semibold text-gray-950 dark:text-white">Upcoming Jobs</h3>
                <div class="mt-3 overflow-hidden rounded-xl border border-gray-200 dark:border-gray-700">
                    <table class="w-full divide-y divide-gray-200 text-sm dark:divide-gray-700">
                        <thead class="bg-gray-50 dark:bg-gray-800">
                            <tr>
                                <th class="px-3 py-2 text-left font-medium">When</th>
                                <th class="px-3 py-2 text-left font-medium">Job</th>
                                <th class="px-3 py-2 text-left font-medium">Cleaner</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 dark:divide-gray-800">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $upcomingJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-3 py-2 text-gray-600 dark:text-gray-300"><?php echo e(optional($job->scheduled_at)->format('d M, g:ia')); ?></td>
                                    <td class="px-3 py-2">
                                        <div class="font-medium text-gray-950 dark:text-white"><?php echo e($job->title); ?></div>
                                        <div class="text-xs text-gray-500"><?php echo e($job->jobType?->name ?? 'No service'); ?></div>
                                    </td>
                                    <td class="px-3 py-2 text-gray-600 dark:text-gray-300"><?php echo e($job->assignedTechnician?->name ?? 'Unassigned'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="3" class="px-3 py-8 text-center text-gray-500">No upcoming jobs found.</td></tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div>
                <h3 class="text-base font-semibold text-gray-950 dark:text-white">Quick Links</h3>
                <div class="mt-3 grid gap-3 sm:grid-cols-2">
                    <a href="/admin/reports" class="rounded-xl border border-gray-200 p-4 transition hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800">
                        <div class="font-semibold text-gray-950 dark:text-white">Reports</div>
                        <div class="text-sm text-gray-500">Revenue, quotes, workload, services.</div>
                    </a>
                    <a href="/titango" target="_blank" class="rounded-xl border border-gray-200 p-4 transition hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800">
                        <div class="font-semibold text-gray-950 dark:text-white">TitanGo</div>
                        <div class="text-sm text-gray-500">Launch the installable field app.</div>
                    </a>
                    <a href="/admin/driver-locations" class="rounded-xl border border-gray-200 p-4 transition hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800">
                        <div class="font-semibold text-gray-950 dark:text-white">Cleaner Locations</div>
                        <div class="text-sm text-gray-500">Dispatch and live tracking.</div>
                    </a>
                    <a href="/admin/invoices" class="rounded-xl border border-gray-200 p-4 transition hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800">
                        <div class="font-semibold text-gray-950 dark:text-white">Invoices</div>
                        <div class="text-sm text-gray-500"><?php echo e($totals['overdue_invoices']); ?> overdue invoices.</div>
                    </a>
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $attributes = $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $component = $__componentOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php /**PATH /home/saassmar/domains/tradiesm.art/public_html/resources/views/filament/widgets/cleaning-operations-overview.blade.php ENDPATH**/ ?>