<?php return array (
  'afatmustafa/blade-hugeicons' => 
  array (
    'providers' => 
    array (
      0 => 'Afatmustafa\\HugeIcons\\BladeHugeIconsServiceProvider',
    ),
  ),
  'alizharb/filament-activity-log' => 
  array (
    'providers' => 
    array (
      0 => 'AlizHarb\\ActivityLog\\ActivityLogServiceProvider',
    ),
  ),
  'anourvalar/eloquent-serialize' => 
  array (
    'aliases' => 
    array (
      'EloquentSerialize' => 'AnourValar\\EloquentSerialize\\Facades\\EloquentSerializeFacade',
    ),
  ),
  'attargah/admin-bar' => 
  array (
    'aliases' => 
    array (
      'AdminBar' => 'Attargah\\AdminBar\\Facades\\AdminBar',
    ),
    'providers' => 
    array (
      0 => 'Attargah\\AdminBar\\AdminBarServiceProvider',
    ),
  ),
  'awcodes/filament-badgeable-column' => 
  array (
    'providers' => 
    array (
      0 => 'Awcodes\\BadgeableColumn\\BadgeableColumnServiceProvider',
    ),
  ),
  'awcodes/filament-curator' => 
  array (
    'aliases' => 
    array (
      'Glide' => 'Awcodes\\Curator\\Facades\\Glide',
      'Curator' => 'Awcodes\\Curator\\Facades\\Curator',
      'Curation' => 'Awcodes\\Curator\\Facades\\Curation',
    ),
    'providers' => 
    array (
      0 => 'Awcodes\\Curator\\CuratorServiceProvider',
    ),
  ),
  'bezhansalleh/filament-panel-switch' => 
  array (
    'aliases' => 
    array (
      'PanelSwitch' => 'BezhanSalleh\\PanelSwitch\\Facades\\PanelSwitch',
    ),
    'providers' => 
    array (
      0 => 'BezhanSalleh\\PanelSwitch\\PanelSwitchServiceProvider',
    ),
  ),
  'bezhansalleh/filament-plugin-essentials' => 
  array (
    'providers' => 
    array (
      0 => 'BezhanSalleh\\PluginEssentials\\PluginEssentialsServiceProvider',
    ),
  ),
  'bezhansalleh/filament-shield' => 
  array (
    'aliases' => 
    array (
      'FilamentShield' => 'BezhanSalleh\\FilamentShield\\Facades\\FilamentShield',
    ),
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentShield\\FilamentShieldServiceProvider',
    ),
  ),
  'biostate/filament-menu-builder' => 
  array (
    'aliases' => 
    array (
      'FilamentMenuBuilder' => 'Biostate\\FilamentMenuBuilder\\Facades\\FilamentMenuBuilder',
    ),
    'providers' => 
    array (
      0 => 'Biostate\\FilamentMenuBuilder\\FilamentMenuBuilderServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-heroicons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Heroicons\\BladeHeroiconsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'eightynine/filament-advanced-widgets' => 
  array (
    'aliases' => 
    array (
      'FilamentAdvancedWidget' => 'EightyNine\\FilamentAdvancedWidget\\Facades\\FilamentAdvancedWidget',
    ),
    'providers' => 
    array (
      0 => 'EightyNine\\FilamentAdvancedWidget\\FilamentAdvancedWidgetServiceProvider',
    ),
  ),
  'filament/actions' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Actions\\ActionsServiceProvider',
    ),
  ),
  'filament/filament' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\FilamentServiceProvider',
    ),
  ),
  'filament/forms' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Forms\\FormsServiceProvider',
    ),
  ),
  'filament/infolists' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Infolists\\InfolistsServiceProvider',
    ),
  ),
  'filament/notifications' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Notifications\\NotificationsServiceProvider',
    ),
  ),
  'filament/query-builder' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\QueryBuilder\\QueryBuilderServiceProvider',
    ),
  ),
  'filament/schemas' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Schemas\\SchemasServiceProvider',
    ),
  ),
  'filament/spatie-laravel-settings-plugin' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\SpatieLaravelSettingsPluginServiceProvider',
    ),
  ),
  'filament/support' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Support\\SupportServiceProvider',
    ),
  ),
  'filament/tables' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Tables\\TablesServiceProvider',
    ),
  ),
  'filament/widgets' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Widgets\\WidgetsServiceProvider',
    ),
  ),
  'inertiajs/inertia-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Inertia\\ServiceProvider',
    ),
  ),
  'jeffersongoncalves/filament-ace-editor-field' => 
  array (
    'providers' => 
    array (
      0 => 'JeffersonGoncalves\\Filament\\AceEditorField\\AceEditorFieldServiceProvider',
    ),
  ),
  'jeffgreco13/filament-breezy' => 
  array (
    'aliases' => 
    array (
      'FilamentBreezy' => 'Jeffgreco13\\FilamentBreezy\\Facades\\FilamentBreezy',
    ),
    'providers' => 
    array (
      0 => 'Jeffgreco13\\FilamentBreezy\\FilamentBreezyServiceProvider',
    ),
  ),
  'kalnoy/nestedset' => 
  array (
    'providers' => 
    array (
      0 => 'Kalnoy\\Nestedset\\NestedSetServiceProvider',
    ),
  ),
  'kirschbaum-development/eloquent-power-joins' => 
  array (
    'providers' => 
    array (
      0 => 'Kirschbaum\\PowerJoins\\PowerJoinsServiceProvider',
    ),
  ),
  'lara-zeus/core' => 
  array (
    'aliases' => 
    array (
      'Core' => 'LaraZeus\\Core\\CoreFacade',
    ),
    'providers' => 
    array (
      0 => 'LaraZeus\\Core\\CoreServiceProvider',
    ),
  ),
  'lara-zeus/dynamic-dashboard' => 
  array (
    'aliases' => 
    array (
      'DynamicDashboard' => 'LaraZeus\\DynamicDashboard\\Facades\\DynamicDashboard',
    ),
    'providers' => 
    array (
      0 => 'LaraZeus\\DynamicDashboard\\DynamicDashboardServiceProvider',
    ),
  ),
  'lara-zeus/filament-plugin-tools' => 
  array (
    'providers' => 
    array (
      0 => 'LaraZeus\\FilamentPluginTools\\FilamentPluginToolsServiceProvider',
    ),
  ),
  'lara-zeus/laravel-seo' => 
  array (
    'providers' => 
    array (
      0 => 'LaraZeus\\SEO\\SEOServiceProvider',
    ),
  ),
  'lara-zeus/spatie-translatable' => 
  array (
    'providers' => 
    array (
      0 => 'LaraZeus\\SpatieTranslatable\\SpatieTranslatableServiceProvider',
    ),
  ),
  'laravel/dusk' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Dusk\\DuskServiceProvider',
    ),
  ),
  'laravel/fortify' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Fortify\\FortifyServiceProvider',
    ),
  ),
  'laravel/pail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Pail\\PailServiceProvider',
    ),
  ),
  'laravel/passkeys' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Passkeys\\PasskeysServiceProvider',
    ),
  ),
  'laravel/reverb' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Reverb\\ApplicationManagerServiceProvider',
      1 => 'Laravel\\Reverb\\ReverbServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sentinel' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sentinel\\SentinelServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/wayfinder' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Wayfinder\\WayfinderServiceProvider',
    ),
  ),
  'leandrocfe/filament-apex-charts' => 
  array (
    'aliases' => 
    array (
      'FilamentApexCharts' => 'Leandrocfe\\FilamentApexCharts\\Facades\\FilamentApexCharts',
    ),
    'providers' => 
    array (
      0 => 'Leandrocfe\\FilamentApexCharts\\FilamentApexChartsServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
  ),
  'maatwebsite/excel' => 
  array (
    'aliases' => 
    array (
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
    ),
    'providers' => 
    array (
      0 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'notebrainslab/filament-menu-manager' => 
  array (
    'providers' => 
    array (
      0 => 'NoteBrainsLab\\FilamentMenuManager\\FilamentMenuManagerServiceProvider',
    ),
  ),
  'novadaemon/filament-combobox' => 
  array (
    'providers' => 
    array (
      0 => 'Novadaemon\\FilamentCombobox\\FilamentComboboxServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'nwidart/laravel-modules' => 
  array (
    'aliases' => 
    array (
      'Module' => 'Nwidart\\Modules\\Facades\\Module',
    ),
    'providers' => 
    array (
      0 => 'Nwidart\\Modules\\LaravelModulesServiceProvider',
    ),
  ),
  'pestphp/pest-plugin-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Pest\\Laravel\\PestServiceProvider',
    ),
  ),
  'phiki/phiki' => 
  array (
    'providers' => 
    array (
      0 => 'Phiki\\Adapters\\Laravel\\PhikiServiceProvider',
    ),
  ),
  'pxlrbt/filament-excel' => 
  array (
    'providers' => 
    array (
      0 => 'pxlrbt\\FilamentExcel\\FilamentExcelServiceProvider',
    ),
  ),
  'pxlrbt/filament-spotlight' => 
  array (
    'providers' => 
    array (
      0 => 'pxlrbt\\FilamentSpotlight\\SpotlightServiceProvider',
    ),
  ),
  'rawilk/filament-password-input' => 
  array (
    'providers' => 
    array (
      0 => 'Rawilk\\FilamentPasswordInput\\FilamentPasswordInputServiceProvider',
    ),
  ),
  'redberry/page-builder-plugin' => 
  array (
    'aliases' => 
    array (
      'PageBuilderPlugin' => 'Redberry\\PageBuilderPlugin\\Facades\\PageBuilderPlugin',
    ),
    'providers' => 
    array (
      0 => 'Redberry\\PageBuilderPlugin\\PageBuilderPluginServiceProvider',
    ),
  ),
  'relaticle/flowforge' => 
  array (
    'aliases' => 
    array (
      'Flowforge' => 'Relaticle\\Flowforge\\Facades\\Flowforge',
    ),
    'providers' => 
    array (
      0 => 'Relaticle\\Flowforge\\FlowforgeServiceProvider',
    ),
  ),
  'ryangjchandler/blade-capture-directive' => 
  array (
    'aliases' => 
    array (
      'BladeCaptureDirective' => 'RyanChandler\\BladeCaptureDirective\\Facades\\BladeCaptureDirective',
    ),
    'providers' => 
    array (
      0 => 'RyanChandler\\BladeCaptureDirective\\BladeCaptureDirectiveServiceProvider',
    ),
  ),
  'savannabits/filament-modules' => 
  array (
    'aliases' => 
    array (
      'FilamentModules' => 'FilamentModules',
    ),
    'providers' => 
    array (
      0 => 'Coolsam\\Modules\\ModulesServiceProvider',
    ),
  ),
  'sentry/sentry-laravel' => 
  array (
    'aliases' => 
    array (
      'Sentry' => 'Sentry\\Laravel\\Facade',
    ),
    'providers' => 
    array (
      0 => 'Sentry\\Laravel\\ServiceProvider',
      1 => 'Sentry\\Laravel\\Tracing\\ServiceProvider',
    ),
  ),
  'shreejan/dash-arrange' => 
  array (
    'providers' => 
    array (
      0 => 'Shreejan\\DashArrange\\DashArrangeServiceProvider',
    ),
  ),
  'solution-forest/tab-layout-plugin' => 
  array (
    'providers' => 
    array (
      0 => 'SolutionForest\\TabLayoutPlugin\\TabLayoutPluginServiceProvider',
    ),
  ),
  'spatie/laravel-activitylog' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Activitylog\\ActivitylogServiceProvider',
    ),
  ),
  'spatie/laravel-medialibrary' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\MediaLibrary\\MediaLibraryServiceProvider',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'spatie/laravel-settings' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelSettings\\LaravelSettingsServiceProvider',
    ),
  ),
  'spatie/laravel-sitemap' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Sitemap\\SitemapServiceProvider',
    ),
  ),
  'spatie/laravel-translatable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Translatable\\TranslatableServiceProvider',
    ),
  ),
  'spykapps/filament-uppy-upload' => 
  array (
    'providers' => 
    array (
      0 => 'SpykApp\\UppyUpload\\UppyUploadServiceProvider',
    ),
  ),
  'tapp/filament-progress-bar-column' => 
  array (
    'providers' => 
    array (
      0 => 'Tapp\\FilamentProgressBarColumn\\FilamentProgressBarColumnServiceProvider',
    ),
  ),
  'tomatophp/console-helpers' => 
  array (
    'providers' => 
    array (
      0 => 'TomatoPHP\\ConsoleHelpers\\ConsoleHelpersServiceProvider',
    ),
  ),
  'tomatophp/filament-cms' => 
  array (
    'providers' => 
    array (
      0 => 'TomatoPHP\\FilamentCms\\FilamentCmsServiceProvider',
    ),
  ),
  'tomatophp/filament-icons' => 
  array (
    'providers' => 
    array (
      0 => 'TomatoPHP\\FilamentIcons\\FilamentIconsServiceProvider',
    ),
  ),
  'tomatophp/filament-settings-hub' => 
  array (
    'providers' => 
    array (
      0 => 'TomatoPHP\\FilamentSettingsHub\\FilamentSettingsHubServiceProvider',
    ),
  ),
  'tomatophp/filament-translation-component' => 
  array (
    'providers' => 
    array (
      0 => 'TomatoPHP\\FilamentTranslationComponent\\FilamentTranslationComponentServiceProvider',
    ),
  ),
  'wire-elements/spotlight' => 
  array (
    'aliases' => 
    array (
      'Spotlight' => 'LivewireUI\\Spotlight\\SpotlightFacade',
    ),
    'providers' => 
    array (
      0 => 'LivewireUI\\Spotlight\\SpotlightServiceProvider',
    ),
  ),
);