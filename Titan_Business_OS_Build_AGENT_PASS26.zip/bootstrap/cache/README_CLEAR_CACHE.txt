Deploy note: remove any generated PHP files in bootstrap/cache on the server, then run php artisan optimize:clear.
This delta intentionally patches both AdminPanelProvider copies because the project contains a module-level duplicate provider tree.
