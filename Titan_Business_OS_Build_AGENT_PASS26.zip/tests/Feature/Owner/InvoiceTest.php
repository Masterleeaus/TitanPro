<?php

use App\Models\Customer;
use App\Models\Invoice;
use App\Models\Job;
use App\Models\JobLineItem;
use App\Models\Organization;
use App\Models\Payment;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Support\Facades\DB;

function invoiceSetup(): array
{
    (new RolesAndPermissionsSeeder)->run();
    $org      = Organization::factory()->create();
    $user     = User::factory()->create(['organization_id' => $org->id]);
    $user->assignRole('owner');
    $customer = Customer::factory()->create(['organization_id' => $org->id]);

    return [$user, $org, $customer];
}

// ── Index ──────────────────────────────────────────────────────────────────────

test('invoice index requires authentication', function () {
    $this->get('/owner/invoices')->assertRedirect('/login');
});

test('user can view their invoice list', function () {
    [$user, $org, $customer] = invoiceSetup();
    Invoice::factory()->forCustomer($customer)->create(['invoice_number' => 'INV-0001']);

    $this->actingAs($user)
        ->get('/owner/invoices')
        ->assertOk()
        ->assertInertia(fn ($page) => $page
            ->component('Owner/Invoices/Index')
            ->has('invoices.data', 1)
        );
});

test('invoice index is scoped to organization', function () {
    [$user] = invoiceSetup();
    [, , $otherCustomer] = invoiceSetup();
    Invoice::factory()->forCustomer($otherCustomer)->create();

    $this->actingAs($user)
        ->get('/owner/invoices')
        ->assertOk()
        ->assertInertia(fn ($page) => $page->has('invoices.data', 0));
});

test('invoice index can filter by status', function () {
    [$user, $org, $customer] = invoiceSetup();
    Invoice::factory()->forCustomer($customer)->draft()->create();
    Invoice::factory()->forCustomer($customer)->sent()->create();

    $this->actingAs($user)
        ->get('/owner/invoices?status=sent')
        ->assertOk()
        ->assertInertia(fn ($page) => $page->has('invoices.data', 1));
});

// ── Show ───────────────────────────────────────────────────────────────────────

test('user can view their own invoice', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->create();

    $this->actingAs($user)
        ->get("/owner/invoices/{$invoice->id}")
        ->assertOk()
        ->assertInertia(fn ($page) => $page->component('Owner/Invoices/Show'));
});

test('user cannot view another org\'s invoice', function () {
    [$user] = invoiceSetup();
    [, , $otherCustomer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($otherCustomer)->create();

    $this->actingAs($user)
        ->get("/owner/invoices/{$invoice->id}")
        ->assertDenied();
});

// ── Generate from Job ──────────────────────────────────────────────────────────

test('user can generate invoice from completed job', function () {
    [$user, $org, $customer] = invoiceSetup();
    $job = Job::factory()->forCustomer($customer)->completed()->create(['title' => 'Pump Service']);

    $job->lineItems()->create([
        'name' => 'Labor', 'unit_price' => 150, 'quantity' => 1, 'sort_order' => 0,
    ]);
    $job->lineItems()->create([
        'name' => 'Parts', 'unit_price' => 75, 'quantity' => 2, 'sort_order' => 1,
    ]);

    $response = $this->actingAs($user)
        ->post("/owner/jobs/{$job->id}/invoice");

    $response->assertRedirect();

    $invoice = Invoice::where('job_id', $job->id)->firstOrFail();
    expect($invoice->customer_id)->toBe($customer->id);
    expect($invoice->status)->toBe(Invoice::STATUS_DRAFT);
    expect($invoice->lineItems)->toHaveCount(2);
    expect((float) $invoice->subtotal)->toBe(300.0);
    expect((float) $invoice->total)->toBe(300.0);
});

test('invoice number is auto-incremented', function () {
    [$user, $org, $customer] = invoiceSetup();

    $job1 = Job::factory()->forCustomer($customer)->completed()->create();
    $job2 = Job::factory()->forCustomer($customer)->completed()->create();

    $this->actingAs($user)->post("/owner/jobs/{$job1->id}/invoice");
    $this->actingAs($user)->post("/owner/jobs/{$job2->id}/invoice");

    $numbers = Invoice::where('organization_id', $org->id)
        ->orderBy('id')
        ->pluck('invoice_number')
        ->toArray();

    expect($numbers[0])->toBe('INV-0001');
    expect($numbers[1])->toBe('INV-0002');
});

test('cannot generate invoice from non-completed job', function () {
    [$user, $org, $customer] = invoiceSetup();
    $job = Job::factory()->forCustomer($customer)->scheduled()->create();

    $this->actingAs($user)
        ->post("/owner/jobs/{$job->id}/invoice")
        ->assertStatus(422);
});

test('cannot generate invoice twice for same job', function () {
    [$user, $org, $customer] = invoiceSetup();
    $job = Job::factory()->forCustomer($customer)->completed()->create();

    $this->actingAs($user)->post("/owner/jobs/{$job->id}/invoice");

    $this->actingAs($user)
        ->post("/owner/jobs/{$job->id}/invoice")
        ->assertStatus(422);
});

test('user cannot generate invoice for another org\'s job', function () {
    [$user] = invoiceSetup();
    [, , $otherCustomer] = invoiceSetup();
    $job = Job::factory()->forCustomer($otherCustomer)->completed()->create();

    $this->actingAs($user)
        ->post("/owner/jobs/{$job->id}/invoice")
        ->assertDenied();
});

// ── Send ───────────────────────────────────────────────────────────────────────

test('user can send a draft invoice', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->draft()->create();

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/send")
        ->assertRedirect();

    expect($invoice->fresh()->status)->toBe(Invoice::STATUS_SENT);
    expect($invoice->fresh()->sent_at)->not->toBeNull();
    expect($invoice->fresh()->send_count)->toBe(1);
});

test('user can re-send a sent invoice', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->sent()->create();

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/send")
        ->assertRedirect();

    expect($invoice->fresh()->status)->toBe(Invoice::STATUS_SENT);
    expect($invoice->fresh()->send_count)->toBe(2);
});

test('user can re-send an overdue invoice', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->overdue()->create();

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/send")
        ->assertRedirect();

    expect($invoice->fresh()->status)->toBe(Invoice::STATUS_SENT);
    expect($invoice->fresh()->send_count)->toBe(2);
});

test('send_count increments on each send', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->draft()->create();

    $this->actingAs($user)->post("/owner/invoices/{$invoice->id}/send");
    expect($invoice->fresh()->send_count)->toBe(1);

    $this->actingAs($user)->post("/owner/invoices/{$invoice->id}/send");
    expect($invoice->fresh()->send_count)->toBe(2);

    $this->actingAs($user)->post("/owner/invoices/{$invoice->id}/send");
    expect($invoice->fresh()->send_count)->toBe(3);
});

test('cannot send a paid invoice', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->paid()->create();

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/send")
        ->assertStatus(422);
});

test('user cannot send another org\'s invoice', function () {
    [$user] = invoiceSetup();
    [, , $otherCustomer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($otherCustomer)->draft()->create();

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/send")
        ->assertDenied();
});

// ── Void ───────────────────────────────────────────────────────────────────────

test('user can void a sent invoice', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->sent()->create();

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/void")
        ->assertRedirect();

    expect($invoice->fresh()->status)->toBe(Invoice::STATUS_VOID);
});

test('cannot void a paid invoice', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->paid()->create();

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/void")
        ->assertStatus(422);
});

test('cannot void an already-voided invoice', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->create(['status' => Invoice::STATUS_VOID]);

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/void")
        ->assertStatus(422);
});

// ── Destroy ───────────────────────────────────────────────────────────────────

test('user can delete a draft invoice', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->draft()->create();

    $this->actingAs($user)
        ->delete("/owner/invoices/{$invoice->id}")
        ->assertRedirect('/owner/invoices');

    expect(Invoice::find($invoice->id))->toBeNull();
    expect(Invoice::withTrashed()->find($invoice->id))->not->toBeNull();
});

test('cannot delete a non-draft invoice', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->sent()->create();

    $this->actingAs($user)
        ->delete("/owner/invoices/{$invoice->id}")
        ->assertStatus(422);
});

test('user cannot delete another org\'s invoice', function () {
    [$user] = invoiceSetup();
    [, , $otherCustomer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($otherCustomer)->draft()->create();

    $this->actingAs($user)
        ->delete("/owner/invoices/{$invoice->id}")
        ->assertDenied();
});

// ── Record Manual Payment ──────────────────────────────────────────────────────

test('user can record a full cash payment', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->sent()->create([
        'total'       => 250.00,
        'balance_due' => 250.00,
        'amount_paid' => 0.00,
    ]);

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/payments", [
            'amount'  => 250.00,
            'method'  => 'cash',
            'paid_at' => today()->toDateString(),
        ])
        ->assertRedirect();

    $invoice->refresh();
    expect($invoice->status)->toBe(\App\Models\Invoice::STATUS_PAID);
    expect((float) $invoice->balance_due)->toBe(0.0);
    expect((float) $invoice->amount_paid)->toBe(250.0);
    expect($invoice->paid_at)->not->toBeNull();

    $payment = \App\Models\Payment::where('invoice_id', $invoice->id)->first();
    expect($payment->method)->toBe('cash');
    expect((float) $payment->amount)->toBe(250.0);
    expect($payment->recorded_by)->toBe($user->id);
});

test('user can record a partial check payment', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->sent()->create([
        'total'       => 500.00,
        'balance_due' => 500.00,
        'amount_paid' => 0.00,
    ]);

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/payments", [
            'amount'    => 200.00,
            'method'    => 'check',
            'reference' => '1042',
            'paid_at'   => today()->toDateString(),
        ])
        ->assertRedirect();

    $invoice->refresh();
    expect($invoice->status)->toBe(\App\Models\Invoice::STATUS_PARTIAL);
    expect((float) $invoice->balance_due)->toBe(300.0);
    expect((float) $invoice->amount_paid)->toBe(200.0);
});

test('payment amount cannot exceed balance due', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->sent()->create([
        'total'       => 100.00,
        'balance_due' => 100.00,
    ]);

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/payments", [
            'amount'  => 999.00,
            'method'  => 'cash',
            'paid_at' => today()->toDateString(),
        ])
        ->assertSessionHasErrors('amount');
});

test('payment requires a valid method', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->sent()->create([
        'total'       => 100.00,
        'balance_due' => 100.00,
    ]);

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/payments", [
            'amount'  => 50.00,
            'method'  => 'stripe', // not allowed for manual recording
            'paid_at' => today()->toDateString(),
        ])
        ->assertSessionHasErrors('method');
});

test('cannot record payment on a paid invoice', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->paid()->create();

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/payments", [
            'amount'  => 10.00,
            'method'  => 'cash',
            'paid_at' => today()->toDateString(),
        ])
        ->assertStatus(422);
});

test('cannot record payment on a voided invoice', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->create([
        'status'      => \App\Models\Invoice::STATUS_VOID,
        'balance_due' => 100.00,
    ]);

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/payments", [
            'amount'  => 10.00,
            'method'  => 'cash',
            'paid_at' => today()->toDateString(),
        ])
        ->assertStatus(422);
});

test('user cannot record payment for another org\'s invoice', function () {
    [$user] = invoiceSetup();
    [, , $otherCustomer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($otherCustomer)->sent()->create([
        'total'       => 100.00,
        'balance_due' => 100.00,
    ]);

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/payments", [
            'amount'  => 100.00,
            'method'  => 'cash',
            'paid_at' => today()->toDateString(),
        ])
        ->assertDenied();
});

test('payment is rejected inside transaction when amount exceeds locked balance_due', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->sent()->create([
        'total'       => 100.00,
        'balance_due' => 50.00,
        'amount_paid' => 50.00,
    ]);

    // Simulate a race condition: the invoice balance_due has already been reduced
    // (e.g. by a concurrent request) but the current request passes the initial
    // validation with the stale value. Inside the transaction the locked row
    // exposes the true (lower) balance_due and the abort_if guard must reject it.
    DB::transaction(function () use ($invoice, $user) {
        $locked = Invoice::lockForUpdate()->findOrFail($invoice->id);
        // Manually reduce balance_due to simulate a concurrent payment having
        // already consumed the remaining balance.
        $locked->update(['balance_due' => 0.00, 'amount_paid' => 100.00, 'status' => Invoice::STATUS_PAID]);
    });

    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/payments", [
            'amount'  => 50.00,
            'method'  => 'cash',
            'paid_at' => today()->toDateString(),
        ])
        ->assertStatus(422);

    // Ensure no extra payment record was created
    expect(Payment::where('invoice_id', $invoice->id)->count())->toBe(0);
});

test('cumulative partial payments compute balance without rounding drift', function () {
    [$user, $org, $customer] = invoiceSetup();
    $invoice = Invoice::factory()->forCustomer($customer)->sent()->create([
        'total'       => 10.00,
        'balance_due' => 10.00,
        'amount_paid' => 0.00,
    ]);

    // First partial payment: 3.335 — stored rounded to 3.34
    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/payments", [
            'amount'  => 3.335,
            'method'  => 'cash',
            'paid_at' => today()->toDateString(),
        ])
        ->assertRedirect();

    $invoice->refresh();
    expect((float) $invoice->amount_paid)->toBe(3.34);
    expect((float) $invoice->balance_due)->toBe(6.66);

    // Second partial payment: 3.335 — raw sum is 6.67, balance is 3.33
    $this->actingAs($user)
        ->post("/owner/invoices/{$invoice->id}/payments", [
            'amount'  => 3.335,
            'method'  => 'cash',
            'paid_at' => today()->toDateString(),
        ])
        ->assertRedirect();

    $invoice->refresh();
    expect((float) $invoice->amount_paid)->toBe(6.67);
    // balance_due computed from unrounded raw sum (6.67), not from already-rounded amount_paid
    expect((float) $invoice->balance_due)->toBe(3.33);
});
