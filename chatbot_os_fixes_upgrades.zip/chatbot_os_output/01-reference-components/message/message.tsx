"use client";

import type {
  ReactTamboThreadMessage,
  TamboToolUseContent,
} from "@tambo-ai/react";
import {
  Message as MessageBase,
  type MessageContentProps as MessageBaseContentProps,
  type MessageImagesProps as MessageBaseImagesProps,
  type MessageRenderedComponentProps as MessageBaseRenderedComponentProps,
  type MessageLoadingIndicatorProps,
  type MessageRootProps,
} from "@tambo-ai/react-ui-base/message";
import {
  ReasoningInfo as ReasoningInfoBase,
  type ReasoningInfoRootProps,
} from "@tambo-ai/react-ui-base/reasoning-info";
import {
  ToolcallInfo as ToolcallInfoBase,
  type ToolcallInfoRootProps as ToolcallInfoBaseRootProps,
} from "@tambo-ai/react-ui-base/toolcall-info";
import { cn } from "@tambo-ai/ui-registry/utils";
import { cva, type VariantProps } from "class-variance-authority";
import { Check, ChevronDown, ExternalLink, Loader2, X } from "lucide-react";
import * as React from "react";
import { harden } from "rehype-harden";
import rehypeRaw from "rehype-raw";
import rehypeSanitize, { defaultSchema } from "rehype-sanitize";
import { Streamdown } from "streamdown";
import type { PluggableList } from "unified";
import { getSafeContent } from "../../lib/thread-hooks";
import {
  createMarkdownComponents,
  markdownComponents,
} from "./markdown-components";

const streamdownSanitizeSchema = {
  ...defaultSchema,
  protocols: {
    ...defaultSchema.protocols,
    href: [...(defaultSchema.protocols?.href ?? []), "tambo-resource"],
  },
};

const streamdownAllowedProtocols = streamdownSanitizeSchema.protocols.href.map(
  (protocol) => {
    const normalized = protocol.endsWith(":")
      ? protocol.slice(0, -1)
      : protocol;
    return `${normalized}:`;
  },
);

const streamdownRehypePlugins: PluggableList = [
  rehypeRaw,
  [rehypeSanitize, streamdownSanitizeSchema],
  [
    harden,
    {
      allowedImagePrefixes: ["*"],
      allowedLinkPrefixes: ["*"],
      allowedProtocols: streamdownAllowedProtocols,
      defaultOrigin: undefined,
      allowDataImages: true,
    },
  ],
];

/**
 * CSS variants for the message container
 * @typedef {Object} MessageVariants
 * @property {string} default - Default styling
 * @property {string} solid - Solid styling with shadow effects
 */
const messageVariants = cva("flex flex-col", {
  variants: {
    variant: {
      default: "",
      solid: "shadow-md bg-container/50 transition-all duration-200",
    },
    role: {
      user: "justify-end",
      assistant: "justify-start shadow-none",
    },
  },
  defaultVariants: {
    variant: "default",
    role: "assistant",
  },
});

/**
 * Props for the Message component.
 */
export type MessageProps = MessageRootProps & {
  /** The role of the message, either "user" or "assistant". Determines alignment and styling. */
  message: ReactTamboThreadMessage;
  /** Optional styling variant for the message container. */
  variant?: VariantProps<typeof messageVariants>["variant"];
};

type MessageContextValue = {
  variant: VariantProps<typeof messageVariants>["variant"];
  role: "user" | "assistant";
  message: ReactTamboThreadMessage;
};

const MessageContext = React.createContext<MessageContextValue | null>(null);

/**
 * The root container for a message component.
 * It establishes the context for its children and applies alignment styles based on the role.
 * @component Message
 * @example
 * ```tsx
 * <Message role="user" message={messageData} variant="solid">
 *   <Message.Bubble />
 *   <Message.RenderedComponentArea />
 * </Message>
 * ```
 */
const Message = React.forwardRef<HTMLDivElement, MessageProps>(
  ({ className, variant, message, children, ...props }, ref) => {
    const role = message?.role === "assistant" ? "assistant" : "user";
    return (
      <MessageContext.Provider value={{ variant, message, role }}>
        <MessageBase.Root
          ref={ref}
          className={cn("data-[message-role=assistant]:w-full", className)}
          message={message}
          {...props}
        >
          {children}
        </MessageBase.Root>
      </MessageContext.Provider>
    );
  },
);
Message.displayName = "Message";

/**
 * Loading indicator with bouncing dots animation.
 *
 * A reusable component that displays three animated dots for loading states.
 * Used in message content and tool status areas.
 *
 * @component
 * @param props - Standard HTML div props
 * @param props.className - Optional CSS classes to apply
 * @returns Animated loading indicator component
 */
const LoadingIndicator: React.FC<MessageLoadingIndicatorProps> = ({
  className,
  ...props
}) => {
  return (
    <MessageBase.LoadingIndicator
      className={cn(
        [
          "flex items-center gap-1",
          "*:data-dot:h-1 *:data-dot:w-1 *:data-dot:bg-current *:data-dot:rounded-full *:data-dot:animate-bounce",
          "*:data-[dot=1]:[animation-delay:-0.3s]",
          "*:data-[dot=2]:[animation-delay:-0.2s]",
          "*:data-[dot=3]:[animation-delay:-0.1s]",
        ],
        className,
      )}
      {...props}
    />
  );
};
LoadingIndicator.displayName = "LoadingIndicator";

/**
 * Internal component to render message content based on its type.
 */
function MessageContentRenderer({
  markdownContent,
  renderAsMarkdown,
  ...props
}: {
  markdownContent?: string;
  renderAsMarkdown: boolean;
}) {
  if (!markdownContent) {
    return <span className="text-muted-foreground italic">Empty message</span>;
  }
  if (renderAsMarkdown) {
    return (
      <Streamdown
        components={markdownComponents}
        rehypePlugins={streamdownRehypePlugins}
        {...props}
      >
        {markdownContent}
      </Streamdown>
    );
  }
  return markdownContent;
}

/**
 * Props for the MessageImages component.
 */
export type MessageImagesProps = Omit<
  MessageBaseImagesProps,
  "renderImage" | "children"
>;

/**
 * Displays images from message content horizontally.
 * @component MessageImages
 */
const MessageImages = React.forwardRef<HTMLDivElement, MessageImagesProps>(
  ({ className, ...props }, ref) => {
    return (
      <MessageBase.Images
        ref={ref}
        className={cn("flex flex-wrap gap-2 mb-2", className)}
        renderImage={({ url, index }) => (
          <div
            key={index}
            className="w-32 h-32 rounded-md overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-200"
          >
            <img
              src={url}
              alt={`Image ${index + 1}`}
              width={128}
              height={128}
              loading="lazy"
              decoding="async"
              className="w-full h-full object-cover"
            />
          </div>
        )}
        {...props}
      />
    );
  },
);
MessageImages.displayName = "MessageImages";

/**
 * Props for the MessageContent component.
 */
export type MessageContentProps = Omit<
  MessageBaseContentProps,
  "children" | "content"
> &
  // TODO(lachieh): Remove these props after July 2026
  {
    /**
     * Optional flag to render content as Markdown. Default is true.
     * @deprecated use `renderAsMarkdown` instead
     */
    markdown?: boolean;
    /**
     * Optional content override. Can be a string or an array of content blocks.
     * If not provided, uses the content from the message context.
     * This allows for dynamic content updates or custom content rendering.
     * @deprecated use `messageContent` prop instead
     */
    content?: string | ReactTamboThreadMessage["content"];
  };

/**
 * Displays the message content with optional markdown formatting.
 * Only shows text content - tool calls are handled by ToolcallInfo component.
 * @component MessageContent
 */
const MessageContent = React.forwardRef<HTMLDivElement, MessageContentProps>(
  (
    {
      className,
      content,
      messageContent,
      markdown = true,
      renderAsMarkdown,
      ...props
    },
    ref,
  ) => {
    const contentEffective = messageContent ?? content;
    const renderAsMarkdownEffective = renderAsMarkdown ?? markdown;
    const { variant, role } = React.useContext(MessageContext) ?? {};
    return (
      <div data-slot="message-content-text">
        <MessageBase.Content
          ref={ref}
          keepMounted
          className={cn(
            "relative rounded-3xl px-4 py-2 text-[15px] leading-relaxed transition-all duration-200 font-medium max-w-full [&_p]:py-1 [&_li]:list-item",
            messageVariants({ variant, role }),
            className,
          )}
          messageContent={contentEffective}
          renderAsMarkdown={renderAsMarkdownEffective}
          render={(props, state) => {
            return (
              <MessageContentRenderer
                markdownContent={state.contentAsMarkdownString}
                renderAsMarkdown={state.markdown}
                {...props}
              />
            );
          }}
          {...props}
        />
      </div>
    );
  },
);
MessageContent.displayName = "MessageContent";

/**
 * Props for the ToolcallInfo component.
 */
export interface ToolcallInfoProps extends Omit<
  ToolcallInfoBaseRootProps,
  "children" | "message"
> {
  /** Optional flag to render response content as Markdown. Default is true. */
  markdown?: boolean;
  /** Optional specific tool_use block to display. If not provided, uses the first from the message. */
  toolUse?: TamboToolUseContent;
}

const toolStatusIconClassName = cva("h-3 w-3 text-bold", {
  variants: {
    status: {
      error: "text-red-500",
      loading: "text-muted-foreground animate-spin",
      success: "text-green-500",
    },
  },
  defaultVariants: {
    status: "success",
  },
});

function ToolcallStatusIcon() {
  return (
    <ToolcallInfoBase.StatusIcon
      render={(_props, { status }) => {
        let Icon = Check;
        if (status === "error") Icon = X;
        if (status === "loading") Icon = Loader2;
        return <Icon className={toolStatusIconClassName({ status })} />;
      }}
    />
  );
}

function ToolResultDisplay({
  content,
  hasResult,
  enableMarkdown,
}: {
  content: ReactTamboThreadMessage["content"] | null;
  hasResult: boolean;
  enableMarkdown: boolean;
}) {
  if (!hasResult) {
    return <span className="text-muted-foreground italic">Empty response</span>;
  }
  if (!content) {
    return null;
  }
  return (
    <ToolResultContent content={content} enableMarkdown={enableMarkdown} />
  );
}

function ToolcallInfoContent({ markdown }: { markdown: boolean }) {
  return (
    <ToolcallInfoBase.Content
      forceMount
      className={cn(
        "flex flex-col gap-1 p-3 pl-7 overflow-auto transition-[max-height,opacity,padding] duration-300 truncate",
        "data-[state=open]:max-h-auto data-[state=open]:opacity-100",
        "data-[state=closed]:max-h-0 data-[state=closed]:opacity-0 data-[state=closed]:p-0",
      )}
      render={(props, { message }) => (
        <div {...props}>
          <span>
            tool:{" "}
            <ToolcallInfoBase.ToolName className="font-mono bg-muted/50 p-0.5 -m-0.5 ml-0.5 rounded-sm" />
          </span>
          <span>
            parameters:{" "}
            <ToolcallInfoBase.Parameters className="font-mono bg-muted/50 p-0.5 -m-0.5 ml-0.5 rounded-sm" />
          </span>
          <SamplingSubThread parentMessageId={message.id} />
          <span>
            result:{" "}
            <ToolcallInfoBase.Result
              render={(props, { content, hasResult }) => {
                return (
                  <div {...props}>
                    <ToolResultDisplay
                      content={content}
                      hasResult={hasResult}
                      enableMarkdown={markdown}
                    />
                  </div>
                );
              }}
            />
          </span>
        </div>
      )}
    />
  );
}

type ToolcallInfoTriggerProps = React.ComponentProps<
  typeof ToolcallInfoBase.Trigger
>;
const ToolcallInfoTrigger = React.forwardRef<
  HTMLButtonElement,
  ToolcallInfoTriggerProps
>(function ToolcallInfoTrigger({ children, className, ...props }, ref) {
  return (
    <ToolcallInfoBase.Trigger
      ref={ref}
      className={cn(
        "group/trigger flex items-center gap-1 cursor-pointer hover:bg-muted rounded-md p-1 select-none w-fit",
        className,
      )}
      {...props}
    >
      {children}
    </ToolcallInfoBase.Trigger>
  );
});
ToolcallInfoTrigger.displayName = "ToolcallInfoTrigger";

/**
 * Displays tool call information in a collapsible dropdown.
 * Shows tool name, parameters, and associated tool response.
 * @component ToolcallInfo
 */
const ToolcallInfo = React.forwardRef<HTMLDivElement, ToolcallInfoProps>(
  ({ className, markdown = true, toolUse, ...props }, ref) => {
    return (
      <ToolcallInfoBase.Root
        ref={ref}
        className={cn(
          "flex flex-col items-start text-xs opacity-50",
          className,
        )}
        toolUse={toolUse}
        {...props}
      >
        <div className="flex flex-col w-full">
          <ToolcallInfoTrigger>
            <ToolcallStatusIcon />
            <ToolcallInfoBase.StatusText />
            <ChevronDown className="h-3 w-3 transition-transform duration-200 group-data-[state=closed]/trigger:-rotate-90" />
          </ToolcallInfoTrigger>
          <ToolcallInfoContent markdown={markdown} />
        </div>
      </ToolcallInfoBase.Root>
    );
  },
);
ToolcallInfo.displayName = "ToolcallInfo";

/**
 * Displays a message's child messages in a collapsible dropdown.
 * Used for MCP sampling sub-threads.
 */
const SamplingSubThread = ({
  parentMessageId: _parentMessageId,
  titleText = "finished additional work",
}: {
  parentMessageId: string;
  titleText?: string;
}) => {
  const [isExpanded, setIsExpanded] = React.useState(false);
  const samplingDetailsId = React.useId();

  // In V1, messages no longer have parentMessageId, so sub-threads are not supported.
  // Render nothing until a V1 equivalent is available.
  const childMessages: ReactTamboThreadMessage[] = [];

  if (!childMessages.length) return null;

  return (
    <div className="flex flex-col gap-1">
      <button
        type="button"
        aria-expanded={isExpanded}
        aria-controls={samplingDetailsId}
        onClick={() => setIsExpanded(!isExpanded)}
        className={cn(
          "flex items-center gap-1 cursor-pointer hover:bg-muted-foreground/10 rounded-md p-2 select-none w-fit",
        )}
      >
        <span>{titleText}</span>
        <ChevronDown
          className={cn(
            "w-3 h-3 transition-transform duration-200",
            !isExpanded && "-rotate-90",
          )}
        />
      </button>
      <div
        id={samplingDetailsId}
        className={cn(
          "transition-[max-height,opacity] duration-300",
          isExpanded
            ? "max-h-96 opacity-100 overflow-auto"
            : "max-h-0 opacity-0 overflow-hidden",
        )}
        aria-hidden={!isExpanded}
      >
        <div className="pl-2">
          <div className="border-l-2 border-muted-foreground p-2 flex flex-col gap-4">
            {childMessages?.map((m: ReactTamboThreadMessage) => (
              <div key={m.id} className={`${m.role === "user" && "pl-2"}`}>
                <span
                  className={cn(
                    "whitespace-pre-wrap",
                    m.role === "assistant" &&
                      "bg-muted/50 rounded-md p-2 inline-block w-fit",
                  )}
                >
                  {getSafeContent(m.content)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
SamplingSubThread.displayName = "SamplingSubThread";

/**
 * Props for the ReasoningInfo component.
 */
export type ReasoningInfoProps = Omit<
  ReasoningInfoRootProps,
  "children" | "message"
>;

/**
 * Displays reasoning information in a collapsible dropdown.
 * Shows the reasoning strings provided by the LLM when available.
 * @component ReasoningInfo
 */
const ReasoningInfo = React.forwardRef<HTMLDivElement, ReasoningInfoProps>(
  ({ className, ...props }, ref) => {
    return (
      <ReasoningInfoBase.Root
        ref={ref}
        className={cn(
          "flex flex-col items-start text-xs opacity-50",
          className,
        )}
        {...props}
      >
        <div className="flex flex-col w-full">
          <ReasoningInfoBase.Trigger
            className={
              "group/trigger flex items-center gap-1 cursor-pointer hover:bg-muted-foreground/10 rounded-md px-3 py-1 select-none w-fit"
            }
          >
            <ReasoningInfoBase.StatusText
              className={"data-loading:animate-thinking-gradient"}
            />
            <ChevronDown className="h-3 w-3 transition-transform duration-200 group-data-[state=closed]/trigger:-rotate-90" />
          </ReasoningInfoBase.Trigger>
          <ReasoningInfoBase.Content
            forceMount
            className={cn(
              "flex flex-col gap-1 px-3 py-3 overflow-auto transition-[max-height,opacity,padding] duration-300 w-full",
              "data-[state=open]:max-h-96 data-[state=open]:opacity-100",
              "data-[state=closed]:max-h-0 data-[state=closed]:opacity-0 data-[state=closed]:p-0",
            )}
          >
            <ReasoningInfoBase.Steps
              className="space-y-4"
              render={(_props, { steps, showStepNumbers }) => (
                <>
                  {steps.map((reasoningStep, index) => (
                    <div key={index} className="flex flex-col gap-1">
                      {showStepNumbers && (
                        <span className="text-muted-foreground text-xs font-medium">
                          Step {index + 1}:
                        </span>
                      )}
                      {reasoningStep && (
                        <div className="bg-muted/50 rounded-md p-3 text-xs overflow-x-auto overflow-y-auto max-w-full">
                          <div className="whitespace-pre-wrap wrap-break-word">
                            <Streamdown
                              components={markdownComponents}
                              rehypePlugins={streamdownRehypePlugins}
                            >
                              {reasoningStep}
                            </Streamdown>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </>
              )}
            />
          </ReasoningInfoBase.Content>
        </div>
      </ReasoningInfoBase.Root>
    );
  },
);
ReasoningInfo.displayName = "ReasoningInfo";

/**
 * Renders an image from a tool result.
 */
function ToolResultImage({ url, index }: { url: string; index: number }) {
  return (
    <div className="rounded-md overflow-hidden shadow-sm max-w-xs">
      <img
        src={url}
        alt={`Tool result image ${index + 1}`}
        loading="lazy"
        decoding="async"
        className="max-w-full h-auto object-contain"
      />
    </div>
  );
}

interface ToolResultResourceProps {
  resource: {
    uri?: string;
    text?: string;
    blob?: string;
    name?: string;
    mimeType?: string;
  };
  index: number;
}

/**
 * Renders a resource from a tool result.
 * Handles text, blob (images), and URI resources.
 */
function ToolResultResource({ resource, index }: ToolResultResourceProps) {
  // Handle blob content (e.g., base64-encoded images)
  if (resource.blob && resource.mimeType?.startsWith("image/")) {
    const dataUrl = `data:${resource.mimeType};base64,${resource.blob}`;
    return (
      <div className="rounded-md overflow-hidden shadow-sm max-w-xs">
        <img
          src={dataUrl}
          alt={resource.name ?? `Resource image ${index + 1}`}
          loading="lazy"
          decoding="async"
          className="max-w-full h-auto object-contain"
        />
      </div>
    );
  }

  // Handle text content
  if (resource.text) {
    return (
      <div className="whitespace-pre-wrap">
        {resource.name && (
          <span className="font-medium text-muted-foreground">
            {resource.name}:{" "}
          </span>
        )}
        {resource.text}
      </div>
    );
  }

  // Handle URI reference
  if (resource.uri) {
    return (
      <div className="flex items-center gap-1">
        <span className="font-medium text-muted-foreground">
          {resource.name ?? "Resource"}:
        </span>
        <span className="font-mono text-xs truncate">{resource.uri}</span>
      </div>
    );
  }

  return null;
}

/**
 * Renders tool result content with appropriate formatting.
 * Handles text (with JSON pretty-printing), images, and MCP resources.
 */
function ToolResultContent({
  content,
  enableMarkdown = true,
}: {
  content: ReactTamboThreadMessage["content"];
  enableMarkdown?: boolean;
}) {
  if (!content) return null;

  // Handle string content directly
  if (typeof content === "string") {
    return <ToolResultText text={content} enableMarkdown={enableMarkdown} />;
  }

  // Handle array content with mixed types
  if (Array.isArray(content)) {
    const textParts: string[] = [];
    const nonTextItems: Array<{
      type: "image" | "resource";
      url?: string;
      resource?: ToolResultResourceProps["resource"];
      index: number;
    }> = [];

    content.forEach((item, index) => {
      if (!item?.type) return;

      if (item.type === "text" && item.text) {
        textParts.push(item.text);
      } else if (item.type === "resource" && item.resource) {
        nonTextItems.push({ type: "resource", resource: item.resource, index });
      }
    });

    const combinedText = textParts.join("");

    // If we only have text, return it directly
    if (nonTextItems.length === 0) {
      return combinedText ? (
        <ToolResultText text={combinedText} enableMarkdown={enableMarkdown} />
      ) : null;
    }

    // If we have mixed content, render in a flex container
    return (
      <div className="flex flex-col gap-2">
        {combinedText && (
          <ToolResultText text={combinedText} enableMarkdown={enableMarkdown} />
        )}
        <div className="flex flex-wrap gap-2">
          {nonTextItems.map((item) => {
            switch (item.type) {
              case "image":
                return item.url ? (
                  <ToolResultImage
                    key={`image-${item.index}`}
                    url={item.url}
                    index={item.index}
                  />
                ) : null;
              case "resource":
                return item.resource ? (
                  <ToolResultResource
                    key={`resource-${item.index}`}
                    resource={item.resource}
                    index={item.index}
                  />
                ) : null;
            }
          })}
        </div>
      </div>
    );
  }

  // Fallback for unknown content types
  return getSafeContent(content);
}

/**
 * Renders text content, attempting JSON parsing for pretty-printing.
 */
function ToolResultText({
  text,
  enableMarkdown,
}: {
  text: string;
  enableMarkdown: boolean;
}) {
  const [parsedJson, setParsedJson] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!text) return;
    try {
      const parsed = JSON.parse(text);
      setParsedJson(JSON.stringify(parsed, null, 2));
    } catch {
      setParsedJson(null);
    }
  }, [text]);

  if (parsedJson) {
    return (
      <pre
        className={cn(
          "bg-muted/50 rounded-md p-3 text-xs overflow-x-auto overflow-y-auto max-w-full max-h-64",
        )}
      >
        <code className="font-mono wrap-break-word whitespace-pre-wrap">
          {parsedJson}
        </code>
      </pre>
    );
  }

  // JSON parsing failed, render as markdown or plain text
  if (!enableMarkdown) return text;
  return (
    <Streamdown
      components={markdownComponents}
      rehypePlugins={streamdownRehypePlugins}
    >
      {text}
    </Streamdown>
  );
}

/**
 * Props for the MessageRenderedComponent component.
 */
export type MessageRenderedComponentAreaProps = Omit<
  MessageBaseRenderedComponentProps,
  "children"
>;

/**
 * Displays the `renderedComponent` associated with an assistant message.
 * Shows a button to view in canvas if a canvas space exists, otherwise renders inline.
 * Only renders if the message role is 'assistant' and `message.renderedComponent` exists.
 */
const MessageRenderedComponentArea = React.forwardRef<
  HTMLDivElement,
  MessageRenderedComponentAreaProps
>(({ className, ...props }, ref) => {
  return (
    <MessageBase.RenderedComponent
      ref={ref}
      className={cn(className)}
      {...props}
    >
      <div className="flex justify-start pl-4">
        <MessageBase.RenderedComponentCanvasButton className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors duration-200 cursor-pointer group">
          View component
          <ExternalLink className="w-3.5 h-3.5" />
        </MessageBase.RenderedComponentCanvasButton>
      </div>
      <MessageBase.RenderedComponentContent className="w-full pt-2 px-2" />
    </MessageBase.RenderedComponent>
  );
});
MessageRenderedComponentArea.displayName = "Message.RenderedComponentArea";

export {
  createMarkdownComponents,
  LoadingIndicator,
  markdownComponents,
  Message,
  MessageContent,
  MessageImages,
  MessageRenderedComponentArea,
  messageVariants,
  ReasoningInfo,
  ToolcallInfo,
};
