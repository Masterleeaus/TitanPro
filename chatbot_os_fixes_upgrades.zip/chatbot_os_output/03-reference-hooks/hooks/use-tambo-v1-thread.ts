"use client";

/**
 * Thread Query Hook
 *
 * React Query hook for fetching a single thread.
 */

import type { UseQueryOptions } from "@tanstack/react-query";
import type { ThreadRetrieveResponse } from "@tambo-ai/typescript-sdk/resources/threads/threads";
import { useTamboClient } from "../../providers/tambo-client-provider";
import { useTamboQuery } from "../../hooks/react-query-hooks";
import { useTamboAuthState } from "./use-tambo-v1-auth-state";

/**
 * Hook to fetch a single thread by ID.
 *
 * Uses React Query for caching and automatic refetching.
 * Thread data is considered stale after 1 second (real-time data).
 *
 * Returns the thread with all its messages and current run status directly
 * from the SDK with no transformation.
 * @param threadId - Thread ID to fetch
 * @param options - Additional React Query options
 * @returns React Query query object with thread data
 * @example
 * ```tsx
 * function ThreadView({ threadId }: { threadId: string }) {
 *   const { data: thread, isLoading, isError } = useTamboThread(threadId);
 *
 *   if (isLoading) return <Spinner />;
 *   if (isError) return <Error />;
 *
 *   return (
 *     <div>
 *       <div>Status: {thread.runStatus}</div>
 *       {thread.messages.map(msg => <Message key={msg.id} message={msg} />)}
 *     </div>
 *   );
 * }
 * ```
 */
export function useTamboThread(
  threadId: string,
  options?: Omit<
    UseQueryOptions<ThreadRetrieveResponse>,
    "queryKey" | "queryFn"
  >,
) {
  const client = useTamboClient();
  const authState = useTamboAuthState();
  const isIdentified = authState.status === "identified";

  return useTamboQuery({
    queryKey: ["v1-threads", threadId],
    queryFn: async () => await client.threads.retrieve(threadId),
    staleTime: 1000, // Consider stale after 1s (real-time data)
    ...options,
    enabled: isIdentified && (options?.enabled ?? true),
  });
}
