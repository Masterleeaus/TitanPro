# TitanPro Chatbot-OS — Implementation Guide

> Last updated: 2026-05-17  
> Source: Deep scan of repo + ui.zip (tambo-main reference)  
> Branch: claude/audit-system-upgrades-cnqce

---

## CURRENT STATE (what already exists)

| Component | File | Status |
|---|---|---|
| Chat panel UI | `resources/js/components/titan-os/BusinessOsChatPanel.vue` | ✅ Basic — no streaming, no markdown |
| Widget renderer | `resources/js/components/titan-os/ControlPanelRenderer.vue` | ✅ Renders metric-card, data-table, log-list |
| Widget set | `resources/js/components/widgets/*.vue` | ✅ BarChart, LineChart, ToolCallCard, etc. |
| API service | `resources/js/services/business-os-api.ts` | ✅ Blocking fetch — needs SSE upgrade |
| TypeScript types | `resources/js/types/control-panel-schema.ts` | ✅ Complete |
| Thread model | `app/Models/TitanZeroThread.php` | ✅ JSON messages/widgets |
| Generate-UI controller | `app/Http/Controllers/TitanZero/GenerateUiController.php` | ✅ Blocking — replace with StreamingChatController |
| Thread controller | `app/Http/Controllers/TitanZero/ThreadController.php` | ✅ GET /api/titan/threads/{id} |
| Suggestions controller | `app/Http/Controllers/TitanZero/SuggestionsController.php` | ✅ Suggestion chips |
| TitanAssistService | `Modules/TitanZero/Services/TitanAssistService.php` | ✅ Full AI generation |
| WidgetFactory | `Modules/TitanZero/Services/WidgetFactory.php` | ✅ Widget intent detection |
| Chatbot models (Echo) | `Modules/TitanEchoAssist/Models/` | ✅ Chatbot, History, Channel, CannedResponse |
| Audio transcription | `Modules/TitanEchoAssist/Http/Controllers/Api/TitanGoVoiceController.php` | ✅ Exists — needs route |
| Webhook handlers | `Modules/TitanEchoAssist/Http/Controllers/Webhooks/` | ✅ WhatsApp, Telegram, Messenger |
| DB migration | `database/migrations/2026_05_17_000001_create_titan_zero_threads_table.php` | ✅ Run this if not done |

---

## WHAT NEEDS TO BE BUILT — Priority Order

### PRIORITY 1: SSE Streaming (blocks everything else)

**Problem:** `BusinessOsChatPanel.vue` uses blocking `fetch()`. The UI freezes until the full AI response is ready.

**Fix:**

1. **Add new route** to `routes/api.php`:
   ```php
   Route::post('/titan/zero/stream', \App\Http\Controllers\TitanZero\StreamingChatController::class)
       ->name('titan.zero.stream')
       ->middleware(['auth:sanctum', 'throttle:60,1']);
   ```

2. **Deploy** `05-titan-stubs/backend/StreamingChatController.php` → `app/Http/Controllers/TitanZero/`

3. **Replace** `sendChatMessage()` in `business-os-api.ts` with `streamChatMessage()` from `05-titan-stubs/frontend/business-os-api-streaming.ts`

4. **Update** `BusinessOsChatPanel.vue` to use `useStreamingChat()` composable:
   - Replace `state.loading` with `streaming.value`
   - Add `GenerationStageIndicator` below the message list
   - Build assistant message progressively with `appendDelta(delta)`

5. **Nginx config**: Add `X-Accel-Buffering: no` header to upstream or use response header (already in StreamingChatController).

**Test:** Send a message and confirm the response streams in character-by-character.

---

### PRIORITY 2: Markdown Rendering

**Problem:** `{{ message.content }}` in `BusinessOsChatPanel.vue` line 28 renders plain text.

**Fix:**
```bash
npm install marked highlight.js @types/marked
```

In `MessageBubble.vue` (stub in `05-titan-stubs/frontend/`):
```ts
import { marked } from 'marked';
import hljs from 'highlight.js';
marked.setOptions({ highlight: (code, lang) => hljs.highlight(code, { language: lang }).value });
const rendered = computed(() => marked.parse(message.content));
```

Add `highlight.js/styles/github.css` to `resources/css/app.css`.  
Add `prose prose-sm` classes from Tailwind Typography (`@tailwindcss/typography`).

---

### PRIORITY 3: Thread History Sidebar

**Problem:** Users can't see or switch between past threads.

**Fix:**

1. Add `GET /api/titan/threads` list endpoint to `ThreadController.php`:
   ```php
   public function index(Request $request): JsonResponse {
       $threads = TitanZeroThread::where('organization_id', $request->user()->organization_id)
           ->orderByDesc('updated_at')->limit(50)->get(['id','title','updated_at']);
       return response()->json($threads);
   }
   ```
   Route: `Route::get('/titan/threads', [ThreadController::class, 'index'])->name('titan.threads.index');`

2. Deploy `05-titan-stubs/frontend/ThreadHistorySidebar.vue` and wire into `BusinessOsChatPanel.vue`.

3. On thread select: call `fetchThread(id)` and replace `state.messages`.

---

### PRIORITY 4: Full-Page /Chat Route

**Problem:** `TitanZeroChatPage.php` uses `filament.pages.suite-placeholder` view — blank page.

**Fix:**

1. Create Inertia page `resources/js/pages/TitanOS/Chat.vue` using `05-titan-stubs/frontend/MessageThreadFull.vue`.

2. Add Laravel route in `routes/web.php`:
   ```php
   Route::get('/chat', fn() => Inertia::render('TitanOS/Chat'))->name('titan.chat')->middleware(['auth', 'verified']);
   ```

3. Update `TitanZeroChatPage.php` to redirect or render the Inertia page.

---

### PRIORITY 5: Floating Control Bar (Cmd+K)

**Problem:** No global keyboard shortcut to open chat.

**Fix:**

1. Deploy `05-titan-stubs/frontend/ControlBar.vue`.

2. Register global keyboard listener in `resources/js/app.ts`:
   ```ts
   window.addEventListener('keydown', (e) => {
     if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
       e.preventDefault();
       controlBarRef.value?.open();
     }
   });
   ```

3. Mount `<ControlBar>` in `AppSidebarLayout.vue` alongside the sidebar.

---

### PRIORITY 6: Tool Call Visualization

**Problem:** `ToolCallCard.vue` exists but not wired to real-time streaming events.

**Fix:**

1. `StreamingChatController` already emits `{"type":"tool_call","id":"...","status":"running"}` events.

2. In `useStreamingChat()`, update `activeToolCalls` on each `tool_call` event.

3. Pass `activeToolCalls` to `ToolCallDisplay.vue` (stub in `05-titan-stubs/frontend/`).

4. Show `ToolCallDisplay` inside `MessageBubble` for assistant messages.

---

### PRIORITY 7: Audio Transcription Endpoint

**Problem:** `TitanGoVoiceController.php` exists but isn't exposed for the chat composer's dictation button.

**Fix:**

1. Add route in `routes/api.php`:
   ```php
   Route::post('/titan/audio/transcribe', \App\Http\Controllers\TitanZero\AudioTranscriptionController::class)
       ->name('titan.audio.transcribe')->middleware(['auth:sanctum', 'throttle:10,1']);
   ```

2. Deploy `05-titan-stubs/backend/AudioTranscriptionController.php`.

3. Set env vars: `OPENAI_API_KEY` (primary) and optionally `GROQ_API_KEY` + `AUDIO_PROVIDER=groq`.

4. Add `DictationButton` to message composer (see reference: `01-reference-components/message-input/dictation-button.tsx`).

---

### PRIORITY 8: Message Feedback (Thumbs Up/Down)

**Fix:**

1. Run migration: `05-titan-stubs/migrations/create_titan_message_feedback_table.php`

2. Deploy `05-titan-stubs/backend/MessageFeedbackController.php`.

3. Add route:
   ```php
   Route::post('/titan/messages/{threadId}/{messageId}/feedback',
       \App\Http\Controllers\TitanZero\MessageFeedbackController::class)
       ->name('titan.messages.feedback');
   ```

4. Wire the 👍/👎 buttons in `MessageBubble.vue` to `POST /api/titan/messages/{threadId}/{messageId}/feedback`.

---

### PRIORITY 9: Collapsible Embedded Chat Widget

Deploy `05-titan-stubs/frontend/MessageThreadCollapsible.vue` and add to module Show pages:

```vue
<!-- In Owner/Jobs/Show.vue -->
<MessageThreadCollapsible context-key="job:{{ job.id }}" context-label="job" />
```

---

### PRIORITY 10: Elicitation UI (Structured Clarification)

When the AI needs to ask a structured question, the backend should return a special widget kind `elicitation`.
Deploy `05-titan-stubs/frontend/ElicitationUI.vue` and render it when `message.elicitation` is set.

Reference backend: `02-reference-backend/mcp-server/elicitations.ts`

---

### REMAINING FEATURES (implement after Priority 1-10)

| Feature | Reference | Where to build |
|---|---|---|
| @ mention context picker | `01-reference-components/message-input/message-input.tsx` | `MessageComposer.vue` |
| Generative chart widget | `01-reference-components/graph/graph.tsx` | `ControlPanelRenderer.vue` new case |
| Generative form widget | `01-reference-components/form/form.tsx` | `ControlPanelRenderer.vue` new case |
| Generative map widget | `01-reference-components/map/map.tsx` | `ControlPanelRenderer.vue` new case |
| Edit-with-AI button | `05-titan-stubs/frontend/EditWithAIButton.vue` | Wrap rich-text fields |
| Thread dropdown | `01-reference-components/thread-dropdown/` | `BusinessOsChatPanel.vue` header |
| Thread auto-naming | `02-reference-backend/memory/memory-extraction.service.ts` | `GenerateUiController` after first message |
| Thread observability dashboard | `04-reference-observability/observability/` | New Filament page |
| Conversation export | Backend: new `ThreadExportController.php` | JSON + PDF export |
| MCP integration | `02-reference-backend/mcp-server/` | New `TitanMcpService.php` |
| Custom LLM params per project | `01-reference-components/project-details/custom-llm-parameters/` | Filament settings |
| Per-session AI memory | `02-reference-backend/memory/` | Background job after thread done |
| Reasoning/thinking UI | `05-titan-stubs/frontend/ReasoningInfo.vue` | `MessageBubble.vue` |
| Image display in responses | `03-reference-hooks/hooks/use-message-images.ts` | `MessageBubble.vue` |
| File attach in composer | `Modules/TitanEchoAssist/Http/Controllers/Api/Portal/PortalConversationController.php` | Wire to Titan Zero |
| Canned responses list | `Modules/TitanEchoAssist/Models/ChatbotCannedResponse.php` | Composer suggestion chip |
| Instagram webhook | Missing handler | `Modules/TitanEchoAssist/Http/Controllers/Webhooks/` |

---

## PACKAGE CONTENTS

```
01-reference-components/    — Tambo UI component sources (React/TSX → port to Vue)
  control-bar/              — Cmd+K modal
  message-thread-full/      — Full-page thread
  message-thread-panel/     — Side panel
  message-thread-collapsible/ — Embedded widget
  message/                  — Message bubble + markdown
  scrollable-message-container/ — Auto-scroll
  thread-history/           — Thread list sidebar
  thread-dropdown/          — Quick thread switcher
  thread-content/           — Thread content wrapper
  elicitation-ui/           — Structured AI dialogs
  edit-with-tambo-button/   — Inline AI refinement
  form/, graph/, map/       — Generative widgets
  message-input/            — Composer with dictation + MCP config
  message-suggestions/      — Stage indicator + chips
  mcp-components/           — MCP server browser
  react-ui-base/            — Primitive headless components (toolcall-info, reasoning, etc.)

02-reference-backend/       — Tambo API sources (NestJS → port to Laravel)
  audio/                    — Whisper transcription
  threads/                  — SSE streaming, thread state, tool tracking
  memory/                   — Cross-session memory extraction
  mcp-server/               — MCP prompts, resources, elicitations
  projects/                 — Per-project LLM config, API keys

03-reference-hooks/         — Tambo React SDK (→ port to Vue composables)
  hooks/                    — useMessageImages, useTamboVoice
  mcp/                      — MCP hooks, elicitation client
  providers/                — Auth, context attachment, registry

04-reference-observability/ — Tambo observability dashboard + generative demos
  observability/            — Thread table, message viewer, tool call display
  generative/               — Demo interfaces for form/graph/map/edit-with-AI

05-titan-stubs/             — Ready-to-deploy TitanPro files
  frontend/
    BusinessOsChatPanel.vue         — EXISTING (current state, needs upgrade)
    ControlPanelRenderer.vue        — EXISTING
    business-os-api.ts              — EXISTING (blocking fetch)
    titan-os-panel.ts               — EXISTING
    MessageThreadFull.vue           — STUB (full-page /chat)
    ControlBar.vue                  — STUB (Cmd+K)
    ThreadHistorySidebar.vue        — STUB
    ScrollableMessageContainer.vue  — STUB (smart scroll lock)
    MessageBubble.vue               — STUB (markdown + action bar)
    ToolCallDisplay.vue             — STUB (expandable tool calls)
    GenerationStageIndicator.vue    — STUB (waiting/streaming/tool-call states)
    ReasoningInfo.vue               — STUB (collapsible thinking steps)
    ElicitationUI.vue               — STUB (structured clarification)
    EditWithAIButton.vue            — STUB (inline AI refinement)
    MessageThreadCollapsible.vue    — STUB (module page embedded chat)
    business-os-api-streaming.ts    — STUB (SSE streaming client + composable)
  backend/
    GenerateUiController.php        — EXISTING (blocking — keep for fallback)
    ThreadController.php            — EXISTING
    SuggestionsController.php       — EXISTING
    TitanZeroThread.php             — EXISTING model
    StreamingChatController.php     — STUB (SSE streaming — replaces generate-ui)
    AudioTranscriptionController.php — STUB (Whisper endpoint)
    MessageFeedbackController.php   — STUB (thumbs up/down)
  migrations/
    create_titan_message_feedback_table.php
    add_streaming_columns_to_titan_zero_threads.php

06-docs/
  CHATBOT_OS_IMPLEMENTATION_GUIDE.md   — This file
```

---

## ENV VARS TO ADD (.env / .env.example)

```bash
# Chatbot-OS
AUDIO_PROVIDER=openai           # 'openai' or 'groq'
GROQ_API_KEY=                   # optional, for faster/cheaper transcription

# Already exist but confirm:
OPENAI_API_KEY=
TITAN_OS_STREAMING=true         # future feature flag
```

---

## ROUTES TO ADD (routes/api.php)

```php
Route::middleware(['auth:sanctum'])->prefix('titan')->group(function () {
    // Existing
    Route::post('/zero/generate-ui', GenerateUiController::class)->name('titan.zero.generate-ui');
    Route::get('/threads/{threadId}', [ThreadController::class, 'show'])->name('titan.threads.show');
    Route::get('/suggestions', SuggestionsController::class)->name('titan.suggestions');

    // NEW — add these
    Route::post('/zero/stream', StreamingChatController::class)->name('titan.zero.stream');
    Route::get('/threads', [ThreadController::class, 'index'])->name('titan.threads.index');
    Route::post('/messages/{threadId}/{messageId}/feedback', MessageFeedbackController::class)->name('titan.messages.feedback');
    Route::post('/audio/transcribe', AudioTranscriptionController::class)
        ->name('titan.audio.transcribe')->middleware('throttle:10,1');
});
```
