<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * STUB migration: titan_message_feedback
 * Run: php artisan make:migration create_titan_message_feedback_table --path=database/migrations
 * then replace body with this content.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('titan_message_feedback', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('organization_id')->index();
            $table->unsignedBigInteger('thread_id')->index();
            $table->string('message_id', 36); // UUID
            $table->unsignedBigInteger('user_id')->index();
            $table->enum('sentiment', ['positive', 'negative']);
            $table->text('comment')->nullable();
            $table->timestamps();

            $table->unique(['thread_id', 'message_id', 'user_id'], 'uniq_thread_msg_user');
            $table->foreign('organization_id')->references('id')->on('organizations')->cascadeOnDelete();
            $table->foreign('thread_id')->references('id')->on('titan_zero_threads')->cascadeOnDelete();
            $table->foreign('user_id')->references('id')->on('users')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_message_feedback');
    }
};
