<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * STUB migration: extend titan_zero_threads for richer thread metadata.
 * Adds: context_key (for scoped collapsible widgets), named_at, last_message_at.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('titan_zero_threads', function (Blueprint $table) {
            $table->string('context_key', 80)->nullable()->index()->after('app_key');
            $table->string('title_generated')->nullable()->after('title'); // AI-generated title
            $table->timestamp('last_message_at')->nullable()->after('updated_at');
        });
    }

    public function down(): void
    {
        Schema::table('titan_zero_threads', function (Blueprint $table) {
            $table->dropColumn(['context_key', 'title_generated', 'last_message_at']);
        });
    }
};
