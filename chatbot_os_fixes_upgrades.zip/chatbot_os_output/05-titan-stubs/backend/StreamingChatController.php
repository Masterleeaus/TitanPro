<?php

namespace App\Http\Controllers\TitanZero;

use App\Http\Controllers\Controller;
use App\Models\TitanZeroThread;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * STUB: POST /api/titan/zero/stream
 *
 * Replaces the blocking GenerateUiController with SSE streaming.
 * Sends delta tokens as they arrive from the AI provider.
 *
 * Reference: tambo-main/apps/api/src/threads/util/streaming.ts
 * Reference: tambo-main/apps/api/src/threads/threads.service.ts
 *
 * Frontend: replace fetch() in business-os-api.ts with EventSource / ReadableStream.
 * Install: no extra Laravel package needed — use Symfony StreamedResponse.
 *
 * Response format (each line is a JSON SSE event):
 *   data: {"type":"delta","content":"Hello"}
 *   data: {"type":"tool_call","id":"tc1","toolName":"get_jobs","status":"running"}
 *   data: {"type":"tool_result","id":"tc1","result":{...},"status":"done"}
 *   data: {"type":"done","threadId":"42","suggestions":["What jobs are open?"]}
 */
class StreamingChatController extends Controller
{
    public function __invoke(Request $request): StreamedResponse
    {
        $validated = $request->validate([
            'message'        => ['required', 'string', 'max:4000'],
            'threadId'       => ['nullable', 'integer'],
            'context'        => ['nullable', 'array'],
            'context.appKey' => ['nullable', 'string', 'max:80'],
        ]);

        $user   = Auth::user();
        $orgId  = $user?->organization_id;
        $userId = $user?->id;

        // Abort if auth is missing (middleware should prevent this, but be safe)
        abort_unless($user && $orgId, 401);

        // Find or create thread
        $thread = null;
        if (!empty($validated['threadId'])) {
            $thread = TitanZeroThread::where('id', $validated['threadId'])
                ->where('organization_id', $orgId)
                ->first();
        }
        if (!$thread) {
            $thread = TitanZeroThread::create([
                'organization_id' => $orgId,
                'user_id'         => $userId,
                'app_key'         => $validated['context']['appKey'] ?? 'default',
                'title'           => Str::limit($validated['message'], 60),
                'messages'        => [],
                'widgets'         => [],
            ]);
        }

        $message = $validated['message'];
        $threadId = $thread->id;

        // Persist user message before streaming starts
        $thread->appendMessage([
            'id'        => (string) Str::uuid(),
            'role'      => 'user',
            'content'   => $message,
            'createdAt' => now()->toISOString(),
        ]);
        $thread->save();

        return response()->stream(function () use ($message, $thread, $threadId) {
            // Disable output buffering for real-time SSE
            if (ob_get_level()) ob_end_clean();

            $apiKey = config('titan-model-runtime.providers.openai.api_key', env('OPENAI_API_KEY'));
            $model  = config('titan-model-runtime.chat_model', 'gpt-4o-mini');
            $fullContent = '';

            try {
                // TODO: Replace with OpenAI streaming client (e.g. openai-php/client stream())
                // For now, simulate stream with chunked HTTP response

                $messages = [
                    ['role' => 'system', 'content' => 'You are Titan Zero AI. Respond helpfully and concisely.'],
                    ...array_slice($thread->messages ?? [], -6),
                    ['role' => 'user', 'content' => $message],
                ];

                // OpenAI streaming call (stream: true)
                $response = Http::withToken($apiKey)
                    ->withOptions(['stream' => true])
                    ->timeout(60)
                    ->post('https://api.openai.com/v1/chat/completions', [
                        'model'    => $model,
                        'messages' => $messages,
                        'stream'   => true,
                    ]);

                foreach ($response->getBody() as $chunk) {
                    foreach (explode("\n", $chunk) as $line) {
                        $line = trim($line);
                        if (!str_starts_with($line, 'data: ')) continue;
                        $json = substr($line, 6);
                        if ($json === '[DONE]') break;

                        $data = json_decode($json, true);
                        $delta = $data['choices'][0]['delta']['content'] ?? null;
                        if ($delta !== null) {
                            $fullContent .= $delta;
                            echo 'data: ' . json_encode(['type' => 'delta', 'content' => $delta]) . "\n\n";
                            flush();
                        }
                    }
                }
            } catch (\Throwable $e) {
                Log::warning('StreamingChatController: stream error', ['error' => $e->getMessage()]);
                $fullContent = 'Titan Zero is ready. How can I help?';
                echo 'data: ' . json_encode(['type' => 'delta', 'content' => $fullContent]) . "\n\n";
                flush();
            }

            // Persist assistant message after stream completes
            $thread->appendMessage([
                'id'        => (string) Str::uuid(),
                'role'      => 'assistant',
                'content'   => $fullContent,
                'createdAt' => now()->toISOString(),
            ]);
            $thread->save();

            // Final done event
            echo 'data: ' . json_encode([
                'type'        => 'done',
                'threadId'    => (string) $threadId,
                'suggestions' => [],
            ]) . "\n\n";
            flush();
        }, 200, [
            'Content-Type'      => 'text/event-stream',
            'Cache-Control'     => 'no-cache',
            'X-Accel-Buffering' => 'no', // disable nginx buffering
        ]);
    }
}
