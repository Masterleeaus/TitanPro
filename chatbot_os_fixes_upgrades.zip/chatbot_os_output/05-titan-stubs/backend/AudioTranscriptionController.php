<?php

namespace App\Http\Controllers\TitanZero;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\RateLimiter;

/**
 * STUB: POST /api/titan/audio/transcribe
 *
 * Accepts multipart/form-data with an audio file, transcribes via OpenAI Whisper
 * (or Groq Whisper as faster/cheaper fallback), returns transcript.
 *
 * Reference: tambo-main/apps/api/src/audio/audio.controller.ts
 * Reference: tambo-main/apps/api/src/audio/audio.service.ts
 *
 * Rate limit: 10 requests/min per user.
 * Max file size: 25 MB. Max duration: 120 seconds.
 * Accepted formats: webm, mp3, wav, m4a, ogg.
 *
 * Route to add in routes/api.php:
 *   Route::post('/titan/audio/transcribe', AudioTranscriptionController::class)
 *       ->name('titan.audio.transcribe')
 *       ->middleware(['auth:sanctum', 'throttle:10,1']);
 */
class AudioTranscriptionController extends Controller
{
    private const MAX_SIZE_MB = 25;
    private const ACCEPTED_MIME = ['audio/webm', 'audio/mpeg', 'audio/wav', 'audio/x-m4a', 'audio/mp4', 'audio/ogg'];

    public function __invoke(Request $request): JsonResponse
    {
        $request->validate([
            'audio' => ['required', 'file', 'max:' . (self::MAX_SIZE_MB * 1024)],
        ]);

        $userId = $request->user()?->id;

        // Rate limit: 10/min per user
        $key = "audio-transcription:{$userId}";
        if (RateLimiter::tooManyAttempts($key, 10)) {
            return response()->json(['error' => 'Rate limit exceeded'], 429)
                ->header('Retry-After', RateLimiter::availableIn($key));
        }
        RateLimiter::hit($key, 60);

        $file = $request->file('audio');

        if ($file->getSize() === 0) {
            return response()->json(['error' => 'Audio file is empty'], 400);
        }

        $provider = config('titan-model-runtime.audio_provider', env('AUDIO_PROVIDER', 'openai'));

        try {
            $startMs = (int) (microtime(true) * 1000);

            $transcript = match ($provider) {
                'groq'  => $this->transcribeGroq($file->getPathname(), $file->getClientOriginalName()),
                default => $this->transcribeOpenAI($file->getPathname(), $file->getClientOriginalName()),
            };

            $durationMs = (int) (microtime(true) * 1000) - $startMs;

            return response()->json(['transcript' => $transcript, 'duration_ms' => $durationMs]);
        } catch (\Throwable $e) {
            // If primary failed, try fallback
            if ($provider !== 'openai') {
                try {
                    $transcript = $this->transcribeOpenAI($file->getPathname(), $file->getClientOriginalName());
                    return response()->json(['transcript' => $transcript, 'duration_ms' => 0]);
                } catch (\Throwable) {}
            }

            return response()->json(['error' => 'Audio transcription not configured or provider unavailable'], 501);
        }
    }

    private function transcribeOpenAI(string $path, string $name): string
    {
        $apiKey = config('titan-model-runtime.providers.openai.api_key', env('OPENAI_API_KEY'));
        if (!$apiKey) throw new \RuntimeException('OpenAI API key not configured');

        $response = Http::withToken($apiKey)
            ->timeout(30)
            ->attach('file', file_get_contents($path), $name)
            ->post('https://api.openai.com/v1/audio/transcriptions', [
                'model' => 'whisper-1',
            ]);

        if (!$response->successful()) {
            throw new \RuntimeException('OpenAI Whisper error: ' . $response->status());
        }

        return $response->json('text', '');
    }

    private function transcribeGroq(string $path, string $name): string
    {
        $apiKey = env('GROQ_API_KEY');
        if (!$apiKey) throw new \RuntimeException('Groq API key not configured');

        $response = Http::withToken($apiKey)
            ->timeout(20)
            ->attach('file', file_get_contents($path), $name)
            ->post('https://api.groq.com/openai/v1/audio/transcriptions', [
                'model' => 'whisper-large-v3',
            ]);

        if (!$response->successful()) {
            throw new \RuntimeException('Groq Whisper error: ' . $response->status());
        }

        return $response->json('text', '');
    }
}
