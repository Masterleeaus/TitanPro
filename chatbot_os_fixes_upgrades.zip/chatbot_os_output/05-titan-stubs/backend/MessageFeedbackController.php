<?php

namespace App\Http\Controllers\TitanZero;

use App\Http\Controllers\Controller;
use App\Models\TitanZeroThread;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * STUB: POST /api/titan/messages/{threadId}/{messageId}/feedback
 *
 * Persists per-message feedback (thumbs up/down) from users to titan_message_feedback table.
 *
 * Reference: tambo-main/apps/web/components/observability/messages/message-id-copy-button.tsx
 *
 * Route to add in routes/api.php:
 *   Route::post('/titan/messages/{threadId}/{messageId}/feedback',
 *       MessageFeedbackController::class)->name('titan.messages.feedback');
 *
 * DB table needed: titan_message_feedback
 *   - id, organization_id, thread_id, message_id, user_id, sentiment (positive|negative), comment, created_at
 *   (see migration stub in migrations/)
 */
class MessageFeedbackController extends Controller
{
    public function __invoke(Request $request, string $threadId, string $messageId): JsonResponse
    {
        $validated = $request->validate([
            'sentiment' => ['required', 'in:positive,negative'],
            'comment'   => ['nullable', 'string', 'max:500'],
        ]);

        $user  = Auth::user();
        $orgId = $user?->organization_id;

        // Verify thread belongs to this org
        $thread = TitanZeroThread::where('id', $threadId)
            ->where('organization_id', $orgId)
            ->firstOrFail();

        // Upsert feedback (one per user per message)
        DB::table('titan_message_feedback')->updateOrInsert(
            ['thread_id' => $thread->id, 'message_id' => $messageId, 'user_id' => $user->id],
            [
                'organization_id' => $orgId,
                'sentiment'       => $validated['sentiment'],
                'comment'         => $validated['comment'] ?? null,
                'created_at'      => now(),
                'updated_at'      => now(),
            ]
        );

        return response()->json(['ok' => true]);
    }
}
