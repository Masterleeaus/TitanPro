<template>
  <!-- STUB: Inline AI refinement button for generated content blocks -->
  <!-- Reference: tambo-main/packages/ui-registry/src/components/edit-with-tambo-button/ -->
  <div class="relative group">
    <slot />
    <!-- Hover overlay button -->
    <button
      v-if="!suggesting"
      class="absolute top-1 right-1 hidden group-hover:flex items-center gap-1 bg-white dark:bg-gray-900 border rounded-lg px-2 py-1 text-xs shadow hover:bg-blue-50"
      @click="openEditor"
    >
      ✦ Edit with AI
    </button>

    <!-- Suggestion panel -->
    <div v-if="suggesting" class="mt-2 border rounded-xl overflow-hidden">
      <div class="bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs text-gray-500">AI suggestion:</div>
      <div class="p-3 text-sm whitespace-pre-wrap">{{ suggestion }}</div>
      <div class="flex gap-2 p-2 border-t">
        <button class="px-3 py-1 bg-green-600 text-white rounded text-xs" @click="accept">Accept</button>
        <button class="px-3 py-1 border rounded text-xs" @click="reject">Reject</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';

const props = defineProps<{ content: string; contextLabel?: string }>();
const emit = defineEmits<{ (e: 'replace', value: string): void }>();

const suggesting = ref(false);
const suggestion = ref('');

function openEditor() {
  // TODO: open ControlBar/chat panel pre-populated with quoted content
  // For now, inline prompt
  const prompt = window.prompt(`Edit "${props.contextLabel ?? 'content'}": describe the change`);
  if (!prompt) return;
  // TODO: call POST /api/titan/zero/generate-ui with content + prompt
  suggesting.value = true;
  suggestion.value = '[AI suggestion will appear here once SSE streaming is wired]';
}

function accept() { emit('replace', suggestion.value); suggesting.value = false; }
function reject() { suggesting.value = false; suggestion.value = ''; }
</script>
