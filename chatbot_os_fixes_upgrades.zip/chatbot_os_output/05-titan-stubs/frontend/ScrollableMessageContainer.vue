<template>
  <!-- STUB: Auto-scroll with smart lock — ScrollableMessageContainer -->
  <!-- Reference: tambo-main/packages/ui-registry/src/components/scrollable-message-container/ -->
  <!-- Lock releases when user scrolls up; re-locks when user scrolls to bottom -->
  <div ref="containerRef" class="overflow-y-auto" @scroll="onScroll">
    <slot />
    <!-- Scroll-to-bottom FAB, visible only when not at bottom -->
    <button
      v-if="!atBottom"
      class="fixed bottom-24 right-6 bg-blue-600 text-white rounded-full p-2 shadow-lg z-10"
      @click="scrollToBottom"
    >
      ↓
    </button>
  </div>
</template>

<script setup lang="ts">
import { nextTick, onMounted, ref, watch } from 'vue';

const props = defineProps<{ messages?: unknown[] }>();
const emit = defineEmits<{ (e: 'scroll-bottom'): void }>();

const containerRef = ref<HTMLElement | null>(null);
const atBottom = ref(true);
const userScrolled = ref(false);

function onScroll() {
  if (!containerRef.value) return;
  const { scrollTop, scrollHeight, clientHeight } = containerRef.value;
  atBottom.value = scrollHeight - scrollTop - clientHeight < 40;
  if (!atBottom.value) userScrolled.value = true;
  else { userScrolled.value = false; emit('scroll-bottom'); }
}

async function scrollToBottom() {
  await nextTick();
  if (containerRef.value && !userScrolled.value) {
    containerRef.value.scrollTop = containerRef.value.scrollHeight;
  }
}

// Auto-scroll on new messages if lock is not held
watch(() => props.messages, scrollToBottom, { deep: true });
onMounted(scrollToBottom);
</script>
