<template>
  <!-- STUB: Floating Cmd+K control bar / modal chat launcher -->
  <!-- Reference: tambo-main/packages/ui-registry/src/components/control-bar/ -->
  <Teleport to="body">
    <div v-if="open" class="fixed inset-0 z-50 flex items-start justify-center pt-[20vh]">
      <div class="absolute inset-0 bg-black/40" @click="close" />
      <div class="relative w-full max-w-xl bg-white dark:bg-gray-900 rounded-xl shadow-2xl overflow-hidden">
        <!-- Search / chat input -->
        <div class="flex items-center px-4 py-3 border-b">
          <span class="text-gray-400 mr-2">⌘</span>
          <input
            ref="inputRef"
            v-model="query"
            type="text"
            class="flex-1 bg-transparent outline-none text-sm"
            placeholder="Ask Titan AI, search, or type a command…"
            @keydown.escape="close"
            @keydown.enter="submit"
          />
        </div>
        <!-- Quick results / thread preview -->
        <div class="max-h-80 overflow-y-auto p-2">
          <!-- TODO: render quick-action list, recent threads, command palette items -->
          <p class="text-xs text-gray-400 px-2 py-4 text-center">Start typing to search or ask AI…</p>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { nextTick, ref, watch } from 'vue';

const open = ref(false);
const query = ref('');
const inputRef = ref<HTMLInputElement | null>(null);

// TODO: register global Cmd+K / Ctrl+K keyboard shortcut
// useGlobalKeydown((e) => { if ((e.metaKey || e.ctrlKey) && e.key === 'k') { open.value = !open.value; } });

watch(open, async (val) => {
  if (val) { await nextTick(); inputRef.value?.focus(); }
});

function close() { open.value = false; query.value = ''; }
function submit() { /* TODO: route to thread or run command */ }

defineExpose({ open });
</script>
