<template>
  <!-- STUB: Collapsible embedded chat widget for module pages (Job/Customer/Invoice show) -->
  <!-- Reference: tambo-main/packages/ui-registry/src/components/message-thread-collapsible/ -->
  <div class="titan-collapsible-chat fixed bottom-0 right-4 z-40 w-80 shadow-xl rounded-t-xl overflow-hidden border bg-white dark:bg-gray-900">
    <!-- Collapsed bar -->
    <button
      class="w-full flex items-center justify-between px-4 py-2 bg-gray-800 text-white text-sm"
      @click="expanded = !expanded"
    >
      <span>✦ Ask AI about this {{ contextLabel }} {{ expanded ? '▼' : '▲' }}</span>
    </button>

    <!-- Expanded panel -->
    <Transition name="slide-up">
      <div v-if="expanded" class="flex flex-col h-72">
        <div ref="msgList" class="flex-1 overflow-y-auto p-2 space-y-1">
          <div v-for="msg in messages" :key="msg.id" class="text-xs p-2 rounded" :class="msg.role === 'user' ? 'bg-blue-50' : 'bg-gray-100'">
            {{ msg.content }}
          </div>
        </div>
        <div class="border-t p-2 flex gap-2">
          <input v-model="draft" type="text" class="flex-1 text-sm border rounded px-2 py-1 dark:bg-gray-800" placeholder="Ask…" @keydown.enter="send" />
          <button class="bg-blue-600 text-white px-3 rounded text-sm" @click="send">→</button>
        </div>
      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
import { nextTick, ref } from 'vue';

const props = defineProps<{ contextKey: string; contextLabel?: string }>();

const expanded = ref(false);
const draft = ref('');
const messages = ref<Array<{ id: string; role: string; content: string }>>([]);
const msgList = ref<HTMLElement | null>(null);

async function send() {
  if (!draft.value.trim()) return;
  messages.value.push({ id: Date.now().toString(), role: 'user', content: draft.value });
  draft.value = '';
  await nextTick();
  if (msgList.value) msgList.value.scrollTop = msgList.value.scrollHeight;
  // TODO: call SSE endpoint with contextKey scoped thread
}
</script>
