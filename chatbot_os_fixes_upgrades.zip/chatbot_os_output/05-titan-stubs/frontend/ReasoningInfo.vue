<template>
  <!-- STUB: Collapsible AI reasoning / thinking steps component -->
  <!-- Reference: tambo-main/packages/react-ui-base/src/reasoning/ -->
  <div class="reasoning-info mt-1 border border-amber-200 rounded-lg overflow-hidden text-xs">
    <button
      class="w-full flex items-center justify-between px-3 py-1.5 bg-amber-50 dark:bg-amber-950 hover:bg-amber-100 text-amber-700 dark:text-amber-300"
      @click="open = !open"
    >
      <span class="flex items-center gap-1">🧠 Reasoning steps</span>
      <span>{{ open ? '▲' : '▼' }}</span>
    </button>
    <div v-if="open" class="px-3 py-2 bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-wrap">
      {{ content }}
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
defineProps<{ content: string }>();
const open = ref(false);
</script>
