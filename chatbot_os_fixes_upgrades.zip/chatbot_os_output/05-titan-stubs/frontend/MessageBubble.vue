<template>
  <!-- STUB: Message bubble with markdown rendering + action bar -->
  <!-- Reference: tambo-main/packages/ui-registry/src/components/message/ -->
  <!-- Install: npm install marked @highlightjs/vue-plugin highlight.js -->
  <div :class="['titan-message flex gap-2', message.role === 'user' ? 'flex-row-reverse' : 'flex-row']">
    <!-- Avatar -->
    <div class="flex-shrink-0 w-7 h-7 rounded-full bg-gray-300 flex items-center justify-center text-xs">
      {{ message.role === 'user' ? 'U' : 'AI' }}
    </div>

    <!-- Bubble -->
    <div class="relative group max-w-[80%]">
      <!-- Markdown content (TODO: wire marked/highlight.js) -->
      <!-- eslint-disable-next-line vue/no-v-html -->
      <div
        :class="['prose prose-sm dark:prose-invert rounded-xl px-3 py-2',
          message.role === 'user' ? 'bg-blue-600 text-white' : 'bg-gray-100 dark:bg-gray-800']"
        v-html="renderedContent"
      />

      <!-- Tool calls (if any) -->
      <ToolCallDisplay v-if="message.toolCalls?.length" :tool-calls="message.toolCalls" />

      <!-- Reasoning steps (if any) -->
      <ReasoningInfo v-if="message.reasoning" :content="message.reasoning" />

      <!-- Hover action bar (assistant messages only) -->
      <div
        v-if="message.role === 'assistant'"
        class="absolute -top-6 right-0 hidden group-hover:flex items-center gap-1 bg-white dark:bg-gray-900 border rounded-lg px-1 py-0.5 shadow text-xs"
      >
        <button title="Copy" @click="copyContent">📋</button>
        <button title="Thumbs up" @click="sendFeedback('positive')">👍</button>
        <button title="Thumbs down" @click="sendFeedback('negative')">👎</button>
        <button v-if="isLast" title="Retry" @click="$emit('retry')">🔄</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
// TODO: import { marked } from 'marked'; import hljs from 'highlight.js';
// TODO: import ToolCallDisplay from './ToolCallDisplay.vue';
// TODO: import ReasoningInfo from './ReasoningInfo.vue';

interface Message {
  id: string; role: 'user' | 'assistant'; content: string;
  toolCalls?: unknown[]; reasoning?: string;
}

const props = defineProps<{ message: Message; isLast?: boolean }>();
const emit = defineEmits<{ (e: 'retry'): void; (e: 'feedback', sentiment: string): void }>();

const renderedContent = computed(() => {
  // TODO: return marked.parse(props.message.content) with hljs highlighting
  return props.message.content;
});

function copyContent() { navigator.clipboard.writeText(props.message.content); }
function sendFeedback(sentiment: 'positive' | 'negative') { emit('feedback', sentiment); }
</script>
