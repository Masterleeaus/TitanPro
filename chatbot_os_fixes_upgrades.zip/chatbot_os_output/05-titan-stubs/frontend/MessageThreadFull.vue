<template>
  <!-- STUB: Full-page thread layout — dedicated /chat route -->
  <!-- Reference: tambo-main/packages/ui-registry/src/components/message-thread-full/ -->
  <div class="titan-os-thread-full flex h-screen overflow-hidden">
    <!-- Thread history sidebar -->
    <ThreadHistorySidebar
      v-if="showSidebar"
      :threads="threads"
      :active-thread-id="activeThreadId"
      @select="selectThread"
      @new="startNewThread"
    />

    <!-- Main chat area -->
    <div class="flex flex-col flex-1 overflow-hidden">
      <!-- Header with thread dropdown and controls -->
      <header class="flex items-center justify-between px-4 py-2 border-b bg-white dark:bg-gray-900">
        <ThreadDropdown :threads="threads" :active-thread-id="activeThreadId" @select="selectThread" />
        <div class="flex items-center gap-2">
          <button @click="showSidebar = !showSidebar" class="p-2 rounded hover:bg-gray-100">
            <!-- Toggle sidebar icon -->
          </button>
        </div>
      </header>

      <!-- Scrollable message container -->
      <ScrollableMessageContainer class="flex-1" @scroll-bottom="atBottom = true">
        <MessageList
          :messages="messages"
          :streaming="streaming"
          :generation-stage="generationStage"
        />
      </ScrollableMessageContainer>

      <!-- Composer -->
      <MessageComposer
        v-model="draft"
        :loading="streaming"
        @send="sendMessage"
        @attach="attachFile"
        @mention="openMentionPicker"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
// TODO: import child components once implemented
// import ThreadHistorySidebar from './ThreadHistorySidebar.vue';
// import ThreadDropdown from './ThreadDropdown.vue';
// import ScrollableMessageContainer from './ScrollableMessageContainer.vue';
// import MessageList from './MessageList.vue';
// import MessageComposer from './MessageComposer.vue';

const showSidebar = ref(true);
const activeThreadId = ref<string | null>(null);
const threads = ref([]);
const messages = ref([]);
const streaming = ref(false);
const generationStage = ref<'idle' | 'waiting' | 'streaming' | 'tool-call'>('idle');
const draft = ref('');
const atBottom = ref(true);

function selectThread(id: string) { activeThreadId.value = id; }
function startNewThread() { activeThreadId.value = null; messages.value = []; }
function sendMessage() { /* TODO: call SSE streaming endpoint */ }
function attachFile() { /* TODO: open file picker */ }
function openMentionPicker() { /* TODO: @mention context picker */ }
</script>
