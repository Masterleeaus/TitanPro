/**
 * STUB: Upgraded BusinessOsApi with SSE streaming support.
 * Replaces the blocking fetch() in business-os-api.ts with EventSource/ReadableStream.
 *
 * Reference: tambo-main/apps/api/src/threads/util/streaming.ts
 *
 * Drop-in replacement for BusinessOsApi.sendChatMessage() — replace the method body,
 * keep the same class and export.
 */

export type StreamDelta = { type: 'delta'; content: string };
export type StreamToolCall = { type: 'tool_call'; id: string; toolName: string; status: 'running' | 'done' | 'error'; parameters?: unknown; result?: unknown };
export type StreamDone = { type: 'done'; threadId: string; suggestions: string[] };
export type StreamEvent = StreamDelta | StreamToolCall | StreamDone;

function getCsrfToken(): string {
    return document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content ?? '';
}

/**
 * Opens an SSE stream to POST /api/titan/zero/stream.
 * Calls onEvent for each parsed SSE line, resolves when 'done' arrives.
 */
export async function streamChatMessage(input: {
    threadId?: string;
    message: string;
    context?: Record<string, unknown>;
}, onEvent: (event: StreamEvent) => void): Promise<void> {
    const response = await fetch('/api/titan/zero/stream', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'text/event-stream',
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-TOKEN': getCsrfToken(),
        },
        body: JSON.stringify(input),
    });

    if (!response.ok) throw new Error(`Stream request failed: ${response.status}`);
    if (!response.body) throw new Error('No response body');

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';

        for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith('data: ')) continue;
            const json = trimmed.slice(6);
            if (json === '[DONE]') return;
            try {
                const event = JSON.parse(json) as StreamEvent;
                onEvent(event);
                if (event.type === 'done') return;
            } catch { /* skip malformed lines */ }
        }
    }
}

/**
 * Composable for Vue 3 — wraps streamChatMessage with reactive state.
 *
 * Usage in BusinessOsChatPanel.vue:
 *   const { stream, streaming, generationStage } = useStreamingChat();
 *   await stream({ message, threadId }, (delta) => appendDelta(delta));
 */
import { ref } from 'vue';

export function useStreamingChat() {
    const streaming = ref(false);
    const generationStage = ref<'idle' | 'waiting' | 'streaming' | 'tool-call'>('idle');
    const activeToolCalls = ref<Record<string, StreamToolCall>>({});

    async function stream(
        input: { message: string; threadId?: string; context?: Record<string, unknown> },
        onDelta: (content: string) => void,
        onDone?: (event: StreamDone) => void,
    ) {
        streaming.value = true;
        generationStage.value = 'waiting';
        activeToolCalls.value = {};

        try {
            await streamChatMessage(input, (event) => {
                if (event.type === 'delta') {
                    generationStage.value = 'streaming';
                    onDelta(event.content);
                } else if (event.type === 'tool_call') {
                    generationStage.value = 'tool-call';
                    activeToolCalls.value[event.id] = event;
                } else if (event.type === 'done') {
                    generationStage.value = 'idle';
                    onDone?.(event);
                }
            });
        } finally {
            streaming.value = false;
            generationStage.value = 'idle';
        }
    }

    return { stream, streaming, generationStage, activeToolCalls };
}
