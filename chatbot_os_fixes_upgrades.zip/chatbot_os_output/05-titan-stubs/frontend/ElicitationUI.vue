<template>
  <!-- STUB: Structured AI clarification dialogs within the chat thread -->
  <!-- Reference: tambo-main/packages/ui-registry/src/components/elicitation-ui/ -->
  <!-- Reference: tambo-main/react-sdk/src/mcp/elicitation.ts -->
  <div class="elicitation-ui border border-blue-200 rounded-xl p-4 my-2 bg-blue-50 dark:bg-blue-950">
    <p class="text-sm font-medium text-blue-800 dark:text-blue-200 mb-3">{{ elicitation.message }}</p>

    <!-- Render fields based on schema -->
    <form @submit.prevent="submit">
      <div v-for="(field, key) in elicitation.requestedSchema?.properties" :key="key" class="mb-3">
        <label class="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
          {{ field.title || key }}
          <span v-if="elicitation.requestedSchema?.required?.includes(key)" class="text-red-500">*</span>
        </label>
        <!-- Text input -->
        <input
          v-if="!field.enum"
          v-model="values[key]"
          :type="field.type === 'number' ? 'number' : 'text'"
          class="w-full border rounded px-2 py-1.5 text-sm dark:bg-gray-800"
        />
        <!-- Select -->
        <select v-else v-model="values[key]" class="w-full border rounded px-2 py-1.5 text-sm dark:bg-gray-800">
          <option v-for="opt in field.enum" :key="opt" :value="opt">{{ opt }}</option>
        </select>
      </div>
      <div class="flex gap-2 mt-4">
        <button type="submit" class="px-4 py-1.5 bg-blue-600 text-white rounded text-sm hover:bg-blue-700">Submit</button>
        <button type="button" class="px-4 py-1.5 border rounded text-sm hover:bg-gray-50" @click="$emit('cancel')">Cancel</button>
      </div>
    </form>
  </div>
</template>

<script setup lang="ts">
import { reactive } from 'vue';

interface ElicitationRequest {
  id: string; message: string;
  requestedSchema?: { properties?: Record<string, { title?: string; type?: string; enum?: string[] }>; required?: string[] };
}

const props = defineProps<{ elicitation: ElicitationRequest }>();
const emit = defineEmits<{ (e: 'submit', values: Record<string, unknown>): void; (e: 'cancel'): void }>();

const values = reactive<Record<string, unknown>>({});
function submit() { emit('submit', { ...values }); }
</script>
