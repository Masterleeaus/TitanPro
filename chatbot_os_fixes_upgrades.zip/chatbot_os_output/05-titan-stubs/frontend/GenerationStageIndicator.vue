<template>
  <!-- STUB: Generation stage status indicator -->
  <!-- Reference: tambo-main/packages/ui-registry/src/components/message-suggestions/message-generation-stage.tsx -->
  <Transition name="fade">
    <div v-if="stage !== 'idle'" class="flex items-center gap-2 px-3 py-1.5 text-xs text-gray-400">
      <span v-if="stage === 'waiting'" class="flex gap-0.5">
        <span class="animate-bounce delay-0 w-1 h-1 bg-gray-400 rounded-full" />
        <span class="animate-bounce delay-100 w-1 h-1 bg-gray-400 rounded-full" />
        <span class="animate-bounce delay-200 w-1 h-1 bg-gray-400 rounded-full" />
      </span>
      <span v-else-if="stage === 'streaming'" class="animate-pulse text-blue-500">●</span>
      <span v-else-if="stage === 'tool-call'" class="animate-spin text-amber-500">⟳</span>
      <span>{{ stageLabel }}</span>
    </div>
  </Transition>
</template>

<script setup lang="ts">
import { computed } from 'vue';
const props = defineProps<{ stage: 'idle' | 'waiting' | 'streaming' | 'tool-call' }>();
const stageLabel = computed(() => ({
  idle: '', waiting: 'Thinking…', streaming: 'Streaming…', 'tool-call': 'Running tool…',
}[props.stage]));
</script>
