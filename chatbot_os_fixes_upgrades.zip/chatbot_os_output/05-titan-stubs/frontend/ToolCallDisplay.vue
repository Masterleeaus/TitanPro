<template>
  <!-- STUB: Tool call visualization — expandable UI for in-progress and completed tool calls -->
  <!-- Reference: tambo-main/packages/react-ui-base/src/toolcall-info/ -->
  <div class="tool-call-display mt-1 space-y-1">
    <div
      v-for="call in toolCalls"
      :key="call.id"
      class="border rounded-lg overflow-hidden text-xs"
    >
      <!-- Trigger row -->
      <button
        class="w-full flex items-center justify-between px-3 py-1.5 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100"
        @click="toggle(call.id)"
      >
        <span class="flex items-center gap-1.5">
          <!-- Status icon -->
          <span v-if="call.status === 'running'" class="animate-spin text-blue-500">⟳</span>
          <span v-else-if="call.status === 'done'" class="text-green-500">✓</span>
          <span v-else class="text-red-500">✗</span>
          <span class="font-mono font-medium">{{ call.toolName }}</span>
        </span>
        <span class="text-gray-400">{{ expanded.has(call.id) ? '▲' : '▼' }}</span>
      </button>

      <!-- Expanded params + result -->
      <div v-if="expanded.has(call.id)" class="px-3 py-2 space-y-1 bg-white dark:bg-gray-900">
        <div v-if="call.parameters">
          <p class="text-gray-500 mb-0.5">Parameters</p>
          <pre class="bg-gray-50 dark:bg-gray-800 p-1.5 rounded text-[10px] overflow-x-auto">{{ JSON.stringify(call.parameters, null, 2) }}</pre>
        </div>
        <div v-if="call.result">
          <p class="text-gray-500 mb-0.5">Result</p>
          <pre class="bg-gray-50 dark:bg-gray-800 p-1.5 rounded text-[10px] overflow-x-auto">{{ JSON.stringify(call.result, null, 2) }}</pre>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';

interface ToolCall { id: string; toolName: string; status: 'running' | 'done' | 'error'; parameters?: unknown; result?: unknown; }
defineProps<{ toolCalls: ToolCall[] }>();

const expanded = ref<Set<string>>(new Set());
function toggle(id: string) {
  expanded.value.has(id) ? expanded.value.delete(id) : expanded.value.add(id);
}
</script>
