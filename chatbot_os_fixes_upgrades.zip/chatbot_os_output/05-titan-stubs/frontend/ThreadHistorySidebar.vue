<template>
  <!-- STUB: Thread history sidebar — collapsible list with search and new-thread button -->
  <!-- Reference: tambo-main/packages/ui-registry/src/components/thread-history/ -->
  <aside class="w-64 flex flex-col border-r bg-gray-50 dark:bg-gray-900 h-full">
    <div class="p-3 border-b flex items-center justify-between">
      <button class="text-sm font-medium text-blue-600 hover:underline" @click="$emit('new')">+ New Thread</button>
      <input v-model="search" type="search" placeholder="Search…" class="text-xs border rounded px-2 py-1 ml-2 flex-1 dark:bg-gray-800" />
    </div>
    <ul class="flex-1 overflow-y-auto py-1">
      <li
        v-for="thread in filteredThreads"
        :key="thread.id"
        :class="['px-3 py-2 cursor-pointer rounded text-sm hover:bg-gray-100 dark:hover:bg-gray-800',
          thread.id === activeThreadId ? 'bg-blue-50 dark:bg-blue-900 font-medium' : '']"
        @click="$emit('select', thread.id)"
      >
        <span class="block truncate">{{ thread.title || 'Untitled thread' }}</span>
        <span class="text-xs text-gray-400">{{ thread.updatedAt }}</span>
      </li>
      <li v-if="filteredThreads.length === 0" class="px-3 py-4 text-xs text-gray-400 text-center">No threads yet</li>
    </ul>
  </aside>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';

const props = defineProps<{ threads: Array<{ id: string; title?: string; updatedAt?: string }>; activeThreadId?: string | null }>();
defineEmits<{ (e: 'select', id: string): void; (e: 'new'): void }>();

const search = ref('');
const filteredThreads = computed(() =>
  props.threads.filter(t => (t.title ?? '').toLowerCase().includes(search.value.toLowerCase()))
);
</script>
