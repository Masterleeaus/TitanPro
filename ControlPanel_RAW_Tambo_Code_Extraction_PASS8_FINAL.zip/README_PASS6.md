# PASS6 Remaining Source Extraction

This pass preserves most remaining source-level files from tambo-main.

Included:
- remaining package source
- configs
- scripts
- examples
- docs
- graphql/schema files
- runtime configs

Excluded:
- node_modules
- build artifacts
- caches
- generated runtime output

Purpose:
maximize source preservation for downstream control-panel construction agents.
