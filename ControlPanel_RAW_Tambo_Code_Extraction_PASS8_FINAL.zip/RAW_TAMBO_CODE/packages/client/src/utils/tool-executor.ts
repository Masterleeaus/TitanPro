/**
 * Tool Executor
 *
 * Handles automatic execution of client-side tools when the model
 * requests them via `tambo.run.awaiting_input` events.
 */

import type { TamboTool } from "../model/component-metadata";
import type {
  ToolResultContent,
  TextContent,
  ResourceContent,
} from "@tambo-ai/typescript-sdk/resources/threads/threads";
import type { ToolCallTracker } from "./tool-call-tracker";
import { createKeyedThrottle, type KeyedThrottle } from "./keyed-throttle";

/**
 * Pending tool call from the stream accumulator
 */
export interface PendingToolCall {
  name: string;
  input: Record<string, unknown>;
}

/**
 * Execute a streamable tool call during streaming with pre-parsed partial args.
 *
 * Called on each TOOL_CALL_ARGS event for tools annotated with
 * `tamboStreamableHint: true`. Enables incremental UI updates while
 * the model is still generating arguments.
 *
 * Errors are caught silently — streaming tool execution is non-fatal since
 * the final execution via `awaiting_input` is what matters.
 * @param toolCallId - The tool call ID being accumulated
 * @param parsedArgs - Pre-parsed partial JSON args
 * @param toolTracker - Tracker holding pending tool call state
 * @param toolRegistry - Record of tool name to tool definition
 */
export async function executeStreamableToolCall(
  toolCallId: string,
  parsedArgs: Record<string, unknown>,
  toolTracker: ToolCallTracker,
  toolRegistry: Record<string, TamboTool>,
): Promise<void> {
  const accumulating = toolTracker.getAccumulatingToolCall(toolCallId);
  if (!accumulating) return;

  const tool = toolRegistry[accumulating.name];
  if (!tool?.annotations?.tamboStreamableHint) return;

  try {
    await tool.tool(parsedArgs);
  } catch (error) {
    console.warn(
      `[ToolExecutor] Non-fatal error in streamable tool "${accumulating.name}" ` +
        `(toolCallId: ${toolCallId}). This likely indicates a bug in the tool ` +
        `implementation; fix the tool to avoid repeated warnings.`,
      error,
    );
  }
}

const DEFAULT_STREAMABLE_THROTTLE_MS = 100;

/**
 * Creates a throttled wrapper around executeStreamableToolCall.
 *
 * Each tool call ID gets its own independent leading+trailing throttle via
 * {@link createKeyedThrottle}. The first call for a tool ID fires immediately
 * (leading edge). Subsequent calls during the cooldown window update the
 * stored args. After `delay` ms, if new args arrived, the tool re-executes
 * with the latest args (trailing edge). This repeats as long as new args
 * keep arriving — roughly one execution per `delay` ms during streaming.
 *
 * Call `flush()` to force-execute all pending trailing calls and reset to idle.
 * @param toolTracker - Tracker holding pending tool call state
 * @param toolRegistry - Record of tool name to tool definition
 * @param delay - Throttle interval in milliseconds
 * @returns Keyed throttle controller (schedule / flush)
 */
export function createThrottledStreamableExecutor(
  toolTracker: ToolCallTracker,
  toolRegistry: Record<string, TamboTool>,
  delay = DEFAULT_STREAMABLE_THROTTLE_MS,
): KeyedThrottle<Record<string, unknown>> {
  return createKeyedThrottle<Record<string, unknown>>((toolCallId, args) => {
    void executeStreamableToolCall(toolCallId, args, toolTracker, toolRegistry);
  }, delay);
}

/**
 * Execute a single client-side tool and return the result.
 * @param tool - The tool definition from the registry
 * @param toolCallId - The ID of the tool call to respond to
 * @param args - The parsed arguments for the tool
 * @returns ToolResultContent with the execution result or error
 */
export async function executeClientTool(
  tool: TamboTool,
  toolCallId: string,
  args: Record<string, unknown>,
): Promise<ToolResultContent> {
  try {
    const result = await tool.tool(args);

    // Transform result to content if transformer provided
    let content: (TextContent | ResourceContent)[];
    if (tool.transformToContent) {
      // transformToContent may return content parts in beta format
      // Convert to content format (TextContent | ResourceContent)
      const transformed = await tool.transformToContent(result);
      content = transformed.map((part) => {
        if (part.type === "text" && "text" in part && part.text) {
          return { type: "text" as const, text: part.text };
        }
        // For other types, stringify as text
        return {
          type: "text" as const,
          text: JSON.stringify(part),
        };
      });
    } else {
      // Default: stringify result as text
      content = [
        {
          type: "text" as const,
          text: typeof result === "string" ? result : JSON.stringify(result),
        },
      ];
    }

    return {
      type: "tool_result",
      toolUseId: toolCallId,
      content,
    };
  } catch (error) {
    return {
      type: "tool_result",
      toolUseId: toolCallId,
      isError: true,
      content: [
        {
          type: "text" as const,
          text:
            error instanceof Error ? error.message : "Tool execution failed",
        },
      ],
    };
  }
}

/**
 * Execute all pending tool calls and return their results.
 * Tools are executed sequentially to avoid race conditions when
 * tools may have side effects that depend on each other.
 * @param toolCalls - Map of tool call IDs to their call details
 * @param registry - Registry of tool names to their definitions (Map or Record)
 * @returns Array of ToolResultContent for all executed tools
 */
export async function executeAllPendingTools(
  toolCalls: Map<string, PendingToolCall>,
  registry: Map<string, TamboTool> | Record<string, TamboTool>,
): Promise<ToolResultContent[]> {
  const results: ToolResultContent[] = [];

  // Normalize registry to allow lookup regardless of Map or Record
  const getTool = (name: string): TamboTool | undefined => {
    if (registry instanceof Map) {
      return registry.get(name);
    }
    return registry[name];
  };

  for (const [toolCallId, { name, input }] of toolCalls) {
    const tool = getTool(name);
    if (!tool) {
      results.push({
        type: "tool_result",
        toolUseId: toolCallId,
        isError: true,
        content: [
          {
            type: "text" as const,
            text: `Tool "${name}" not found in registry`,
          },
        ],
      });
      continue;
    }

    const result = await executeClientTool(tool, toolCallId, input);
    results.push(result);
  }

  return results;
}
