"use client";

import { useThreadContentContext } from "@tambo-ai/react-ui-base/thread-content";
import type { messageVariants } from "@tambo-ai/ui-registry/components/message";
import {
  MessageInput,
  MessageInputError,
  MessageInputFileButton,
  MessageInputMcpPromptButton,
  MessageInputMcpResourceButton,
  MessageInputStopButton,
  MessageInputSubmitButton,
  MessageInputTextarea,
  MessageInputToolbar,
} from "@tambo-ai/ui-registry/components/message-input";
import { ScrollableMessageContainer } from "@tambo-ai/ui-registry/components/scrollable-message-container";
import {
  ThreadContent,
  ThreadContentMessages,
} from "@tambo-ai/ui-registry/components/thread-content";
import { cn } from "@tambo-ai/ui-registry/utils";
import type { VariantProps } from "class-variance-authority";
import { Dialog } from "radix-ui";
import * as React from "react";

/**
 * Props for the ControlBar component
 * @interface
 * @extends React.HTMLAttributes<HTMLDivElement>
 */
export interface ControlBarProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Keyboard shortcut for toggling the control bar (default: "mod+k") */
  hotkey?: string;
  /** Additional classes for the trigger button */
  triggerClassName?: string;
  /** Additional classes for the modal overlay */
  overlayClassName?: string;
  /**
   * Controls the visual styling of messages in the thread.
   * Possible values include: "default", "compact", etc.
   * These values are defined in messageVariants from "@tambo-ai/ui-registry/components/message".
   * @example variant="compact"
   */
  variant?: VariantProps<typeof messageVariants>["variant"];
}

/**
 * A floating control bar component for quick access to chat functionality
 * @component
 * @example
 * ```tsx
 * <ControlBar
 *   hotkey="mod+k"
 *   className="custom-styles"
 * />
 * ```
 */
export const ControlBar = React.forwardRef<HTMLDivElement, ControlBarProps>(
  (
    {
      className,
      hotkey = "mod+k",
      triggerClassName,
      overlayClassName,
      variant,
      ...props
    },
    ref,
  ) => {
    const [open, setOpen] = React.useState(false);
    const isMac =
      typeof navigator !== "undefined" && navigator.platform.startsWith("Mac");

    React.useEffect(() => {
      const down = (e: KeyboardEvent) => {
        const [modifier, key] = hotkey.split("+");
        const isModifierPressed =
          modifier === "mod" ? e.metaKey || e.ctrlKey : false;
        if (e.key === key && isModifierPressed) {
          e.preventDefault();
          setOpen((open) => !open);
        }
      };
      document.addEventListener("keydown", down);
      return () => document.removeEventListener("keydown", down);
    }, [hotkey, setOpen]);

    return (
      <Dialog.Root open={open} onOpenChange={setOpen}>
        <Dialog.Trigger asChild>
          <button
            className={cn(
              "fixed bottom-4 right-4 z-50 bg-background/50 backdrop-blur-sm border rounded-lg px-3 py-1.5 text-xs text-muted-foreground hover:bg-accent/50 transition-colors",
              triggerClassName,
            )}
            data-slot="control-bar-trigger"
          >
            Talk to AI (
            <span suppressHydrationWarning>
              {hotkey.replace("mod", isMac ? "⌘" : "Ctrl")}
            </span>
            )
          </button>
        </Dialog.Trigger>
        <Dialog.Portal>
          <Dialog.Overlay
            className={cn("fixed inset-0 z-50 bg-black/40", overlayClassName)}
            data-slot="control-bar-overlay"
          />
          <Dialog.Content
            ref={ref}
            className={cn(
              "fixed top-1/4 left-1/2 z-50 -translate-x-1/2 w-[440px] rounded-lg shadow-lg transition-all duration-200 outline-none",
              className,
            )}
            {...props}
          >
            <Dialog.Title className="sr-only">Control Bar</Dialog.Title>
            <div className="flex flex-col gap-3">
              <div className="bg-background border rounded-lg p-3 flex items-center justify-between gap-4">
                <div className="flex-1">
                  <MessageInput>
                    <MessageInputTextarea />
                    <MessageInputToolbar>
                      <MessageInputFileButton />
                      <MessageInputMcpPromptButton />
                      <MessageInputMcpResourceButton />
                      {/* Uncomment this to enable client-side MCP config modal button */}
                      {/* <MessageInputMcpConfigButton /> */}
                      <MessageInputSubmitButton />
                      <MessageInputStopButton />
                    </MessageInputToolbar>
                    <MessageInputError />
                  </MessageInput>
                </div>
              </div>
              <ThreadContent variant={variant}>
                <ControlBarMessageArea />
              </ThreadContent>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    );
  },
);
ControlBar.displayName = "ControlBar";

/**
 * Conditionally renders the scrollable messages area.
 * Only shows the bordered container when messages exist.
 * Uses ThreadContent context to determine visibility instead of DOM selectors.
 */
function ControlBarMessageArea() {
  const { isEmpty } = useThreadContentContext();

  if (isEmpty) return null;

  return (
    <ScrollableMessageContainer className="bg-background border rounded-lg p-4 max-h-[500px]">
      <ThreadContentMessages />
    </ScrollableMessageContainer>
  );
}
