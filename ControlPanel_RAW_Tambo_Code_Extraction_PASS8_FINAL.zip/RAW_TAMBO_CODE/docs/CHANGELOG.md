# Changelog

## [1.31.0](https://github.com/tambo-ai/tambo/compare/docs-v1.30.2...docs-v1.31.0) (2026-03-13)


### Features

* **models:** add gpt-5.4, gpt-5.4-pro, gpt-5.3-chat-latest, gpt-5.2-pro ([#2619](https://github.com/tambo-ai/tambo/issues/2619)) ([950c180](https://github.com/tambo-ai/tambo/commit/950c180ea390fea4320062166e72dfa651b9cfb9))


### Miscellaneous Chores

* **deps-dev:** bump @types/node from 22.19.8 to 22.19.15 ([#2606](https://github.com/tambo-ai/tambo/issues/2606)) ([1159b8c](https://github.com/tambo-ai/tambo/commit/1159b8cc0be23165d2d6ae5e409f5eb1867c62af))
* **deps:** bump the small-safe-packages group with 10 updates ([#2602](https://github.com/tambo-ai/tambo/issues/2602)) ([4a6b8d8](https://github.com/tambo-ai/tambo/commit/4a6b8d8f5f71affe710e709d34f312a48aa024a8))

## [1.30.2](https://github.com/tambo-ai/tambo/compare/docs-v1.30.1...docs-v1.30.2) (2026-03-09)


### Documentation

* **react-ui-base:** audit and fix all component reference pages ([#2584](https://github.com/tambo-ai/tambo/issues/2584)) ([d42c5b9](https://github.com/tambo-ai/tambo/commit/d42c5b9bf9fb3123670183699cd41c8961caa8d2))

## [1.30.1](https://github.com/tambo-ai/tambo/compare/docs-v1.30.0...docs-v1.30.1) (2026-03-07)


### Miscellaneous Chores

* **deps:** bump dompurify from 3.3.1 to 3.3.2 ([#2560](https://github.com/tambo-ai/tambo/issues/2560)) ([9f59466](https://github.com/tambo-ai/tambo/commit/9f59466fab9b3639baf3aba4e23b8fac7e9b40dd))

## [1.30.0](https://github.com/tambo-ai/tambo/compare/docs-v1.29.0...docs-v1.30.0) (2026-03-05)


### Features

* **cli:** rename start-from-scratch skill to generative-ui ([#2530](https://github.com/tambo-ai/tambo/issues/2530)) ([ce789e6](https://github.com/tambo-ai/tambo/commit/ce789e652024fe06d37f8785a53877e6407a4afb))
* **docs:** add live demo to react-ui-base overview with three styling variations ([#2529](https://github.com/tambo-ai/tambo/issues/2529)) ([9e4f826](https://github.com/tambo-ai/tambo/commit/9e4f826e893499c3e8fae1913e195e1358acd0c2))
* **docs:** phase 6 - live demos, DemoPreview, and docs polish for react-ui-base ([#2515](https://github.com/tambo-ai/tambo/issues/2515)) ([40fc632](https://github.com/tambo-ai/tambo/commit/40fc632df2554cd610940c95a82415fe17a3f466))
* **react-ui-base:** add McpPrompts and McpResources headless primitives ([#2512](https://github.com/tambo-ai/tambo/issues/2512)) ([459144d](https://github.com/tambo-ai/tambo/commit/459144d32acac499cd109f587fa6c5c2173f36e0))
* **react-ui-base:** add ThreadContent headless primitives ([#2509](https://github.com/tambo-ai/tambo/issues/2509)) ([51dd31b](https://github.com/tambo-ai/tambo/commit/51dd31bc5c1dbdd865342114f268ce559c29087b))
* **react-ui-base:** add ThreadHistory, ThreadDropdown base components ([#2504](https://github.com/tambo-ai/tambo/issues/2504)) ([52815e0](https://github.com/tambo-ai/tambo/commit/52815e07f60c64ea728d3d3363b5d4c168a69139))


### Miscellaneous Chores

* **deps:** bump @tailwindcss/postcss from 4.2.0 to 4.2.1 in the tailwind group ([#2536](https://github.com/tambo-ai/tambo/issues/2536)) ([ab3414a](https://github.com/tambo-ai/tambo/commit/ab3414a8af68b7fbb3a286961b5a18329511f7b2))
* **deps:** bump @tambo-ai/typescript-sdk from 0.93.0 to 0.93.1 in the tambo-ai group ([#2533](https://github.com/tambo-ai/tambo/issues/2533)) ([97158c3](https://github.com/tambo-ai/tambo/commit/97158c36ca0514d34cdae57fc0ebd3031957b55c))
* **deps:** bump the small-safe-packages group with 4 updates ([#2534](https://github.com/tambo-ai/tambo/issues/2534)) ([3694fe4](https://github.com/tambo-ai/tambo/commit/3694fe448691c1b9c4730b457d22bb971ad72d1f))


### Documentation

* **docs:** update skills page to reflect consolidated 2-skill model ([#2558](https://github.com/tambo-ai/tambo/issues/2558)) ([50db45e](https://github.com/tambo-ai/tambo/commit/50db45e25bb09dbd0e6a2e91ce424de25feeada1))

## [1.29.0](https://github.com/tambo-ai/tambo/compare/docs-v1.28.0...docs-v1.29.0) (2026-02-25)


### Features

* **cli:** add anonymous CLI telemetry via posthog-node SDK ([#2479](https://github.com/tambo-ai/tambo/issues/2479)) ([4894767](https://github.com/tambo-ai/tambo/commit/48947679dcf25826695cc3f6a2e4eecdf1d4c4a6))


### Bug Fixes

* **api:** return 400 instead of 500 for input validation errors ([#2464](https://github.com/tambo-ai/tambo/issues/2464)) ([c45ddb6](https://github.com/tambo-ai/tambo/commit/c45ddb684ba15de04a6c4ab9057e8263b1799358))
* **docs:** add og/twitter image to docs app ([#2455](https://github.com/tambo-ai/tambo/issues/2455)) ([6513129](https://github.com/tambo-ai/tambo/commit/65131291577e43524c4092b56c3414f0da1b7c3a))


### Miscellaneous Chores

* **deps:** bump @tailwindcss/postcss from 4.1.18 to 4.2.0 in the tailwind group ([#2473](https://github.com/tambo-ai/tambo/issues/2473)) ([7d9303b](https://github.com/tambo-ai/tambo/commit/7d9303b3977d455da7f21256061eaa3ab843883b))
* **deps:** bump the small-safe-packages group with 6 updates ([#2470](https://github.com/tambo-ai/tambo/issues/2470)) ([cb48c28](https://github.com/tambo-ai/tambo/commit/cb48c281b78b64e2e2352fd52007984681fb5ab6))
* enable monorepo hot reload DX ([#2427](https://github.com/tambo-ai/tambo/issues/2427)) ([c72bb66](https://github.com/tambo-ai/tambo/commit/c72bb663b86f3a751064cf5a87db84d250a7462c))

## [1.28.0](https://github.com/tambo-ai/tambo/compare/docs-v1.27.1...docs-v1.28.0) (2026-02-20)


### Features

* **core:** add Claude Opus 4.6 and Sonnet 4.6 to available models ([#2439](https://github.com/tambo-ai/tambo/issues/2439)) ([b421a94](https://github.com/tambo-ai/tambo/commit/b421a9428eabd78a4aa9a0bb5bea8a83cd90a5fb))


### Bug Fixes

* **api:** resolve opaque OAuth tokens via userinfo endpoint ([#2440](https://github.com/tambo-ai/tambo/issues/2440)) ([2380f0c](https://github.com/tambo-ai/tambo/commit/2380f0cd40659072ce8e0a5e7b1c7108cf1d6aeb))


### Miscellaneous Chores

* **deps:** bump @tambo-ai/typescript-sdk from 0.91.0 to 0.92.0 in the tambo-ai group ([#2337](https://github.com/tambo-ai/tambo/issues/2337)) ([97dcd7d](https://github.com/tambo-ai/tambo/commit/97dcd7dd70b8337da1bf957eaccff00b0b83a4ee))
* **deps:** bump the small-safe-packages group across 1 directory with 4 updates ([#2423](https://github.com/tambo-ai/tambo/issues/2423)) ([48a3aed](https://github.com/tambo-ai/tambo/commit/48a3aed15bf01e61d6422c18ad0b7d6a4c399285))

## [1.27.1](https://github.com/tambo-ai/tambo/compare/docs-v1.27.0...docs-v1.27.1) (2026-02-13)


### Documentation

* **self-hosting:** break up SELF-HOSTING.md into docs site guide section ([#2387](https://github.com/tambo-ai/tambo/issues/2387)) ([2fdb145](https://github.com/tambo-ai/tambo/commit/2fdb145cd41f95a67dc29bfd390d6a2018f6ed05))

## [1.27.0](https://github.com/tambo-ai/tambo/compare/docs-v1.26.3...docs-v1.27.0) (2026-02-11)


### Features

* **cli:** auto-initialize git and run tambo init by default ([#2383](https://github.com/tambo-ai/tambo/issues/2383)) ([a086a5c](https://github.com/tambo-ai/tambo/commit/a086a5ce2e0a0478202689a56e96e3e814f4c775))

## [1.26.3](https://github.com/tambo-ai/tambo/compare/docs-v1.26.2...docs-v1.26.3) (2026-02-11)


### Miscellaneous Chores

* remove cd into tambo app from quickstart ([#2380](https://github.com/tambo-ai/tambo/issues/2380)) ([3bf12cd](https://github.com/tambo-ai/tambo/commit/3bf12cd76fbecf519ed7258d1c4399a0969ffd5d))

## [1.26.2](https://github.com/tambo-ai/tambo/compare/docs-v1.26.1...docs-v1.26.2) (2026-02-11)


### Bug Fixes

* **react-ui-base:** preserve MAX_IMAGES and IS_PASTED_IMAGE in build output ([#2371](https://github.com/tambo-ai/tambo/issues/2371)) ([dc6d5e5](https://github.com/tambo-ai/tambo/commit/dc6d5e5a1714641890ef1fd6dbb7bcdbcc54a521))

## [1.26.1](https://github.com/tambo-ai/tambo/compare/docs-v1.26.0...docs-v1.26.1) (2026-02-10)


### Features

* **cli:** add Vite support — Tailwind v4 toolchain, framework detection, and Vite template ([#2322](https://github.com/tambo-ai/tambo/issues/2322)) ([5b544ac](https://github.com/tambo-ai/tambo/commit/5b544acb960e7869600411f7d300f6422aca05de))


### Miscellaneous Chores

* bump to typescript-sdk 0.92 ([#2334](https://github.com/tambo-ai/tambo/issues/2334)) ([3767c6c](https://github.com/tambo-ai/tambo/commit/3767c6c0e12c9862afd992b6f18bc3338ea4201d))
* **docs:** add package description ([#2308](https://github.com/tambo-ai/tambo/issues/2308)) ([1352c50](https://github.com/tambo-ai/tambo/commit/1352c50179b17c49f7f7186dc8bdcad1b0b4f13c))
* **docs:** update doc content to reflect sdk updates ([#2356](https://github.com/tambo-ai/tambo/issues/2356)) ([05d6cda](https://github.com/tambo-ai/tambo/commit/05d6cdafde2fcd73a13222a1acb6d546f57bca5d))


### Documentation

* **docs:** finalize v1 SDK documentation for 1.0 release ([#2327](https://github.com/tambo-ai/tambo/issues/2327)) ([a63c1a7](https://github.com/tambo-ai/tambo/commit/a63c1a79972cece79f0c22462084b201b1fad1c8))


### Code Refactoring

* **react-sdk:** promote V1 SDK to main export (1.0.0-rc.1) ([#2297](https://github.com/tambo-ai/tambo/issues/2297)) ([1799bce](https://github.com/tambo-ai/tambo/commit/1799bceecf412d1a4f263108dae75ddcb3fe7491))

## [1.26.0](https://github.com/tambo-ai/tambo/compare/docs-v1.25.0...docs-v1.26.0) (2026-02-07)


### Features

* **web:** move dashboard from /dashboard to root path ([#2232](https://github.com/tambo-ai/tambo/issues/2232)) ([9aec81d](https://github.com/tambo-ai/tambo/commit/9aec81d5e3017d4de5eb83d020bad4a9d401d70f))


### Bug Fixes

* **docs:** add CI validation for docs.tambo.co links and fix broken links ([#2136](https://github.com/tambo-ai/tambo/issues/2136)) ([6a9ba62](https://github.com/tambo-ai/tambo/commit/6a9ba62cffc42b0b5bc2f646f6ec0b8e3eb394ea))


### Miscellaneous Chores

* **deps-dev:** bump @types/node from 22.19.7 to 22.19.8 ([#2249](https://github.com/tambo-ai/tambo/issues/2249)) ([aed1ae6](https://github.com/tambo-ai/tambo/commit/aed1ae6a83a35f74e3c4d919f5ee266206711880))
* **deps:** bump @tambo-ai/typescript-sdk from 0.88.0 to 0.89.0 in the tambo-ai group ([#2245](https://github.com/tambo-ai/tambo/issues/2245)) ([aec371a](https://github.com/tambo-ai/tambo/commit/aec371aa99da5b6e75129038278c19d25f3c3462))
* **deps:** bump tailwind-merge from 2.6.0 to 2.6.1 in the tailwind group ([#2247](https://github.com/tambo-ai/tambo/issues/2247)) ([723185c](https://github.com/tambo-ai/tambo/commit/723185cc510bbe164677e7e371924cb1cfc24c0e))


### Documentation

* **react-sdk:** add v1 migration guide ([#2221](https://github.com/tambo-ai/tambo/issues/2221)) ([e9cb197](https://github.com/tambo-ai/tambo/commit/e9cb197ca18a8270a9602cc0aefc0d0b2b2f491f))
* **react-sdk:** update V1 SDK reference for new features ([#2292](https://github.com/tambo-ai/tambo/issues/2292)) ([f285d75](https://github.com/tambo-ai/tambo/commit/f285d755bdb3a877d6db08166aeed51894cdb97d))

## [1.25.0](https://github.com/tambo-ai/tambo/compare/docs-v1.24.0...docs-v1.25.0) (2026-02-05)


### Features

* **skills:** add skills.sh integration and new integration skills ([#2214](https://github.com/tambo-ai/tambo/issues/2214)) ([640ea08](https://github.com/tambo-ai/tambo/commit/640ea0817fc8b0f2095559f26dd49feb1bd619e3))


### Bug Fixes

* **api:** remove deprecated claude models ([#2197](https://github.com/tambo-ai/tambo/issues/2197)) ([fa37182](https://github.com/tambo-ai/tambo/commit/fa37182eb0b7e7cdd7acc3a76fa7c9a0273bb877))
* **docs:** keep chat close button on-screen ([#2083](https://github.com/tambo-ai/tambo/issues/2083)) ([15929cc](https://github.com/tambo-ai/tambo/commit/15929cc49b9b50db5769110ce5fd3f2b6a8787aa))
* **docs:** remove extra border from code blocks ([#2164](https://github.com/tambo-ai/tambo/issues/2164)) ([4fa5448](https://github.com/tambo-ai/tambo/commit/4fa54480307da4e64edae3371739c329f0fa1b75))


### Miscellaneous Chores

* **deps-dev:** bump @types/node from 22.19.5 to 22.19.7 ([#2181](https://github.com/tambo-ai/tambo/issues/2181)) ([2dbb652](https://github.com/tambo-ai/tambo/commit/2dbb652293255c5f1baf370a87c0760567eb441e))
* **deps:** bump the small-safe-packages group with 4 updates ([#2161](https://github.com/tambo-ai/tambo/issues/2161)) ([5e4022e](https://github.com/tambo-ai/tambo/commit/5e4022e5697e8607abc0b85a9b28f96f4260ba31))
* **deps:** bump typescript sdk to 0.89 ([#2203](https://github.com/tambo-ai/tambo/issues/2203)) ([22130d4](https://github.com/tambo-ai/tambo/commit/22130d4cfe7951343bea660e8f64f2a2161fd38a))


### Documentation

* **cli:** add agent-friendly and non-interactive mode documentation ([#2102](https://github.com/tambo-ai/tambo/issues/2102)) ([8327a63](https://github.com/tambo-ai/tambo/commit/8327a637207818022cdc0ffb0ad51c62b02dc9d9))
* **react-sdk:** add React SDK 1.0 (coming soon) reference section ([#2192](https://github.com/tambo-ai/tambo/issues/2192)) ([3471f2c](https://github.com/tambo-ai/tambo/commit/3471f2c943822e67104cb546c4a88eacc272492b))

## [1.24.0](https://github.com/tambo-ai/tambo/compare/docs-v1.23.1...docs-v1.24.0) (2026-01-30)


### Features

* add gpt-5.2 to models list ([#1978](https://github.com/tambo-ai/tambo/issues/1978)) ([edd9ad9](https://github.com/tambo-ai/tambo/commit/edd9ad9605188d90406978505abaf801c44ea410))
* **react-sdk:** implement v1 API Phase 9-10 with userKey and API cleanup ([#2032](https://github.com/tambo-ai/tambo/issues/2032)) ([9e055ab](https://github.com/tambo-ai/tambo/commit/9e055abddab6390498e5f2c6cb1224efbb556dfc))
* **react-sdk:** implement v1 API Phases 6-7 with code review fixes ([#1954](https://github.com/tambo-ai/tambo/issues/1954)) ([9a7e098](https://github.com/tambo-ai/tambo/commit/9a7e098e0f969ec1512d6705c020dc46f625ac95))


### Bug Fixes

* set valid `reasoningEffort` for openAI models ([#1965](https://github.com/tambo-ai/tambo/issues/1965)) ([daf6c34](https://github.com/tambo-ai/tambo/commit/daf6c34c6afc6f2cafd764d21775bcc03dcedc76))


### Miscellaneous Chores

* **deps:** bump the small-safe-packages group with 10 updates ([#1932](https://github.com/tambo-ai/tambo/issues/1932)) ([66f8ee8](https://github.com/tambo-ai/tambo/commit/66f8ee83adbcdb8c64d5c85159bc6574d4166f7b))
* **docs:** Organize reference section ([#1916](https://github.com/tambo-ai/tambo/issues/1916)) ([46154a5](https://github.com/tambo-ai/tambo/commit/46154a5fd22525f9d6dc601119d09c8f8909d841))

## [1.23.1](https://github.com/tambo-ai/tambo/compare/docs-v1.23.0...docs-v1.23.1) (2026-01-22)


### Miscellaneous Chores

* **docs:** Split concepts into explanations and guides  ([#1747](https://github.com/tambo-ai/tambo/issues/1747)) ([a2cc494](https://github.com/tambo-ai/tambo/commit/a2cc4940d8a924e62c6cbfd07c849b503ec4eef1))
* **react:** bump to new @tambo-ai/typescript-sdk ([#1864](https://github.com/tambo-ai/tambo/issues/1864)) ([7643415](https://github.com/tambo-ai/tambo/commit/76434157aeaa2f4fb6501702403262025614931b))
* **sdk:** Bump again: get SSE streaming types ([#1870](https://github.com/tambo-ai/tambo/issues/1870)) ([e6fbb44](https://github.com/tambo-ai/tambo/commit/e6fbb4432bc3ba07fe8b660206a1c514ffb98ea8))

## [1.23.0](https://github.com/tambo-ai/tambo/compare/docs-v1.22.0...docs-v1.23.0) (2026-01-21)


### Features

* **analytics:** PostHog cross-subdomain tracking (Phase 1) ([#1842](https://github.com/tambo-ai/tambo/issues/1842)) ([ed80eb0](https://github.com/tambo-ai/tambo/commit/ed80eb0c6a6d15a4be844ff895f983788a6d9fba))
* **docs:** Implement middleware to serve markdown when `Accept` prefers ([#1766](https://github.com/tambo-ai/tambo/issues/1766)) ([286ccd3](https://github.com/tambo-ai/tambo/commit/286ccd39040f08e2dc4972c9e8bb8038ae54b4d4))
* **models:** add Cerebras AI provider support ([#1795](https://github.com/tambo-ai/tambo/issues/1795)) ([21650bb](https://github.com/tambo-ai/tambo/commit/21650bbd3f706f4a1cf04ae5b42536edb57ff8ce))


### Miscellaneous Chores

* **deps:** bump the small-safe-packages group with 8 updates ([#1831](https://github.com/tambo-ai/tambo/issues/1831)) ([a5965b4](https://github.com/tambo-ai/tambo/commit/a5965b4f9d1cf502eaf185cc8b1e26a93f847de0))

## [1.22.0](https://github.com/tambo-ai/tambo/compare/docs-v1.21.1...docs-v1.22.0) (2026-01-07)


### Features

* **api:** remove non-streaming advance thread endpoints ([#1648](https://github.com/tambo-ai/tambo/issues/1648)) ([3802c8d](https://github.com/tambo-ai/tambo/commit/3802c8deb24e8b72140656418b5e5f0549bbf228))


### Miscellaneous Chores

* **deps:** bump framer-motion from 12.23.24 to 12.23.26 ([#1644](https://github.com/tambo-ai/tambo/issues/1644)) ([34cc795](https://github.com/tambo-ai/tambo/commit/34cc795100121f8b1a4469b9a34a3113ba7bd424))
* **deps:** bump posthog-js from 1.310.1 to 1.311.0 in the small-safe-packages group across 1 directory ([#1636](https://github.com/tambo-ai/tambo/issues/1636)) ([67d8ba3](https://github.com/tambo-ai/tambo/commit/67d8ba3fdbf22a25e91d0ed624e4ca7272f6b2dd))
* **deps:** bump the small-safe-packages group with 2 updates ([#1629](https://github.com/tambo-ai/tambo/issues/1629)) ([7655ca7](https://github.com/tambo-ai/tambo/commit/7655ca77bfa5843e30c0d1447cc705c572c5fe41))
* **deps:** bump the small-safe-packages group with 2 updates ([#1641](https://github.com/tambo-ai/tambo/issues/1641)) ([154b264](https://github.com/tambo-ai/tambo/commit/154b2647a3ba3ee836a521d4a23a20e80d68e497))
* **deps:** bump the small-safe-packages group with 5 updates ([#1614](https://github.com/tambo-ai/tambo/issues/1614)) ([0f9843b](https://github.com/tambo-ai/tambo/commit/0f9843beae591605144054a7b17f1c9ad9830857))

## [1.21.1](https://github.com/tambo-ai/tambo/compare/docs-v1.21.0...docs-v1.21.1) (2025-12-17)


### Bug Fixes

* **react-sdk:** update tests and components for contextKey refactor ([#1575](https://github.com/tambo-ai/tambo/issues/1575)) ([2e0ddcc](https://github.com/tambo-ai/tambo/commit/2e0ddccac6d946a82e461398a414e74a8993cb5f))


### Miscellaneous Chores

* add LICENSE files across workspaces ([#1532](https://github.com/tambo-ai/tambo/issues/1532)) ([6e41be5](https://github.com/tambo-ai/tambo/commit/6e41be55b85be629f9b23d5688d058ccd2bd57f8))
* **deps:** Bump @tambo-ai/typescript-sdk to get tool maxCalls ([#1533](https://github.com/tambo-ai/tambo/issues/1533)) ([97e85ba](https://github.com/tambo-ai/tambo/commit/97e85ba0eb334a8b3b482a0cff368d2528b91d74))
* **deps:** bump dompurify from 3.3.0 to 3.3.1 ([#1555](https://github.com/tambo-ai/tambo/issues/1555)) ([cbc3328](https://github.com/tambo-ai/tambo/commit/cbc332845171e87d4f04c11429af8acbf1e4b0d3))
* **deps:** bump the next group with 2 updates ([#1543](https://github.com/tambo-ai/tambo/issues/1543)) ([86e399f](https://github.com/tambo-ai/tambo/commit/86e399fbb3b10aacfb626af96bfd0e5880e1d78a))
* **deps:** bump the small-safe-packages group with 3 updates ([#1546](https://github.com/tambo-ai/tambo/issues/1546)) ([462d2c8](https://github.com/tambo-ai/tambo/commit/462d2c8f23f11512ccd3de6caa89c6d9cbb5bf69))
* don't show EditWithTamboButton when component is in thread ([#1519](https://github.com/tambo-ai/tambo/issues/1519)) ([5e814e4](https://github.com/tambo-ai/tambo/commit/5e814e4c439f4f4869614035dcf61a9684d16689))
* remove tambo-cloud directory after migration ([#1521](https://github.com/tambo-ai/tambo/issues/1521)) ([686dde6](https://github.com/tambo-ai/tambo/commit/686dde6fcc1f612b092d750359ac1f1b56055d9b))


### Documentation

* clarify per-user auth and MCP server auth ([#1517](https://github.com/tambo-ai/tambo/issues/1517)) ([5030748](https://github.com/tambo-ai/tambo/commit/5030748fbf056768b6dcdf7b5536762a1d5f86f4))
* use relative internal docs links ([#1523](https://github.com/tambo-ai/tambo/issues/1523)) ([c3e4b1a](https://github.com/tambo-ai/tambo/commit/c3e4b1a47ebb01d6710165fdc932119ca693aed9))

## [1.21.0](https://github.com/tambo-ai/tambo/compare/docs-v1.20.0...docs-v1.21.0) (2025-12-11)


### Features

* integrate EditWithTambo component for inline component editing ([#1477](https://github.com/tambo-ai/tambo/issues/1477)) ([390c204](https://github.com/tambo-ai/tambo/commit/390c2045148c63dfb85f1988861e1cf6ad7f021e))
* **react-sdk:** add local resource registration to TamboRegistryProvider ([#1504](https://github.com/tambo-ai/tambo/issues/1504)) ([59c94a9](https://github.com/tambo-ai/tambo/commit/59c94a9214c165cbc6728d5a17f39697e4d4c370))


### Bug Fixes

* **resources:** Make sure to show resource names in text editor and user messages ([#1497](https://github.com/tambo-ai/tambo/issues/1497)) ([b2d8013](https://github.com/tambo-ai/tambo/commit/b2d8013c0b4bf5fbf7801eca20e97fcf98b5ae55))


### Miscellaneous Chores

* **deps:** bump the small-safe-packages group with 3 updates ([#1487](https://github.com/tambo-ai/tambo/issues/1487)) ([2178c32](https://github.com/tambo-ai/tambo/commit/2178c32ed7c962a915aa80694cc8e3c4a7f434ba))


### Documentation

* **cli:** document useMergeRefs React 19 cleanup ([#1470](https://github.com/tambo-ai/tambo/issues/1470)) ([e215716](https://github.com/tambo-ai/tambo/commit/e21571673b4c92c6fedbb6e74dceb27b921d0a19))
* **docs:** strengthen metadata for key docs pages (TAM-768) ([#1474](https://github.com/tambo-ai/tambo/issues/1474)) ([1343592](https://github.com/tambo-ai/tambo/commit/13435921864af1a9c8e608bfc552747738f59bd5))
* **mcp:** add comprehensive resources and prompts documentation ([#1501](https://github.com/tambo-ai/tambo/issues/1501)) ([3973dcc](https://github.com/tambo-ai/tambo/commit/3973dccf62cfec63eae3a655be94acbfb55db314))

## [1.20.0](https://github.com/tambo-ai/tambo/compare/docs-v1.19.1...docs-v1.20.0) (2025-12-08)


### Features

* add claude opus 4.5 ([#1444](https://github.com/tambo-ai/tambo/issues/1444)) ([d581560](https://github.com/tambo-ai/tambo/commit/d581560597e810f0d88c6b357a2cdb75e727f9eb))


### Bug Fixes

* **deps:** upgrade to zod v3 subpath imports and MCP SDK 1.24 ([#1465](https://github.com/tambo-ai/tambo/issues/1465)) ([c8b7f07](https://github.com/tambo-ai/tambo/commit/c8b7f079560d423082c005018a103b9eb3cf6993))
* **docs:** add canonical URLs for docs.tambo.co pages ([#1454](https://github.com/tambo-ai/tambo/issues/1454)) ([ce01815](https://github.com/tambo-ai/tambo/commit/ce0181585e3304f7f6e738845410d43af440b459))
* **react-sdk,docs:** address streaming docs review feedback ([#1459](https://github.com/tambo-ai/tambo/issues/1459)) ([3fb4ed2](https://github.com/tambo-ai/tambo/commit/3fb4ed269c8ad13bd04c142743c2268ae8a29fec))


### Miscellaneous Chores

* **deps:** Bump @tambo-ai/typescript-sdk to get updated enum ([#1445](https://github.com/tambo-ai/tambo/issues/1445)) ([7bee1f3](https://github.com/tambo-ai/tambo/commit/7bee1f32b7864d381eb2b5f346ec050ed61358a3))
* **deps:** bump next from 15.5.6 to 15.5.7 ([#1473](https://github.com/tambo-ai/tambo/issues/1473)) ([d8c7f1e](https://github.com/tambo-ai/tambo/commit/d8c7f1e0e8bab619daccf774822c421891ac3e5f))
* **deps:** bump the small-safe-packages group with 5 updates ([#1436](https://github.com/tambo-ai/tambo/issues/1436)) ([5974a87](https://github.com/tambo-ai/tambo/commit/5974a87c06577da92cd6ef9a500ebc9226f46fec))


### Documentation

* **docs:** standardize core docs headings for SEO ([#1456](https://github.com/tambo-ai/tambo/issues/1456)) ([3bc7333](https://github.com/tambo-ai/tambo/commit/3bc73331980ed0d8f459bafc0a773ef8fca51ef9))
* **react-sdk:** document streaming components pattern ([#1457](https://github.com/tambo-ai/tambo/issues/1457)) ([d0beb5a](https://github.com/tambo-ai/tambo/commit/d0beb5a9efe992137407c00481f342d38be9c293))

## [1.19.1](https://github.com/tambo-ai/tambo/compare/docs-v1.19.0...docs-v1.19.1) (2025-11-22)


### Documentation

* update MCP provider API usage to reflect v0.65.0 changes ([#1332](https://github.com/tambo-ai/tambo/issues/1332)) ([4dc2cc2](https://github.com/tambo-ai/tambo/commit/4dc2cc22a3d8b141c57fa8439b1f478b15ed4b9c))

## [1.19.0](https://github.com/tambo-ai/tambo/compare/docs-v1.18.0...docs-v1.19.0) (2025-11-20)


### Features

* **mcp-resources:** Handle inline mcp resource references with correct prefix behavior, transforming to resource content nodes ([#1308](https://github.com/tambo-ai/tambo/issues/1308)) ([ae90e4a](https://github.com/tambo-ai/tambo/commit/ae90e4af67ea732dac7b795ba3ed873701e2cca8))
* merge cloud repo into mono repo ([#1314](https://github.com/tambo-ai/tambo/issues/1314)) ([6b88f60](https://github.com/tambo-ai/tambo/commit/6b88f609b3b7ba1b243a2be9a4bb426038e9e596))


### Miscellaneous Chores

* **deps-dev:** bump the eslint group with 4 updates ([#1299](https://github.com/tambo-ai/tambo/issues/1299)) ([a5a7ecd](https://github.com/tambo-ai/tambo/commit/a5a7ecddb7e8fada5d4abf5ac4fd516e24d67b85))
* **deps-dev:** bump the eslint group with 4 updates ([#1299](https://github.com/tambo-ai/tambo/issues/1299)) ([3287eaf](https://github.com/tambo-ai/tambo/commit/3287eaf83e6068fe5d2e0774506da3acf29eeba3))
* **deps:** bump @modelcontextprotocol/sdk from 1.21.1 to 1.22.0 ([#1307](https://github.com/tambo-ai/tambo/issues/1307)) ([1242270](https://github.com/tambo-ai/tambo/commit/1242270c2e4949e2b4e342ed12da99dc29086a67))
* **deps:** bump @modelcontextprotocol/sdk from 1.21.1 to 1.22.0 ([#1307](https://github.com/tambo-ai/tambo/issues/1307)) ([3351269](https://github.com/tambo-ai/tambo/commit/3351269f793be2ef261de55f979f32d672f2b6eb))
* **deps:** bump the small-safe-packages group with 7 updates ([#1319](https://github.com/tambo-ai/tambo/issues/1319)) ([5dfadc0](https://github.com/tambo-ai/tambo/commit/5dfadc07e9a13fcae9569cf5d939aa81a459df36))

## [1.18.0](https://github.com/tambo-ai/tambo/compare/docs-v1.17.0...docs-v1.18.0) (2025-11-05)


### Features

* add tambo context attachment provider ([#1258](https://github.com/tambo-ai/tambo/issues/1258)) ([eb20883](https://github.com/tambo-ai/tambo/commit/eb2088322ff4a3d1efabd5621cf29e6f9563e963))


### Bug Fixes

* **mcp:** Update default transport type from SSE to HTTP for MCP ([#1250](https://github.com/tambo-ai/tambo/issues/1250)) ([679f508](https://github.com/tambo-ai/tambo/commit/679f508a38b1c77eb643712d97a3c5da039b682a))


### Miscellaneous Chores

* **lint:** Proactively fix some React 19 issues ([#1251](https://github.com/tambo-ai/tambo/issues/1251)) ([b1984ed](https://github.com/tambo-ai/tambo/commit/b1984ed6d97631f342677826232a10fb0a87cd51))


### Documentation

* add prop syncing guidance for interactable components ([#1133](https://github.com/tambo-ai/tambo/issues/1133)) ([0c53d23](https://github.com/tambo-ai/tambo/commit/0c53d23b52bb944bd009854cdcb0e4addeabe97d))


### Code Refactoring

* optimize currentIds lookup and ignore generated sitemaps ([#1262](https://github.com/tambo-ai/tambo/issues/1262)) ([48ad0f6](https://github.com/tambo-ai/tambo/commit/48ad0f68aba709975747d0122b5396154750a889))

## [1.17.0](https://github.com/tambo-ai/tambo/compare/docs-v1.16.0...docs-v1.17.0) (2025-11-04)


### Features

* **ui:** Update Design Token Usage in Component Library ([#1221](https://github.com/tambo-ai/tambo/issues/1221)) ([b2d16f6](https://github.com/tambo-ai/tambo/commit/b2d16f67df80a6cf28cfbec66a5e76d9297cf131))


### Bug Fixes

* **docs:** Migrate to Tailwind CSS v4 ([#1222](https://github.com/tambo-ai/tambo/issues/1222)) ([253af21](https://github.com/tambo-ai/tambo/commit/253af21b900ccd837d959abc1d7a09729716b11a))
* **docs:** revive mermaid charts ([#1230](https://github.com/tambo-ai/tambo/issues/1230)) ([41c774d](https://github.com/tambo-ai/tambo/commit/41c774d080bf26208c260d3b044cac17df7c7259))
* fix broken mcp links ([#1249](https://github.com/tambo-ai/tambo/issues/1249)) ([78d2f56](https://github.com/tambo-ai/tambo/commit/78d2f5602e975a82d4520941ef76336b17d9508a))


### Miscellaneous Chores

* **deps:** bump @tambo-ai/typescript-sdk from 0.75.1 to 0.76.0 ([#1241](https://github.com/tambo-ai/tambo/issues/1241)) ([62d792e](https://github.com/tambo-ai/tambo/commit/62d792e38cd34832e729219a4f1ea28424d85433))
* **deps:** bump lucide-react from 0.546.0 to 0.548.0 ([#1242](https://github.com/tambo-ai/tambo/issues/1242)) ([5824e0b](https://github.com/tambo-ai/tambo/commit/5824e0b1a8c6362cb476ee62959748ea85c31953))
* **deps:** bump mermaid from 11.12.0 to 11.12.1 ([#1243](https://github.com/tambo-ai/tambo/issues/1243)) ([2d969f1](https://github.com/tambo-ai/tambo/commit/2d969f1aaa7d2d9e7af43d0db4c21b7cec5cb76e))
* **deps:** bump posthog-js from 1.280.1 to 1.282.0 ([#1244](https://github.com/tambo-ai/tambo/issues/1244)) ([bbe1389](https://github.com/tambo-ai/tambo/commit/bbe1389aa0a7b6cabab75325a02c6a9ef0ce7101))


### Documentation

* **mcp-features:** Add docs for Prompts and Sampling ([#1247](https://github.com/tambo-ai/tambo/issues/1247)) ([599faaf](https://github.com/tambo-ai/tambo/commit/599faaf4ad7669423a4f9d89dc5758c7b3917c42))
* **mcp:** Add section on MCP elicitation ([#1231](https://github.com/tambo-ai/tambo/issues/1231)) ([64a564c](https://github.com/tambo-ai/tambo/commit/64a564c3f07792e3c5a4ef60239ef60baebb38d0))
* **mcp:** Add some structure to existing MCP pages ([#1236](https://github.com/tambo-ai/tambo/issues/1236)) ([4921921](https://github.com/tambo-ai/tambo/commit/4921921afff73e54f39bd0792e284c9e3f620c67))

## [1.16.0](https://github.com/tambo-ai/tambo/compare/docs-v1.15.0...docs-v1.16.0) (2025-10-31)


### Features

* add context badge for images ([#1192](https://github.com/tambo-ai/tambo/issues/1192)) ([020cd5e](https://github.com/tambo-ai/tambo/commit/020cd5e19285921bf0ef3086d3d84777bf694685))


### Bug Fixes

* run transformToContent for streaming requests too ([#1184](https://github.com/tambo-ai/tambo/issues/1184)) ([42d8a82](https://github.com/tambo-ai/tambo/commit/42d8a82eff25836d021480ff3b9ca0fb3b9793cb))


### Miscellaneous Chores

* **config:** Align tsconfigs and eslint configs between docs, showcase, and base ([#1216](https://github.com/tambo-ai/tambo/issues/1216)) ([ab61266](https://github.com/tambo-ai/tambo/commit/ab61266f89f14084d9f9f8abc2098bc3a3cb3adf))
* **deps-dev:** bump @tailwindcss/postcss from 4.1.14 to 4.1.16 in the tailwind group ([#1204](https://github.com/tambo-ai/tambo/issues/1204)) ([352b252](https://github.com/tambo-ai/tambo/commit/352b252d5152d500dd87168002524f6219df0984))
* **deps:** bump @tambo-ai/typescript-sdk from 0.75.0 to 0.75.1 ([#1208](https://github.com/tambo-ai/tambo/issues/1208)) ([76640d7](https://github.com/tambo-ai/tambo/commit/76640d7eab0202555ba699039152be7b656d40ef))
* **deps:** bump posthog-js from 1.276.0 to 1.280.1 ([#1200](https://github.com/tambo-ai/tambo/issues/1200)) ([c7886ad](https://github.com/tambo-ai/tambo/commit/c7886adaf96e654c175534082682676b29bfbb8f))
* **docs:** add callouts for interactable components registration ([#1213](https://github.com/tambo-ai/tambo/issues/1213)) ([1bdd145](https://github.com/tambo-ai/tambo/commit/1bdd145788d6738c5f0e24896400ff45188be637))
* update CLAUDE.md files to reference AGENTS.md properly ([#1214](https://github.com/tambo-ai/tambo/issues/1214)) ([22d6ea2](https://github.com/tambo-ai/tambo/commit/22d6ea28fd18c073b3f739d901121bb1e1e59e31))

## [1.15.0](https://github.com/tambo-ai/tambo/compare/docs-v1.14.0...docs-v1.15.0) (2025-10-21)


### Features

* **sdk:** Add client-side transformToContent callback in tool registration ([#1169](https://github.com/tambo-ai/tambo/issues/1169)) ([651dc01](https://github.com/tambo-ai/tambo/commit/651dc01649e17fce4bcfb778a041e7b7ef830dbf))


### Miscellaneous Chores

* **deps:** bump @tambo-ai/typescript-sdk from 0.73.0 to 0.75.0 ([#1179](https://github.com/tambo-ai/tambo/issues/1179)) ([e781957](https://github.com/tambo-ai/tambo/commit/e781957a758cdd3f5e820b24f8fe9266b3c86baf))
* **deps:** bump dompurify from 3.2.7 to 3.3.0 ([#1175](https://github.com/tambo-ai/tambo/issues/1175)) ([ffd2ec1](https://github.com/tambo-ai/tambo/commit/ffd2ec1b2eb56eaf92f2d7eb68a9529cc3da4f92))
* **deps:** bump framer-motion from 12.23.22 to 12.23.24 ([#1160](https://github.com/tambo-ai/tambo/issues/1160)) ([6dab68f](https://github.com/tambo-ai/tambo/commit/6dab68f916d255174b37c09c041ede244f9f8c4a))
* **deps:** bump lucide-react from 0.545.0 to 0.546.0 ([#1174](https://github.com/tambo-ai/tambo/issues/1174)) ([49dc23f](https://github.com/tambo-ai/tambo/commit/49dc23f7ae1b0d4a88a2cea38aaccab189afa023))
* **deps:** bump posthog-js from 1.273.1 to 1.274.1 ([#1157](https://github.com/tambo-ai/tambo/issues/1157)) ([49445c2](https://github.com/tambo-ai/tambo/commit/49445c267806909c7546d6d452ff94aea8a8e8bc))
* **deps:** bump posthog-js from 1.274.1 to 1.276.0 ([#1173](https://github.com/tambo-ai/tambo/issues/1173)) ([6baf8ce](https://github.com/tambo-ai/tambo/commit/6baf8ce4da39ed9de0223ca74dcb8aaf3358d730))
* **deps:** bump streamdown from 1.3.0 to 1.4.0 ([#1181](https://github.com/tambo-ai/tambo/issues/1181)) ([441d3e0](https://github.com/tambo-ai/tambo/commit/441d3e0587d71fdfb63f2365c52d0aa88bfdbb21))
* **deps:** bump the next group with 2 updates ([#1172](https://github.com/tambo-ai/tambo/issues/1172)) ([61f92b6](https://github.com/tambo-ai/tambo/commit/61f92b6ee158f8f8b62f316d7c138937d851d132))


### Code Refactoring

* **message:** simplify tool call request retrieval and enhance status message handling ([#1152](https://github.com/tambo-ai/tambo/issues/1152)) ([c866b67](https://github.com/tambo-ai/tambo/commit/c866b674e8fcc8524cf0de9e347902ac31efe81f))

## [1.14.0](https://github.com/tambo-ai/tambo/compare/docs-v1.13.1...docs-v1.14.0) (2025-10-09)


### Features

* initial messages ([#1000](https://github.com/tambo-ai/tambo/issues/1000)) ([7d7a52a](https://github.com/tambo-ai/tambo/commit/7d7a52ab45f8d230b428cb83cace36cc1037152f))


### Bug Fixes

* **ui:** text pasting in the message input and update message component to use role instead of actionType ([#1139](https://github.com/tambo-ai/tambo/issues/1139)) ([48b9e5a](https://github.com/tambo-ai/tambo/commit/48b9e5ae11040f86a4a558c3c89e0b22bb8a6af4))


### Miscellaneous Chores

* **deps:** bump @tambo-ai/typescript-sdk from 0.72.1 to 0.73.0 ([#1146](https://github.com/tambo-ai/tambo/issues/1146)) ([47432e7](https://github.com/tambo-ai/tambo/commit/47432e735d7ed3f6d6c99ac1cb727e86936d9c88))
* **deps:** bump lucide-react from 0.544.0 to 0.545.0 ([#1145](https://github.com/tambo-ai/tambo/issues/1145)) ([dae817d](https://github.com/tambo-ai/tambo/commit/dae817d5e0eb279cbb5d0f0a1ed10e98d38bf93b))
* **deps:** bump posthog-js from 1.271.0 to 1.273.1 ([#1143](https://github.com/tambo-ai/tambo/issues/1143)) ([9bbdb3e](https://github.com/tambo-ai/tambo/commit/9bbdb3edd87c19d3a874ae07d463e09a3af3806e))
* **deps:** bump the fumadocs group with 2 updates ([#1142](https://github.com/tambo-ai/tambo/issues/1142)) ([69778e6](https://github.com/tambo-ai/tambo/commit/69778e63328a4e239d226e67e79fcbb02777f0be))

## [1.13.1](https://github.com/tambo-ai/tambo/compare/docs-v1.13.0...docs-v1.13.1) (2025-10-07)


### Miscellaneous Chores

* add reasoning documentation ([#1134](https://github.com/tambo-ai/tambo/issues/1134)) ([8dadfd9](https://github.com/tambo-ai/tambo/commit/8dadfd9ded5ee16fd267f40f5dcebff9d17cab56))
* **deps-dev:** bump the tailwind group with 2 updates ([#1126](https://github.com/tambo-ai/tambo/issues/1126)) ([0cb24a0](https://github.com/tambo-ai/tambo/commit/0cb24a0199da76e8283aafa7cf835c710c19db91))
* **deps-dev:** bump typescript from 5.9.2 to 5.9.3 ([#1132](https://github.com/tambo-ai/tambo/issues/1132)) ([94b23a4](https://github.com/tambo-ai/tambo/commit/94b23a47d2d347033a15a2232b7c04216c982ad3))
* **deps:** bump @tambo-ai/typescript-sdk from 0.72.0 to 0.72.1 ([#1129](https://github.com/tambo-ai/tambo/issues/1129)) ([8d8cf9f](https://github.com/tambo-ai/tambo/commit/8d8cf9f2fe5c0661a576f8f77192d8b9c20ca62f))
* **deps:** bump posthog-js from 1.261.8 to 1.271.0 ([#1130](https://github.com/tambo-ai/tambo/issues/1130)) ([c494411](https://github.com/tambo-ai/tambo/commit/c49441118f8ae5d573f3176b75443836583dda43))
* **deps:** bump the fumadocs group with 3 updates ([#1124](https://github.com/tambo-ai/tambo/issues/1124)) ([82a0757](https://github.com/tambo-ai/tambo/commit/82a0757dfa7f0211c466ba7156b43e44edecf49c))

## [1.13.0](https://github.com/tambo-ai/tambo/compare/docs-v1.12.1...docs-v1.13.0) (2025-10-02)


### Features

* add reasoning UI, smart autoscroll with UI improvements and update component paths to use /tambo ([#1101](https://github.com/tambo-ai/tambo/issues/1101)) ([9ec66c3](https://github.com/tambo-ai/tambo/commit/9ec66c37493eb636d5778e51ca8553ffb9982fc4))


### Miscellaneous Chores

* add agents.md & claude.md to monorepo. ([#1116](https://github.com/tambo-ai/tambo/issues/1116)) ([fe911d4](https://github.com/tambo-ai/tambo/commit/fe911d4613b301cf9a68a6a95ebc2b7a6a294dd5))
* **deps:** bump dompurify from 3.2.6 to 3.2.7 ([#1111](https://github.com/tambo-ai/tambo/issues/1111)) ([024a6ca](https://github.com/tambo-ai/tambo/commit/024a6ca703652cdb1b014ef293e6a07a4eea2269))
* **deps:** bump framer-motion from 12.23.12 to 12.23.22 ([#1107](https://github.com/tambo-ai/tambo/issues/1107)) ([3c0ab4b](https://github.com/tambo-ai/tambo/commit/3c0ab4b9875e2d12166fceb98915a8ef34505118))
* **deps:** bump lucide-react from 0.542.0 to 0.544.0 ([#1105](https://github.com/tambo-ai/tambo/issues/1105)) ([8b5a36b](https://github.com/tambo-ai/tambo/commit/8b5a36b772300f164351443dafe2692432981cff))
* **deps:** bump mermaid from 11.11.0 to 11.12.0 ([#1088](https://github.com/tambo-ai/tambo/issues/1088)) ([03ea0c3](https://github.com/tambo-ai/tambo/commit/03ea0c31b5547a9286314ee2ee3b9962b6b1f4b9))
* **deps:** bump next from 15.5.3 to 15.5.4 in the next group ([#1110](https://github.com/tambo-ai/tambo/issues/1110)) ([dd1a35d](https://github.com/tambo-ai/tambo/commit/dd1a35d669023d0440a885237e73d2109e247144))
* **deps:** bump streamdown from 1.2.0 to 1.3.0 ([#1093](https://github.com/tambo-ai/tambo/issues/1093)) ([761f213](https://github.com/tambo-ai/tambo/commit/761f213340ea0b611d8c712d1b5ca8fb744a8ace))
* **deps:** bump the fumadocs group with 2 updates ([#1109](https://github.com/tambo-ai/tambo/issues/1109)) ([74e09de](https://github.com/tambo-ai/tambo/commit/74e09de369a412b409d12e4d94888125ac1a1bf9))
* **deps:** bump the fumadocs group with 3 updates ([#1085](https://github.com/tambo-ai/tambo/issues/1085)) ([14f5e72](https://github.com/tambo-ai/tambo/commit/14f5e728988b9c03bbe0df1e6c04b15feb9ab6a2))

## [1.12.1](https://github.com/tambo-ai/tambo/compare/docs-v1.12.0...docs-v1.12.1) (2025-09-22)


### Miscellaneous Chores

* Add next-sitemap to docs sitemap to see ([#1083](https://github.com/tambo-ai/tambo/issues/1083)) ([9d500c5](https://github.com/tambo-ai/tambo/commit/9d500c5259cdf440630d3c113b432ed98c1838d6))

## [1.12.0](https://github.com/tambo-ai/tambo/compare/docs-v1.11.0...docs-v1.12.0) (2025-09-20)


### Features

* **docs:** add documentation for custom llm parameters ([#1071](https://github.com/tambo-ai/tambo/issues/1071)) ([fe64ca3](https://github.com/tambo-ai/tambo/commit/fe64ca3a71c9c1616a9269fe7b7a9ec878b1ce4d))


### Miscellaneous Chores

* **deps:** bump @tambo-ai/typescript-sdk to 0.72 for reasoning shape ([#1072](https://github.com/tambo-ai/tambo/issues/1072)) ([a103b5f](https://github.com/tambo-ai/tambo/commit/a103b5fa250b334edaa4d81ba8fe82d36995ae7c))

## [1.11.0](https://github.com/tambo-ai/tambo/compare/docs-v1.10.0...docs-v1.11.0) (2025-09-19)


### Features

* **sdk:** Update to the new "typescript sdk" from stainless ([#1061](https://github.com/tambo-ai/tambo/issues/1061)) ([22dd7e3](https://github.com/tambo-ai/tambo/commit/22dd7e392cbf005a2d8bb7f43a813d53eee51611))


### Miscellaneous Chores

* remove producthunt banners, bubbles and widget ([#1065](https://github.com/tambo-ai/tambo/issues/1065)) ([7ceff06](https://github.com/tambo-ai/tambo/commit/7ceff06f312e404a0e1d3c81efec569139e6f847))

## [1.10.0](https://github.com/tambo-ai/tambo/compare/docs-v1.9.0...docs-v1.10.0) (2025-09-17)


### Features

* **sdk:** partial updates for interactables + auto tools + new docs ([#1036](https://github.com/tambo-ai/tambo/issues/1036)) ([7352f12](https://github.com/tambo-ai/tambo/commit/7352f1274c399215bfc99b4bbd69b3db4b7364cc))


### Miscellaneous Chores

* **deps:** bump mermaid from 11.10.1 to 11.11.0 ([#1051](https://github.com/tambo-ai/tambo/issues/1051)) ([e3b3ce7](https://github.com/tambo-ai/tambo/commit/e3b3ce7fb3751165a86842ca770526eccce9a2ef))
* **deps:** bump next from 15.5.2 to 15.5.3 in the next group across 1 directory ([#1055](https://github.com/tambo-ai/tambo/issues/1055)) ([d21ecdb](https://github.com/tambo-ai/tambo/commit/d21ecdbc498ca018f2763b9f4f1df87fd2edafcc))
* **deps:** bump streamdown from 1.1.5 to 1.2.0 ([#1050](https://github.com/tambo-ai/tambo/issues/1050)) ([f78ae45](https://github.com/tambo-ai/tambo/commit/f78ae4545c1714df7a954ff513da47ef8bd8958e))
* **deps:** bump the fumadocs group with 3 updates ([#1045](https://github.com/tambo-ai/tambo/issues/1045)) ([70bd2dc](https://github.com/tambo-ai/tambo/commit/70bd2dceeb77fc0df89057400a40957e00b9e7ac))
* update sitemap to .co domain ([#1042](https://github.com/tambo-ai/tambo/issues/1042)) ([64b2da1](https://github.com/tambo-ai/tambo/commit/64b2da187dbbc1fda98953bedb3cfe84c6e83d66))


### Documentation

* use https://docs.tambo.co as default baseUrl in layout ([#1043](https://github.com/tambo-ai/tambo/issues/1043)) ([55aa89c](https://github.com/tambo-ai/tambo/commit/55aa89cdea368b8476820504b549ca562c504038))

## [1.9.0](https://github.com/tambo-ai/tambo/compare/docs-v1.8.0...docs-v1.9.0) (2025-09-12)


### Features

* **image:** add image attachment support ([#1001](https://github.com/tambo-ai/tambo/issues/1001)) ([5a8e9a2](https://github.com/tambo-ai/tambo/commit/5a8e9a2267801feb1d24dd43e3bacd4fcc368b53))
* Replace TamboHackBanner with ProductHuntBanner ([#1035](https://github.com/tambo-ai/tambo/issues/1035)) ([7af2f53](https://github.com/tambo-ai/tambo/commit/7af2f5394c5d3d85ee7e0ec03b4b767df946d249))

## [1.8.0](https://github.com/tambo-ai/tambo/compare/docs-v1.7.0...docs-v1.8.0) (2025-09-11)


### Features

* **sdk:** Add onCallUnregisteredTool callback for handling unexpected tool callbacks ([#1030](https://github.com/tambo-ai/tambo/issues/1030)) ([993405b](https://github.com/tambo-ai/tambo/commit/993405b6593b622f6ec755cf93d65c5272a49127))


### Bug Fixes

* **ui:** When tool calls are big, allow scrolling ([#1034](https://github.com/tambo-ai/tambo/issues/1034)) ([8149f6b](https://github.com/tambo-ai/tambo/commit/8149f6bd3f2513861bd699649a0500376388e0c4))


### Miscellaneous Chores

* **docs:** update sitemap domain to docs.tambo.co ([#1027](https://github.com/tambo-ai/tambo/issues/1027)) ([cfd5a7e](https://github.com/tambo-ai/tambo/commit/cfd5a7ea41dd0a7983bce825ccaec997e966a431))

## [1.7.0](https://github.com/tambo-ai/tambo/compare/docs-v1.6.0...docs-v1.7.0) (2025-09-09)


### Features

* add ask to tambo in the ai actions dropdown ([#993](https://github.com/tambo-ai/tambo/issues/993)) ([1b2882c](https://github.com/tambo-ai/tambo/commit/1b2882c8b64c58340551d065cba6500135a2f474))
* **cli:** add analytics template and update related commands and docs ([#978](https://github.com/tambo-ai/tambo/issues/978)) ([5431386](https://github.com/tambo-ai/tambo/commit/5431386a79d3933725c4d395bcf4548869a7c23f))
* **interactables:** Add automatic context injection for interactable components that sends their current state to the AI by default. ([#977](https://github.com/tambo-ai/tambo/issues/977)) ([bdec8f9](https://github.com/tambo-ai/tambo/commit/bdec8f9a3097d7bae52086b6ff0699e0e6759e12))


### Bug Fixes

* resolve ENOENT error during Vercel deployment ([#1019](https://github.com/tambo-ai/tambo/issues/1019)) ([f077236](https://github.com/tambo-ai/tambo/commit/f077236ca44a4b005e5309d4a647ade0597b5344))


### Miscellaneous Chores

* **deps-dev:** bump @tailwindcss/postcss from 4.1.12 to 4.1.13 in the tailwind group ([#1008](https://github.com/tambo-ai/tambo/issues/1008)) ([2aa0126](https://github.com/tambo-ai/tambo/commit/2aa01268b7bc7ec3702249e437cc8df8a6827587))
* **deps:** bump posthog-js from 1.261.0 to 1.261.8 ([#1011](https://github.com/tambo-ai/tambo/issues/1011)) ([fa139f3](https://github.com/tambo-ai/tambo/commit/fa139f335d731e98ac923268aebf2ee2e78539d3))
* **deps:** bump the fumadocs group with 3 updates ([#1006](https://github.com/tambo-ai/tambo/issues/1006)) ([2fcc4e5](https://github.com/tambo-ai/tambo/commit/2fcc4e5cfa8162e444ca16653c138be0fab0c834))

## [1.6.0](https://github.com/tambo-ai/tambo/compare/docs-v1.5.1...docs-v1.6.0) (2025-09-05)


### Features

* **docs:** setup ai page actions ([#943](https://github.com/tambo-ai/tambo/issues/943)) ([836d7a3](https://github.com/tambo-ai/tambo/commit/836d7a3c88edea65fc6441519cc574f53372e01b))

## [1.5.1](https://github.com/tambo-ai/tambo/compare/docs-v1.5.0...docs-v1.5.1) (2025-09-04)


### Miscellaneous Chores

* update tambo mcp url ([#970](https://github.com/tambo-ai/tambo/issues/970)) ([613f3f6](https://github.com/tambo-ai/tambo/commit/613f3f60b832a3306edb66532bab66d73e56a193))

## [1.5.0](https://github.com/tambo-ai/tambo/compare/docs-v1.4.0...docs-v1.5.0) (2025-09-02)


### Features

* **docs:** add sitemap and robots.txt ([#940](https://github.com/tambo-ai/tambo/issues/940)) ([99114d7](https://github.com/tambo-ai/tambo/commit/99114d7f54c2ef71cf4cdea1baa94fe2008ef781))
* **docs:** added support for llms.txt/llm-full.txt along with .mdx support for individual routes ([#935](https://github.com/tambo-ai/tambo/issues/935)) ([9c3bb5c](https://github.com/tambo-ai/tambo/commit/9c3bb5c8d5ddf8b22a547ea8f705ca7308e1500c))


### Bug Fixes

* **docs:** fixed document alignment issue ([#962](https://github.com/tambo-ai/tambo/issues/962)) ([26bc5ad](https://github.com/tambo-ai/tambo/commit/26bc5adc0495ef25e2ef4bd56db602be52a2f72a))
* sidebar overlaps with header [#942](https://github.com/tambo-ai/tambo/issues/942) ([#944](https://github.com/tambo-ai/tambo/issues/944)) ([9467132](https://github.com/tambo-ai/tambo/commit/94671328260e01e5c4aabae77865da1120d6f6fa))


### Miscellaneous Chores

* **deps:** bump next from 15.5.1 to 15.5.2 in the next group across 1 directory ([#955](https://github.com/tambo-ai/tambo/issues/955)) ([c1b99f4](https://github.com/tambo-ai/tambo/commit/c1b99f4eb19edcd18456d1d2cf43df724129d6e9))
* update upgrade command to filter known safe packages ([#959](https://github.com/tambo-ai/tambo/issues/959)) ([3e57bd5](https://github.com/tambo-ai/tambo/commit/3e57bd593e78991664cf66eed2367a47168c65b3))

## [1.4.0](https://github.com/tambo-ai/tambo/compare/docs-v1.3.2...docs-v1.4.0) (2025-08-28)


### Features

* migrate from react-markdown to streamdown ([#927](https://github.com/tambo-ai/tambo/issues/927)) ([fe5648e](https://github.com/tambo-ai/tambo/commit/fe5648e1e15d0181bc3bfc48bebdc556bb4be6b9))


### Miscellaneous Chores

* **deps:** bump mermaid from 11.10.0 to 11.10.1 ([#930](https://github.com/tambo-ai/tambo/issues/930)) ([1de614a](https://github.com/tambo-ai/tambo/commit/1de614af1c04c77bbf2431d347efb6f519a60de2))
* **deps:** bump posthog-js from 1.260.3 to 1.261.0 ([#953](https://github.com/tambo-ai/tambo/issues/953)) ([26e9507](https://github.com/tambo-ai/tambo/commit/26e9507d5976423cdc572757c1c9be40fcfc8789))
* **deps:** bump streamdown from 1.1.3 to 1.1.5 ([#950](https://github.com/tambo-ai/tambo/issues/950)) ([5aff96d](https://github.com/tambo-ai/tambo/commit/5aff96daf6685b7b9198819aba3cb1576d9622a0))
* **deps:** bump the fumadocs group with 3 updates ([#952](https://github.com/tambo-ai/tambo/issues/952)) ([d7e2a72](https://github.com/tambo-ai/tambo/commit/d7e2a7244f2383a2195da67c1a79422b6506b0a7))
* Fix react/mcp subpackage path ([#946](https://github.com/tambo-ai/tambo/issues/946)) ([180ed1b](https://github.com/tambo-ai/tambo/commit/180ed1be9c04dc58c256d1183cdfc812fb3b961b))
* fix tsconfig paths for react-sdk ([#945](https://github.com/tambo-ai/tambo/issues/945)) ([14dab2f](https://github.com/tambo-ai/tambo/commit/14dab2f4ae96e1a3c7b24cc84b0d15d74106f9a5))

## [1.3.2](https://github.com/tambo-ai/tambo/compare/docs-v1.3.1...docs-v1.3.2) (2025-08-27)


### Miscellaneous Chores

* **build:** fix docs build ([#923](https://github.com/tambo-ai/tambo/issues/923)) ([b65f0d3](https://github.com/tambo-ai/tambo/commit/b65f0d371e05285460cf88cb9d51c2141d9747d0))
* **deps:** bump @tambo-ai/typescript-sdk to get deprecated ActionType ([#928](https://github.com/tambo-ai/tambo/issues/928)) ([0b316e6](https://github.com/tambo-ai/tambo/commit/0b316e6d842241069e8b17d5823b8b8df60cbaf8))
* **deps:** bump fumadocs-mdx from 11.7.5 to 11.8.0 ([#918](https://github.com/tambo-ai/tambo/issues/918)) ([2604122](https://github.com/tambo-ai/tambo/commit/26041226db95e8cfeff7882a2a546c44418d7e83))
* **deps:** bump lucide-react from 0.540.0 to 0.541.0 ([#916](https://github.com/tambo-ai/tambo/issues/916)) ([50da283](https://github.com/tambo-ai/tambo/commit/50da2833e2e451211377cde13abd28d5835e2b7c))
* **deps:** bump next from 15.4.7 to 15.5.0 ([#914](https://github.com/tambo-ai/tambo/issues/914)) ([4c4ff85](https://github.com/tambo-ai/tambo/commit/4c4ff85c219e8018f743d5fbe32d8a2b111819dc))
* **deps:** bump posthog-js from 1.260.1 to 1.260.2 ([#921](https://github.com/tambo-ai/tambo/issues/921)) ([f14e759](https://github.com/tambo-ai/tambo/commit/f14e7590129c2d4d32ee551c840b8a7773692a22))
* remove conversational-form template from CLI and documentation ([#908](https://github.com/tambo-ai/tambo/issues/908)) ([3f24f2b](https://github.com/tambo-ai/tambo/commit/3f24f2be17819e338df031ea26d3c27f4caf9637))


### Documentation

* update component-state docs ([#936](https://github.com/tambo-ai/tambo/issues/936)) ([102227b](https://github.com/tambo-ai/tambo/commit/102227bde99ebf94e1bbb708e45683f43027184a))

## [1.3.1](https://github.com/tambo-ai/tambo/compare/docs-v1.3.0...docs-v1.3.1) (2025-08-23)


### Miscellaneous Chores

* update dependencies and update message input handling ([#905](https://github.com/tambo-ai/tambo/issues/905)) ([8015195](https://github.com/tambo-ai/tambo/commit/80151952ea321f8cf65a5e9b447b84ea6986125e))

## [1.3.0](https://github.com/tambo-ai/tambo/compare/docs-v1.2.4...docs-v1.3.0) (2025-08-21)


### Features

* add tambo hack banner and update mobile layout ([#895](https://github.com/tambo-ai/tambo/issues/895)) ([bb04b1c](https://github.com/tambo-ai/tambo/commit/bb04b1cff0eccbf087a4c5d4b01b24eb64dc9014))
* **docs:** integrate PostHog for analytics and add Web Vitals reporting ([#894](https://github.com/tambo-ai/tambo/issues/894)) ([90c5c3f](https://github.com/tambo-ai/tambo/commit/90c5c3f05702fd18c29a6caf342b013ee2788f5e))
* useTamboThreadInput context return reactquery values ([#897](https://github.com/tambo-ai/tambo/issues/897)) ([13aeff6](https://github.com/tambo-ai/tambo/commit/13aeff669bd5760e4f8f93e9ff77dae301f4ba83))

## [1.2.4](https://github.com/tambo-ai/tambo/compare/docs-v1.2.3...docs-v1.2.4) (2025-08-20)


### Miscellaneous

* **deps:** bump mermaid from 11.9.0 to 11.10.0 in the npm_and_yarn group ([#871](https://github.com/tambo-ai/tambo/issues/871)) ([e4f5feb](https://github.com/tambo-ai/tambo/commit/e4f5febb7b211f9d783cf347d8909be4c0a37106))

## [1.2.3](https://github.com/tambo-ai/tambo/compare/docs-v1.2.2...docs-v1.2.3) (2025-08-20)


### Miscellaneous

* **deps-dev:** bump @tailwindcss/postcss from 4.1.11 to 4.1.12 ([#855](https://github.com/tambo-ai/tambo/issues/855)) ([a7b5caf](https://github.com/tambo-ai/tambo/commit/a7b5caf2ef12781fe5e16033a5d8449cecea6512))
* **deps:** bump fumadocs-core from 15.6.10 to 15.6.12 ([#850](https://github.com/tambo-ai/tambo/issues/850)) ([24644a1](https://github.com/tambo-ai/tambo/commit/24644a1358824475ed50442ee1493b66bce34c9f))
* **deps:** bump fumadocs-mdx from 11.7.4 to 11.7.5 ([#860](https://github.com/tambo-ai/tambo/issues/860)) ([512a202](https://github.com/tambo-ai/tambo/commit/512a202b266eea819daae1d4861b7b6ff9e68aea))
* **deps:** bump fumadocs-ui from 15.6.9 to 15.6.12 ([#854](https://github.com/tambo-ai/tambo/issues/854)) ([4f26122](https://github.com/tambo-ai/tambo/commit/4f261225de8ca869f136e714c3fd3538893e24db))
* **deps:** bump lucide-react from 0.539.0 to 0.540.0 ([#849](https://github.com/tambo-ai/tambo/issues/849)) ([52f4804](https://github.com/tambo-ai/tambo/commit/52f48045cc051882c990b353c3ef9152717abe2a))
* **deps:** bump next from 15.4.6 to 15.4.7 ([#862](https://github.com/tambo-ai/tambo/issues/862)) ([7abc4f9](https://github.com/tambo-ai/tambo/commit/7abc4f97337d08adc5bd132dd4e6f44dfaea6b35))
* **deps:** Fix some duplicated/misaligned [@types](https://github.com/types) versions ([#867](https://github.com/tambo-ai/tambo/issues/867)) ([0c3fcfe](https://github.com/tambo-ai/tambo/commit/0c3fcfe4a7356966e74104b5c60397aab7eb7848))


### Documentation

* add docs header and chatwithtambo ([#838](https://github.com/tambo-ai/tambo/issues/838)) ([8509f26](https://github.com/tambo-ai/tambo/commit/8509f26180ca1f3d53333b61321c3fa6c54f263a))

## [1.2.2](https://github.com/tambo-ai/tambo/compare/docs-v1.2.1...docs-v1.2.2) (2025-08-14)


### Miscellaneous

* **deps:** bump fumadocs-core from 15.6.6 to 15.6.9 ([#821](https://github.com/tambo-ai/tambo/issues/821)) ([2423953](https://github.com/tambo-ai/tambo/commit/24239533114148903d0195ddce8e8b1c57602c64))
* **deps:** bump fumadocs-mdx from 11.7.3 to 11.7.4 ([#824](https://github.com/tambo-ai/tambo/issues/824)) ([8eef4cf](https://github.com/tambo-ai/tambo/commit/8eef4cf44339772709cd690657f46fcd83d063e8))
* **deps:** bump lucide-react from 0.536.0 to 0.539.0 ([#830](https://github.com/tambo-ai/tambo/issues/830)) ([1dfe483](https://github.com/tambo-ai/tambo/commit/1dfe483dc92ec6a3e043f9d15f958d183f87e557))
* **deps:** bump next from 15.4.4 to 15.4.6 ([#828](https://github.com/tambo-ai/tambo/issues/828)) ([a073604](https://github.com/tambo-ai/tambo/commit/a0736041c951d21c84c23979b617dc47d62648bd))


### Documentation

* add tambo mcp doc page ([#835](https://github.com/tambo-ai/tambo/issues/835)) ([69d9777](https://github.com/tambo-ai/tambo/commit/69d977735ac734d83f6f1ebd321011c3559d66df))

## [1.2.1](https://github.com/tambo-ai/tambo/compare/docs-v1.2.0...docs-v1.2.1) (2025-08-08)


### Documentation

* add new section for Models ([#809](https://github.com/tambo-ai/tambo/issues/809)) ([7b4652a](https://github.com/tambo-ai/tambo/commit/7b4652a8c961f0b14b9022e5be54e6d86e1f5287))

## [1.2.0](https://github.com/tambo-ai/tambo/compare/docs-v1.1.2...docs-v1.2.0) (2025-08-07)


### Features

* add custom context helpers for additional context ([#801](https://github.com/tambo-ai/tambo/issues/801)) ([2e33769](https://github.com/tambo-ai/tambo/commit/2e3376962c096e965266a9db96b0dcdc5c930b43))

## [1.1.2](https://github.com/tambo-ai/tambo/compare/docs-v1.1.1...docs-v1.1.2) (2025-08-05)


### Miscellaneous

* **deps-dev:** bump typescript from 5.8.3 to 5.9.2 ([#790](https://github.com/tambo-ai/tambo/issues/790)) ([49b86a0](https://github.com/tambo-ai/tambo/commit/49b86a0ba3198419054b7b75af9970321224b997))
* **deps:** bump fumadocs-mdx from 11.7.1 to 11.7.3 ([#785](https://github.com/tambo-ai/tambo/issues/785)) ([f73a4ce](https://github.com/tambo-ai/tambo/commit/f73a4ce189618be6c13a226aa370dca31e61a7cb))
* **deps:** bump fumadocs-ui from 15.6.6 to 15.6.9 ([#783](https://github.com/tambo-ai/tambo/issues/783)) ([c73936c](https://github.com/tambo-ai/tambo/commit/c73936c84e22308069843439fe0107558d5534ba))
* **deps:** bump lucide-react from 0.532.0 to 0.536.0 ([#781](https://github.com/tambo-ai/tambo/issues/781)) ([9f80a50](https://github.com/tambo-ai/tambo/commit/9f80a50c9359c3df741f329584608c35f7fbee58))


### Documentation

* update function name in interactables doc to 'withInteractable' ([#799](https://github.com/tambo-ai/tambo/issues/799)) ([cbb2ada](https://github.com/tambo-ai/tambo/commit/cbb2adab2e3c5c213203b8a7eb09f56ac4c52225))

## [1.1.1](https://github.com/tambo-ai/tambo/compare/docs-v1.1.0...docs-v1.1.1) (2025-08-05)


### Miscellaneous

* update additional context docs ([#780](https://github.com/tambo-ai/tambo/issues/780)) ([dcaaa1c](https://github.com/tambo-ai/tambo/commit/dcaaa1c91a966c6882aa61075b1391a4682ab313))


### Documentation

* add init docs llms.txt ([#778](https://github.com/tambo-ai/tambo/issues/778)) ([4624b34](https://github.com/tambo-ai/tambo/commit/4624b3447f115b23879acf58a416de63203d5c3a))

## [1.1.0](https://github.com/tambo-ai/tambo/compare/docs-v1.0.12...docs-v1.1.0) (2025-08-05)


### Features

* add pre-built context helpers ([#769](https://github.com/tambo-ai/tambo/issues/769)) ([757448b](https://github.com/tambo-ai/tambo/commit/757448b949f33a89ad0bc25b56918d95748da5ab))


### Bug Fixes

* remove last edit from docs to allow build ([#777](https://github.com/tambo-ai/tambo/issues/777)) ([7cf864a](https://github.com/tambo-ai/tambo/commit/7cf864a38ef5be9bbd1f36bb404538806041f2c9))

## [1.0.12](https://github.com/tambo-ai/tambo/compare/docs-v1.0.11...docs-v1.0.12) (2025-08-03)


### Documentation

* add 'edit on github' link to docs pages ([#767](https://github.com/tambo-ai/tambo/issues/767)) ([63aae74](https://github.com/tambo-ai/tambo/commit/63aae74b57395baa076a8da80a68ee8da784515b))

## [1.0.11](https://github.com/tambo-ai/tambo/compare/docs-v1.0.10...docs-v1.0.11) (2025-08-03)


### Bug Fixes

* add back in doc gif ([#765](https://github.com/tambo-ai/tambo/issues/765)) ([6be69e5](https://github.com/tambo-ai/tambo/commit/6be69e553b9138546d4d66c9059ea50a27faad29))

## [1.0.10](https://github.com/tambo-ai/tambo/compare/docs-v1.0.9...docs-v1.0.10) (2025-08-01)


### Documentation

* fix mermaid diagram ([#763](https://github.com/tambo-ai/tambo/issues/763)) ([b33d5cf](https://github.com/tambo-ai/tambo/commit/b33d5cf04c71345f768097e85de13e8dc5a81748))

## [1.0.9](https://github.com/tambo-ai/tambo/compare/docs-v1.0.8...docs-v1.0.9) (2025-08-01)


### Documentation

* trigger docs release ([#755](https://github.com/tambo-ai/tambo/issues/755)) ([5ff8544](https://github.com/tambo-ai/tambo/commit/5ff8544ac21dac547cc27f7673ba586fe00a0c55))

## [1.0.8](https://github.com/tambo-ai/tambo/compare/docs-v1.0.7...docs-v1.0.8) (2025-08-01)


### Documentation

* small change to trigger release ([#752](https://github.com/tambo-ai/tambo/issues/752)) ([7c1975c](https://github.com/tambo-ai/tambo/commit/7c1975cb59c1267d095d1334c0feed882feb8317))

## [1.0.7](https://github.com/tambo-ai/tambo/compare/docs-v1.0.6...docs-v1.0.7) (2025-08-01)


### Miscellaneous

* **docs:** add documentation for additional context ([#745](https://github.com/tambo-ai/tambo/issues/745)) ([84ccd70](https://github.com/tambo-ai/tambo/commit/84ccd705fccf3e4acb798134d998bacf199e6fb7))

## [1.0.6](https://github.com/tambo-ai/tambo/compare/docs-v1.0.5...docs-v1.0.6) (2025-07-31)


### Documentation

* Add Interactables doc page ([#744](https://github.com/tambo-ai/tambo/issues/744)) ([cfacd3d](https://github.com/tambo-ai/tambo/commit/cfacd3dc23a80ef4c2d135a5c02d6a1c5374f119))

## [1.0.5](https://github.com/tambo-ai/tambo/compare/docs-v1.0.4...docs-v1.0.5) (2025-07-29)


### Miscellaneous

* **deps:** bump fumadocs-core from 15.6.5 to 15.6.6 ([#732](https://github.com/tambo-ai/tambo/issues/732)) ([14aa154](https://github.com/tambo-ai/tambo/commit/14aa1540c7944d5538ac2e0ab525bfbeb35f3039))
* **deps:** bump fumadocs-mdx from 11.7.0 to 11.7.1 ([#725](https://github.com/tambo-ai/tambo/issues/725)) ([6f786ae](https://github.com/tambo-ai/tambo/commit/6f786ae482c698f13237fef70a874dbe75f33773))
* **deps:** bump fumadocs-ui from 15.6.5 to 15.6.6 ([#735](https://github.com/tambo-ai/tambo/issues/735)) ([44a55bd](https://github.com/tambo-ai/tambo/commit/44a55bd92c3a9f8eba1aaac3ac8f8bb9dd32b98f))
* **deps:** bump next from 15.3.5 to 15.4.4 ([#724](https://github.com/tambo-ai/tambo/issues/724)) ([bcbc50a](https://github.com/tambo-ai/tambo/commit/bcbc50a4e7cea5fcf720ca6d0ffbe57c5897cf54))

## [1.0.4](https://github.com/tambo-ai/tambo/compare/docs-v1.0.3...docs-v1.0.4) (2025-07-29)


### Miscellaneous

* **main:** release docs 1.0.3 ([#719](https://github.com/tambo-ai/tambo/issues/719)) ([4050059](https://github.com/tambo-ai/tambo/commit/40500595b916bab7922cb663f5958bf9cdd2ce3a))

## [1.0.3](https://github.com/tambo-ai/tambo/compare/docs-v1.0.2...docs-v1.0.3) (2025-07-28)


### Bug Fixes

* cleanup TamboPropStreamProvider ([#713](https://github.com/tambo-ai/tambo/issues/713)) ([d486d0a](https://github.com/tambo-ai/tambo/commit/d486d0aeef52930fb531d15fbe3e662af09ad254))


### Miscellaneous

* **main:** release docs 1.0.3 ([#718](https://github.com/tambo-ai/tambo/issues/718)) ([49b85b1](https://github.com/tambo-ai/tambo/commit/49b85b1717417708e58a9901b7331536bd006b2e))

## [1.0.3](https://github.com/tambo-ai/tambo/compare/docs-v1.0.2...docs-v1.0.3) (2025-07-28)


### Bug Fixes

* cleanup TamboPropStreamProvider ([#713](https://github.com/tambo-ai/tambo/issues/713)) ([d486d0a](https://github.com/tambo-ai/tambo/commit/d486d0aeef52930fb531d15fbe3e662af09ad254))

## [1.0.2](https://github.com/tambo-ai/tambo/compare/docs-v1.0.1...docs-v1.0.2) (2025-07-25)


### Documentation

* small update to trigger release ([#708](https://github.com/tambo-ai/tambo/issues/708)) ([52bcfed](https://github.com/tambo-ai/tambo/commit/52bcfedac8e4aca0ede00959787c48b8ab672cc3))

## [1.0.1](https://github.com/tambo-ai/tambo/compare/docs-v1.0.0...docs-v1.0.1) (2025-07-25)


### Documentation

* small update to test release ([#705](https://github.com/tambo-ai/tambo/issues/705)) ([b3de946](https://github.com/tambo-ai/tambo/commit/b3de94634527e56d489eae50c7a65cfa1dd110f5))

## 1.0.0 (2025-07-23)


### Features

* setup release-please for docs site ([#699](https://github.com/tambo-ai/tambo/issues/699)) ([13cb83d](https://github.com/tambo-ai/tambo/commit/13cb83d09c98994d6ce56e11b2d5dfb143e0c32d))


### Miscellaneous

* update documentation links to new domain and update dev command filter ([#698](https://github.com/tambo-ai/tambo/issues/698)) ([23946de](https://github.com/tambo-ai/tambo/commit/23946de0d4a67919e119f7188731f83bcc2e86a0))


### Documentation

* add recently-added docs ([#701](https://github.com/tambo-ai/tambo/issues/701)) ([5044c5a](https://github.com/tambo-ai/tambo/commit/5044c5aefc03ddc586b8239e78d91ae716712714))
* move docs to opensource repo ([#697](https://github.com/tambo-ai/tambo/issues/697)) ([3576dac](https://github.com/tambo-ai/tambo/commit/3576dace7c6dc33308e228395211a1a2f38ad17a))
