# PASS8 Final Raw Extraction Sweep

This is the final maximum-preservation pass for the Tambo control-panel source extraction.

It compares the existing raw extraction against the full `tambo-main` source tree and adds remaining small source/config/doc files.

Still excluded:
- node_modules
- build output
- caches
- `.next`
- `dist`
- `.turbo`
- generated coverage
- oversized non-source files

Result:
This ZIP should now contain the practical maximum useful raw code payload for a separate agent to build the control panel.
