# PASS5 Raw Expansion

This pass expands the raw extraction deeper into:
- packages
- apps
- examples
- scripts
- showcase
- docs

Goal:
maximize reusable frontend/runtime/control-panel source preservation for a separate build agent.
