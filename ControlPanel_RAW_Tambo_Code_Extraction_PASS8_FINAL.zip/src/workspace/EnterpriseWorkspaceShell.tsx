import React, { useState } from "react";
import { BusinessOsChatPanel } from "../components/BusinessOsChatPanel";

export type WorkspaceModule =
  | "chat"
  | "analytics"
  | "projects"
  | "customers"
  | "operations"
  | "observability"
  | "settings";

export function EnterpriseWorkspaceShell() {
  const [module, setModule] = useState<WorkspaceModule>("chat");

  return (
    <div className="enterprise-workspace-shell">
      <aside className="enterprise-workspace-shell__sidebar">
        <button onClick={() => setModule("chat")}>AI Workspace</button>
        <button onClick={() => setModule("analytics")}>Analytics</button>
        <button onClick={() => setModule("projects")}>Projects</button>
        <button onClick={() => setModule("customers")}>Customers</button>
        <button onClick={() => setModule("operations")}>Operations</button>
        <button onClick={() => setModule("observability")}>Observability</button>
        <button onClick={() => setModule("settings")}>Settings</button>
      </aside>

      <main className="enterprise-workspace-shell__content">
        {module === "chat" && <BusinessOsChatPanel />}
        {module !== "chat" && (
          <section>
            <h2>{module}</h2>
            <p>This workspace is driven by chatbot-generated widgets and Tambo runtime components.</p>
          </section>
        )}
      </main>
    </div>
  );
}
