/**
 * Runtime entrypoints for the extracted Tambo frontend source.
 *
 * The original source is preserved under:
 *   vendor/tambo/apps/dashboard/src
 *   vendor/tambo/react-sdk/src
 *   vendor/tambo/packages/react-ui-base/src
 *   vendor/tambo/packages/ui-registry
 *   vendor/tambo/packages/client/src
 *   vendor/tambo/packages/core/src
 *
 * Use this file as the stable adapter layer for the Business OS Control Panel.
 */

export const TAMBO_VENDOR_PATHS = {
  dashboard: "vendor/tambo/apps/dashboard/src",
  reactSdk: "vendor/tambo/react-sdk/src",
  reactUiBase: "vendor/tambo/packages/react-ui-base/src",
  uiRegistry: "vendor/tambo/packages/ui-registry",
  client: "vendor/tambo/packages/client/src",
  core: "vendor/tambo/packages/core/src",
};

export const CONTROL_PANEL_EXTRACTION_BOUNDARY = {
  belongsHere: [
    "chat workspace UI",
    "dashboard widgets",
    "generated UI renderer",
    "component registry",
    "thread and message UI",
    "tool-call display UI",
    "MCP display UI",
    "settings and analytics surfaces",
  ],
  notHere: [
    "TitanCore backend runtime",
    "TitanZero orchestration backend",
    "node_modules",
    "build artifacts",
    "demo-only generated output",
  ],
};
