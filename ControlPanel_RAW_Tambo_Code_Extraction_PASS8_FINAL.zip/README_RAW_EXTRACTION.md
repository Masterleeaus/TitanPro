# Raw Tambo Code Extraction

This ZIP is for a separate build agent.

It contains raw usable source extracted from `tambo-main(3).zip` for building the Business OS control panel.

## Extracted Roots

- `RAW_TAMBO_CODE/apps/dashboard`
- `RAW_TAMBO_CODE/react-sdk`
- `RAW_TAMBO_CODE/packages/react-ui-base`
- `RAW_TAMBO_CODE/packages/ui-registry`
- `RAW_TAMBO_CODE/packages/client`
- `RAW_TAMBO_CODE/packages/core`
- `RAW_TAMBO_CODE/showcase`
- `RAW_TAMBO_CODE/create-tambo-app`
- `RAW_TAMBO_CODE/cli`
- `RAW_TAMBO_CODE/docs`
- `RAW_TAMBO_CODE/devdocs`

## Not Included

- `node_modules`
- build output
- `.next`
- `dist`
- coverage
- git metadata

## Purpose

Give the next agent the maximum useful frontend/control-panel/runtime source without contaminating TitanCore or TitanZero.
