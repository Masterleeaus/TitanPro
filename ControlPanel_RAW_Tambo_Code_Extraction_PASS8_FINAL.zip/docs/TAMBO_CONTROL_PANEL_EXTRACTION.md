# Tambo Control Panel Extraction

This package adds reusable control-panel code inspired by the scanned `tambo-main(3).zip` dashboard and chat architecture.

## Extracted usable concepts

- Chat-first business workspace
- Persistent thread/message display
- Assistant response widgets
- Generated component rendering
- Suggestions / next actions
- Tool-call and MCP-oriented data display
- Project/settings/log/analytics widget categories
- A2UI-compatible portable schema

## Files added

- `src/schemas/control-panel-schema.ts`
- `src/services/business-os-api.ts`
- `src/components/BusinessOsChatPanel.tsx`
- `src/components/ControlPanelRenderer.tsx`
- `src/components/business-os-panel.css`
- `src/tambo/tambo-feature-map.json`

## Integration

Mount `BusinessOsChatPanel` inside your control panel application and connect it to TitanZero endpoints. TitanZero should orchestrate the agent and return A2UI/control-panel parts. TitanCore should remain the runtime layer.

## Boundary

This package is intentionally separate from TitanCore and TitanZero. It is the user-facing Business OS control-panel layer.
