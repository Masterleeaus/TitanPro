# PASS2 Full Frontend Runtime Extraction

This pass expands the Control Panel package with the reusable frontend/runtime source from `tambo-main`.

## Added vendor source areas

- `vendor/tambo/apps/dashboard/src`
- `vendor/tambo/react-sdk/src`
- `vendor/tambo/packages/react-ui-base/src`
- `vendor/tambo/packages/ui-registry`
- `vendor/tambo/packages/client/src`
- `vendor/tambo/packages/core/src`

## Why this is separate

This code is user-facing Business OS control-panel code. It is intentionally not placed in TitanCore or TitanZero.

## Intended use

Use the extracted Tambo runtime as a source pool for:

- AI chat workspace
- dynamic dashboard rendering
- component registry
- generated UI rendering
- thread/message display
- tool-call display
- MCP integration surfaces
- project/settings/analytics UI
- observability panels

## Cleanup still recommended

This extraction preserves source to avoid feature loss. Later passes should normalize imports, remove demo-only routes, and adapt the components to your app structure.
