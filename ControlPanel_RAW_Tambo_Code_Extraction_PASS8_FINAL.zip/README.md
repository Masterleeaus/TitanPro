# Control Panel A2UI Integration

This directory contains a minimal skeleton for integrating the A2UI
generative UI specification into your Titan Business OS control panel.

The goal of A2UI integration is to allow agents to dynamically generate
rich user interfaces that are rendered directly in the control panel
without requiring ad‑hoc HTML or Javascript. When combined with the
`GenerativeUIService` in **TitanCore** and the `GenerativeUIOrchestrator` in
**TitanZero**, your agents can call tools and return interactive
dashboards or forms that are rendered on the fly.

## Contents

* `README.md` – high‑level overview and integration steps.
* `a2ui-client.js` – a placeholder client module showing how to
  initialize an A2UI renderer and request UI from your agents.

## Integration Steps

1. **Import the A2UI client library.** If you are using a frontend
   framework such as React, install the official A2UI renderer for your
   framework (e.g. `@a2ui/react-renderer`) and import it into your
   project. Alternatively you can use the generic web‑core renderer
   referenced in the A2UI documentation【939307357559651†L149-L168】.

2. **Request UI from your agent.** When the user interacts with the
   control panel chat, send the query to your backend agent via
   TitanZero. Use the `GenerativeUIOrchestrator` to generate the system
   prompt and parse the A2UI response. The backend should respond
   with a JSON object containing a `parts` array.

3. **Render the A2UI parts.** Pass the received `parts` array to your
   chosen A2UI renderer on the frontend. The renderer will create the
   appropriate components (cards, forms, tables, etc.) as defined by
   your catalog. Use the `a2ui-client.js` file as a starting point for
   wiring up the renderer.

4. **Handle interactions.** When the user interacts with a generated
   component, such as submitting a form or clicking a button, send the
   updated state back to your agent. The agent can then return a new
   set of A2UI parts reflecting the updated UI. This round‑trip
   architecture enables dynamic and stateful dashboards, forms and
   assistants.

This skeleton intentionally omits full implementation details such as
authentication or state management. It provides a starting point for
building a modular, agent‑driven UI using the A2UI specification.