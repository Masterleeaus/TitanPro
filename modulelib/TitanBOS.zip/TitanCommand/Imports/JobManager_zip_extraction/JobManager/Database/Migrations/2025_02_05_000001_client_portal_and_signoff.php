<?php

namespace Modules\JobManager\Database\Migrations;

use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;

use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{public function up():void{if(!Schema::hasTable('work_order_client_files')) Schema::create('work_order_client_files', function(Blueprint $t){$t->id();$t->unsignedBigInteger('work_order_id');$t->unsignedBigInteger('uploaded_by')->nullable();$t->string('path');$t->string('name')->nullable();$t->timestamps();$t->index(['work_order_id']);});if(Schema::hasTable('work_orders')) Schema::table('work_orders', function(Blueprint $t){if(!Schema::hasColumn('work_orders','client_signed_at')) $t->timestamp('client_signed_at')->nullable();if(!Schema::hasColumn('work_orders','client_signature_path')) $t->string('client_signature_path')->nullable();if(!Schema::hasColumn('work_orders','client_sign_name')) $t->string('client_sign_name')->nullable();});}public function down():void{/* reverse omitted */}};