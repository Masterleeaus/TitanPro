namespace App\Extensions\TitanCommand\System\JobManager\Resources\views\crud;


<x-app-layout><h2 class='text-xl font-semibold'>CRUD: edit</h2><p>{{ \$resource ?? '' }} {% if(isset($id)) %}</p></x-app-layout>
