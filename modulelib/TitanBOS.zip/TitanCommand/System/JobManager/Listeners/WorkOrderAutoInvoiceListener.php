<?php

namespace App\Extensions\TitanCommand\System\JobManager\Listeners;




namespace App\Extensions\TitanCommand\System\JobManager\Listeners;use Illuminate\Support\Facades\DB;use Illuminate\Support\Facades\Log;class WorkOrderAutoInvoiceListener{public function handle($workOrderId){$fsm=DB::table('fsm_settings')->orderBy('id','desc')->first();if(!data_get($fsm,'features.auto_invoice',false))return;$wo=DB::table('work_orders')->where('id',$workOrderId)->first();if(!$wo)return;$parts=DB::table('work_order_part_usages')->where('work_order_id',$workOrderId)->get();$sum=0;$lines=[];foreach($parts as $p){$qty=(float)($p->qty??0);$price=(float)($p->unit_price??0);$amount=$qty*$price;$sum+=$amount;$lines[]=['item_name'=>$p->item_name??('Item #'.$p->item_id),'quantity'=>$qty,'unit_price'=>$price,'amount'=>$amount];}$invoiceId=DB::table('invoices')->insertGetId(['client_id'=>$wo->client_id??null,'issue_date'=>now(),'due_date'=>now()->addDays(14),'sub_total'=>$sum,'total'=>$sum,'status'=>'draft','created_at'=>now(),'updated_at'=>now(),'note'=>'Auto-generated from Job #'.$wo->id,]);foreach($lines as $li){DB::table('invoice_items')->insert(['invoice_id'=>$invoiceId,'item_name'=>$li['item_name'],'quantity'=>$li['quantity'],'unit_price'=>$li['unit_price'],'amount'=>$li['amount'],'created_at'=>now(),'updated_at'=>now()]);}Log::info("WO #{$workOrderId} auto-invoiced as invoice #{$invoiceId}");}}
