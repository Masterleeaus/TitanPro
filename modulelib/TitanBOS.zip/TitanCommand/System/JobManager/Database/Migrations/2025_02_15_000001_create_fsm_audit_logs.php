<?php

namespace App\Extensions\TitanCommand\System\JobManager\Database\Migrations;

use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;

use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{public function up():void{if(!Schema::hasTable('fsm_audit_logs')) Schema::create('fsm_audit_logs', function(Blueprint $t){$t->id();$t->string('entity_type');$t->unsignedBigInteger('entity_id')->nullable();$t->unsignedBigInteger('user_id')->nullable();$t->string('action');$t->json('before')->nullable();$t->json('after')->nullable();$t->ipAddress('ip')->nullable();$t->timestamps();$t->index(['entity_type','entity_id']);});}public function down():void{/* reverse omitted */}};
