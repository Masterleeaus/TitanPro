<?php

namespace App\Extensions\TitanCommand\System\JobManager\Database\Migrations;

use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;

use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{public function up():void{if(!Schema::hasTable('fsm_catalog_items')) Schema::create('fsm_catalog_items', function(Blueprint $t){$t->id();$t->string('vertical')->index();$t->string('sku')->nullable();$t->string('name');$t->decimal('price',10,2)->default(0);$t->string('unit')->default('ea');$t->timestamps();});if(!Schema::hasTable('fsm_rate_cards')) Schema::create('fsm_rate_cards', function(Blueprint $t){$t->id();$t->string('vertical')->index();$t->string('code')->default('default');$t->decimal('hourly',10,2)->default(0);$t->decimal('callout',10,2)->default(0);$t->decimal('after_hours_multiplier',5,2)->default(1.50);$t->timestamps();});}public function down():void{/* reverse omitted */}};
