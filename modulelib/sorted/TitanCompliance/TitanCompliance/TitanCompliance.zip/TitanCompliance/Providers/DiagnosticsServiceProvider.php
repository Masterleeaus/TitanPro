<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Config;

class DiagnosticsServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Merge our AI config into the module's config namespace.
        $this->mergeConfigFrom(__DIR__.'/../Config/ai.php', 'titancompliance.ai');
    }

    public function boot(): void
    {
        if ($this->app->runningInConsole()) {
            $this->commands([
                \Modules\TitanCompliance\Console\Commands\AISmoke::class,
            ]);
        }

        // Optionally publish the config for host apps that want to override.
        $this->publishes([
            __DIR__.'/../Config/ai.php' => config_path('titancompliance/ai.php'),
        ], 'titancompliance-config');
    }
}
