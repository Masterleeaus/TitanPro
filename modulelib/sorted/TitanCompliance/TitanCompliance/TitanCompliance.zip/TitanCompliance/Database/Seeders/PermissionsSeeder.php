<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\TitanCompliance\Support\Seeders\UsesSafeInsert;
use Modules\TitanCompliance\Support\Seeders\TenantAware;

class PermissionsSeeder extends Seeder
{
    use UsesSafeInsert;

    public function run(): void
    {
        // Minimal assumption: table 'permissions' with unique 'name' and optional 'tenant_id' column.
        // If your schema differs, adjust table/columns accordingly.
        $this->seedPermission('permissions', 'titancompliance.use', 'web');
    }

    protected function seedPermission(string $table, string $name, string $guard = 'web', ?int $tenantId = null): void
    {
        TenantAware::insertOnce($table, [
            'name'       => $name,
            'guard_name' => $guard,
            'created_at' => now(),
            'updated_at' => now(),
        ], ['name'], $tenantId);
    }
}
