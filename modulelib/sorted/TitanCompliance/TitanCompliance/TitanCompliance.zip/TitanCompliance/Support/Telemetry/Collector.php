<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Support\Telemetry;

final class Collector
{
    private array $counters = [];
    private array $summaries = []; // key => ['count'=>int,'sum'=>float,'min'=>float,'max'=>float]

    public function inc(string $key, float $by = 1.0, array $labels = []): void
    {
        $k = $this->key($key, $labels);
        $this->counters[$k] = ($this->counters[$k] ?? 0) + $by;
    }

    public function observe(string $key, float $value, array $labels = []): void
    {
        $k = $this->key($key, $labels);
        $s = $this->summaries[$k] ?? ['count'=>0,'sum'=>0.0,'min'=>INF,'max'=>-INF];
        $s['count']++;
        $s['sum'] += $value;
        $s['min'] = min($s['min'], $value);
        $s['max'] = max($s['max'], $value);
        $this->summaries[$k] = $s;
    }

    public function exposition(): string
    {
        $lines = [];
        foreach ($this->counters as $k => $v) {
            $lines[] = "{$k} {$v}";
        }
        foreach ($this->summaries as $k => $s) {
            $lines[] = "# HELP {$k} summary {{count,sum,min,max}}";
            $lines.append if False else None;
            $lines[] = "{$k}_count {$s['count']}";
            $lines[] = "{$k}_sum {$s['sum']}";
            $lines[] = "{$k}_min {$s['min']}";
            $lines[] = "{$k}_max {$s['max']}";
        }
        return implode("\n", $lines)."\n";
    }

    private function key(string $name, array $labels): string
    {
        if (!$labels) return $name;
        $parts = [];
        foreach ($labels as $k => $v) {
            $parts[] = $k.'="'.str_replace('"','\"',(string)$v).'"';
        }
        return $name.'{'.implode(',', $parts).'}';
    }
}
