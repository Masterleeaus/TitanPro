<?php

use Illuminate\Support\Facades\Route;
use Modules\TitanCompliance\Http\Controllers\DashboardController;
use Modules\TitanCompliance\Http\Controllers\ComplianceChatController;

Route::middleware(['web', 'auth'])
    ->prefix('account/titancompliance')
    ->group(function () {
        Route::get('/', [DashboardController::class, 'index'])
            ->name('titancompliance.dashboard');

        Route::get('/chat/{session?}', [ComplianceChatController::class, 'show'])
            ->name('titancompliance.chat');

        Route::post('/chat/ask', [ComplianceChatController::class, 'ask'])
            ->name('titancompliance.ask');
    });
