<?php

namespace Modules\TitanCompliance\Providers;

use Illuminate\Support\ServiceProvider;

class TitanComplianceServiceProvider extends ServiceProvider
{
    public function register()
    {
        //
    }

    public function boot()
    {
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');
        $this->loadRoutesFrom(__DIR__ . '/../Routes/web.php');
        $this->loadViewsFrom(__DIR__ . '/../Resources/views', 'titancompliance');
        $this->mergeConfigFrom(__DIR__ . '/../Config/config.php', 'titancompliance');
    }
}
