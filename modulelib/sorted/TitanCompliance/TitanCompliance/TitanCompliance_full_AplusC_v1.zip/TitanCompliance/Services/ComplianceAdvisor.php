<?php

namespace Modules\TitanCompliance\Services;

use AICopilot\Support\Contracts\ClientInterface as AICopilotClient;
use Modules\TitanCore\Contracts\AI\ClientInterface as TitanCoreClient;
use Illuminate\Support\Arr;

class ComplianceAdvisor
{
    protected TitanCoreClient $titanCoreClient;
    protected ?AICopilotClient $aiCopilotClient;

    public function __construct(TitanCoreClient $titanCoreClient, ?AICopilotClient $aiCopilotClient = null)
    {
        $this->titanCoreClient = $titanCoreClient;
        $this->aiCopilotClient = $aiCopilotClient;
    }

    /**
     * Ask for compliance guidance.
     */
    public function advise(array $context, string $question): string
    {
        $system = $this->buildSystemPrompt($context);

        $messages = [
            ['role' => 'system', 'content' => $system],
            ['role' => 'user', 'content' => $question],
        ];

        $response = $this->titanCoreClient->chat($messages, [
            'temperature' => 0.2,
        ]);

        return (string) Arr::get($response, 'content', '');
    }

    protected function buildSystemPrompt(array $context): string
    {
        $project   = $context['project'] ?? null;
        $standards = $context['standards'] ?? [];
        $jurisd    = $context['jurisdiction'] ?? 'AU';

        $lines = [];
        $lines[] = 'You are Titan Compliance, a professional construction compliance assistant.';
        $lines[] = 'You do NOT draft full documents; you explain obligations, risks, and required controls.';
        $lines[] = 'Base your answers on official building codes and standards. If unsure, say so.';

        if ($jurisd === 'AU') {
            $lines[] = 'Jurisdiction: Australia (NCC, AS/NZS standards).';
        }

        if (!empty($standards)) {
            $lines[] = 'Relevant standards / documents in context:';
            foreach ($standards as $std) {
                $lines[] = '- ' . $std;
            }
        }

        if ($project) {
            if (is_object($project)) {
                $name = $project->project_name ?? $project->name ?? 'n/a';
                $category = $project->category ?? 'n/a';
                $address = $project->address ?? 'n/a';
            } else {
                $name = $project['name'] ?? 'n/a';
                $category = $project['category'] ?? 'n/a';
                $address = $project['address'] ?? 'n/a';
            }
            $lines[] = 'Project context (for examples only, not as legal advice):';
            $lines[] = '- Name: ' . $name;
            $lines[] = '- Type: ' . $category;
            $lines[] = '- Site: ' . $address;
        }

        return implode("\n", $lines);
    }
}
