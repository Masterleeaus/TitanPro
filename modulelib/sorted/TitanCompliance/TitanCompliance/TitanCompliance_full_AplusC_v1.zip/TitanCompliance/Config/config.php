<?php

return [
    'name' => 'TitanCompliance',
    'verification_required' => false,
    'envato_item_id' => '',
    'parent_envato_id' => 23263417,
    'script_name' => 'worksuite-saas-titan-compliance',
    // Setting model is optional; leaving null avoids DB lookup until implemented
    'setting' => null,
];
