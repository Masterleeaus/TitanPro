<?php

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;

class Library extends Model
{
    protected $table = 'titancompliance_libraries';

    protected $fillable = [
        'company_id',
        'name',
        'jurisdiction',
        'category',
        'description',
        'is_active',
    ];
}
