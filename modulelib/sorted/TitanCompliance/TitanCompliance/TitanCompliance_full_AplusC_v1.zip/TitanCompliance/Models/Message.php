<?php

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    protected $table = 'titancompliance_messages';

    protected $fillable = [
        'session_id',
        'role',
        'content',
        'meta',
    ];

    protected $casts = [
        'meta' => 'array',
    ];

    public function session()
    {
        return $this->belongsTo(Session::class, 'session_id');
    }
}
