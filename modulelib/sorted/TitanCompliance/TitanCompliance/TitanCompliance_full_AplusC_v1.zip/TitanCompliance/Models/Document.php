<?php

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    protected $table = 'titancompliance_documents';

    protected $fillable = [
        'library_id',
        'source_type',
        'source_path',
        'title',
        'standard_code',
        'is_indexed',
        'token_count',
    ];
}
