<?php

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;

class Session extends Model
{
    protected $table = 'titancompliance_sessions';

    protected $fillable = [
        'company_id',
        'user_id',
        'project_id',
        'context_type',
        'context_id',
        'standards',
    ];

    protected $casts = [
        'standards' => 'array',
    ];

    public function messages()
    {
        return $this->hasMany(Message::class, 'session_id');
    }
}
