<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('titancompliance_documents', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('library_id')->index();
            $table->string('source_type');
            $table->string('source_path')->nullable();
            $table->string('title')->nullable();
            $table->string('standard_code')->nullable();
            $table->boolean('is_indexed')->default(false);
            $table->unsignedInteger('token_count')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titancompliance_documents');
    }
};
