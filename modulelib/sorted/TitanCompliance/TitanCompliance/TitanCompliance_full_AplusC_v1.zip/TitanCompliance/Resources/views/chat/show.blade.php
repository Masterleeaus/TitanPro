@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="white-box">
            <h3 class="box-title">Titan Compliance – Advisor</h3>

            <div class="chat-window" style="max-height:400px; overflow-y:auto;">
                @forelse($messages as $msg)
                    <div class="m-b-10">
                        <strong>{{ ucfirst($msg->role) }}:</strong>
                        <p class="m-b-0">{{ $msg->content }}</p>
                    </div>
                @empty
                    <p class="text-muted">Ask a question about standards, safety or compliance to get started.</p>
                @endforelse
            </div>

            <form method="POST" action="{{ route('titancompliance.ask') }}" class="m-t-20">
                @csrf
                <input type="hidden" name="session_id" value="{{ $session->id ?? '' }}">
                <div class="form-group">
                    <label for="question">Your question</label>
                    <textarea name="question" id="question" rows="3" class="form-control" required></textarea>
                </div>
                <button type="submit" class="btn btn-success m-t-10">
                    Ask Titan Compliance
                </button>
            </form>
        </div>
    </div>
</div>
@endsection
