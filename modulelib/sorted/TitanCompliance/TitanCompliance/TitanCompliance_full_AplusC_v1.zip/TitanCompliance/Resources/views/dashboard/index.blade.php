@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="white-box">
            <h3 class="box-title">{{ __('Titan Compliance') }}</h3>
            <p class="text-muted m-b-20">
                Central hub for compliance, standards and safety guidance powered by Titan Core.
            </p>
            <ul>
                <li>Overview of compliance libraries and standards (future).</li>
                <li>Shortcuts into project-specific compliance tools.</li>
                <li>Status of training data and standards libraries.</li>
            </ul>
            <a href="{{ route('titancompliance.chat') }}" class="btn btn-success m-t-10">
                {{ __('Open Compliance Advisor') }}
            </a>
        </div>
    </div>
</div>
@endsection
