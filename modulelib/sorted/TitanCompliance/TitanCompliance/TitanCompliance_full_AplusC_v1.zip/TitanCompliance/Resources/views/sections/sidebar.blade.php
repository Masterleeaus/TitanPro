@php
    $user = auth()->user();
@endphp

@if ($user)
    <li class="sidebar-item">
        <a class="sidebar-link" href="{{ route('titancompliance.dashboard') }}">
            <i class="fa fa-shield-alt sidebar-icon"></i>
            <span>{{ __('Titan Compliance') }}</span>
        </a>
    </li>
@endif
