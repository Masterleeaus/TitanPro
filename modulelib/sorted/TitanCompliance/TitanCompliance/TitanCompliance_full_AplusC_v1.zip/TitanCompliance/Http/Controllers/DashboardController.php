<?php

namespace Modules\TitanCompliance\Http\Controllers;

use App\Http\Controllers\AccountBaseController;

class DashboardController extends AccountBaseController
{
    public function index()
    {
        $this->pageTitle = __('Titan Compliance');
        $this->activeSettingMenu = 'titancompliance';

        return view('titancompliance::dashboard.index', $this->data);
    }
}
