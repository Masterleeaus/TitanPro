<?php

namespace Modules\TitanCompliance\Http\Controllers;

use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\TitanCompliance\Models\Session;
use Modules\TitanCompliance\Models\Message;
use Modules\TitanCompliance\Services\ComplianceAdvisor;

class ComplianceChatController extends AccountBaseController
{
    protected ComplianceAdvisor $advisor;

    public function __construct(ComplianceAdvisor $advisor)
    {
        parent::__construct();
        $this->advisor = $advisor;
    }

    public function show(Request $request, ?int $session = null)
    {
        $this->pageTitle = __('Titan Compliance');

        $sessionModel = null;
        $messages = collect();

        if ($session) {
            $sessionModel = Session::with('messages')->findOrFail($session);
            $messages = $sessionModel->messages()->orderBy('id')->get();
        }

        return view('titancompliance::chat.show', $this->data + [
            'session'  => $sessionModel,
            'messages' => $messages,
        ]);
    }

    public function ask(Request $request)
    {
        $data = $request->validate([
            'question'   => 'required|string',
            'session_id' => 'nullable|integer',
        ]);

        $user    = user();
        $company = company();

        $session = null;
        if (!empty($data['session_id'])) {
            $session = Session::find($data['session_id']);
        }

        if (!$session) {
            $session = Session::create([
                'company_id' => $company->id,
                'user_id'    => $user->id,
            ]);
        }

        $context = [
            'project'      => null,
            'jurisdiction' => 'AU',
            'standards'    => $session->standards ?? [],
        ];

        $answer = $this->advisor->advise($context, $data['question']);

        Message::create([
            'session_id' => $session->id,
            'role'       => 'user',
            'content'    => $data['question'],
        ]);

        Message::create([
            'session_id' => $session->id,
            'role'       => 'assistant',
            'content'    => $answer,
        ]);

        return redirect()->route('titancompliance.chat', ['session' => $session->id]);
    }
}
