<?php
declare(strict_types=1);

namespace Modules\AICopilot\Support\Providers;

abstract class BaseAdapter
{
    protected string $apiKey;
    protected ?string $model;
    protected int $timeout;

    public function __construct(string $apiKey, ?string $model, int $timeout = 30)
    {
        $this->apiKey = $apiKey;
        $this->model = $model;
        $this->timeout = $timeout;
    }

    protected function buildUserAgent(): string
    {
        return 'AICopilot/1.0 (+telemetry; +quota-caps)';
    }
}
