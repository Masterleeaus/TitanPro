<?php
declare(strict_types=1);

namespace Modules\AICopilot\Support\Providers;

use Modules\AICopilot\Support\Contracts\ClientInterface;

final class AnthropicAdapter extends BaseAdapter implements ClientInterface
{
    public function ping(int $timeout = 15): bool
    {
        $ch = curl_init('https://api.anthropic.com/v1/models');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_HTTPHEADER => [
                'x-api-key: '.$this->apiKey,
                'anthropic-version: 2023-06-01',
                'User-Agent: '.$this->buildUserAgent(),
            ],
        ]);
        $resp = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        return $code > 0;
    }

    public function chat(array $messages, array $options = []): array
    {
        $payload = [
            'model' => $options['model'] ?? $this->model ?? 'claude-3-5-sonnet',
            'max_tokens' => $options['max_tokens'] ?? 256,
            'temperature' => $options['temperature'] ?? 0.7,
            'messages' => $messages,
        ];
        $ch = curl_init('https://api.anthropic.com/v1/messages');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_HTTPHEADER => [
                'x-api-key: '.$this->apiKey,
                'anthropic-version: 2023-06-01',
                'content-type: application/json',
                'User-Agent: '.$this->buildUserAgent(),
            ],
        ]);
        $resp = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($code >= 200 && $code < 300 && $resp) {
            $j = json_decode($resp, true);
            $text = $j['content'][0]['text'] ?? '';
            return ['content'=>$text, 'usage'=>['input_tokens'=>0,'output_tokens'=>0]];
        }
        return ['content'=>'', 'usage'=>['input_tokens'=>0,'output_tokens'=>0]];
    }
}
