<?php
declare(strict_types=1);

namespace Modules\AICopilot\Console\Commands;

use Illuminate\Console\Command;

class AIOpenApiVerify extends Command
{
    protected $signature = 'ai:openapi-verify {--file=Modules/AICopilot/Docs/openapi.yaml}';
    protected $description = 'Lightweight check: ensures OpenAPI file exists and includes bearer auth + secured paths.';

    public function handle(): int
    {
        $file = base_path($this->option('file'));
        if (!is_file($file)) {
            $this->error('OpenAPI file not found: '.$file);
            return self::FAILURE;
        }
        $yaml = file_get_contents($file);
        $checks = [
            'openapi_header' => (bool) preg_match('/^openapi:\s*3\./m', $yaml),
            'has_security_schemes' => (bool) preg_match('/securitySchemes:\s*\n\s*bearerAuth:/m', $yaml),
            'global_security' => (bool) preg_match('/^security:\s*\n\s*-\s*bearerAuth:/m', $yaml),
            'chat_secured' => (bool) preg_match('/\/aicopilot\/chat:[\s\S]*?security:[\s\S]*?bearerAuth:/m', $yaml),
        ];
        foreach ($checks as $k => $ok) {
            $this->line(sprintf('%-22s : %s', $k, $ok ? 'OK' : 'MISSING'));
        }
        if (in_array(false, $checks, true)) {
            $this->warn('Some checks failed. Ensure security is declared and applied to paths.');
            return self::FAILURE;
        }
        $this->info('OpenAPI looks secured and well-formed (basic checks).');
        return self::SUCCESS;
    }
}
