<?php
declare(strict_types=1);

namespace Modules\AICopilot\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Route;
use Modules\AICopilot\Support\Telemetry\Collector;

class TelemetryServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__.'/../Config/telemetry.php', 'aicopilot.telemetry');
        $this->app->singleton(Collector::class, fn() => new Collector());
    }

    public function boot(): void
    {
        $cfg = Config::get('aicopilot.telemetry', []);
        if (!($cfg['enabled'] ?? false)) return;

        // Subscribe to http metrics events and aggregate
        Event::listen('aicopilot.http.metric', function (array $data) {
            $collector = app(Collector::class);
            $collector->inc('aic_http_requests_total', 1, [
                'status' => $data['status'] ?? 0,
                'path'   => $data['path'] ?? 'unknown',
            ]);
            if (isset($data['duration_ms'])) {
                $collector->observe('aic_http_duration_ms', (float) $data['duration_ms'], ['path' => $data['path'] ?? 'unknown']);
            }
        });

        // Optional /metrics endpoint
        $prom = $cfg['prometheus'] ?? [];
        if ($prom['enabled'] ?? false) {
            $guard = $prom['guard'] ?? 'auth';
            $route = $prom['route'] ?? '/aicopilot/metrics';

            Route::middleware($guard === 'none' ? ['web'] : ['web', $guard])
                ->get($route, function () {
                    $collector = app(Collector::class);
                    $header = [
                        "# HELP aic_http_requests_total Total HTTP requests observed by AICopilot middleware",
                        "# TYPE aic_http_requests_total counter",
                        "# HELP aic_http_duration_ms HTTP request duration (ms)",
                        "# TYPE aic_http_duration_ms summary",
                        "aic_info{version=\"S7P4\"} 1",
                    ];
                    return response(implode("\n", $header)."\n".$collector->exposition(), 200, [
                        'Content-Type' => 'text/plain; charset=utf-8'
                    ]);
                })->name('aicopilot.metrics');
        }
    }
}
