#!/usr/bin/env bash
set -euo pipefail
APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
cd "$APP_ROOT"

# Basic environment checks
php artisan --version || true

# Config smoke (no network)
php artisan ai:smoke --dry-run || true

# Live ping if keys set
php artisan ai:smoke --live || true

# OpenAPI basic checks
php artisan ai:openapi-verify || true

# Seeder audit
php artisan ai:seed-audit || true
