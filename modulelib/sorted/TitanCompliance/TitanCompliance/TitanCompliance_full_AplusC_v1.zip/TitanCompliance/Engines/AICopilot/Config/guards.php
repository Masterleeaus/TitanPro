<?php
declare(strict_types=1);

return [
    'enabled' => (bool) env('AIC_FAILSAFE_GUARD_ENABLED', true),
    'prefixes' => [
        'aicopilot', // any path starting with this will require auth by default
    ],
    'guard' => env('AIC_FAILSAFE_GUARD', 'auth'),
];
