<?php
declare(strict_types=1);

namespace Modules\AICopilot\Console\Commands;

use Illuminate\Console\Command;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

class AISeedAudit extends Command
{
    protected $signature = 'ai:seed-audit {--path=Modules/AICopilot/Database/Seeders}';
    protected $description = 'Audit seeders for idempotency and tenant-awareness. Dry-run; prints suggestions.';

    public function handle(): int
    {
        $path = base_path($this->option('path'));
        if (!is_dir($path)) {
            $this->warn("No seeders directory at {$path}.");
            return self::SUCCESS;
        }

        $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS));
        $issues = 0;
        foreach ($rii as $file) {
            if ($file->getExtension() !== 'php') continue;
            $code = file_get_contents($file->getPathname());

            $hasHelper = (bool) preg_match('/UsesSafeInsert|SeederHelpers|TenantAware/', $code);
            $rawInsert = (bool) preg_match('/DB::table\([^)]*\)\s*->\s*insert\s*\(/', $code);
            $upsert = (bool) preg_match('/upsert\s*\(/', $code);

            $findings = [];
            if ($rawInsert && !$hasHelper && !$upsert) {
                $findings[] = 'Raw insert without idempotency helper detected.';
            }
            if (!preg_match('/tenant_id/', $code)) {
                $findings[] = 'No tenant guard detected (ok if not multi-tenant).';
            }

            if ($findings) {
                $issues++;
                $this->line("\n[{$file->getFilename()}]"); 
                foreach ($findings as $f) $this->warn(' - '.$f);
                $this->line('   Suggestion: use UsesSafeInsert::insertOnce(...) or TenantAware::insertOnce(...)');
            }
        }

        if ($issues === 0) {
            $this->info('Seeders look good: idempotent/tenant-aware patterns detected.');
        } else {
            $this->info("\nTotal files with suggestions: {$issues}");
        }
        return self::SUCCESS;
    }
}
