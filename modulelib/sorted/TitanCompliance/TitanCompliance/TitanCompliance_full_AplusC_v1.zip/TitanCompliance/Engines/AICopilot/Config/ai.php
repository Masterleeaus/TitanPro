<?php
declare(strict_types=1);

return [
    // Which provider to use by default. Must be a key from the "providers" array below.
    'default' => env('AI_PROVIDER', 'openai'),

    // Provider configurations. Keys are provider names; values include API keys and model choices.
    'providers' => [
        'openai' => [
            'api_key'     => env('OPENAI_API_KEY'),
            'model_chat'  => env('OPENAI_MODEL_CHAT', 'gpt-4o-mini'),
            'timeout'     => (int) env('OPENAI_TIMEOUT', 30),
        ],
        'anthropic' => [
            'api_key'     => env('ANTHROPIC_API_KEY'),
            'model_chat'  => env('ANTHROPIC_MODEL_CHAT', 'claude-3-5-sonnet'),
            'timeout'     => (int) env('ANTHROPIC_TIMEOUT', 30),
        ],
        'gemini' => [
            'api_key'     => env('GEMINI_API_KEY'),
            'model_chat'  => env('GEMINI_MODEL_CHAT', 'gemini-1.5-pro'),
            'timeout'     => (int) env('GEMINI_TIMEOUT', 30),
        ],
    ],

    // Feature toggles within the module. Keep images off unless adapters exist.
    'features' => [
        'chat'   => true,
        'images' => false
    ],

    // Quick global enables for providers. Use envs in production to switch these safely.
    'providers_enabled' => [
        'openai'    => (bool) env('AI_ENABLE_OPENAI', true),
        'anthropic' => (bool) env('AI_ENABLE_ANTHROPIC', false),
        'gemini'    => (bool) env('AI_ENABLE_GEMINI', false),
    ],

    // Call quotas (soft). Enforced by the module; set per-user and per-tenant.
    'quotas' => [
        'per_user_daily_calls'   => (int) env('AI_CALLS_PER_USER_DAILY', 200),
        'per_tenant_daily_calls' => (int) env('AI_CALLS_PER_TENANT_DAILY', 2000),
    ],

    // Dollar caps (soft). Stop or degrade when exceeded.
    'cost_caps' => [
        'per_tenant_daily_usd' => (float) env('AI_USD_PER_TENANT_DAILY', 10.00),
        'per_user_daily_usd'   => (float) env('AI_USD_PER_USER_DAILY', 2.00),
    ],

    // Rough pricing table (USD / 1M tokens) for accounting dashboards. Non-authoritative.
    'pricing' => [
        'openai' => [
            'gpt-4o-mini' => ['input' => 0.15, 'output' => 0.60],
            'gpt-4o'      => ['input' => 5.00, 'output' => 15.00],
        ],
        'anthropic' => [
            'claude-3-5-sonnet' => ['input' => 3.00, 'output' => 15.00],
        ],
        'gemini' => [
            'gemini-1.5-pro' => ['input' => 0.125, 'output' => 0.50],
        ],
    ],
];
