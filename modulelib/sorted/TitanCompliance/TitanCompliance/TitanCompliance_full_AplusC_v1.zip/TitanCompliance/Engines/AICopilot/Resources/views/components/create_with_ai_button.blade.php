@php
  $can = auth()->check() && auth()->user()->can('aicopilot.use');
@endphp
@if($can)
<button type="button" class="btn btn-primary" data-ai-action="create-with-ai" data-ai-context="{{ $context ?? 'default' }}">
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14m-7-7h14" fill="none" stroke="currentColor" stroke-width="2"/></svg>
  Create with AI
</button>
@else
<!-- hidden: user lacks permission -->
@endif
