<?php
declare(strict_types=1);

namespace Modules\AICopilot\Support\Providers;

use Modules\AICopilot\Support\Contracts\ClientInterface;

final class OpenAIAdapter extends BaseAdapter implements ClientInterface
{
    public function ping(int $timeout = 15): bool
    {
        // Do a HEAD or minimal GET to models list (no auth test on HEAD, but we'll treat 200 as network OK)
        $ch = curl_init('https://api.openai.com/v1/models');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer '.$this->apiKey,
                'User-Agent: '.$this->buildUserAgent(),
            ],
        ]);
        $resp = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        // 200/401/403 still proves we can reach the service; 0 = network error
        return $code > 0;
    }

    public function chat(array $messages, array $options = []): array
    {
        $payload = [
            'model' => $options['model'] ?? $this->model ?? 'gpt-4o-mini',
            'messages' => $messages,
            'temperature' => $options['temperature'] ?? 0.7,
            'max_tokens' => $options['max_tokens'] ?? 256,
        ];
        $ch = curl_init('https://api.openai.com/v1/chat/completions');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer '.$this->apiKey,
                'Content-Type: application/json',
                'User-Agent: '.$this->buildUserAgent(),
            ],
        ]);
        $resp = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($code >= 200 && $code < 300 && $resp) {
            $j = json_decode($resp, true);
            $text = $j['choices'][0]['message']['content'] ?? '';
            $usage = $j['usage'] ?? ['prompt_tokens'=>0,'completion_tokens'=>0];
            return [
                'content' => $text,
                'usage' => [
                    'input_tokens' => (int) ($usage['prompt_tokens'] ?? 0),
                    'output_tokens'=> (int) ($usage['completion_tokens'] ?? 0),
                ]
            ];
        }
        return ['content'=>'', 'usage'=>['input_tokens'=>0,'output_tokens'=>0]];
    }
}
