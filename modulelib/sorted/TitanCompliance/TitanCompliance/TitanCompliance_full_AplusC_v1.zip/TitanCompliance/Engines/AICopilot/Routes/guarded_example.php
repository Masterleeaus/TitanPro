<?php
// Example: import this file from your existing Routes/web.php to enforce guards consistently.
use Illuminate\Support\Facades\Route;

Route::middleware(['web','auth'])
    ->prefix('aicopilot')
    ->name('aicopilot.')
    ->group(function () {
        // Example guarded UI route (replace with your controllers)
        // Route::get('/dashboard', [\Modules\AICopilot\Http\Controllers\DashboardController::class, 'index'])
        //     ->name('dashboard');
    });
