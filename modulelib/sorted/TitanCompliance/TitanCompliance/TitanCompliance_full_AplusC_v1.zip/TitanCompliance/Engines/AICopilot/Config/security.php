<?php
declare(strict_types=1);

return [
    'web_group' => ['web', 'auth', \Modules\AICopilot\Http\Middleware\AIFailsafeGuard::class, \Modules\AICopilot\Http\Middleware\AIMetricsMiddleware::class],
    'api_group' => ['api', 'auth:sanctum', \Modules\AICopilot\Http\Middleware\AIMetricsMiddleware::class],
    'api_key_header' => env('AIC_API_KEY_HEADER', 'X-API-Key'),
];
