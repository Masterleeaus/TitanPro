# AICopilot — P5 Full Module (S7 baseline + P2/P3/P4 deltas)
Built: 2025-10-01T22:39:52.105872Z

Included:
- Fixed `Config/ai.php` (env-only keys, quotas, cost caps, pricing table).
- `Console/Commands/AISmoke.php` + provider to merge config and register command.
- Telemetry: `Http/Middleware/AIMetricsMiddleware.php`, `Support/Telemetry/Collector.php`, `Config/telemetry.php`,
  and `Providers/TelemetryServiceProvider.php` with guarded `/aicopilot/metrics` exposition.
- Fail-safe auth: `Http/Middleware/AIFailsafeGuard.php` + `Config/guards.php` to protect `/aicopilot/*` even if routes miss `auth`.
- Blade component: `Resources/views/components/create_with_ai_button.blade.php` with `aicopilot.use` permission check.
- Seeder helpers + `PermissionsSeeder` (idempotent).

Quick install after copy:
```bash
php artisan config:clear && php artisan cache:clear
php artisan ai:smoke --dry-run
php artisan db:seed --class="Modules\AICopilot\Database\Seeders\PermissionsSeeder"
```
Env (recommended):
```
AI_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL_CHAT=gpt-4o-mini
AI_ENABLE_OPENAI=true
AI_ENABLE_ANTHROPIC=false
AI_ENABLE_GEMINI=false
AI_CALLS_PER_USER_DAILY=200
AI_CALLS_PER_TENANT_DAILY=2000
AI_USD_PER_TENANT_DAILY=10.00
AI_USD_PER_USER_DAILY=2.00

AIC_TELEMETRY_ENABLED=true
AIC_PROMETHEUS_ENABLED=true
AIC_PROMETHEUS_ROUTE=/aicopilot/metrics
AIC_PROMETHEUS_GUARD=auth

AIC_FAILSAFE_GUARD_ENABLED=true
AIC_FAILSAFE_GUARD=auth
```
