# AICopilot Delta (P7)
Date: 2025-10-01T22:58:49.123569Z

Harden seeders without guessing your schema:
- **TenantAware** helper: `TenantAware::insertOnce($table, $data, $uniqueKeys, $tenantId)` adds `tenant_id` when present.
- **PermissionsSeeder** updated: uses idempotent insert via helpers.
- **ai:seed-audit** command: scans seeders and warns on raw inserts / missing tenant hints (dry-run only, no code writes).

## Install
```bash
unzip AICopilot_Delta_P7.zip -d .
rsync -a Modules/AICopilot/ Modules/AICopilot/
php artisan config:clear && php artisan cache:clear
```

## Use
- Audit your seeders:
```bash
php artisan ai:seed-audit
```
- Seed (safe to re-run):
```bash
php artisan db:seed --class="Modules\AICopilot\Database\Seeders\PermissionsSeeder"
```

## Pattern
```php
use Modules\AICopilot\Support\Seeders\TenantAware;

TenantAware::insertOnce('menu', [
  'slug' => 'aicopilot.menu',
  'label' => 'AI Copilot',
  'url' => '/aicopilot',
  'created_at' => now(),
  'updated_at' => now(),
], ['slug'], $tenantId /* or null */);
```
