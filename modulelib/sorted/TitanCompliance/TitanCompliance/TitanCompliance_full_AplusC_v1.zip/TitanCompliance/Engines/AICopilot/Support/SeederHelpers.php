<?php
declare(strict_types=1);

namespace Modules\AICopilot\Support;

use Illuminate\Support\Facades\DB;

final class SeederHelpers
{
    public static function insertIgnore(string $table, array $data, array $uniqueKeys): void
    {
        // Try an upsert-like insert (safe re-run). Laravel upsert requires a unique index; this emulates minimum safety.
        $exists = DB::table($table)->where(function($q) use ($data, $uniqueKeys){
            foreach ($uniqueKeys as $k) { $q->where($k, $data[$k] ?? null); }
        })->exists();

        if (!$exists) {
            DB::table($table)->insert($data);
        }
    }
}
