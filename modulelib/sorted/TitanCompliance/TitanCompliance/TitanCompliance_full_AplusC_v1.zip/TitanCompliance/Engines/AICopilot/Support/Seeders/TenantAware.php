<?php
declare(strict_types=1);

namespace Modules\AICopilot\Support\Seeders;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Modules\AICopilot\Support\SeederHelpers;

final class TenantAware
{
    public static function hasTenant(string $table, string $col = 'tenant_id'): bool
    {
        try {
            return Schema::hasColumn($table, $col);
        } catch (\Throwable $e) {
            return false;
        }
    }

    public static function insertOnce(string $table, array $data, array $uniqueKeys, ?int $tenantId = null, string $tenantCol = 'tenant_id'): void
    {
        if ($tenantId !== null && self::hasTenant($table, $tenantCol)) {
            $data[$tenantCol] = $tenantId;
            if (!in_array($tenantCol, $uniqueKeys, true)) {
                $uniqueKeys = array_values(array_unique(array_merge($uniqueKeys, [$tenantCol])));
            }
        }
        SeederHelpers::insertIgnore($table, $data, $uniqueKeys);
    }
}
