<?php
declare(strict_types=1);

namespace Modules\AICopilot\Support\Seeders;

use Modules\AICopilot\Support\SeederHelpers;

trait UsesSafeInsert
{
    protected function insertOnce(string $table, array $data, array $uniqueKeys): void
    {
        SeederHelpers::insertIgnore($table, $data, $uniqueKeys);
    }
}
