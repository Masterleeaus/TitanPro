<?php
declare(strict_types=1);

namespace Modules\AICopilot\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Event;

class AIMetricsMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        $start = microtime(true);
        $resp = $next($request);
        $durMs = (int) ((microtime(true) - $start) * 1000);

        // Emit a lightweight event; a Prometheus collector (if enabled) can listen and aggregate.
        Event::dispatch('aicopilot.http.metric', [
            'path' => $request->path(),
            'status' => $resp->getStatusCode(),
            'duration_ms' => $durMs,
        ]);

        return $resp;
    }
}
