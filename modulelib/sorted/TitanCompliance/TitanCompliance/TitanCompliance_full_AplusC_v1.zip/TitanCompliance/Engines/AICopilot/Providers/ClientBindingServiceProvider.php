<?php
declare(strict_types=1);

namespace Modules\AICopilot\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Config;
use Modules\AICopilot\Support\Contracts\ClientInterface;
use Modules\AICopilot\Support\Providers\OpenAIAdapter;
use Modules\AICopilot\Support\Providers\AnthropicAdapter;
use Modules\AICopilot\Support\Providers\GeminiAdapter;

class ClientBindingServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind(ClientInterface::class, function () {
            $default = Config::get('aicopilot.ai.default', 'openai');
            $cfg     = Config::get('aicopilot.ai.providers.'.$default, []);
            $key     = $cfg['api_key'] ?? '';
            $model   = $cfg['model_chat'] ?? null;
            $timeout = (int) ($cfg['timeout'] ?? 30);

            switch ($default) {
                case 'anthropic':
                    return new AnthropicAdapter($key, $model, $timeout);
                case 'gemini':
                    return new GeminiAdapter($key, $model, $timeout);
                default:
                    return new OpenAIAdapter($key, $model, $timeout);
            }
        });
    }

    public function boot(): void {}
}
