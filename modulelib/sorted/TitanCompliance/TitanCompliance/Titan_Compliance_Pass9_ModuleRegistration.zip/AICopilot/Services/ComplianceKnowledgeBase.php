<?php
// Titan Compliance Pass8

namespace Modules\AICopilot\Services;

use Illuminate\Support\Str;
use Modules\AICopilot\Entities\ComplianceDocument;
use Modules\AICopilot\Entities\ComplianceDocumentSection;
use Modules\TitanCore\Contracts\ClientInterface as TitanClient;

class ComplianceKnowledgeBase
{
    public function __construct(protected TitanClient $client)
    {
    }

    /**
     * Very simple chunking of a long text into sections.
     */
    public function chunkDocument(ComplianceDocument $document, int $chunkSize = 1200): void
    {
        $text = $document->text_content ?? '';

        if (! $text) {
            return;
        }

        $chunks = Str::of($text)->split('/(\n\n+)/');

        $sections = [];
        $index = 0;

        foreach ($chunks as $chunk) {
            $chunkText = trim($chunk);
            if ($chunkText === '') {
                continue;
            }

            $sections[] = [
                'section_index' => $index,
                'heading'       => null,
                'start_offset'  => null,
                'end_offset'    => null,
                'text'          => $chunkText,
                'embedding'     => null,
                'tags'          => null,
            ];

            $index++;
        }

        foreach ($sections as $section) {
            $document->sections()->create($section);
        }
    }

    /**
     * Attach embeddings to each section if Titan Core provides an embed method.
     */
    public function embedSections(ComplianceDocument $document): void
    {
        $sections = $document->sections()->get();

        foreach ($sections as $section) {
            if (method_exists($this->client, 'embed')) {
                $result = $this->client->embed([
                    'input' => $section->text,
                    'model' => 'gpt-5-mini',
                ]);

                $embedding = $result['embedding'] ?? null;
                $section->embedding = $embedding ? json_encode($embedding) : null;
                $section->save();
            }
        }
    }

    /**
     * Build a context string from the most relevant sections.
     * This is intentionally simple: if embeddings are not available,
     * we just return a small sample of sections; if they are, a more
     * advanced search layer can be implemented later.
     */
    public function buildContextFromQuery(string $query, int $limit = 5): string
    {
        // If there is no dedicated embedding search, just return a few recent sections.
        $sections = ComplianceDocumentSection::query()
            ->orderByDesc('id')
            ->limit($limit)
            ->get();

        if ($sections->isEmpty()) {
            return '';
        }

        $parts = [];

        foreach ($sections as $section) {
            $parts[] = $section->text;
        }

        return "Use the following compliance reference excerpts where relevant:\n\n" . implode("\n\n---\n\n", $parts);
    }
}
