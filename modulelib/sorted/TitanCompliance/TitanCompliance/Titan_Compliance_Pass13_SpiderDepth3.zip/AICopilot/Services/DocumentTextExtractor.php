<?php
// Titan Compliance Pass13 - Document text extraction + crawling

namespace Modules\AICopilot\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Http;

class DocumentTextExtractor
{
    /**
     * Extract plain text from an uploaded file.
     *
     * Supports:
     *  - txt / md / log: direct read
     *  - pdf: tries common PDF parsers, then falls back to "pdftotext" CLI if available.
     */
    public function fromUploadedFile(UploadedFile $file): ?string
    {
        $ext = strtolower($file->getClientOriginalExtension());

        if (in_array($ext, ['txt', 'md', 'log'])) {
            return @file_get_contents($file->getRealPath()) ?: null;
        }

        if ($ext === 'pdf') {
            // 1) Smalot\PdfParser
            if (class_exists('Smalot\\PdfParser\\Parser')) {
                try {
                    $parser = new \Smalot\PdfParser\Parser();
                    $pdf    = $parser->parseFile($file->getRealPath());
                    $text   = $pdf->getText();
                    if ($text) {
                        return $this->normaliseWhitespace($text);
                    }
                } catch (\Throwable $e) {
                    // fall through
                }
            }

            // 2) Spatie\PdfToText
            if (class_exists('Spatie\\PdfToText\\Pdf')) {
                try {
                    $text = \Spatie\PdfToText\Pdf::getText($file->getRealPath());
                    if ($text) {
                        return $this->normaliseWhitespace($text);
                    }
                } catch (\Throwable $e) {
                    // fall through
                }
            }

            // 3) pdftotext CLI if available
            if (function_exists('shell_exec')) {
                $binary = trim((string) @shell_exec('which pdftotext'));
                if ($binary !== '') {
                    $tmpTxt = $file->getRealPath() . '.txt';
                    $cmd    = escapeshellarg($binary) . ' ' . escapeshellarg($file->getRealPath()) . ' ' . escapeshellarg($tmpTxt);
                    try {
                        @shell_exec($cmd);
                        if (is_file($tmpTxt)) {
                            $text = @file_get_contents($tmpTxt);
                            @unlink($tmpTxt);
                            if ($text) {
                                return $this->normaliseWhitespace($text);
                            }
                        }
                    } catch (\Throwable $e) {
                        // ignore and fall through
                    }
                }
            }
        }

        // Unknown / unsupported type here.
        return null;
    }

    /**
     * Fetch and extract text from a single URL.
     */
    public function fromUrl(string $url): ?string
    {
        if (! filter_var($url, FILTER_VALIDATE_URL)) {
            return null;
        }

        try {
            $response = Http::timeout(10)->get($url);
            if (! $response->ok()) {
                return null;
            }

            return $this->htmlToText($response->body());
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Crawl a URL up to a limited depth and page count, returning a single
     * concatenated text blob suitable for chunking into sections.
     *
     * Depth is inclusive: depth=1 means just the starting page, depth=3
     * means the starting page plus links and links-of-links (within the
     * same domain), up to the page limit.
     */
    public function crawlUrl(string $url, int $maxDepth = 3, int $maxPages = 30): ?string
    {
        if (! filter_var($url, FILTER_VALIDATE_URL)) {
            return null;
        }

        $startParts  = parse_url($url);
        $allowedHost = $startParts['host'] ?? null;
        $scheme      = $startParts['scheme'] ?? 'https';

        if (! $allowedHost) {
            return null;
        }

        $visited    = [];
        $queue      = [['url' => $url, 'depth' => 1]];
        $pages      = [];
        $totalPages = 0;

        while (! empty($queue) && $totalPages < $maxPages) {
            $current    = array_shift($queue);
            $currentUrl = $current['url'];
            $depth      = $current['depth'];

            if (isset($visited[$currentUrl])) {
                continue;
            }
            $visited[$currentUrl] = true;

            try {
                $response = Http::timeout(10)->get($currentUrl);
                if (! $response->ok()) {
                    continue;
                }

                $body = $response->body();
                $text = $this->htmlToText($body);

                if ($text) {
                    $pages[] = $text;
                    $totalPages++;
                }

                if ($depth >= $maxDepth || $totalPages >= $maxPages) {
                    continue;
                }

                // Extract links
                if (preg_match_all('/<a[^>]+href=["\']([^"\']+)["\']/i', $body, $matches)) {
                    foreach ($matches[1] as $href) {
                        $normalized = $this->normalizeUrl($href, $currentUrl, $scheme, $allowedHost);
                        if (! $normalized) {
                            continue;
                        }
                        if (! isset($visited[$normalized])) {
                            $queue[] = [
                                'url'   => $normalized,
                                'depth' => $depth + 1,
                            ];
                        }
                    }
                }
            } catch (\Throwable $e) {
                continue;
            }
        }

        if (empty($pages)) {
            return null;
        }

        return implode("\n\n---\n\n", $pages);
    }

    /**
     * Basic HTML -> text normalisation shared by URL helpers.
     */
    protected function htmlToText(string $html): string
    {
        $text = strip_tags($html);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return $this->normaliseWhitespace($text);
    }

    /**
     * Collapse excessive whitespace and normalise newlines.
     */
    protected function normaliseWhitespace(string $text): string
    {
        $text = preg_replace('/[ \t]+/', ' ', $text);
        $text = preg_replace('/\n{3,}/', "\n\n", $text);
        return trim($text);
    }

    /**
     * Resolve and normalise a found href against a base URL, enforcing
     * that we stay on the same host.
     */
    protected function normalizeUrl(string $href, string $base, string $scheme, string $allowedHost): ?string
    {
        $href = trim($href);

        if ($href === '' || str_starts_with($href, '#')) {
            return null;
        }

        if (preg_match('/^(mailto:|tel:|javascript:)/i', $href)) {
            return null;
        }

        // Absolute URL
        if (preg_match('/^https?:\/\//i', $href)) {
            $parts = parse_url($href);
            if (! $parts || ($parts['host'] ?? null) !== $allowedHost) {
                return null;
            }
            return $href;
        }

        // Protocol-relative  //example.com/path
        if (str_starts_with($href, '//')) {
            $candidate = $scheme . ':' . $href;
            $parts     = parse_url($candidate);
            if (! $parts || ($parts['host'] ?? null) !== $allowedHost) {
                return null;
            }
            return $candidate;
        }

        $baseParts = parse_url($base) ?: [];
        $host      = $baseParts['host'] ?? $allowedHost;
        $basePath  = $baseParts['path'] ?? '/';

        // Root-relative path
        if (str_starts_with($href, '/')) {
            return $scheme . '://' . $host . $href;
        }

        // Relative path
        $dir = rtrim(str_replace('\\', '/', dirname($basePath)), '/');
        if ($dir === '.') {
            $dir = '';
        }

        $path = $dir === '' ? '/' . ltrim($href, '/') : $dir . '/' . ltrim($href, '/');

        return $scheme . '://' . $host . $path;
    }
}
