<?php
// Titan Compliance Pass8

namespace Modules\AICopilot\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Modules\AICopilot\Entities\ComplianceDocument;
use Modules\AICopilot\Services\ComplianceKnowledgeBase;
use Modules\AICopilot\Services\DocumentTextExtractor;

class ComplianceDocumentController extends Controller
{
    public function __construct(
        protected ComplianceKnowledgeBase $knowledgeBase,
        protected DocumentTextExtractor $textExtractor
    ) {
        // Dependencies are auto-resolved by the container.
    }

    public function index()
    {
        $documents = ComplianceDocument::latest()->paginate(20);

        return view('aicopilot::compliance.documents.index', compact('documents'));
    }

    public function create()
    {
        return view('aicopilot::compliance.documents.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'document'     => 'required_without:source_url|file',
            'source_url'   => 'required_without:document|nullable|url|max:2000',
            'standard_ref' => 'nullable|string|max:191',
            'category'     => 'nullable|string|max:191',
        ]);

        $file      = $request->file('document');
        $sourceUrl = $request->get('source_url');
        $crawl     = method_exists($request, 'boolean')
            ? $request->boolean('crawl_url')
            : (bool) $request->get('crawl_url');

        $path     = null;
        $filename = null;
        $mime     = null;
        $size     = null;
        $text     = null;

        if ($file) {
            $path     = $file->store('aicopilot/compliance-documents', [
                'disk' => config('filesystems.default', 'local'),
            ]);
            $filename = basename($path);
            $mime     = $file->getClientMimeType();
            $size     = $file->getSize();
            $text     = $this->textExtractor->fromUploadedFile($file);
        } elseif ($sourceUrl) {
            if ($crawl) {
                // Crawl up to depth 3, max 30 pages within the same domain.
                $text = $this->textExtractor->crawlUrl($sourceUrl, 3, 30);
            } else {
                $text = $this->textExtractor->fromUrl($sourceUrl);
            }
            $filename = $sourceUrl;
            $mime     = 'text/url';
        }

        $document = ComplianceDocument::create([
            'title'        => $filename ?: $sourceUrl ?: $request->get('standard_ref'),
            'filename'     => $filename,
            'path'         => $path,
            'source_url'   => $sourceUrl,
            'mime_type'    => $mime,
            'size'         => $size,
            'standard_ref' => $request->get('standard_ref'),
            'category'     => $request->get('category'),
            'tags'         => $request->get('tags') ? explode(',', $request->get('tags')) : null,
            'uploaded_by'  => optional($request->user())->id,
            'text_content' => $text,
        ]);

        // Chunk & embed in background if needed. For now we do it inline,
        // but you may wish to dispatch to a job instead.
        if ($document->text_content) {
            $this->knowledgeBase->chunkDocument($document);
            $this->knowledgeBase->embedSections($document);
        }

        return redirect()
            ->route('aicopilot.compliance-documents.index')
            ->with('status', __('Compliance document uploaded and processed.'));
    }
    public function show(ComplianceDocument $complianceDocument)
    {
        $document = $complianceDocument->load('sections');

        return view('aicopilot::compliance.documents.show', compact('document'));
    }
}
