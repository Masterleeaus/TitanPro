<?php
// Titan Compliance Pass12 - store source_url on compliance documents

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        if (Schema::hasTable('compliance_documents') && ! Schema::hasColumn('compliance_documents', 'source_url')) {
            Schema::table('compliance_documents', function (Blueprint $table) {
                $table->string('source_url', 191)->nullable()->after('path');
            });
        }
    }

    public function down()
    {
        if (Schema::hasTable('compliance_documents') && Schema::hasColumn('compliance_documents', 'source_url')) {
            Schema::table('compliance_documents', function (Blueprint $table) {
                $table->dropColumn('source_url');
            });
        }
    }
};
