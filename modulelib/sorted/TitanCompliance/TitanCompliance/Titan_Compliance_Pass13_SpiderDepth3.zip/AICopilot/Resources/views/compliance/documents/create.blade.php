{{-- Titan Compliance Pass8 --}}
@extends('aicopilot::layouts.master')

@section('content')
<div class="container">
    <h1 class="mb-3">Upload compliance document</h1>

    <form method="POST" action="{{ route('aicopilot.compliance-documents.store') }}" enctype="multipart/form-data">
        @csrf

        <div class="form-group mb-3">
            <label for="document">Document file</label>
            <input type="file" name="document" id="document" class="form-control">
            <small class="form-text text-muted">
                Upload a PDF, TXT or MD file. Either a file or a URL is required.
            </small>
        </div>

        <div class="form-group mb-3">
            <label for="source_url">Source URL (optional alternative to file)</label>
            <input type="url" name="source_url" id="source_url" class="form-control" placeholder="https://example.com/standard-or-guidance">
            <small class="form-text text-muted">
                Titan Compliance will fetch the page and strip it to plain text for training.
            </small>
        </div>

        <div class="form-group mb-3">
            <div class="form-check">
                <input type="checkbox" name="crawl_url" id="crawl_url" value="1" class="form-check-input">
                <label class="form-check-label" for="crawl_url">
                    Spider this URL (up to 3 levels, max 30 pages on the same domain)
                </label>
            </div>
            <small class="form-text text-muted">
                Enable this to train Titan Compliance on the whole section of the site (within limits),
                instead of just the single page.
            </small>
        </div>

        <div class="form-group mb-3">
            <label for="standard_ref">Standard reference (optional)</label>
            <input type="text" name="standard_ref" id="standard_ref" class="form-control" placeholder="Eg. AS 3740, NCC Vol 2">
        </div>

        <div class="form-group mb-3">
            <label for="category">Category (optional)</label>
            <input type="text" name="category" id="category" class="form-control" placeholder="Eg. Waterproofing, Framing, Fire">
        </div>

        <div class="form-group mb-3">
            <label for="tags">Tags (optional, comma separated)</label>
            <input type="text" name="tags" id="tags" class="form-control" placeholder="Eg. wet areas, residential, bathrooms">
        </div>

        <button type="submit" class="btn btn-primary">
            Upload &amp; train
        </button>
    </form>
</div>
@endsection
