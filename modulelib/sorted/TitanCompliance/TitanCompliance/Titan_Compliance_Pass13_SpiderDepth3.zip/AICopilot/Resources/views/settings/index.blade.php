@extends('aicopilot::layout')
@section('content')
<h1 style="font-size:1.4rem; margin-bottom:.6rem;">Titan Compliance Settings</h1>
@if (session('status'))
    <div class="alert alert-success">{{ session('status') }}</div>
@endif

<form method="post" action="{{ route('aicopilot.settings.update') }}">
    @csrf
    <div class="form-group mb-3">
        <label for="default" style="display:block; margin-bottom:.25rem;">
            Default AI provider (for compliance answers)
        </label>
        <input
            id="default"
            class="form-control"
            name="default"
            value="{{ old('default', $cfg['default'] ?? 'openai') }}"
        />
        <small style="color:#9ca3af; font-size:.8rem;">
            This maps onto the provider Titan Core will use for compliance Q&amp;A (e.g. openai, anthropic).
        </small>
    </div>

    <button class="btn btn-primary mt-2" type="submit">
        Save settings
    </button>
</form>
@endsection
