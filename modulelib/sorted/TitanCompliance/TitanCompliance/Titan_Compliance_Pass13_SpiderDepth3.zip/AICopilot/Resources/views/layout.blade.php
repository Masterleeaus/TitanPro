<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Titan Compliance · AI Standards Advisor</title>
    <style>
    :root{
        --pri:#2563eb;
        --bg:#0b1220;
        --fg:#e5e7eb;
        --mut:#9ca3af;
    }
    body{
        background:var(--bg);
        color:var(--fg);
        font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Ubuntu,Cantarell,'Helvetica Neue',sans-serif;
        margin:0;
    }
    a{
        color:#93c5fd;
        text-decoration:none;
    }
    a:hover{
        text-decoration:underline;
    }
    .btn{
        display:inline-block;
        padding:.45rem .8rem;
        border-radius:.375rem;
        border:1px solid #1f2937;
        background:#111827;
        color:var(--fg);
        font-size:.875rem;
    }
    .btn-primary{
        background:var(--pri);
        border-color:#1d4ed8;
    }
    header{
        position:sticky;
        top:0;
        background:#020617;
        border-bottom:1px solid #111827;
        padding:.6rem 1rem;
        display:flex;
        gap:.6rem;
        align-items:center;
        z-index:10;
    }
    header strong{
        font-weight:600;
        letter-spacing:.03em;
    }
    header .brand-pill{
        padding:.2rem .55rem;
        border-radius:999px;
        background:#0f172a;
        border:1px solid #1f2937;
        font-size:.7rem;
        text-transform:uppercase;
        letter-spacing:.08em;
        color:var(--mut);
        margin-left:.3rem;
    }
    header nav{
        margin-left:auto;
        display:flex;
        gap:.4rem;
        align-items:center;
    }
    .page{
        padding:1.2rem 1.4rem 1.6rem;
        max-width:1100px;
        margin:0 auto;
    }
    </style>
</head>
<body>
<header>
    <strong>Titan Compliance</strong>
    <span class="brand-pill">Standards · SWMS · Safety</span>

    <nav>
        <a class="btn" href="{{ route('aicopilot.dashboard') }}">Dashboard</a>
        <a class="btn" href="{{ route('aicopilot.compliance-documents.index') }}">Docs</a>
        <a class="btn" href="{{ route('aicopilot.settings.index') }}">Settings</a>
    </nav>
</header>
<div class="page">
    @yield('content')
</div>
</body>
</html>
