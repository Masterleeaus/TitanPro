@extends('aicopilot::layout')

@section('content')
    <div class="mb-6">
        <h1 style="font-size:1.75rem; margin-bottom:.25rem;">Titan Compliance</h1>
        <p style="color:#9ca3af; max-width:46rem;">
            Train Titan Core on Australian building codes, NCC references, SWMS templates and safety guidance – then
            ask questions directly from within Worksuite jobs, projects and tasks.
        </p>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px,1fr)); gap:1rem; margin-bottom:1.5rem;">
        <div style="border-radius:.75rem; border:1px solid #1f2937; padding:1rem; background:#020617;">
            <h2 style="font-size:1.05rem; margin-bottom:.5rem;">1. Upload standards</h2>
            <p style="color:#9ca3af; font-size:.9rem; margin-bottom:.8rem;">
                Load in your NCC extracts, manufacturer guides, SWMS libraries or internal safety policies.
            </p>
            <a class="btn btn-primary" href="{{ route('aicopilot.compliance-documents.create') }}">
                Upload compliance document
            </a>
        </div>

        <div style="border-radius:.75rem; border:1px solid #1f2937; padding:1rem; background:#020617;">
            <h2 style="font-size:1.05rem; margin-bottom:.5rem;">2. Review the knowledge base</h2>
            <p style="color:#9ca3af; font-size:.9rem; margin-bottom:.8rem;">
                Browse the trained documents and sections Titan Compliance will draw from when answering.
            </p>
            <a class="btn" href="{{ route('aicopilot.compliance-documents.index') }}">
                View trained documents
            </a>
        </div>

        <div style="border-radius:.75rem; border:1px solid #1f2937; padding:1rem; background:#020617;">
            <h2 style="font-size:1.05rem; margin-bottom:.5rem;">3. Wire into assistants</h2>
            <p style="color:#9ca3af; font-size:.9rem; margin-bottom:.8rem;">
                Use Titan Compliance as the “brain” behind your on-screen assistants, SWMS wizards and project AI.
            </p>
            <a class="btn" href="{{ route('aicopilot.dashboard') }}">
                Open health & diagnostics
            </a>
        </div>
    </div>

    <div style="border-radius:.75rem; border:1px dashed #1f2937; padding:1rem; background:#020617;">
        <h3 style="font-size:1rem; margin-bottom:.4rem;">Tip</h3>
        <p style="color:#9ca3af; font-size:.9rem; max-width:48rem;">
            Start with core national standards and your most-used SWMS packs. Once those are stable,
            add manufacturer datasheets, project-specific requirements and internal checklists.
        </p>
    </div>
@endsection
