@extends('aicopilot::layout')
@section('content')
<h1 style="font-size:1.5rem; margin-bottom:.4rem;">Titan Compliance — Health & Connection</h1>
@php
  $cfg = config('aicopilot');
  $key = $cfg['providers']['openai']['api_key'] ?? null;
@endphp
<p style="color:#9ca3af; max-width:40rem; margin-bottom:1rem;">
  Quick snapshot of the Titan Core connection and recent compliance usage. If anything here looks off,
  fix it before trusting answers on jobs or SWMS.
</p>

<ul class="list-group mb-3" style="list-style:none; padding:0; margin:0 0 1rem;">
  <li class="list-group-item" style="padding:.4rem 0;">
      <strong>Default AI Provider:</strong> {{ $cfg['default'] ?? 'openai' }}
  </li>
  <li class="list-group-item" style="padding:.4rem 0;">
      <strong>OpenAI Key Present:</strong> {{ $key ? 'Yes' : 'No' }}
  </li>
  <li class="list-group-item" style="padding:.4rem 0;">
      <strong>Features enabled:</strong>
      {{ implode(', ', array_keys(array_filter($cfg['features'] ?? []))) ?: 'None detected' }}
  </li>
</ul>

<div class="card p-3" style="border-radius:.75rem; border:1px solid #1f2937; padding:1rem; background:#020617; margin-bottom:1.25rem;">
  <h5 style="margin:0 0 .4rem;">Status &amp; API checks</h5>
  <p style="color:#9ca3af; font-size:.9rem;">
      These links hit the underlying health/metrics endpoints exposed by the Titan Core integration.
  </p>
  <p>
      <a href="{{ route('aicopilot.home') }}">/ai</a> ·
      <a href="{{ route('aicopilot.api.health') }}" target="_blank">/api/ai/health</a> ·
      <a href="{{ route('aicopilot.api.metrics') }}" target="_blank">/api/ai/metrics</a>
  </p>
  <form method="get" action="{{ route('aicopilot.api.health') }}" target="_blank">
      <button class="btn btn-primary" type="submit">Run live health check</button>
  </form>
</div>

@php
  $rows = collect();
  try {
    if (\Illuminate\Support\Facades\Schema::hasTable('ai_assistant_usage')) {
      $rows = \Illuminate\Support\Facades\DB::table('ai_assistant_usage')
        ->selectRaw('DATE(created_at) d, SUM(calls) calls, SUM(cost_usd) cost')
        ->groupBy('d')->orderBy('d','desc')->limit(14)->get();
    }
  } catch (\Throwable $e) {}
@endphp

@if($rows->isNotEmpty())
  <h5 style="margin-bottom:.4rem;">Last 14 days — compliance calls</h5>
  <table class="table table-sm" style="width:100%; border-collapse:collapse; font-size:.9rem;">
    <thead>
      <tr>
        <th style="border-bottom:1px solid #1f2937; text-align:left; padding:.35rem .4rem;">Date</th>
        <th style="border-bottom:1px solid #1f2937; text-align:right; padding:.35rem .4rem;">Calls</th>
        <th style="border-bottom:1px solid #1f2937; text-align:right; padding:.35rem .4rem;">Cost (USD)</th>
      </tr>
    </thead>
    <tbody>
    @foreach($rows as $r)
      <tr>
        <td style="border-bottom:1px solid #0b1120; padding:.3rem .4rem;">{{ $r->d }}</td>
        <td style="border-bottom:1px solid #0b1120; padding:.3rem .4rem; text-align:right;">{{ $r->calls }}</td>
        <td style="border-bottom:1px solid #0b1120; padding:.3rem .4rem; text-align:right;">{{ number_format($r->cost, 4) }}</td>
      </tr>
    @endforeach
    </tbody>
  </table>
@else
  <p style="color:#9ca3af; font-size:.9rem;">
    No usage rows found yet. Once teams start asking compliance questions, you’ll see daily call and cost stats here.
  </p>
@endif
@endsection
