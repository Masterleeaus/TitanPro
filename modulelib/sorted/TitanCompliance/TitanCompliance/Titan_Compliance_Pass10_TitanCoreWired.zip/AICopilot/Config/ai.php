<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6

return [
  'default' => env('AI_PROVIDER','openai'),
  'providers' => [
    'openai' => [
      'api_key' => env('OPENAI_API_KEY'),
      'model_chat' => env('OPENAI_MODEL_CHAT','gpt-4o-mini'),
      'timeout' => env('OPENAI_TIMEOUT', 30),
    ],
  ],
  'features' => ['chat' => true],
];

'quotas' => [
    // soft caps; enforce in controller
    'per_user_daily_calls' => env('AI_CALLS_PER_USER_DAILY', 200),
    'per_tenant_daily_calls' => env('AI_CALLS_PER_TENANT_DAILY', 2000),
    'block_on_exceed' => env('AI_BLOCK_ON_EXCEED', false),
],
'provider_flags' => [
    'openai' => true,
    'anthropic' => false,
    'gemini' => false,
],

'pricing' => [
    // USD per 1K tokens (rough defaults; adjust per provider/model in host app)
    'openai' => [
        'gpt-4o-mini' => ['input' => 0.15, 'output' => 0.60],
        'gpt-4o'      => ['input' => 5.00, 'output' => 15.00],
    ],
],
'cost_caps' => [
    'per_tenant_daily_usd' => env('AI_USD_PER_TENANT_DAILY', 10.00),
    'per_user_daily_usd'   => env('AI_USD_PER_USER_DAILY', 2.00),
],
