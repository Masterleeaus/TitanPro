<?php
// Titan Compliance Pass8

namespace Modules\AICopilot\Entities;

use Illuminate\Database\Eloquent\Model;

class ComplianceDocument extends Model
{
    protected $table = 'compliance_documents';

    protected $fillable = [
        'title',
        'filename',
        'path',
        'mime_type',
        'size',
        'standard_ref',
        'category',
        'tags',
        'project_id',
        'uploaded_by',
        'text_content',
    ];

    protected $casts = [
        'tags' => 'array',
    ];

    public function sections()
    {
        return $this->hasMany(ComplianceDocumentSection::class, 'document_id');
    }
}
