<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6


namespace Modules\\AICopilot\Entities;

use Illuminate\Database\Eloquent\Model;

class AssistantAudit extends Model
{
    protected $table = 'assistant_audits';
    protected $guarded = [];
    protected $casts = ['context'=>'array'];
}
