<?php
// Titan Compliance Pass8

namespace Modules\AICopilot\Entities;

use Illuminate\Database\Eloquent\Model;

class ComplianceDocumentSection extends Model
{
    protected $table = 'compliance_document_sections';

    protected $fillable = [
        'document_id',
        'section_index',
        'heading',
        'start_offset',
        'end_offset',
        'text',
        'embedding',
        'tags',
    ];

    protected $casts = [
        'tags' => 'array',
    ];

    public function document()
    {
        return $this->belongsTo(ComplianceDocument::class, 'document_id');
    }
}
