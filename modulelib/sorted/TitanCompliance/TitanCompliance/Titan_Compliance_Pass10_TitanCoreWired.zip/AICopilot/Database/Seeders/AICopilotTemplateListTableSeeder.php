<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6


namespace Modules\AICopilot\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AICopilotTemplateListTableSeeder extends Seeder
{
    public function run()
    {
        $exists = DB::table('assistant_templates')
            ->where('template_module', 'Compliance')
            ->where('module', 'titan-compliance')
            ->exists();

        if ($exists) {
            return;
        }

        $templates = [
            [
                'template_name'   => 'Notice of unsafe work',
                'template_module' => 'Compliance',
                'module'          => 'titan-compliance',
                'prompt'          => "Draft a clear notice of unsafe work for {{project_name}} at {{site_address}} involving {{trade}}.\n\nDescribe the unsafe condition:\n{{risk_description}}\n\nExplain immediate actions taken and required corrective actions.\nReference that work must comply with relevant AS/NZS and NCC provisions and WHS obligations.",
                'fields'          => [
                    ['label' => 'Project name', 'field_name' => 'project_name', 'field_type' => 'text_box', 'placeholder' => 'Eg. Smith Residence Extension'],
                    ['label' => 'Site address', 'field_name' => 'site_address', 'field_type' => 'text_box', 'placeholder' => 'Eg. 123 Example Street, Suburb'],
                    ['label' => 'Trade', 'field_name' => 'trade', 'field_type' => 'text_box', 'placeholder' => 'Eg. Electrical, Waterproofing'],
                    ['label' => 'Risk description', 'field_name' => 'risk_description', 'field_type' => 'textarea', 'placeholder' => 'Describe the unsafe work or condition observed.'],
                ],
            ],
            [
                'template_name'   => 'Defect notification – residential job',
                'template_module' => 'Compliance',
                'module'          => 'titan-compliance',
                'prompt'          => "Draft a defect notification letter for {{project_name}} at {{site_address}}.\n\nDescribe the defect:\n{{defect_description}}\n\nExplain the risk to performance or safety, reference relevant AS/NZS and NCC requirements at a high level, and outline required rectification and timeframes.",
                'fields'          => [
                    ['label' => 'Project name', 'field_name' => 'project_name', 'field_type' => 'text_box', 'placeholder' => 'Eg. Smith Residence Extension'],
                    ['label' => 'Site address', 'field_name' => 'site_address', 'field_type' => 'text_box', 'placeholder' => 'Eg. 123 Example Street, Suburb'],
                    ['label' => 'Defect description', 'field_name' => 'defect_description', 'field_type' => 'textarea', 'placeholder' => 'Describe the defect and observed impact.'],
                ],
            ],
            [
                'template_name'   => 'Client advisory – non-compliant installation risk',
                'template_module' => 'Compliance',
                'module'          => 'titan-compliance',
                'prompt'          => "Draft an advisory letter to the client about non-compliant or potentially non-compliant installation on {{project_name}} at {{site_address}}.\n\nSummarise the issue:\n{{issue_summary}}\n\nExplain risks (safety, durability, legal/insurance implications) in plain language, and recommend next steps including engaging a certifier or engineer and checking relevant AS/NZS or NCC provisions.",
                'fields'          => [
                    ['label' => 'Project name', 'field_name' => 'project_name', 'field_type' => 'text_box', 'placeholder' => 'Eg. Smith Residence Extension'],
                    ['label' => 'Site address', 'field_name' => 'site_address', 'field_type' => 'text_box', 'placeholder' => 'Eg. 123 Example Street, Suburb'],
                    ['label' => 'Issue summary', 'field_name' => 'issue_summary', 'field_type' => 'textarea', 'placeholder' => 'Describe the installation and the concern.'],
                ],
            ],
            [
                'template_name'   => 'Compliance checklist – wet area waterproofing (AS 3740)',
                'template_module' => 'Compliance',
                'module'          => 'titan-compliance',
                'prompt'          => "Draft a practical checklist for wet area waterproofing for {{project_name}} at {{site_address}}.\n\nChecklist should:\n- reference AS 3740 and relevant NCC provisions at a high level\n- include pre-installation checks\n- installation checks\n- inspection and documentation items\n\nFocus on field-friendly tick-box style items.",
                'fields'          => [
                    ['label' => 'Project name', 'field_name' => 'project_name', 'field_type' => 'text_box', 'placeholder' => 'Eg. Smith Residence Extension'],
                    ['label' => 'Site address', 'field_name' => 'site_address', 'field_type' => 'text_box', 'placeholder' => 'Eg. 123 Example Street, Suburb'],
                ],
            ],
            [
                'template_name'   => 'Site safety briefing – high risk work',
                'template_module' => 'Compliance',
                'module'          => 'titan-compliance',
                'prompt'          => "Draft a site safety briefing for high risk work on {{project_name}} at {{site_address}} involving {{work_type}}.\n\nInclude:\n- brief description of work\n- key hazards\n- control measures\n- PPE\n- emergency procedures\n\nReference WHS duties and relevant AS/NZS / NCC requirements at a high level.",
                'fields'          => [
                    ['label' => 'Project name', 'field_name' => 'project_name', 'field_type' => 'text_box', 'placeholder' => 'Eg. Smith Residence Extension'],
                    ['label' => 'Site address', 'field_name' => 'site_address', 'field_type' => 'text_box', 'placeholder' => 'Eg. 123 Example Street, Suburb'],
                    ['label' => 'Work type', 'field_name' => 'work_type', 'field_type' => 'text_box', 'placeholder' => 'Eg. Working at heights, confined space entry'],
                ],
            ],
        ];

        foreach ($templates as $tpl) {
            DB::table('assistant_templates')->insert([
                'template_name'   => $tpl['template_name'],
                'template_module' => $tpl['template_module'],
                'module'          => $tpl['module'],
                'prompt'          => $tpl['prompt'],
                'field_json'      => json_encode([
                    'field' => array_map(function ($f) {
                        return (object) $f;
                    }, $tpl['fields']),
                ]),
                'is_tone'         => 1,
                'category'        => $tpl['category'] ?? 'Compliance',
                'risk_level'      => $tpl['risk_level'] ?? 'medium',
                'is_compliance'   => $tpl['is_compliance'] ?? true,
                'tags'            => isset($tpl['tags']) ? json_encode($tpl['tags']) : json_encode(['compliance','construction']),
            ]);
        }
    }
}
