<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6

namespace Modules\\AICopilot\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AICopilotRoleAttachSeeder extends Seeder
{
    public function run(): void
    {
        if (!Schema::hasTable('roles') || !Schema::hasTable('permissions')) return;

        $goalPerms = [
            'aicopilot.view','aicopilot.generate','aicopilot.api',
            'aicopilot.admin','aicopilot.logs','aicopilot.settings'
        ];

        $roleNames = ['super_admin','admin']; // edit as needed in host app

        try {
            // Spatie-style pivot: role_has_permissions
            if (Schema::hasTable('role_has_permissions')) {
                $perms = DB::table('permissions')->whereIn('name',$goalPerms)->pluck('id','name')->all();
                $roles = DB::table('roles')->whereIn('name',$roleNames)->pluck('id','name')->all();
                foreach ($roles as $rname=>$rid) {
                    foreach ($goalPerms as $pname) {
                        if (!isset($perms[$pname])) continue;
                        $pid = $perms[$pname];
                        $exists = DB::table('role_has_permissions')->where('role_id',$rid)->where('permission_id',$pid)->exists();
                        if (!$exists) DB::table('role_has_permissions')->insert(['role_id'=>$rid,'permission_id'=>$pid]);
                    }
                }
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }
}
