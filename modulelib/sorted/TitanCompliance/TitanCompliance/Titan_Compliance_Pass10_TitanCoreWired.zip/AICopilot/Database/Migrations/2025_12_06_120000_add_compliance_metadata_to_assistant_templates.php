<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6


use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('assistant_templates', function (Blueprint $table) {
            if (!Schema::hasColumn('assistant_templates', 'category')) {
                $table->string('category', 191)->nullable()->after('module');
            }
            if (!Schema::hasColumn('assistant_templates', 'risk_level')) {
                $table->string('risk_level', 50)->nullable()->after('category');
            }
            if (!Schema::hasColumn('assistant_templates', 'is_compliance')) {
                $table->boolean('is_compliance')->default(false)->after('risk_level');
            }
            if (!Schema::hasColumn('assistant_templates', 'tags')) {
                $table->json('tags')->nullable()->after('field_json');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('assistant_templates', function (Blueprint $table) {
            if (Schema::hasColumn('assistant_templates', 'tags')) {
                $table->dropColumn('tags');
            }
            if (Schema::hasColumn('assistant_templates', 'is_compliance')) {
                $table->dropColumn('is_compliance');
            }
            if (Schema::hasColumn('assistant_templates', 'risk_level')) {
                $table->dropColumn('risk_level');
            }
            if (Schema::hasColumn('assistant_templates', 'category')) {
                $table->dropColumn('category');
            }
        });
    }
};
