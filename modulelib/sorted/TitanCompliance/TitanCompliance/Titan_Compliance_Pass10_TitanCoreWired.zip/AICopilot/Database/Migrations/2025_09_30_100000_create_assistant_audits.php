<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('assistant_audits')) {
            Schema::create('assistant_audits', function(Blueprint $t){
                $t->id();
                $t->string('action');
                $t->json('context')->nullable();
                $t->unsignedBigInteger('user_id')->nullable()->index();
                $t->timestamps();
            });
        }
    }
    public function down(): void {
        Schema::dropIfExists('assistant_audits');
    }
};
