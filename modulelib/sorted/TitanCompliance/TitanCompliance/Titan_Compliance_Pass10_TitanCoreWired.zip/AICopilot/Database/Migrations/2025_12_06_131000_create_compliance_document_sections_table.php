<?php
// Titan Compliance Pass8


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        if (! Schema::hasTable('compliance_document_sections')) {
            Schema::create('compliance_document_sections', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('document_id');
                $table->integer('section_index')->default(0);
                $table->string('heading')->nullable();
                $table->integer('start_offset')->nullable();
                $table->integer('end_offset')->nullable();
                $table->longText('text')->nullable();
                $table->longText('embedding')->nullable();
                $table->json('tags')->nullable();
                $table->timestamps();

                $table->index('document_id');
            });
        }
    }

    public function down()
    {
        Schema::dropIfExists('compliance_document_sections');
    }
};
