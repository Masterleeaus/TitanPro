<?php
// Titan Compliance Pass8


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        if (! Schema::hasTable('compliance_documents')) {
            Schema::create('compliance_documents', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('title')->nullable();
                $table->string('filename')->nullable();
                $table->string('path')->nullable();
                $table->string('mime_type', 191)->nullable();
                $table->unsignedBigInteger('size')->nullable();
                $table->string('standard_ref', 191)->nullable();
                $table->string('category', 191)->nullable();
                $table->json('tags')->nullable();
                $table->unsignedBigInteger('project_id')->nullable();
                $table->unsignedBigInteger('uploaded_by')->nullable();
                $table->longText('text_content')->nullable();
                $table->timestamps();
            });
        }
    }

    public function down()
    {
        Schema::dropIfExists('compliance_documents');
    }
};
