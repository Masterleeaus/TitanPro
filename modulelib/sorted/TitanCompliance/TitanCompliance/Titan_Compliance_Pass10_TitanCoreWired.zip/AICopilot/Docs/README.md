# AICopilot (nWidart module)

Routes:
- Web: `/aicopilot` (requires `web, auth` middleware)
- API: `POST /api/aicopilot/chat`

Service Provider: `Modules\\AICopilot\Providers\AICopilotServiceProvider`
