@extends('aicopilot::layout')
@section('content')
<h1>Prompt Library</h1>
@if (session('status')) <div class="alert alert-success">{{ session('status') }}</div> @endif
<p><a class="btn btn-primary" href="{{ route('aicopilot.prompts.create') }}">New Prompt</a></p>
<table class="table">
<thead><tr><th>Title</th><th>Category</th><th>Visibility</th><th></th></tr></thead>
<tbody>
@foreach($prompts as $p)
<tr>
  <td>{{ $p->title }}</td>
  <td>{{ optional($p->category)->name ?? '-' }}</td>
  <td>{{ $p->visibility }}</td>
  <td>
    <a href="{{ route('aicopilot.prompts.edit',$p) }}" class="btn btn-sm btn-outline-secondary">Edit</a>
    <form method="post" action="{{ route('aicopilot.prompts.destroy',$p) }}" style="display:inline">@csrf @method('DELETE')
      <button class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete prompt?')">Delete</button>
    </form>
  </td>
</tr>
@endforeach
</tbody>
</table>
{{ $prompts->links() }}
@endsection
