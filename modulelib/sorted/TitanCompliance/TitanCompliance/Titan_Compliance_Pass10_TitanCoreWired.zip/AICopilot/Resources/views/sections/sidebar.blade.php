@php
    $user = auth()->user();
    $modules = function_exists('user_modules') ? user_modules() : [];
    $hasModule = $user && (empty($modules) || in_array('titan-compliance', $modules));
@endphp

@if($hasModule)
    <li class="sidebar-item {{ request()->routeIs('aicopilot.*') ? 'active' : '' }}">
        <a class="sidebar-link" href="{{ route('aicopilot.dashboard') }}">
            <i class="ti ti-shield-check"></i>
            <span>{{ __('Titan Compliance') }}</span>
        </a>
    </li>
@endif
