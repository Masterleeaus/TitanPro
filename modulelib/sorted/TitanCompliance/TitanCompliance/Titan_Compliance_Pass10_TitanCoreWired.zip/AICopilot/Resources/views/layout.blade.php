<!doctype html>
<html><head><meta charset="utf-8"><title>AI Assistant</title>
<style>
:root{ --pri:#2563eb; --bg:#0b1220; --fg:#e5e7eb; --mut:#9ca3af; }
body{ background:var(--bg); color:var(--fg); font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif; }
a{ color:#93c5fd; text-decoration:none } a:hover{text-decoration:underline}
.btn{ display:inline-block; padding:.45rem .8rem; border-radius:.42rem; border:1px solid #1f2937; background:#111827; color:var(--fg); }
.btn-primary{ background:var(--pri); border-color:#1d4ed8 }
header{ position:sticky; top:0; background:#0b1220; border-bottom:1px solid #1f2937; padding:.6rem 1rem; display:flex; gap:.6rem; align-items:center }
</style>
</head>
<body>
<header>
  <strong>AI Assistant</strong>
  <a class="btn" href="/aicopilot">Home</a>
  <a class="btn" href="/aicopilot/audit">Audit</a>
</header>
<div style="padding:16px">@yield('content')</div>
</body></html>
