@extends('aicopilot::layout')
@section('content')
<h1>AI Providers</h1>
@if (session('status')) <div class="alert alert-info">{{ session('status') }}</div> @endif
<form method="post" action="{{ route('aicopilot.providers.update') }}">
  @csrf
  <div class="mb-3">
    <label class="form-label">Default Provider</label>
    <select name="default" class="form-select">
      @foreach (['openai','anthropic','gemini'] as $opt)
        <option value="{{ $opt }}" {{ ($cfg['default'] ?? 'openai')===$opt ? 'selected' : '' }}>{{ ucfirst($opt) }}</option>
      @endforeach
    </select>
  </div>
  <button class="btn btn-primary">Save</button>
  <a class="btn btn-outline-secondary" href="{{ route('aicopilot.providers.test') }}">Run Test</a>
</form>
@endsection
