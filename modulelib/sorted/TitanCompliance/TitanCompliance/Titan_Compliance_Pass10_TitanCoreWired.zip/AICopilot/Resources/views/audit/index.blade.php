@extends('aicopilot::layout')
@section('content')
<h2>AI Assistant Audit</h2>
<form method="GET"><input name="action" value="{{ request('action') }}" placeholder="Action contains"> <button>Filter</button></form>
<table border="1" cellspacing="0" cellpadding="6">
<tr><th>ID</th><th>Action</th><th>User</th><th>At</th><th></th></tr>
@foreach($rows as $r)
<tr>
<td>{{ $r->id }}</td><td>{{ $r->action }}</td><td>{{ $r->user_id }}</td><td>{{ $r->created_at }}</td>
<td><a href="{{ route('aicopilot.audit.show',$r->id) }}">View</a></td>
</tr>
@endforeach
</table>
{{ $rows->links() }}
@endsection
