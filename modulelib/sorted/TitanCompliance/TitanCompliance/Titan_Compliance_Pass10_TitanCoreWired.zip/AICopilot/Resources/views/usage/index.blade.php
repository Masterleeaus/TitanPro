@extends('aicopilot::layout')
@section('content')
<h1>AI Usage Log</h1>
<p><a class="btn btn-outline-secondary" href="{{ route('aicopilot.usage.export') }}">Export CSV</a></p>
<table class="table table-sm">
  <thead><tr><th>ID</th><th>Date</th><th>Tenant</th><th>User</th><th>Provider</th><th>Model</th><th>Prompt</th><th>Completion</th><th>Calls</th><th>USD</th></tr></thead>
  <tbody>
  @forelse($rows as $r)
    <tr>
      <td>{{ $r->id }}</td>
      <td>{{ $r->created_at }}</td>
      <td>{{ $r->tenant_id }}</td>
      <td>{{ $r->user_id }}</td>
      <td>{{ $r->provider }}</td>
      <td>{{ $r->model }}</td>
      <td>{{ $r->tokens_prompt }}</td>
      <td>{{ $r->tokens_completion }}</td>
      <td>{{ $r->calls }}</td>
      <td>{{ number_format($r->cost_usd, 4) }}</td>
    </tr>
  @empty
    <tr><td colspan="10">No usage yet.</td></tr>
  @endforelse
  </tbody>
</table>
@endsection
