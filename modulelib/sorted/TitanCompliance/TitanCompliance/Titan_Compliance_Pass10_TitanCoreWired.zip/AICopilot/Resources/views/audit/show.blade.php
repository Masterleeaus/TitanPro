@extends('aicopilot::layout')
@section('content')
<h2>Audit #{{ $row->id }}</h2>
<pre>{{ json_encode($row->context, JSON_PRETTY_PRINT) }}</pre>
@endsection
