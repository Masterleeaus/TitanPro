@extends('aicopilot::layout')
@section('content')
<h1>AI Assistant Settings</h1>
@if (session('status')) <div class="alert alert-success">{{ session('status') }}</div> @endif
<form method="post" action="{{ route('aicopilot.settings.update') }}"> @csrf
  <label>Default Provider</label>
  <input class="form-control" name="default" value="{{ old('default', $cfg['default'] ?? 'openai') }}"/>
  <button class="btn btn-primary mt-3">Save</button>
</form>
@endsection
