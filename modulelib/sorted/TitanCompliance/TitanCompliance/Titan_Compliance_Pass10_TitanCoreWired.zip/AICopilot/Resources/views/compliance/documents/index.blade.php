{{-- Titan Compliance Pass8 --}}
@extends('aicopilot::layouts.master')

@section('content')
<div class="container">
    <h1 class="mb-3">Compliance Documents</h1>

    <a href="{{ route('aicopilot.compliance-documents.create') }}" class="btn btn-primary mb-3">
        Upload standard / guidance document
    </a>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Title</th>
                <th>Standard ref</th>
                <th>Category</th>
                <th>Uploaded</th>
            </tr>
        </thead>
        <tbody>
            @forelse($documents as $doc)
                <tr>
                    <td>
                        <a href="{{ route('aicopilot.compliance-documents.show', $doc->id) }}">
                            {{ $doc->title }}
                        </a>
                    </td>
                    <td>{{ $doc->standard_ref }}</td>
                    <td>{{ $doc->category }}</td>
                    <td>{{ optional($doc->created_at)->format('Y-m-d') }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="4">No compliance documents uploaded yet.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    {{ $documents->links() }}
</div>
@endsection
