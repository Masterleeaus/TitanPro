@php
    $user = auth()->user();
@endphp

@if($user && (property_exists($user, 'is_superadmin') ? $user->is_superadmin : ($user->is_admin ?? false)))
    <li class="sidebar-item {{ request()->routeIs('aicopilot.settings.*') ? 'active' : '' }}">
        <a class="sidebar-link" href="{{ route('aicopilot.settings.index') }}">
            <i class="ti ti-shield-check"></i>
            <span>{{ __('Titan Compliance') }}</span>
        </a>
    </li>
@endif
