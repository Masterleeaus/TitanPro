{{-- Titan Compliance Pass9 --}}
<li class="{{ request()->routeIs('aicopilot.*') ? 'active' : '' }}">
    <a href="{{ route('aicopilot.dashboard') }}">
        <i class="ti ti-shield-check"></i>
        <span>Titan Compliance</span>
    </a>
</li>
