{{-- Titan Compliance Pass8 --}}
@extends('aicopilot::layouts.master')

@section('content')
<div class="container">
    <h1 class="mb-3">Upload compliance document</h1>

    <form method="POST" action="{{ route('aicopilot.compliance-documents.store') }}" enctype="multipart/form-data">
        @csrf

        <div class="form-group mb-3">
            <label for="document">Document file</label>
            <input type="file" name="document" id="document" class="form-control" required>
        </div>

        <div class="form-group mb-3">
            <label for="standard_ref">Standard reference (optional)</label>
            <input type="text" name="standard_ref" id="standard_ref" class="form-control" placeholder="Eg. AS 3740, NCC Vol 2">
        </div>

        <div class="form-group mb-3">
            <label for="category">Category (optional)</label>
            <input type="text" name="category" id="category" class="form-control" placeholder="Eg. Waterproofing, Framing, Fire">
        </div>

        <div class="form-group mb-3">
            <label for="tags">Tags (optional, comma separated)</label>
            <input type="text" name="tags" id="tags" class="form-control" placeholder="Eg. wet areas, residential, bathrooms">
        </div>

        <button type="submit" class="btn btn-primary">
            Upload &amp; train
        </button>
    </form>
</div>
@endsection
