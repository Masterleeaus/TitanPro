@extends('aicopilot::layout')
@section('content')
<h1>AI Assistant — Health</h1>
@php
  $cfg = config('aicopilot');
  $key = $cfg['providers']['openai']['api_key'] ?? null;
@endphp
<ul class="list-group mb-3">
  <li class="list-group-item"><strong>Default Provider:</strong> {{ $cfg['default'] ?? 'openai' }}</li>
  <li class="list-group-item"><strong>OpenAI Key Present:</strong> {{ $key ? 'Yes' : 'No' }}</li>
  <li class="list-group-item"><strong>Features:</strong> {{ implode(', ', array_keys(array_filter($cfg['features'] ?? []))) }}</li>
</ul>
<div class="card p-3">
  <h5>Status & Metrics</h5>
  <p><a href="{{ route('aicopilot.home') }}">/ai</a> · <a href="{{ route('aicopilot.settings.index') }}">/ai/settings</a> · <a href="{{ route('aicopilot.api.health') }}">/api/ai/health</a> · <a href="{{ route('aicopilot.api.metrics') }}">/api/ai/metrics</a></p>
  <form method="get" action="{{ route('aicopilot.api.health') }}" target="_blank">
    <button class="btn btn-outline-secondary">Run Health Check</button>
  </form>
</div>
@endsection

<hr/>
<h5>Analytics</h5>
@php
  $rows = collect([]);
  try {
    if (\Illuminate\Support\Facades\Schema::hasTable('ai_assistant_usage')) {
      $rows = \Illuminate\Support\Facades\DB::table('ai_assistant_usage')
        ->selectRaw('DATE(created_at) d, SUM(calls) calls, SUM(cost_usd) cost')
        ->groupBy('d')->orderBy('d','desc')->limit(14)->get();
    }
  } catch (\Throwable $e) {}
@endphp
<table class="table table-sm">
  <thead><tr><th>Date</th><th>Calls</th><th>Cost (USD)</th></tr></thead>
  <tbody>
  @foreach($rows as $r)
    <tr><td>{{ $r->d }}</td><td>{{ $r->calls }}</td><td>{{ number_format($r->cost, 4) }}</td></tr>
  @endforeach
  </tbody>
</table>
