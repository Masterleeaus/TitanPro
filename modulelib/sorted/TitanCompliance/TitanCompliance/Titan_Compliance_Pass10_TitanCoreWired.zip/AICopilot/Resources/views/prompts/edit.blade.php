@extends('aicopilot::layout')
@section('content')
<h1>Edit Prompt</h1>
@if (session('status')) <div class="alert alert-success">{{ session('status') }}</div> @endif
<form method="post" action="{{ route('aicopilot.prompts.update',$prompt) }}">@csrf @method('PUT')
  <div class="mb-3"><label>Title</label><input name="title" class="form-control" value="{{ $prompt->title }}" required></div>
  <div class="mb-3"><label>Category</label>
    <select name="category_id" class="form-select">
      <option value="">-</option>
      @foreach($cats as $c)<option value="{{ $c->id }}" @if($prompt->category_id==$c->id) selected @endif>{{ $c->name }}</option>@endforeach
    </select>
  </div>
  <div class="mb-3"><label>Visibility</label>
    <select name="visibility" class="form-select">
      @foreach(['private','team','public'] as $v)<option value="{{ $v }}" @if($prompt->visibility==$v) selected @endif>{{ ucfirst($v) }}</option>@endforeach
    </select>
  </div>
  <div class="mb-3"><label>Content</label><textarea name="content" class="form-control" rows="10" required>{{ $prompt->content }}</textarea></div>
  <button class="btn btn-success">Save</button>
</form>
@endsection
