@extends('aicopilot::layout')
@section('content')
<h1>New Prompt</h1>
<form method="post" action="{{ route('aicopilot.prompts.store') }}">@csrf
  <div class="mb-3"><label>Title</label><input name="title" class="form-control" required></div>
  <div class="mb-3"><label>Category</label>
    <select name="category_id" class="form-select">
      <option value="">-</option>
      @foreach($cats as $c)<option value="{{ $c->id }}">{{ $c->name }}</option>@endforeach
    </select>
  </div>
  <div class="mb-3"><label>Visibility</label>
    <select name="visibility" class="form-select">
      @foreach(['private','team','public'] as $v)<option value="{{ $v }}">{{ ucfirst($v) }}</option>@endforeach
    </select>
  </div>
  <div class="mb-3"><label>Content</label><textarea name="content" class="form-control" rows="10" required></textarea></div>
  <button class="btn btn-success">Save</button>
</form>
@endsection
