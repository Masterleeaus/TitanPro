{{-- Titan Compliance Pass8 --}}
@extends('aicopilot::layouts.master')

@section('content')
<div class="container">
    <h1 class="mb-3">{{ $document->title }}</h1>

    <p><strong>Standard ref:</strong> {{ $document->standard_ref }}</p>
    <p><strong>Category:</strong> {{ $document->category }}</p>

    <h3 class="mt-4">Sections</h3>
    @if($document->sections->isEmpty())
        <p>No sections stored for this document yet.</p>
    @else
        <div class="list-group">
            @foreach($document->sections as $section)
                <div class="list-group-item mb-2">
                    <pre class="mb-0" style="white-space: pre-wrap;">{{ $section->text }}</pre>
                </div>
            @endforeach
        </div>
    @endif
</div>
@endsection
