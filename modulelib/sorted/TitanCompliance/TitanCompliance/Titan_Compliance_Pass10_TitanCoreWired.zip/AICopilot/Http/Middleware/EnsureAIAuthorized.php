<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6

namespace Modules\\AICopilot\Http\Middleware;
use Closure; use Illuminate\Http\Request;
class EnsureAIAuthorized
{
    public function handle(Request $request, Closure $next, string $ability = 'aicopilot.view')
    {
        if (!$request->user() || !$request->user()->can($ability)) abort(403);
        return $next($request);
    }
}
