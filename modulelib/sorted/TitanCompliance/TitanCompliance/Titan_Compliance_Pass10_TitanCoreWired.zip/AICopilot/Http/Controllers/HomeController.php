<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6


namespace Modules\\AICopilot\Http\Controllers;

use Illuminate\Routing\Controller;

use Illuminate\Support\Facades\Gate;

class HomeController extends Controller
{
    public function index(){ Gate::authorize('aicopilot.view');
    {
        return view('aicopilot::index');
    }
}
