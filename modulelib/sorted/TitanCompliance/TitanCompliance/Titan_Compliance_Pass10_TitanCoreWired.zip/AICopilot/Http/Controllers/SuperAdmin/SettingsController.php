<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6

// This file use for handle super admin setting page

namespace Modules\\AICopilot\Http\Controllers\SuperAdmin;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class SettingsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index($settings)
    {
        return view('aicopilot::super-admin.settings.index',compact('settings'));
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }
}
