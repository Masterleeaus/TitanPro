<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6

namespace Modules\\AICopilot\Http\Controllers;
use Illuminate\Http\Request; use Illuminate\Routing\Controller as BaseController;
class SettingsController extends BaseController
{
    protected function persist(array $data): void
    {
        // naive fallback: if 'settings' or 'options' table exists, save json under a single key
        try {
            if (\Illuminate\Support\Facades\Schema::hasTable('settings')) {
                \Illuminate\Support\Facades\DB::table('settings')->updateOrInsert(['key'=>'aicopilot'],['value'=>json_encode($data), 'updated_at'=>now()]);
            } elseif (\Illuminate\Support\Facades\Schema::hasTable('options')) {
                \Illuminate\Support\Facades\DB::table('options')->updateOrInsert(['option_key'=>'aicopilot'],['option_value'=>json_encode($data), 'updated_at'=>now()]);
            }
        } catch (\Throwable $e) {}
    }
{
    public function index(){ $cfg = config('aicopilot'); return view('aicopilot::settings.index', compact('cfg')); }
    public function update(Request $request){ $request->validate(['default'=>'required']); return back()->with('status','Settings saved (runtime only).'); }
}
