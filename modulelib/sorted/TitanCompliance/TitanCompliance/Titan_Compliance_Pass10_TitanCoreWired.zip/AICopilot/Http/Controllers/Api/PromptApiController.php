<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6

namespace Modules\AICopilot\Http\Controllers\Api;
use Illuminate\Http\Request; use Illuminate\Routing\Controller as BaseController;
use Modules\AICopilot\Models\Prompt;
class PromptApiController extends BaseController
{
    public function index(Request $request) {
        $q = Prompt::query();
        if ($s = $request->string('q')) {
            $q->where(function($qq) use ($s){
                $qq->where('title','like','%'.$s.'%')->orWhere('content','like','%'.$s.'%');
            });
        }
        return response()->json($q->orderBy('title')->limit(200)->get());
    }
}
