<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6


namespace Modules\\AICopilot\Http\Controllers;

use App\Models\ApikeySetiings;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Modules\\AICopilot\Entities\AssistantTemplate;
use Modules\AICore\Contracts\AI\ClientInterface as TitanClient;

class AICopilotController extends Controller
{
    public function __construct(protected TitanClient $client)
    {
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        return view('aicopilot::index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create($template_module,$module)
    {
        $templateName = AssistantTemplate::where('template_module', $template_module)->where('module', $module)->get();

        return view('aicopilot::ai.generate',compact('templateName'));
    }
    public function vcard_create_business($template_module,$module,$id)
    {
        $business_id=$id;
        $templateName = AssistantTemplate::where('template_module',$template_module)->where('module',$module)->get();
        return view('aicopilot::ai.generate_vcard_business',compact('templateName','business_id'));
    }
    public function vcard_create_service($template_module,$module,$id)
    {
        $serviceid=$id;
        $templateName = AssistantTemplate::where('template_module',$template_module)->where('module',$module)->get();
        return view('aicopilot::ai.generate_vcard_service',compact('templateName','serviceid'));
    }

    public function vcard_create_testimonial($template_module,$module,$id)
    {
        $testimonial_id=$id;
        $templateName = AssistantTemplate::where('template_module',$template_module)->where('module',$module)->get();
        return view('aicopilot::ai.generate_vcard_testimonial',compact('templateName','testimonial_id'));
    }

    public function cmms_create($template_module,$module)
    {
        $templateName = AssistantTemplate::where('template_module',$template_module)->where('module',$module)->get();

        return view('aicopilot::ai.cmms_generate',compact('templateName'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('aicopilot::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('aicopilot::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }
    public function GetKeywords(Request $request, $id)
    {
     
        $template = AssistantTemplate::find($id);
        $field_data = json_decode($template->field_json);

        $html = "";
        foreach ($field_data->field as  $value) {
            $html .= '<div class="form-group col-md-12">
                    <label class="form-label ">' . $value->label . '</label>';
            if ($value->field_type == "text_box") {

                $html .= '<input type="text" class="form-control" name="' . $value->field_name . '" value="" placeholder="' . $value->placeholder . '" required">';
            }
            if ($value->field_type == "textarea") {
                $html .= '<textarea type="text" rows=3 class="form-control " id="description" name="' . $value->field_name . '" placeholder="' . $value->placeholder . '" required></textarea>';
            }
            $html .= '</div>';
        }
        return response()->json(
            [
                'success' => true,
                'template' => $html,
                'tone'=>$template->is_tone
            ]
        );
    }
    
    public function AiGenerate(Request $request)
    {
        if ($request->ajax()) {

            $post = $request->all();

            unset(
                $post['_token'],
                $post['template_name'],
                $post['language'],
                $post['tone'],
                $post['ai_creativity'],
                $post['num_of_result'],
                $post['result_length']
            );

            $data = [];

            $prompt = '';
            $model = '';
            $text = '';
            $ai_token = '';
            $counter = 1;

            $template = AssistantTemplate::where('id', $request->template_name)->first();

            if ($request->template_name) {

                $required_field = [];
                $data_field = json_decode($template->field_json);

                foreach ($data_field->field as $val) {
                    $validator = \Validator::make(
                        $request->all(),
                        [
                            $val->field_name => 'required',
                        ]
                    );

                    if ($validator->fails()) {
                        $required_field[] = $val->label;
                    }
                }

                if (count($required_field) > 0) {
                    return response()->json([
                        'status' => 'error',
                        'message' => __('Please fill all required fields: ') . implode(', ', $required_field),
                    ]);
                }

                $prompt = $template->prompt;

                foreach ($data_field->field as $field) {
                    $text_rep = "##" . $field->field_name . "##";
                    if (strpos($prompt, $text_rep) !== false) {
                        $field->value = $post[$field->field_name] ?? '';
                        $prompt = str_replace($text_rep, $post[$field->field_name] ?? '', $prompt);
                    }

                    if ($template->is_tone == 1) {
                        $tone = $request->tone;
                        $param = "##tone_language##";
                        $prompt = str_replace($param, $tone, $prompt);
                    }
                }
            }

            $lang_text = "Provide response in " . $request->language . " language.\n\n ";
            $ai_token = (int) $request->result_length;
            $max_results = (int) $request->num_of_result;
            $ai_creativity = (float) $request->ai_creativity;

            $systemPrefix = <<<TXT
You are Titan Compliance, an informational assistant for construction standards, safety, and compliance.
You help with:
- summarising relevant standards (AS/NZS, NCC) at a high level
- drafting compliance checklists, notices, and advisory letters
- suggesting risk-mitigation wording

Rules:
- You DO NOT give legal advice.
- You DO NOT claim to be a lawyer, certifier, or regulator.
- If unsure about specific clauses, say "verify in the relevant AS/NZS or NCC section" instead of inventing a clause number.
- Encourage users to consult a qualified building certifier, engineer, or WHS professional.
TXT;

            $context = app(\Modules\AICopilot\Services\ComplianceKnowledgeBase::class)
                ->buildContextFromQuery($prompt);

            if (! empty($context)) {
                $finalPrompt = $systemPrefix . "\n\n" . $context . "\n\n" . $prompt . ' ' . $lang_text;
            } else {
                $finalPrompt = $systemPrefix . "\n\n" . $prompt . ' ' . $lang_text;
            }

            $result = $this->client->chat([
                'model' => 'gpt-5-mini',
                'messages' => [
                    ['role' => 'user', 'content' => $finalPrompt],
                ],
            ]);

            $resultText = $result['response'] ?? '';

            $resultText .= "\n\n⚠️ This is compliance guidance only and not legal advice. " .
                           "Always verify with AS/NZS / NCC and consult qualified professionals.";

            return trim($resultText);
        }
    }

}
