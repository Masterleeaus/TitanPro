<?php
// Titan Compliance Pass8

namespace Modules\AICopilot\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Modules\AICopilot\Entities\ComplianceDocument;
use Modules\AICopilot\Services\ComplianceKnowledgeBase;

class ComplianceDocumentController extends Controller
{
    public function __construct(protected ComplianceKnowledgeBase $knowledgeBase)
    {
    }

    public function index()
    {
        $documents = ComplianceDocument::latest()->paginate(20);

        return view('aicopilot::compliance.documents.index', compact('documents'));
    }

    public function create()
    {
        return view('aicopilot::compliance.documents.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'document'     => 'required|file',
            'standard_ref' => 'nullable|string|max:191',
            'category'     => 'nullable|string|max:191',
        ]);

        $file = $request->file('document');

        $path = $file->store('aicopilot/compliance-documents', [
            'disk' => config('filesystems.default', 'local'),
        ]);

        $text = null;

        // NOTE: This is intentionally simple. In your real app you
        // would plug in a PDF/DOCX parser or OCR here.
        if (in_array($file->getClientOriginalExtension(), ['txt', 'md'])) {
            $text = file_get_contents($file->getRealPath());
        }

        $document = ComplianceDocument::create([
            'title'        => $file->getClientOriginalName(),
            'filename'     => basename($path),
            'path'         => $path,
            'mime_type'    => $file->getClientMimeType(),
            'size'         => $file->getSize(),
            'standard_ref' => $request->get('standard_ref'),
            'category'     => $request->get('category'),
            'tags'         => $request->get('tags') ? explode(',', $request->get('tags')) : null,
            'uploaded_by'  => optional($request->user())->id,
            'text_content' => $text,
        ]);

        // Chunk & embed in background if needed. For now we do it inline,
        // but you may wish to dispatch to a job instead.
        if ($document->text_content) {
            $this->knowledgeBase->chunkDocument($document);
            $this->knowledgeBase->embedSections($document);
        }

        return redirect()
            ->route('aicopilot.compliance-documents.index')
            ->with('status', __('Compliance document uploaded and processed.'));
    }

    public function show(ComplianceDocument $complianceDocument)
    {
        $document = $complianceDocument->load('sections');

        return view('aicopilot::compliance.documents.show', compact('document'));
    }
}
