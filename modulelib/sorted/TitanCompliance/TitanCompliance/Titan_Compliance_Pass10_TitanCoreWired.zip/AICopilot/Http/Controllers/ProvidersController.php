<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6

namespace Modules\\AICopilot\Http\Controllers;
use Illuminate\Http\Request; use Illuminate\Routing\Controller as BaseController;

class ProvidersController extends BaseController
{
    public function index()
    {
        $cfg = config('aicopilot');
        return view('aicopilot::providers.index', compact('cfg'));
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'default' => 'required|string',
        ]);
        // persist to settings/options if present
        try {
            if (\Illuminate\Support\Facades\Schema::hasTable('settings')) {
                \Illuminate\Support\Facades\DB::table('settings')->updateOrInsert(['key'=>'aicopilot'],['value'=>json_encode($data),'updated_at'=>now()]);
            } elseif (\Illuminate\Support\Facades\Schema::hasTable('options')) {
                \Illuminate\Support\Facades\DB::table('options')->updateOrInsert(['option_key'=>'aicopilot'],['option_value'=>json_encode($data),'updated_at'=>now()]);
            }
        } catch (\Throwable $e) {}
        return back()->with('status','Provider settings saved.');
    }

    public function test(Request $request)
    {
        try {
            $client = app(\Modules\\AICopilot\Services\AI\ClientInterface::class);
            $reply = $client->chat('Ping?');
            return back()->with('status', 'Test OK: '.substr((string)$reply,0,140));
        } catch (\Throwable $e) {
            return back()->with('status', 'Test failed: '.$e->getMessage());
        }
    }
}
