<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6

namespace Modules\AICopilot\Http\Controllers;
use Illuminate\Http\Request; use Illuminate\Support\Str;
use Illuminate\Routing\Controller as BaseController;
use Modules\AICopilot\Models\Prompt; use Modules\AICopilot\Models\PromptCategory;

class PromptController extends BaseController
{
    public function index() {
        $prompts = Prompt::with('category')->orderBy('title')->paginate(20);
        $cats = PromptCategory::orderBy('sort')->get();
        return view('aicopilot::prompts.index', compact('prompts','cats'));
    }
    public function create() {
        $cats = PromptCategory::orderBy('sort')->get();
        return view('aicopilot::prompts.create', compact('cats'));
    }
    public function store(Request $request) {
        $data = $request->validate([
            'title'=>'required|string|max:160',
            'category_id'=>'nullable|integer',
            'content'=>'required|string',
            'visibility'=>'required|in:private,team,public',
        ]);
        $data['slug'] = Str::slug($data['title']).'-'.Str::random(4);
        $data['author_id'] = optional($request->user())->id;
        Prompt::create($data);
        return redirect()->route('aicopilot.prompts.index')->with('status','Prompt created.');
    }
    public function edit(Prompt $prompt) {
        $cats = PromptCategory::orderBy('sort')->get();
        return view('aicopilot::prompts.edit', compact('prompt','cats'));
    }
    public function update(Request $request, Prompt $prompt) {
        $data = $request->validate([
            'title'=>'required|string|max:160',
            'category_id'=>'nullable|integer',
            'content'=>'required|string',
            'visibility'=>'required|in:private,team,public',
        ]);
        $prompt->update($data);
        return back()->with('status','Prompt updated.');
    }
    public function destroy(Prompt $prompt) {
        $prompt->delete();
        return back()->with('status','Prompt deleted.');
    }
}
