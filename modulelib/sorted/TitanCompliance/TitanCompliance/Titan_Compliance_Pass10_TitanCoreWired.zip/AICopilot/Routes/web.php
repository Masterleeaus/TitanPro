<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Modules\\AICopilot\Http\Controllers\AICopilotController;
Route::group(['middleware' => 'PlanModuleCheck:AICopilot'], function ()
{
    Route::prefix('aicopilot')->group(function() {
		
		Route::get('/generate/{template_module}/{module}', [AICopilotController::class, 'create'])->name('aicopilot.generate')->middleware(['auth']);
		Route::post('/generate/keywords/{id}', [AICopilotController::class, 'GetKeywords'])->name('aicopilot.generate.keywords')->middleware(['auth']);
		Route::any('/generate/response', [AICopilotController::class, 'AiGenerate'])->name('aicopilot.generate.response')->middleware(['auth']);
		Route::any('/generate/{template_module}/{module}/{id}', [AICopilotController::class, 'vcard_create_business'])->name('aicopilot.generate_business')->middleware(['auth']);
		Route::any('/generate_service/{template_module}/{module}/{id}', [AICopilotController::class, 'vcard_create_service'])->name('aicopilot.generate_vcard_service')->middleware(['auth']);
		Route::any('/generate_testimonial/{template_module}/{module}/{id}', [AICopilotController::class, 'vcard_create_testimonial'])->name('aicopilot.generate_vcard_testimonial')->middleware(['auth']);
		Route::any('/cmms-generate/{template_module}/{module}', [AICopilotController::class, 'cmms_create'])->name('cmms_aicopilot.generate')->middleware(['auth']);
	


    });
});

Route::middleware(['web','auth','ai.can:aicopilot.admin'])
  ->prefix('ai/settings')->name('aicopilot.settings.')->group(function(){
    Route::get('/', [\Modules\\AICopilot\Http\Controllers\SettingsController::class,'index'])->name('index');
    Route::post('/', [\Modules\\AICopilot\Http\Controllers\SettingsController::class,'update'])->name('update');
});


Route::middleware(['web','auth','ai.can:aicopilot.admin'])
    ->get('/ai/health', fn() => view('aicopilot::dashboard'))->name('aicopilot.dashboard');

Route::middleware(['web','auth','ai.can:aicopilot.logs'])
  ->prefix('ai/usage')->name('aicopilot.usage.')->group(function () {
    Route::get('/', [\Modules\\AICopilot\Http\Controllers\UsageController::class, 'index'])->name('index');
    Route::get('/export', [\Modules\\AICopilot\Http\Controllers\UsageController::class, 'exportCsv'])->name('export');
});

Route::middleware(['web','auth','ai.can:aicopilot.settings'])
  ->prefix('ai/providers')->name('aicopilot.providers.')->group(function(){
    Route::get('/', [\Modules\\AICopilot\Http\Controllers\ProvidersController::class,'index'])->name('index');
    Route::post('/', [\Modules\\AICopilot\Http\Controllers\ProvidersController::class,'update'])->name('update');
    Route::get('/test', [\Modules\\AICopilot\Http\Controllers\ProvidersController::class,'test'])->name('test');
});

Route::middleware(['web','auth','ai.can:aicopilot.settings'])
  ->prefix('ai/prompts')->name('aicopilot.prompts.')->group(function(){
    Route::get('/', [\Modules\AICopilot\Http\Controllers\PromptController::class,'index'])->name('index');
    Route::get('/create', [\Modules\AICopilot\Http\Controllers\PromptController::class,'create'])->name('create');
    Route::post('/', [\Modules\AICopilot\Http\Controllers\PromptController::class,'store'])->name('store');
    Route::get('/{prompt}/edit', [\Modules\AICopilot\Http\Controllers\PromptController::class,'edit'])->name('edit');
    Route::put('/{prompt}', [\Modules\AICopilot\Http\Controllers\PromptController::class,'update'])->name('update');
    Route::delete('/{prompt}', [\Modules\AICopilot\Http\Controllers\PromptController::class,'destroy'])->name('destroy');
});


Route::middleware(['web','auth','ai.can:aicopilot.settings'])
    ->prefix('ai/compliance-documents')
    ->name('aicopilot.compliance-documents.')
    ->group(function () {
        Route::get('/', [\Modules\AICopilot\Http\Controllers\ComplianceDocumentController::class, 'index'])->name('index');
        Route::get('/create', [\Modules\AICopilot\Http\Controllers\ComplianceDocumentController::class, 'create'])->name('create');
        Route::post('/', [\Modules\AICopilot\Http\Controllers\ComplianceDocumentController::class, 'store'])->name('store');
        Route::get('/{complianceDocument}', [\Modules\AICopilot\Http\Controllers\ComplianceDocumentController::class, 'show'])->name('show');
    });
