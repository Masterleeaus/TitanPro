<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/aicopilot', function (Request $request) {
    return $request->user();
});
Route::middleware(['api','auth:sanctum','ai.can:aicopilot.admin'])
  ->prefix('api/ai')->group(function(){
    Route::get('/metrics', function(){
      try {
        $rows = \Illuminate\Support\Facades\DB::table('ai_assistant_usage')->count();
        $calls = \Illuminate\Support\Facades\DB::table('ai_assistant_usage')->sum('calls');
        return response("aicopilot_usage_rows {r}\naicopilot_calls_total {c}\n",200)
          ->header('Content-Type','text/plain')
          ->setContent(strtr("aicopilot_usage_rows {r}\naicopilot_calls_total {c}\n", ['{r}'=>$rows,'{c}'=>$calls]));
      } catch (\Throwable $e){ return response("aicopilot_usage_rows 0\naicopilot_calls_total 0\n",200)->header('Content-Type','text/plain'); }
    })->name('aicopilot.api.metrics');
});

Route::middleware(['api','auth:sanctum','ai.can:aicopilot.view'])
  ->prefix('api/ai')->name('aicopilot.api.')->group(function(){
    Route::get('/prompts', [\Modules\AICopilot\Http\Controllers\Api\PromptApiController::class,'index'])->name('prompts');
});

Route::middleware(['api','auth:sanctum','ai.can:aicopilot.generate'])
  ->prefix('api/ai')->name('aicopilot.api.')->group(function(){
    Route::post('/images/generate', [\Modules\AICopilot\Http\Controllers\Api\ImageApiController::class,'generate'])->name('images.generate');
});
