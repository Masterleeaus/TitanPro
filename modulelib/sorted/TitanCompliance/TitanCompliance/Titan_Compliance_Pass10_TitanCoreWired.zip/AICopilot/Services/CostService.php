<?php
namespace Modules\\AICopilot\Services;

class CostService
{
    public function estimateUsd(string $provider, ?string $model, int $promptTokens, int $completionTokens): float
    {
        $pricing = config('aicopilot.pricing', []);
        $p = $pricing[$provider][$model] ?? null;
        if (!$p) return 0.0;
        $in = ($p['input'] ?? 0) * ($promptTokens / 1000);
        $out = ($p['output'] ?? 0) * ($completionTokens / 1000);
        return round($in + $out, 6);
    }
}
