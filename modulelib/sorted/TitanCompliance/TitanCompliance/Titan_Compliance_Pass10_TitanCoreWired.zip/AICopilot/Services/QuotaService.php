<?php
namespace Modules\\AICopilot\Services;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class QuotaService
{
    public function check(?int $userId, ?string $tenantId): array
    {
        $limits = config('aicopilot.quotas', []);
        $perUser = (int)($limits['per_user_daily_calls'] ?? 200);
        $perTenant = (int)($limits['per_tenant_daily_calls'] ?? 2000);

        $today = now()->startOfDay();
        $userCalls = 0;
        $tenantCalls = 0;

        if (Schema::hasTable('ai_assistant_usage')) {
            $q = DB::table('ai_assistant_usage')->where('created_at','>=',$today);
            if ($userId) {
                $userCalls = (clone $q)->where('user_id',$userId)->sum('calls');
            }
            if ($tenantId) {
                $tenantCalls = (clone $q)->where('tenant_id',$tenantId)->sum('calls');
            }
        }
        $overUser = $userId ? ($userCalls >= $perUser) : false;
        $overTenant = $tenantId ? ($tenantCalls >= $perTenant) : false;
        return [
            'over' => $overUser or $overTenant,
            'user_calls' => $userCalls, 'user_limit' => $perUser,
            'tenant_calls' => $tenantCalls, 'tenant_limit' => $perTenant,
        ];
    }
}
