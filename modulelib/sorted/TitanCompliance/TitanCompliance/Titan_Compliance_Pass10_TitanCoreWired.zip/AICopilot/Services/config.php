<?php

return [
    'name' => 'AICopilot'
];
