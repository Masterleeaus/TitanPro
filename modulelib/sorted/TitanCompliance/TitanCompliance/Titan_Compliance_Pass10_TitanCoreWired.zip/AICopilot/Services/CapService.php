<?php
namespace Modules\\AICopilot\Services;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CapService
{
    public function exceeded(?int $userId, ?string $tenantId, float $newCostUsd): array
    {
        $limits = config('aicopilot.cost_caps', []);
        $perUser = (float)($limits['per_user_daily_usd'] ?? 2.00);
        $perTenant = (float)($limits['per_tenant_daily_usd'] ?? 10.00);
        $today = now()->startOfDay();
        $userCost = 0.0; $tenantCost = 0.0;

        if (Schema::hasTable('ai_assistant_usage')) {
            if ($userId) {
                $userCost = (float) DB::table('ai_assistant_usage')
                    ->where('created_at','>=',$today)->where('user_id',$userId)->sum('cost_usd');
            }
            if ($tenantId) {
                $tenantCost = (float) DB::table('ai_assistant_usage')
                    ->where('created_at','>=',$today)->where('tenant_id',$tenantId)->sum('cost_usd');
            }
        }
        $overUser = $userId ? ($userCost + $newCostUsd > $perUser) : false;
        $overTenant = $tenantId ? ($tenantCost + $newCostUsd > $perTenant) : false;
        return ['over'=>$overUser || $overTenant, 'user_cost'=>$userCost, 'tenant_cost'=>$tenantCost,
                'user_limit'=>$perUser, 'tenant_limit'=>$perTenant];
    }
}
