<?php
// Titan Compliance Pass7

namespace Modules\AICopilot\Services;

use Modules\AICopilot\Entities\AssistantTemplate;

class ComplianceTemplateService
{
    public function allComplianceTemplates()
    {
        return AssistantTemplate::where('is_compliance', true)->get();
    }

    public function complianceTemplatesByRisk(?string $risk = null)
    {
        $query = AssistantTemplate::where('is_compliance', true);

        if ($risk) {
            $query->where('risk_level', $risk);
        }

        return $query->get();
    }

    public function categories()
    {
        return AssistantTemplate::whereNotNull('category')
            ->distinct()
            ->pluck('category')
            ->toArray();
    }
}
