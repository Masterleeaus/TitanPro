<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6

namespace Modules\\AICopilot\Policies;
use App\Models\User;
class AICopilotPolicy
{
    public function view(?User $user): bool { return $user ? $user->can('aicopilot.view') : false; }
    public function generate(?User $user): bool { return $user ? $user->can('aicopilot.generate') : false; }
    public function admin(?User $user): bool { return $user ? $user->can('aicopilot.admin') : false; }
}
