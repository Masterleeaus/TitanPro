<?php
// Titan Compliance Pass8

// Titan Compliance Pass7

// Titan Compliance Pass6

namespace Modules\AICopilot\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Prompt extends Model
{
    protected $table = 'ai_prompts';
    protected $fillable = ['title','slug','category_id','content','meta','visibility','author_id'];
    protected $casts = ['meta' => 'array'];
    public function category(): BelongsTo { return $this->belongsTo(PromptCategory::class, 'category_id'); }
}
