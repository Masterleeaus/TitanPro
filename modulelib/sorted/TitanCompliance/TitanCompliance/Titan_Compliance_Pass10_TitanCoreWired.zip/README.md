# AICopilot Delta (S7 → P4)
Date: 2025-10-01T22:38:12.229561Z

Adds:
- **Telemetry Collector** — aggregates http metrics from events and exposes text exposition.
- **Updated TelemetryServiceProvider** — wires collector and `/aicopilot/metrics` output.
- **Fail-safe Guard** — middleware + config to enforce auth on `/aicopilot/*` without editing routes.
- **PermissionsSeeder** — idempotent insert of `aicopilot.use` permission.
- **Docs** partials.

## Install
```bash
unzip AICopilot_Delta_S7P4.zip -d .
rsync -a Modules/AICopilot/ Modules/AICopilot/
php artisan config:clear && php artisan cache:clear
```

Register provider (if not yet):
```php
$this->app->register(\Modules\AICopilot\Providers\TelemetryServiceProvider::class);
```

Wire middleware:
- **Web kernel**: add to route or group middleware where appropriate.
```php
\Modules\AICopilot\Http\Middleware\AIFailsafeGuard::class
```
or include it in your `web` group.

Seed permission (optional, safe to re-run):
```bash
php artisan db:seed --class="Modules\AICopilot\Database\Seeders\PermissionsSeeder"
```

Enable metrics (guarded by default):
```
AIC_TELEMETRY_ENABLED=true
AIC_PROMETHEUS_ENABLED=true
AIC_PROMETHEUS_ROUTE=/aicopilot/metrics
AIC_PROMETHEUS_GUARD=auth
```

Fail-safe auth:
```
AIC_FAILSAFE_GUARD_ENABLED=true
AIC_FAILSAFE_GUARD=auth
```
