<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;

class AIFailsafeGuard
{
    public function handle(Request $request, Closure $next)
    {
        $cfg = Config::get('titancompliance.guards', []);
        if (!($cfg['enabled'] ?? true)) return $next($request);

        $prefixes = $cfg['prefixes'] ?? ['titancompliance'];
        $path = ltrim($request->path(), '/');

        foreach ($prefixes as $px) {
            if (stripos($path, trim($px, '/')) === 0) {
                if (!Auth::check()) {
                    // Redirect to login (web) or 401 for API/AJAX
                    if ($request->expectsJson()) {
                        return response()->json(['message' => 'Unauthenticated.'], 401);
                    }
                    return redirect()->guest(route('login'));
                }
                break;
            }
        }
        return $next($request);
    }
}
