<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Symfony\Component\HttpFoundation\Response as BaseResponse;
use Modules\TitanCompliance\Services\ComplianceEnforcementService;
use Modules\TitanCompliance\Contracts\Integrations\JobContextProviderInterface;

final class EnsureCompliance
{
    public function __construct(
        private readonly ComplianceEnforcementService $enforcer,
        private readonly JobContextProviderInterface $jobContext,
    ) {}

    /**
     * Expects `job_id` in route params or query.
     */
    public function handle(Request $request, Closure $next, string $action = 'job_action'): BaseResponse
    {
        $jobId = $request->route('job_id') ?? $request->get('job_id');
        if ($jobId === null) {
            return $next($request);
        }

        $context = $this->jobContext->buildFromJobId($jobId);
        $decision = $this->enforcer->decide($action, $context);

        if (!$decision->allowed && $decision->level === 'block') {
            return new Response(['message' => 'Compliance gate failed', 'reason' => $decision->reason, 'details' => $decision->details], 422);
        }

        // Non-blocking: attach warning header
        $response = $next($request);
        if (!$decision->allowed) {
            $response->headers->set('X-TitanCompliance-Warn', $decision->reason);
        }
        return $response;
    }
}
