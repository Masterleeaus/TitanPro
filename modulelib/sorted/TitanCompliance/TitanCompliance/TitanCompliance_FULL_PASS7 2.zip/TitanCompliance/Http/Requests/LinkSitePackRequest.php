<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class LinkSitePackRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'status' => ['nullable','string','max:50'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
