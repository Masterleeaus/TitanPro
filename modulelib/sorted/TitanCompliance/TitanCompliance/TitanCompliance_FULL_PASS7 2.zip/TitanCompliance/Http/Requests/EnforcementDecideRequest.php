<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class EnforcementDecideRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'action' => ['required','string'],
            'job_id' => ['nullable'],
        ];
    }
}
