<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class AddComplianceNoteRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'note' => ['required','string','min:1'],
            'subject_type' => ['nullable','string','max:32'],
            'subject_id' => ['nullable','integer','min:1'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
