<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class LockRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'reason' => ['nullable','string','max:64'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
