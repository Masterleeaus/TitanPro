<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class CreateSnapshotRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'subject_type' => ['nullable','string','max:32'],
            'subject_id' => ['nullable','integer','min:1'],
            'payload' => ['nullable','array'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
