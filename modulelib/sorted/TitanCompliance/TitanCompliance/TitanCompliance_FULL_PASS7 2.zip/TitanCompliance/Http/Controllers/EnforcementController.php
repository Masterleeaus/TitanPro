<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\TitanCompliance\Services\ComplianceEnforcementService;
use Modules\TitanCompliance\Contracts\Integrations\JobContextProviderInterface;
use Modules\TitanCompliance\Integrations\Adapters\NullJobContextProvider;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class EnforcementController extends Controller
{
    public function decide(Request $request, ComplianceEnforcementService $svc)
    {
        $action = (string) $request->input('action', 'unknown');

        /** @var JobContextProviderInterface $provider */
        $provider = app()->bound(JobContextProviderInterface::class)
            ? app(JobContextProviderInterface::class)
            : new NullJobContextProvider();

        $jobId = $request->input('job_id');
        $ctx = $jobId !== null
            ? $provider->buildFromJobId($jobId)
            : new ComplianceContext(null, null, null, null, null, null, []);

        $decision = $svc->decide($action, $ctx);

        return response()->json([
            'allowed' => $decision->allowed,
            'reason' => $decision->reason,
            'details' => $decision->details,
            'level' => $decision->level,
        ]);
    }
}
