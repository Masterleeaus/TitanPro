<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Services\JobComplianceService;

final class JobComplianceController
{
    public function __construct(private readonly JobComplianceService $svc) {}

    public function link(Request $request, int $jobId, int $packId): JsonResponse
    {
        $pack = CompliancePack::query()->findOrFail($packId);
        $row = $this->svc->linkPackToJob($jobId, $pack, (string) $request->input('status', 'draft'));
        return response()->json(['ok' => true, 'data' => $row]);
    }
}
