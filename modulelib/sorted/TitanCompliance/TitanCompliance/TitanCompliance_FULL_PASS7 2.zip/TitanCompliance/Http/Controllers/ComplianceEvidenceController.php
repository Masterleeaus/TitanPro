<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Modules\TitanCompliance\Services\EvidenceIngestService;

final class ComplianceEvidenceController
{
    public function __construct(private readonly EvidenceIngestService $svc) {}

    public function addNote(Request $request, int $packId): JsonResponse
    {
        $note = (string) $request->input('note', '');
        $subjectType = (string) $request->input('subject_type', 'pack');
        $subjectId = $request->integer('subject_id') ?: null;

        $row = $this->svc->addNote($packId, $note, $subjectType, $subjectId, $request->user()?->id);
        return response()->json(['ok' => true, 'data' => $row]);
    }
}
