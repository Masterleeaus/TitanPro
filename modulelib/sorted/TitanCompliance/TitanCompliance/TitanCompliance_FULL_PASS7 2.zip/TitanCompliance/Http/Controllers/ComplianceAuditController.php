<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Modules\TitanCompliance\Models\ComplianceAudit;

final class ComplianceAuditController
{
    public function index(): JsonResponse
    {
        $rows = ComplianceAudit::query()->latest()->limit(50)->get();
        return response()->json(['ok' => true, 'data' => $rows]);
    }
}
