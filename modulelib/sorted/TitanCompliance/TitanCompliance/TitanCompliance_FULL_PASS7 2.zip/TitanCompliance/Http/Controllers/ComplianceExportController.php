<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Modules\TitanCompliance\Models\CompliancePack;

final class ComplianceExportController
{
    public function show(int $packId): JsonResponse
    {
        $pack = CompliancePack::query()->findOrFail($packId);
        return response()->json(['ok' => true, 'data' => $pack]);
    }
}
