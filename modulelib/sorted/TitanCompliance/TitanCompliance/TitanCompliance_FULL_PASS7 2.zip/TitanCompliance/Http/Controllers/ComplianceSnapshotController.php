<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Services\ComplianceSnapshotService;

final class ComplianceSnapshotController
{
    public function __construct(private readonly ComplianceSnapshotService $svc) {}

    public function snapshot(Request $request, int $packId): JsonResponse
    {
        $pack = CompliancePack::query()->findOrFail($packId);
        $subjectType = (string) $request->input('subject_type', 'pack');
        $subjectId = $request->integer('subject_id') ?: null;
        $payload = (array) $request->input('payload', []);

        $row = $this->svc->snapshot($pack, $subjectType, $subjectId, $payload, $request->user()?->id);
        return response()->json(['ok' => true, 'data' => $row]);
    }
}
