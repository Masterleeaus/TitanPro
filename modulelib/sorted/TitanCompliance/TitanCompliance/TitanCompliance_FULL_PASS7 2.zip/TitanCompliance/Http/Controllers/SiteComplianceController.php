<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Services\SiteComplianceService;

final class SiteComplianceController
{
    public function __construct(private readonly SiteComplianceService $svc) {}

    public function link(Request $request, int $siteId, int $packId): JsonResponse
    {
        $pack = CompliancePack::query()->findOrFail($packId);
        $row = $this->svc->linkPackToSite($siteId, $pack, (string) $request->input('status', 'draft'));
        return response()->json(['ok' => true, 'data' => $row]);
    }
}
