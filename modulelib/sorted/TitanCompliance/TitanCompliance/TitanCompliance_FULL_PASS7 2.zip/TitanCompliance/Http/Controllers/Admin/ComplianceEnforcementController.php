<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Http\Controllers\Admin;

use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Config;

final class ComplianceEnforcementController extends Controller
{
    public function index()
    {
        return response()->json([
            'mode' => Config::get('titancompliance.enforcement.mode', 'soft'),
            'actions' => Config::get('titancompliance.enforcement.actions', []),
        ]);
    }
}
