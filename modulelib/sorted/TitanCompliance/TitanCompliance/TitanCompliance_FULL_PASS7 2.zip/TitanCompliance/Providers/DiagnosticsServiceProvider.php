<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Config;

class DiagnosticsServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Merge our AI config into the module's config namespace.
        $this->mergeConfigFrom(__DIR__.'/../Config/ai.php', 'titancompliance.ai');
        $this->mergeConfigFrom(__DIR__.'/../Config/domain.php', 'titancompliance.domain');
        $this->mergeConfigFrom(__DIR__.'/../Config/enforcement.php', 'titancompliance.enforcement');

        // Domain bindings (Pass 1)
        $this->app->bind(
            \Modules\TitanCompliance\Repositories\Contracts\CompliancePackRepositoryInterface::class,
            \Modules\TitanCompliance\Repositories\Eloquent\CompliancePackRepository::class
        );
        $this->app->bind(
            \Modules\TitanCompliance\Repositories\Contracts\ComplianceDocumentRepositoryInterface::class,
            \Modules\TitanCompliance\Repositories\Eloquent\ComplianceDocumentRepository::class
        );

        $this->app->singleton(\Modules\TitanCompliance\Services\CompliancePackBuilder::class);
        $this->app->singleton(\Modules\TitanCompliance\Services\ComplianceValidator::class);
        $this->app->singleton(\Modules\TitanCompliance\Services\ComplianceRiskScorer::class);
        $this->app->singleton(\Modules\TitanCompliance\Services\ComplianceDocumentAssembler::class);
        $this->app->singleton(\Modules\TitanCompliance\Services\ComplianceVersioningService::class);
        $this->app->singleton(\Modules\TitanCompliance\Services\ComplianceEvidenceService::class);
        $this->app->singleton(\Modules\TitanCompliance\Services\ComplianceRuleResolver::class);

        $this->app->singleton(\Modules\TitanCompliance\Services\ComplianceEngine::class);


        $this->app->singleton(\Modules\TitanCompliance\Support\Guards\EnforcementGuard::class);
        $this->app->bind(
            \Modules\TitanCompliance\Repositories\Contracts\ComplianceEnforcementRepositoryInterface::class,
            \Modules\TitanCompliance\Repositories\Eloquent\ComplianceEnforcementRepository::class
        );
        $this->app->singleton(\Modules\TitanCompliance\Services\ComplianceEnforcementService::class, function ($app) {
            return new \Modules\TitanCompliance\Services\ComplianceEnforcementService(
                $app->make(\Modules\TitanCompliance\Support\Guards\EnforcementGuard::class),
                $app->make(\Modules\TitanCompliance\Repositories\Contracts\ComplianceEnforcementRepositoryInterface::class),
            );
        });

        // Integration adapters (host can override via config)
        $this->app->bind(\Modules\TitanCompliance\Contracts\Integrations\JobAdapterInterface::class, function ($app) {
            $cls = \Illuminate\Support\Facades\Config::get('titancompliance.enforcement.adapters.job');
            return $app->make($cls);
        });
        $this->app->bind(\Modules\TitanCompliance\Contracts\Integrations\QuoteAdapterInterface::class, function ($app) {
            $cls = \Illuminate\Support\Facades\Config::get('titancompliance.enforcement.adapters.quote');
            return $app->make($cls);
        });
        $this->app->bind(\Modules\TitanCompliance\Contracts\Integrations\InvoiceAdapterInterface::class, function ($app) {
            $cls = \Illuminate\Support\Facades\Config::get('titancompliance.enforcement.adapters.invoice');
            return $app->make($cls);
        });

    }

    public function boot(): void
    {
        $this->loadMigrationsFrom(__DIR__.'/../Database/Migrations');
        $this->loadRoutesFrom(__DIR__.'/../Routes/web.php');
        $this->loadRoutesFrom(__DIR__.'/../Routes/api.php');
        if ($this->app->runningInConsole()) {
            $this->commands([
                \Modules\TitanCompliance\Console\Commands\AISmoke::class,
                \Modules\TitanCompliance\Console\Commands\Doctor::class,
                \Modules\TitanCompliance\Console\Commands\SyncEnforcementHooks::class,
            ]);
        }

        // Optionally publish the config for host apps that want to override.
        $this->publishes([
            __DIR__.'/../Config/ai.php' => config_path('titancompliance/ai.php'),
            __DIR__.'/../Config/enforcement.php' => config_path('titancompliance/enforcement.php'),
        ], 'titancompliance-config');
    }
}