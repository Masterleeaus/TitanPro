<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Config;
use Modules\TitanCompliance\Support\Contracts\ClientInterface;
use Modules\TitanCompliance\Support\Providers\OpenAIAdapter;
use Modules\TitanCompliance\Support\Providers\AnthropicAdapter;
use Modules\TitanCompliance\Support\Providers\GeminiAdapter;

class ClientBindingServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind(ClientInterface::class, function () {
            $default = Config::get('titancompliance.ai.default', 'openai');
            $cfg     = Config::get('titancompliance.ai.providers.'.$default, []);
            $key     = $cfg['api_key'] ?? '';
            $model   = $cfg['model_chat'] ?? null;
            $timeout = (int) ($cfg['timeout'] ?? 30);

            switch ($default) {
                case 'anthropic':
                    return new AnthropicAdapter($key, $model, $timeout);
                case 'gemini':
                    return new GeminiAdapter($key, $model, $timeout);
                default:
                    return new OpenAIAdapter($key, $model, $timeout);
            }
        });
    }

    public function boot(): void {}
}
