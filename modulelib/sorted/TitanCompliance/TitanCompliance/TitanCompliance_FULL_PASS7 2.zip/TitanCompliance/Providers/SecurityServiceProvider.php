<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Route;

class SecurityServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__.'/../Config/security.php', 'titancompliance.security');
    }

    public function boot(): void
    {
        $cfg = Config::get('titancompliance.security', []);

        $apiGroup = $cfg['api_group'] ?? ['api', 'auth:sanctum'];
        $webGroup = $cfg['web_group'] ?? ['web', 'auth'];

        Route::macro('aicApi', function () use ($apiGroup) {
            return \Illuminate\Support\Facades\Route::middleware($apiGroup)->prefix('titancompliance')->name('titancompliance.');
        });

        Route::macro('aicWeb', function () use ($webGroup) {
            return \Illuminate\Support\Facades\Route::middleware($webGroup)->prefix('titancompliance')->name('titancompliance.');
        });
    }
}
