<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Jurisdictions;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

interface JurisdictionPackInterface
{
    /** @return array<int,string> */
    public function ruleKeys(ComplianceContext $context): array;

    public function key(): string;
}
