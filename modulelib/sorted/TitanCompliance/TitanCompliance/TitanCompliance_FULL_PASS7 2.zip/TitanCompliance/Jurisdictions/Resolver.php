<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Jurisdictions;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class Resolver
{
    /** @return array<int,string> */
    public function resolveRuleKeys(ComplianceContext $context): array
    {
        $map = (array) config('titancompliance_packs.jurisdictions', []);
        $key = (new JurisdictionContext($context))->jurisdictionKey();

        $cls = $map[$key] ?? ($map['au.general'] ?? null);
        if (!is_string($cls) || !class_exists($cls)) return [];

        $pack = new $cls();
        return $pack instanceof JurisdictionPackInterface ? $pack->ruleKeys($context) : [];
    }
}
