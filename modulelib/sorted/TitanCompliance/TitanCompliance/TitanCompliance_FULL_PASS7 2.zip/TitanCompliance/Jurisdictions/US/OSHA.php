<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Jurisdictions\US;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;
use Modules\TitanCompliance\Jurisdictions\JurisdictionPackInterface;

final class OSHA implements JurisdictionPackInterface
{
    public function key(): string { return 'us.osha'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'ppe.basic',
            'falls.heights',
            'confined_spaces',
            'hot_works',
        ];
    }
}
