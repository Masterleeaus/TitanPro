<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Jurisdictions\AU;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;
use Modules\TitanCompliance\Jurisdictions\JurisdictionPackInterface;

final class Plumbing implements JurisdictionPackInterface
{
    public function key(): string { return 'au.plumbing'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'confined_spaces',
            'chemicals.basic',
            'manual_handling',
        ];
    }
}
