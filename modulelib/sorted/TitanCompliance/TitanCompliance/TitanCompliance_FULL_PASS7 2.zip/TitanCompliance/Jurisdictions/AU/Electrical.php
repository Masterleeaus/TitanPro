<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Jurisdictions\AU;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;
use Modules\TitanCompliance\Jurisdictions\JurisdictionPackInterface;

final class Electrical implements JurisdictionPackInterface
{
    public function key(): string { return 'au.electrical'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'electrical.isolation',
            'electrical.lockout_tagout',
            'hot_works',
        ];
    }
}
