<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Jurisdictions\AU;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;
use Modules\TitanCompliance\Jurisdictions\JurisdictionPackInterface;

final class Construction implements JurisdictionPackInterface
{
    public function key(): string { return 'au.construction'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'falls.heights',
            'plant.equipment',
            'confined_spaces',
        ];
    }
}
