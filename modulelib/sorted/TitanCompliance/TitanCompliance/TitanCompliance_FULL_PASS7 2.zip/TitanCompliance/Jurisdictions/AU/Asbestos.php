<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Jurisdictions\AU;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;
use Modules\TitanCompliance\Jurisdictions\JurisdictionPackInterface;

final class Asbestos implements JurisdictionPackInterface
{
    public function key(): string { return 'au.asbestos'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'asbestos.awareness',
            'ppe.respiratory',
            'waste.management',
        ];
    }
}
