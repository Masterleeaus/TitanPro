<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Jurisdictions;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class JurisdictionContext
{
    public function __construct(public readonly ComplianceContext $context) {}

    public function jurisdictionKey(): string
    {
        $raw = strtolower((string) ($this->context->jurisdiction ?? ''));
        if ($raw === '') return 'au.general';

        if (in_array($raw, ['australia','au','aus'], true)) return 'au.general';
        if (str_starts_with($raw, 'au:')) return str_replace('au:', 'au.', $raw);
        if (str_starts_with($raw, 'nz:')) return str_replace('nz:', 'nz.', $raw);
        if (str_starts_with($raw, 'uk:')) return str_replace('uk:', 'uk.', $raw);
        if (str_starts_with($raw, 'eu:')) return str_replace('eu:', 'eu.', $raw);
        if (str_starts_with($raw, 'us:')) return str_replace('us:', 'us.', $raw);

        return $raw;
    }
}
