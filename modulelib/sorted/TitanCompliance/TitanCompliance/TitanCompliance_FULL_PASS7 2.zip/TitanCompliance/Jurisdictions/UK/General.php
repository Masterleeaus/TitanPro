<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Jurisdictions\UK;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;
use Modules\TitanCompliance\Jurisdictions\JurisdictionPackInterface;

final class General implements JurisdictionPackInterface
{
    public function key(): string { return 'uk.general'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'ppe.basic',
            'manual_handling',
            'falls.heights',
        ];
    }
}
