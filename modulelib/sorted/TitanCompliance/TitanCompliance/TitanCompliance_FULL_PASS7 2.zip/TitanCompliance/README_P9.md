# TitanCompliance Delta (P9)
Date: 2025-10-01T23:03:03.322923Z

Tightens the contract and the guards:
- **Docs/openapi.yaml** now declares `bearerAuth` and applies security globally and at each path.
- Adds `operationId`s, examples, and schemas for Chat request/response.
- **Routes/examples_p9.php** shows how to use `Route::aicApi()` / `Route::aicWeb()` groups.
- **ai:openapi-verify** command checks for common foot-guns (missing bearerAuth/security blocks).

## Install
```bash
unzip TitanCompliance_Delta_P9.zip -d .
rsync -a Modules/TitanCompliance/ Modules/TitanCompliance/
php artisan config:clear && php artisan cache:clear
```

## Verify
```bash
php artisan ai:openapi-verify
```

## Next (P10 milestone)
- Roll all deltas into a full module ZIP with updated OpenAPI, adapters, guards, seeders, telemetry, and a fresh smoke log.
