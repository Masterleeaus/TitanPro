<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Events;

final class ComplianceGateEvaluated
{
    public function __construct(
        public readonly string $action,
        public readonly array $decision,
    ) {}
}
