<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Events;

final class ComplianceBlocked
{
    public function __construct(
        public readonly string $action,
        public readonly string $reason,
        public readonly array $details = [],
    ) {}
}
