<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Events;

final class CompliancePackFinalized
{
    public function __construct(public readonly int $packId) {}
}
