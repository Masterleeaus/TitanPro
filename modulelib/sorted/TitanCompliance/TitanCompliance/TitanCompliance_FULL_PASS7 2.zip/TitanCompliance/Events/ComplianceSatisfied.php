<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Events;

final class ComplianceSatisfied
{
    public function __construct(
        public string $action,
        public int|string $entityId,
        public array $context = [],
    ) {}
}
