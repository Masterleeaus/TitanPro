<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Events;

final class ComplianceExported
{
    public function __construct(public readonly string $type, public readonly array $meta = []) {}
}
