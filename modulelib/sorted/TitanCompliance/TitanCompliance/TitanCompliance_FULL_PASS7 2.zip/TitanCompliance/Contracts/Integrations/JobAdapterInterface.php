<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Contracts\Integrations;

use Modules\TitanCompliance\Integrations\Dto\JobContextDto;

interface JobAdapterInterface
{
    public function resolveJobContext(int|string $jobId): ?JobContextDto;
}
