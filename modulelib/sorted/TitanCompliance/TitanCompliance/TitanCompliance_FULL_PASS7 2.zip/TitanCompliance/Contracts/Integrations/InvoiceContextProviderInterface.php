<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Contracts\Integrations;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

interface InvoiceContextProviderInterface
{
    public function buildFromInvoiceId(int|string $invoiceId): ComplianceContext;
}
