<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Contracts\Integrations;

interface EvidenceStorageInterface
{
    public function put(string $path, string $contents, array $meta = []): string;
    public function exists(string $path): bool;
    public function get(string $path): string;
}
