<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Contracts\Integrations;

interface ExportStorageInterface
{
    public function put(string $path, string $contents, array $meta = []): string;
}
