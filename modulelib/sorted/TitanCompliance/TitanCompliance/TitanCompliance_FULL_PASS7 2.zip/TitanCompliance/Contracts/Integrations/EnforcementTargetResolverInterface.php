<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Contracts\Integrations;

use Modules\TitanCompliance\Integrations\Dto\EnforcementTarget;

interface EnforcementTargetResolverInterface
{
    /**
     * Resolve an arbitrary host model (or ID) into an EnforcementTarget.
     */
    public function resolve(mixed $subject, ?string $action = null): EnforcementTarget;
}
