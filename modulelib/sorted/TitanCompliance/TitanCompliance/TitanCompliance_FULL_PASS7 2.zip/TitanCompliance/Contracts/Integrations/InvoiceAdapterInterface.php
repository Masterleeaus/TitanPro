<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Contracts\Integrations;

use Modules\TitanCompliance\Integrations\Dto\InvoiceContextDto;

interface InvoiceAdapterInterface
{
    public function resolveInvoiceContext(int|string $invoiceId): ?InvoiceContextDto;
}
