<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Contracts\Integrations;

use Modules\TitanCompliance\Integrations\Dto\QuoteContextDto;

interface QuoteAdapterInterface
{
    public function resolveQuoteContext(int|string $quoteId): ?QuoteContextDto;
}
