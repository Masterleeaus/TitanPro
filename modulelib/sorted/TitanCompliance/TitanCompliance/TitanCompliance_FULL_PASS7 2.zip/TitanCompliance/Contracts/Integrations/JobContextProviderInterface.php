<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Contracts\Integrations;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

interface JobContextProviderInterface
{
    public function buildFromJobId(int|string $jobId): ComplianceContext;
}
