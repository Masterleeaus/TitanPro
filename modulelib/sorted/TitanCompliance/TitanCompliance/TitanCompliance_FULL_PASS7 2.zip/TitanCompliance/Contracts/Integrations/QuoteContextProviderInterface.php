<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Contracts\Integrations;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

interface QuoteContextProviderInterface
{
    public function buildFromQuoteId(int|string $quoteId): ComplianceContext;
}
