<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Listeners;

use Modules\TitanCompliance\Events\ComplianceGateEvaluated;

final class LogComplianceGateDecision
{
    public function handle(ComplianceGateEvaluated $event): void
    {
        // Hook point for host-app logging or telemetry.
    }
}
