<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Listeners;

use Modules\TitanCompliance\Events\ComplianceBlocked;

final class BlockOnNonCompliance
{
    public function handle(ComplianceBlocked $event): void
    {
        // Hook point for notifications/escalations.
    }
}
