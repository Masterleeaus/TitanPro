<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Listeners;

use Illuminate\Contracts\Events\Dispatcher;
use Modules\TitanCompliance\Events\ComplianceRequired;
use Modules\TitanCompliance\Events\ComplianceBlocked;
use Modules\TitanCompliance\Events\ComplianceSatisfied;
use Modules\TitanCompliance\Services\ComplianceEnforcementService;

final class EnforceCompliance
{
    public function __construct(private ComplianceEnforcementService $enforcement) {}

    public function subscribe(Dispatcher $events): void
    {
        $events->listen(ComplianceRequired::class, [$this, 'handle']);
    }

    public function handle(ComplianceRequired $event): void
    {
        $result = $this->enforcement->check($event->action, $event->entityId, $event->context);
        if ($result->blocked) {
            event(new ComplianceBlocked($event->action, $event->entityId, $result->reason ?? 'unknown', $event->context));
            return;
        }
        event(new ComplianceSatisfied($event->action, $event->entityId, $event->context));
    }
}
