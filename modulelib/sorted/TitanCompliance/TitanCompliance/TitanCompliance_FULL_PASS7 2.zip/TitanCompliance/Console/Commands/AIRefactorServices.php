<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;

class AIRefactorServices extends Command
{
    protected $signature = 'ai:refactor-services {--apply : Actually move files} {--from= : Source dir (default: Modules/TitanCompliance/Services)}';
    protected $description = 'Scan Modules/TitanCompliance/Services for misfiled classes/views and suggest (or apply) moves into canonical nWidart folders.';

    public function handle(): int
    {
        $src = $this->option('from') ?: base_path('Modules/TitanCompliance/Services');
        if (!File::isDirectory($src)) {
            $this->info("No Services directory at: {$src} (nothing to do).");
            return self::SUCCESS;
        }

        $plan = [];
        $rii = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($src, \FilesystemIterator::SKIP_DOTS));
        foreach ($rii as $file) {
            /** @var \SplFileInfo $file */
            $path = $file->getPathname();
            $rel  = ltrim(str_replace(base_path().DIRECTORY_SEPARATOR, '', $path), DIRECTORY_SEPARATOR);

            $target = null;
            if (preg_match('/\.blade\.php$/', $path)) {
                // Blade views → Resources/views/services/*
                $tail = ltrim(str_replace($src, '', $path), DIRECTORY_SEPARATOR);
                $target = base_path('Modules/TitanCompliance/Resources/views/services/'. $tail);
            } elseif (preg_match('/Controller\.php$/', $path)) {
                // Controllers → Http/Controllers/*
                $tail = basename($path);
                $target = base_path('Modules/TitanCompliance/Http/Controllers/'. $tail);
            } elseif (preg_match('/Seeder\.php$/', $path)) {
                // Seeders → Database/Seeders/*
                $tail = basename($path);
                $target = base_path('Modules/TitanCompliance/Database/Seeders/'. $tail);
            } elseif (preg_match('/ServiceProvider\.php$/', $path)) {
                // Providers → Providers/*
                $tail = basename($path);
                $target = base_path('Modules/TitanCompliance/Providers/'. $tail);
            } elseif (preg_match('/(web|api)\.php$/', $path)) {
                // Routes → Routes/*
                $tail = basename($path);
                $target = base_path('Modules/TitanCompliance/Routes/'. $tail);
            }

            if ($target) {
                $plan[] = ['from' => $path, 'to' => $target];
            }
        }

        if (empty($plan)) {
            $this->info("Nothing to move. Services folder looks clean.");
            return self::SUCCESS;
        }

        $this->line("Proposed moves:");
        foreach ($plan as $step) {
            $this->line(" - {$step['from']}  ->  {$step['to']}");
        }

        if ($this->option('apply')) {
            foreach ($plan as $step) {
                @mkdir(dirname($step['to']), 0775, true);
                // Avoid overwriting: if target exists, keep original and skip.
                if (file_exists($step['to'])) {
                    $this->warn("Target exists, skipping: {$step['to']}");
                    continue;
                }
                if (!@rename($step['from'], $step['to'])) {
                    $this->error("Failed to move: {$step['from']} -> {$step['to']}");
                }
            }
            // Clean up empty dirs under Services
            $this->cleanupEmptyDirs($src);
            $this->info("Refactor applied.");
        } else {
            $this->info("Dry-run complete. Re-run with --apply to move files.");
        }

        return self::SUCCESS;
    }

    private function cleanupEmptyDirs(string $dir): void
    {
        $it = new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS);
        $childFirst = new \RecursiveIteratorIterator($it, \RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($childFirst as $path) {
            if ($path->isDir() && !(new \FilesystemIterator($path->getPathname()))->valid()) {
                @rmdir($path->getPathname());
            }
        }
    }
}
