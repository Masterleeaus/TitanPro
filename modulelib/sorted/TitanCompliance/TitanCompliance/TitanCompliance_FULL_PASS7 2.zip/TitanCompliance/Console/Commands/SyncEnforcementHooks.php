<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Console\Commands;

use Illuminate\Console\Command;

final class SyncEnforcementHooks extends Command
{
    protected $signature = 'titancompliance:sync-hooks';
    protected $description = 'Validate and sync TitanCompliance enforcement hook bindings (no-op defaults).';

    public function handle(): int
    {
        $this->info('TitanCompliance enforcement hooks are installed. (No-op defaults)');

        return self::SUCCESS;
    }
}
