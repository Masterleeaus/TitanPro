<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Modules\TitanCompliance\Support\Contracts\ClientInterface;

class AISmoke extends Command
{
    protected $signature = 'ai:smoke {--provider=} {--live}';
    protected $description = 'Verify AI provider config and connectivity. Use --live for a real ping.';

    public function handle(): int
    {
        $provider = $this->option('provider') ?: Config::get('titancompliance.ai.default', 'openai');
        $cfgAll   = Config::get('titancompliance.ai.providers', []);
        $enabled  = Config::get('titancompliance.ai.providers_enabled', []);

        if (!isset($cfgAll[$provider])) {
            $this->error("Provider '{$provider}' is not configured.");
            return self::FAILURE;
        }
        if (isset($enabled[$provider]) && !$enabled[$provider]) {
            $this->warn("Provider '{$provider}' is disabled by config.");
        }

        $cfg = $cfgAll[$provider];
        $key = $cfg['api_key'] ?? null;
        if (!$key) {
            $this->error("Missing API key for provider '{$provider}'. Set the appropriate env var.");
            return self::FAILURE;
        }

        $this->line("Provider: {$provider}");
        $this->line("Model:    " . ($cfg['model_chat'] ?? '(none)'));
        $this->line("Timeout:  " . (int) ($cfg['timeout'] ?? 30) . "s");
        $this->line("Key:      ********".substr($key, -4));

        if (!$this->option('live')) {
            $this->info("Config OK. Add --live for a connectivity ping.");
            return self::SUCCESS;
        }

        try {
            /** @var ClientInterface $client */
            $client = app(ClientInterface::class);
            $ok = $client->ping((int) ($cfg['timeout'] ?? 30));
            $this->info('Live ping: '.($ok ? 'OK' : 'FAILED'));
            return $ok ? self::SUCCESS : self::FAILURE;
        } catch (\Throwable $e) {
            $this->error('Live ping failed: '.$e->getMessage());
            return self::FAILURE;
        }
    }
}
