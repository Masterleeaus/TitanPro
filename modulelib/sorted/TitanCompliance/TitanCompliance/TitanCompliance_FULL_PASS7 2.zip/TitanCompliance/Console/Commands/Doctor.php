<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Console\Commands;

use Illuminate\Console\Command;
use Modules\TitanCompliance\Health\ComplianceDoctor;

class Doctor extends Command
{
    protected $signature = 'titancompliance:doctor';
    protected $description = 'Run TitanCompliance health checks';

    public function handle(ComplianceDoctor $doctor): int
    {
        $result = $doctor->run();
        if ($result['ok']) {
            $this->info('TitanCompliance: OK');
            return self::SUCCESS;
        }
        $this->error('TitanCompliance: Issues detected');
        foreach ($result['issues'] as $issue) {
            $this->line('- '.$issue);
        }
        return self::FAILURE;
    }
}
