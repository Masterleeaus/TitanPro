<?php
declare(strict_types=1);

use Modules\TitanCompliance\Services\CompliancePackBuilder;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

it('can upsert a compliance pack', function () {
    $svc = app(CompliancePackBuilder::class);
    $ctx = new ComplianceContext(null, null, 'builder', 'AU', null, null);
    $pack = $svc->upsert(['title' => 'Test Pack'], $ctx);
    expect($pack->id)->not->toBeNull();
});
