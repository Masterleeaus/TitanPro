<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Tests\Feature;

use Orchestra\Testbench\TestCase;
use Modules\TitanCompliance\Support\Guards\EnforcementGuard;

class EnforcementGuardTest extends TestCase
{
    public function test_default_mode_is_soft(): void
    {
        $guard = new EnforcementGuard();
        $this->assertSame('soft', $guard->mode());
    }
}
