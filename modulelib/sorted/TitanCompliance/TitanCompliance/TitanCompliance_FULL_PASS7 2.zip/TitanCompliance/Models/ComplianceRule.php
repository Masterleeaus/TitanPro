<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

/**
 * @property int $id
 */
final class ComplianceRule extends Model
{
    protected $table = 'titan_compliance_rules';
    protected $guarded = [];

    protected $casts = [];

    public function jurisdiction(): BelongsTo
    {
        return $this->belongsTo(ComplianceJurisdiction::class, 'jurisdiction_id');
    }
}
