<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

/**
 * @property int $id
 */
final class ComplianceDocument extends Model
{
    protected $table = 'titan_compliance_documents';
    protected $guarded = [];

    protected $casts = ['meta' => 'array'];

    public function pack(): BelongsTo
    {
        return $this->belongsTo(CompliancePack::class, 'pack_id');
    }

    public function evidences(): MorphMany
    {
        return $this->morphMany(ComplianceEvidence::class, 'evidenceable');
    }
}
