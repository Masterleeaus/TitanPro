<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

/**
 * @property int $id
 */
final class ComplianceAudit extends Model
{
    protected $table = 'titan_compliance_audits';
    protected $guarded = [];

    protected $casts = [];

    public function pack(): BelongsTo
    {
        return $this->belongsTo(CompliancePack::class, 'pack_id');
    }
}
