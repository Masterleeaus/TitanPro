<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;

final class ComplianceChange extends Model
{
    protected $table = 'titan_compliance_changes';

    protected $fillable = [
        'compliance_pack_id',
        'subject_type',
        'subject_id',
        'change_type',
        'diff',
        'created_by',
    ];

    protected $casts = [
        'diff' => 'array',
    ];
}
