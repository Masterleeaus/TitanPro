<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;

final class ComplianceSignature extends Model
{
    protected $table = 'titan_compliance_signatures';

    protected $fillable = [
        'compliance_pack_id',
        'subject_type',
        'subject_id',
        'signed_by',
        'signed_name',
        'signed_role',
        'signature_payload',
        'signed_at',
    ];

    protected $casts = [
        'signature_payload' => 'array',
        'signed_at' => 'datetime',
    ];
}
