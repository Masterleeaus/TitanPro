<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;

final class ComplianceNote extends Model
{
    protected $table = 'titan_compliance_notes';

    protected $fillable = [
        'compliance_pack_id',
        'subject_type',
        'subject_id',
        'note',
        'created_by',
    ];
}
