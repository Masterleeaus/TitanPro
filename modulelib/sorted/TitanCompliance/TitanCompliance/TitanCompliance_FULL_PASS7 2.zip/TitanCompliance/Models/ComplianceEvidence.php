<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

/**
 * @property int $id
 */
final class ComplianceEvidence extends Model
{
    protected $table = 'titan_compliance_evidences';
    protected $guarded = [];

    protected $casts = ['payload' => 'array'];

    public function evidenceable()
    {
        return $this->morphTo();
    }
}
