<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

/**
 * @property int $id
 */
final class CompliancePack extends Model
{
    protected $table = 'titan_compliance_packs';
    protected $guarded = [];

    protected $casts = ['meta' => 'array'];

    public function documents(): HasMany
    {
        return $this->hasMany(ComplianceDocument::class, 'pack_id');
    }

    public function versions(): HasMany
    {
        return $this->hasMany(ComplianceVersion::class, 'pack_id');
    }
}
