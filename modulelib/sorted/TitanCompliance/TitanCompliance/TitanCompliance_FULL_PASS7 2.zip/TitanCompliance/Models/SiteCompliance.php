<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class SiteCompliance extends Model
{
    protected $table = 'titan_compliance_site_compliance';

    protected $fillable = [
        'site_id',
        'compliance_pack_id',
        'status',
        'locked_at',
        'locked_by',
        'lock_reason',
    ];

    protected $casts = [
        'locked_at' => 'datetime',
    ];

    public function pack(): BelongsTo
    {
        return $this->belongsTo(CompliancePack::class, 'compliance_pack_id');
    }
}
