<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;

final class ComplianceAttachment extends Model
{
    protected $table = 'titan_compliance_attachments';

    protected $fillable = [
        'compliance_pack_id',
        'subject_type',
        'subject_id',
        'filename',
        'mime',
        'disk',
        'path',
        'bytes',
        'meta',
        'uploaded_by',
    ];

    protected $casts = [
        'meta' => 'array',
    ];
}
