<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;

final class CompliancePhoto extends Model
{
    protected $table = 'titan_compliance_photos';

    protected $fillable = [
        'compliance_pack_id',
        'subject_type',
        'subject_id',
        'disk',
        'path',
        'caption',
        'taken_at',
        'gps_lat',
        'gps_lng',
        'meta',
        'uploaded_by',
    ];

    protected $casts = [
        'taken_at' => 'datetime',
        'meta' => 'array',
    ];
}
