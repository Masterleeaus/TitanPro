<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;

final class ComplianceSnapshot extends Model
{
    protected $table = 'titan_compliance_snapshots';

    protected $fillable = [
        'compliance_pack_id',
        'subject_type',
        'subject_id',
        'version',
        'payload',
        'created_by',
    ];

    protected $casts = [
        'payload' => 'array',
    ];
}
