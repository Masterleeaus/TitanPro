<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

/**
 * @property int $id
 */
final class ComplianceTemplate extends Model
{
    protected $table = 'titan_compliance_templates';
    protected $guarded = [];

    protected $casts = ['meta' => 'array'];

    public function jurisdiction(): BelongsTo
    {
        return $this->belongsTo(ComplianceJurisdiction::class, 'jurisdiction_id');
    }
}
