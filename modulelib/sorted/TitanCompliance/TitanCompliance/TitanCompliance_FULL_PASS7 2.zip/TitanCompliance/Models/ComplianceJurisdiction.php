<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

/**
 * @property int $id
 */
final class ComplianceJurisdiction extends Model
{
    protected $table = 'titan_compliance_jurisdictions';
    protected $guarded = [];

    protected $casts = [];

    public function rules(): HasMany
    {
        return $this->hasMany(ComplianceRule::class, 'jurisdiction_id');
    }
}
