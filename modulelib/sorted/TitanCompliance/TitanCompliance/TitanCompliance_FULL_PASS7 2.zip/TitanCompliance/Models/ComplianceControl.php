<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

/**
 * @property int $id
 */
final class ComplianceControl extends Model
{
    protected $table = 'titan_compliance_controls';
    protected $guarded = [];

    protected $casts = [];

    public function hazard(): BelongsTo
    {
        return $this->belongsTo(ComplianceHazard::class, 'hazard_id');
    }
}
