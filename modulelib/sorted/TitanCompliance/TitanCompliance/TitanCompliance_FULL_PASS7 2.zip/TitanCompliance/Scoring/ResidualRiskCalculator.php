<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Scoring;

use Modules\TitanCompliance\Enums\RiskLevel;

/**
 * ResidualRiskCalculator - scoring primitive for TitanCompliance.
 * This is deterministic (non-AI) logic to support explainability.
 */
final class ResidualRiskCalculator
{
    /**
     * @param array<string,mixed> $inputs
     * @return array<string,mixed>
     */
    public function compute(array $inputs): array
    {
        // Minimal baseline implementation; extend per jurisdiction/industry packs in later passes.
        $score = (float) ($inputs['score'] ?? 0);
        $level = $score >= 0.75 ? RiskLevel::High : ($score >= 0.40 ? RiskLevel::Medium : RiskLevel::Low);

        return [
            'score' => $score,
            'level' => $level->value,
            'explain' => 'Baseline scoring; expand rules in later passes.',
        ];
    }
}
