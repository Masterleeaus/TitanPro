<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class PlantEquipment implements RuleInterface
{
    public function key(): string { return 'plant.equipment'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'plant.equipment',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
