<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

final class Registry
{
    /** @return array<string,class-string<RuleInterface>> */
    public static function map(): array
    {
        return [
            'falls.heights' => Falls::class,
            'electrical.isolation' => Electrical::class,
            'electrical.lockout_tagout' => LockoutTagout::class,
            'confined_spaces' => ConfinedSpaces::class,
            'hot_works' => HotWorks::class,
            'manual_handling' => ManualHandling::class,
            'chemicals.basic' => Chemicals::class,
            'ppe.basic' => PPE::class,
            'ppe.respiratory' => RespiratoryPPE::class,
            'ppe.electrical' => ElectricalPPE::class,
            'plant.equipment' => PlantEquipment::class,
            'asbestos.awareness' => Asbestos::class,
            'waste.management' => WasteManagement::class,
        ];
    }
}
