<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class PPE implements RuleInterface
{
    public function key(): string { return 'ppe.basic'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'ppe.basic',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
