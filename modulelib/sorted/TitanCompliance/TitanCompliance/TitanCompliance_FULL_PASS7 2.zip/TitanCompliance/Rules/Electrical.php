<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class Electrical implements RuleInterface
{
    public function key(): string { return 'electrical.isolation'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'electrical.isolation',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
