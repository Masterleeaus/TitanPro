<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class ElectricalPPE implements RuleInterface
{
    public function key(): string { return 'ppe.electrical'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'ppe.electrical',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
