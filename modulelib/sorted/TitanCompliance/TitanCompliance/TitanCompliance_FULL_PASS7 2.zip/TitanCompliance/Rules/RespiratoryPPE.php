<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class RespiratoryPPE implements RuleInterface
{
    public function key(): string { return 'ppe.respiratory'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'ppe.respiratory',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
