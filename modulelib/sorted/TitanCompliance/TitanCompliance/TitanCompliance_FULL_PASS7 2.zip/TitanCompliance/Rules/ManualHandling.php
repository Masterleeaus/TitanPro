<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class ManualHandling implements RuleInterface
{
    public function key(): string { return 'manual_handling'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'manual_handling',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
