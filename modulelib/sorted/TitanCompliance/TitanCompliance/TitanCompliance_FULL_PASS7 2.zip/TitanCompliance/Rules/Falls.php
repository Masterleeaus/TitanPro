<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class Falls implements RuleInterface
{
    public function key(): string { return 'falls.heights'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'falls.heights',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
