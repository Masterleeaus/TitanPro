<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class LockoutTagout implements RuleInterface
{
    public function key(): string { return 'electrical.lockout_tagout'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'electrical.lockout_tagout',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
