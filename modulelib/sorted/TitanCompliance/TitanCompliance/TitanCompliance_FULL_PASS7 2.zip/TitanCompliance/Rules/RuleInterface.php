<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

interface RuleInterface
{
    public function key(): string;

    /** @return array<string,mixed> */
    public function metadata(ComplianceContext $context): array;
}
