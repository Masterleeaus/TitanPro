<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class ConfinedSpaces implements RuleInterface
{
    public function key(): string { return 'confined_spaces'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'confined_spaces',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
