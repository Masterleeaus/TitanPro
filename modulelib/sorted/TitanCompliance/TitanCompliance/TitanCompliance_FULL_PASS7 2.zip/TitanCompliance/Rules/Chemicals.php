<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class Chemicals implements RuleInterface
{
    public function key(): string { return 'chemicals.basic'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'chemicals.basic',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
