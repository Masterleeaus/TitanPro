<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class HotWorks implements RuleInterface
{
    public function key(): string { return 'hot_works'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'hot_works',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
