<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class WasteManagement implements RuleInterface
{
    public function key(): string { return 'waste.management'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'waste.management',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
