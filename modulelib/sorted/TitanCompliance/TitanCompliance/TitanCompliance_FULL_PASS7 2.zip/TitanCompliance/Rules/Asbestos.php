<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Rules;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class Asbestos implements RuleInterface
{
    public function key(): string { return 'asbestos.awareness'; }

    public function metadata(ComplianceContext $context): array
    {
        return [
            'key' => 'asbestos.awareness',
            'trade' => $context->trade,
            'jurisdiction' => $context->jurisdiction,
        ];
    }
}
