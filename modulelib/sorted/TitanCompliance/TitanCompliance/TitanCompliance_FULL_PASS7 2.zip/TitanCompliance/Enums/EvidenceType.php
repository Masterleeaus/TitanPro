<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Enums;

enum EvidenceType: string
{
    case Photo = 'photo';
    case Attachment = 'attachment';
    case Signature = 'signature';
    case Note = 'note';
    case AiRun = 'ai_run';
}
