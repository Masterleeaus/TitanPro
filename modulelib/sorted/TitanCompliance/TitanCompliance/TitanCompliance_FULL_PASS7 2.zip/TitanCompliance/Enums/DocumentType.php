<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Enums;

enum DocumentType: string
{
    case SWMS = 'swms';
    case RiskAssessment = 'risk_assessment';
    case ToolboxTalk = 'toolbox_talk';
    case SafetyPlan = 'safety_plan';
    case ComplianceSummary = 'compliance_summary';
}
