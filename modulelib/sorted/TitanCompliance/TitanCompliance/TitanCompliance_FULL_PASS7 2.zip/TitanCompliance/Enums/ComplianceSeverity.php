<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Enums;

enum ComplianceSeverity: string
{
    case Info = 'info';
    case Warning = 'warning';
    case Critical = 'critical';
}
