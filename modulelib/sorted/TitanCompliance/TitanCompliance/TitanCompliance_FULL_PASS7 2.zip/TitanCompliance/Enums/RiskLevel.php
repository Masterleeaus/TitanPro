<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Enums;

enum RiskLevel: string
{
    case Low = 'low';
    case Medium = 'medium';
    case High = 'high';
    case Extreme = 'extreme';
}
