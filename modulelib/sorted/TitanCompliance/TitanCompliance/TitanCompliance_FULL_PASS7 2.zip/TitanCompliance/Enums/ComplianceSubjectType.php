<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Enums;

enum ComplianceSubjectType: string
{
    case Pack = 'pack';
    case Job = 'job';
    case Site = 'site';
}
