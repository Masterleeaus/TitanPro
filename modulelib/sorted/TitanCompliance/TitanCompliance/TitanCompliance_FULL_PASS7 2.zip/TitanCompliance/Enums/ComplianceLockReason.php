<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Enums;

enum ComplianceLockReason: string
{
    case ClientApproved = 'client_approved';
    case SupervisorSignoff = 'supervisor_signoff';
    case SubmittedToRegulator = 'submitted_to_regulator';
    case InsuranceIssued = 'insurance_issued';
    case Other = 'other';
}
