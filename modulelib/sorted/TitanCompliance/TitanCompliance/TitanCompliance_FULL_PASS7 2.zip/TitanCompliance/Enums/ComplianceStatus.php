<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Enums;

enum ComplianceStatus: string
{
    case Draft = 'draft';
    case Ready = 'ready';
    case Signed = 'signed';
    case Locked = 'locked';
    case Archived = 'archived';
}
