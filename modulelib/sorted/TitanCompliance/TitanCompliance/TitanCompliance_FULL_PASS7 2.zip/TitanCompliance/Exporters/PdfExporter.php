<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Exporters;

final class PdfExporter
{
    public function export(array $data): string { return json_encode(['type'=>'pdf','data'=>$data]) ?: ''; }
}
