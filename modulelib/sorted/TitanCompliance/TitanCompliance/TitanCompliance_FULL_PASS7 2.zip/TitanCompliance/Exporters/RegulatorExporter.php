<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Exporters;

final class RegulatorExporter
{
    public function export(array $data): string { return json_encode(['type'=>'regulator','data'=>$data]) ?: ''; }
}
