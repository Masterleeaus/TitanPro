<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Exporters;

final class JsonSchemaExporter
{
    public function export(array $data): string { return json_encode($data, JSON_PRETTY_PRINT) ?: ''; }
}
