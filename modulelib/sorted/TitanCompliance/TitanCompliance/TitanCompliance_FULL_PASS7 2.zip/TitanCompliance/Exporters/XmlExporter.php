<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Exporters;

final class XmlExporter
{
    public function export(array $data): string { return '<xml></xml>'; }
}
