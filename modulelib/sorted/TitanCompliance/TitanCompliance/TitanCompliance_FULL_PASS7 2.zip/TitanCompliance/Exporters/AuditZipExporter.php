<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Exporters;

final class AuditZipExporter
{
    public function export(array $data): string { return json_encode(['type'=>'audit_zip','data'=>$data]) ?: ''; }
}
