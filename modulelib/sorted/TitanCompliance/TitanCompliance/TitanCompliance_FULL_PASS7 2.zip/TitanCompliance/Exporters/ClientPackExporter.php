<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Exporters;

final class ClientPackExporter
{
    public function export(array $data): string { return json_encode(['type'=>'client_pack','data'=>$data]) ?: ''; }
}
