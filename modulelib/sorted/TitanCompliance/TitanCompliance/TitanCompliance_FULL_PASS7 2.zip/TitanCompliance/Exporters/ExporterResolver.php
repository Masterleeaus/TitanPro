<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Exporters;

final class ExporterResolver
{
    public function __construct(
        private readonly PdfExporter $pdf,
        private readonly RegulatorExporter $regulator,
        private readonly InsuranceExporter $insurance,
        private readonly AuditZipExporter $auditZip,
        private readonly ClientPackExporter $clientPack,
    ) {}

    public function resolve(string $type): object
    {
        return match ($type) {
            'pdf' => $this->pdf,
            'regulator' => $this->regulator,
            'insurance' => $this->insurance,
            'audit_zip' => $this->auditZip,
            'client_pack' => $this->clientPack,
            default => $this->pdf,
        };
    }
}
