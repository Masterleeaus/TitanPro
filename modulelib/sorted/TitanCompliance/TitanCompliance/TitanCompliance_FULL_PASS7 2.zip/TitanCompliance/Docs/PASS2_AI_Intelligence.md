# PASS 2 — AI Intelligence & Explainability

This pass introduces deterministic prompt blueprints, model selection, cost guarding, response normalisation, and scoring primitives.
