# TitanCompliance PASS 3 — Job, Site & Evidence Integration

This pass introduces first-class linkage between Compliance Packs and operational subjects (Jobs / Sites) and adds
evidence primitives (notes, photos, attachments, signatures), plus snapshot + change tracking to support audit-grade timelines.

Key additions:
- Models: JobCompliance, SiteCompliance, ComplianceSnapshot, ComplianceChange, ComplianceAttachment, CompliancePhoto, ComplianceNote, ComplianceSignature
- Migrations: 000012..000019
- Services: Job/Site linking, snapshotting, change detection, evidence ingestion, diffing, restoring, locking
- Routes: Routes/web.php loaded by DiagnosticsServiceProvider

All cross-module foreign keys are intentionally avoided for portability.
