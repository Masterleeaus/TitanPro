<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Diary;

final class SiteDiaryBuilder
{
    public function build(array $inputs): array
    {
        $entries = [];
        foreach ($inputs as $item) {
            $entries[] = new DiaryEntry(
                timestamp: $item['timestamp'] ?? date('c'),
                summary: $item['summary'] ?? 'Diary entry',
                evidence: $item['evidence'] ?? [],
            );
        }
        return $entries;
    }
}
