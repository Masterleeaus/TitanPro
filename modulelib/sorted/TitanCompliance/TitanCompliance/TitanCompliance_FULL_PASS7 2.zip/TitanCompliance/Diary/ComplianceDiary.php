<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Diary;

final class ComplianceDiary
{
    public function compile(array $entries): array
    {
        return [
            'generated_at' => date('c'),
            'entries' => array_map(fn($e) => [
                'timestamp' => $e->timestamp,
                'summary' => $e->summary,
                'evidence' => $e->evidence,
            ], $entries),
        ];
    }
}
