<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Diary;

final class DiaryPolicy
{
    public function view(?object $user=null): bool { return true; }
    public function create(?object $user=null): bool { return true; }
}
