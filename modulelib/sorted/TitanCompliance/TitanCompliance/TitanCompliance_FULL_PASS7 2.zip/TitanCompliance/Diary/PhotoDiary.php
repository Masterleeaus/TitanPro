<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Diary;

final class PhotoDiary
{
    public function fromPhotos(array $photos): array
    {
        return array_map(fn($p) => [
            'type' => 'photo',
            'path' => $p['path'] ?? null,
            'taken_at' => $p['taken_at'] ?? null,
        ], $photos);
    }
}
