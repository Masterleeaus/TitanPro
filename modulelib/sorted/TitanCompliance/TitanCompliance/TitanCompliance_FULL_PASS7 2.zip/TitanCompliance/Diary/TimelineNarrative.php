<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Diary;

final class TimelineNarrative
{
    public function narrate(array $entries): string
    {
        $lines = [];
        foreach ($entries as $e) { $lines[] = sprintf('%s — %s', $e->timestamp, $e->summary); }
        return implode("\n", $lines);
    }
}
