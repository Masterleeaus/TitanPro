<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Diary;

final class DiaryEntry
{
    public function __construct(
        public readonly string $timestamp,
        public readonly string $summary,
        public readonly array $evidence = [],
    ) {}
}
