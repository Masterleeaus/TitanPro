<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Diary;

final class DiaryExporter
{
    public function exportJson(array $diary): string { return json_encode($diary, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) ?: '{}'; }
}
