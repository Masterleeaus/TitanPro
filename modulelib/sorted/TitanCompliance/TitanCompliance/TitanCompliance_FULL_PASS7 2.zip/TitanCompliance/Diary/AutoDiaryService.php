<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Diary;

final class AutoDiaryService
{
    public function __construct(
        private readonly SiteDiaryBuilder $builder,
        private readonly ComplianceDiary $compiler,
        private readonly TimelineNarrative $narrative,
    ) {}

    public function generate(array $inputs): array
    {
        $entries = $this->builder->build($inputs);
        return ['diary' => $this->compiler->compile($entries), 'narrative' => $this->narrative->narrate($entries)];
    }
}
