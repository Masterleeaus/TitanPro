<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Health;

final class ComplianceHealthCheck
{
    public function run(): array
    {
        return ['ok' => true, 'checked_at' => date('c')];
    }
}
