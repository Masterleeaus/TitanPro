<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Health;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Config;

final class ComplianceDoctor
{
    public function run(): array
    {
        $issues = [];

        // Config sanity
        $mode = Config::get('titancompliance.enforcement.mode', 'soft');
        if (!in_array($mode, ['off','soft','hard'], true)) {
            $issues[] = "Invalid enforcement.mode: {$mode}";
        }

        // DB sanity
        try {
            DB::connection()->getPdo();
        } catch (\Throwable $e) {
            $issues[] = 'DB connection failed: '.$e->getMessage();
        }

        return [
            'ok' => count($issues) === 0,
            'issues' => $issues,
        ];
    }
}
