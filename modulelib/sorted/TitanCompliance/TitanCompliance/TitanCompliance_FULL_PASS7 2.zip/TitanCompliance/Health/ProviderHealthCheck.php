<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Health;

final class ProviderHealthCheck
{
    public function run(): array { return ['ok' => true]; }
}
