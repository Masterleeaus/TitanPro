<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Health;

final class EnforcementHealthCheck
{
    public function run(): array { return ['ok' => true]; }
}
