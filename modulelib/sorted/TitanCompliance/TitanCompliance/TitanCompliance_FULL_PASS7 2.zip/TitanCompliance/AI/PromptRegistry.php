<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\AI;

use Modules\TitanCompliance\AI\Prompts\GenerateSWMS;
use Modules\TitanCompliance\AI\Prompts\AnalyseRisk;
use Modules\TitanCompliance\AI\Prompts\DetectMissingControls;
use Modules\TitanCompliance\AI\Prompts\ValidateCompliance;
use Modules\TitanCompliance\AI\Prompts\ExplainRiskScore;
use Modules\TitanCompliance\AI\Prompts\GenerateToolboxTalk;
use Modules\TitanCompliance\AI\Prompts\GenerateComplianceSummary;
use Modules\TitanCompliance\AI\Prompts\CompareScopeVsControls;
use Modules\TitanCompliance\AI\Prompts\GenerateAuditNarrative;
use Modules\TitanCompliance\AI\Prompts\JurisdictionalCheck;
use Modules\TitanCompliance\AI\Prompts\InsuranceReadiness;
use Modules\TitanCompliance\AI\Prompts\RegulatorFriendlyOutput;

final class PromptRegistry
{
    /**
     * @return array<string,class-string>
     */
    public static function map(): array
    {
        return [
            'swms.generate' => GenerateSWMS::class,
            'risk.analyse' => AnalyseRisk::class,
            'controls.missing' => DetectMissingControls::class,
            'compliance.validate' => ValidateCompliance::class,
            'risk.explain' => ExplainRiskScore::class,
            'toolbox.generate' => GenerateToolboxTalk::class,
            'summary.generate' => GenerateComplianceSummary::class,
            'scope.compare' => CompareScopeVsControls::class,
            'audit.narrative' => GenerateAuditNarrative::class,
            'jurisdiction.check' => JurisdictionalCheck::class,
            'insurance.readiness' => InsuranceReadiness::class,
            'regulator.output' => RegulatorFriendlyOutput::class,
        ];
    }
}
