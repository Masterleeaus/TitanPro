<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\AI\Prompts;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

/**
 * Deterministic prompt blueprint for GenerateComplianceSummary.
 * Returns a provider-agnostic payload (messages + expected JSON shape).
 */
final class GenerateComplianceSummary
{
    public static function name(): string
    {
        return 'GenerateComplianceSummary';
    }

    /**
     * @return array{messages: array<int,array{role:string,content:string}>, json_schema: array<string,mixed>, temperature: float}
     */
    public static function build(ComplianceContext $ctx): array
    {
        $system = 'You are TitanCompliance, an AI compliance assistant. Output ONLY valid JSON that matches the schema.';
        $user = self::userInstruction($ctx);

        return [
            'messages' => [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => $user],
            ],
            'json_schema' => self::schema(),
            'temperature' => 0.2,
        ];
    }

    private static function userInstruction(ComplianceContext $ctx): string
    {
        // Keep content deterministic and context-driven.
        $lines = [
            'tenant_id=' . (string) $ctx->tenantId,
            'user_id=' . (string) $ctx->userId,
            'industry=' . ($ctx->industry ?? 'unknown'),
            'jurisdiction=' . ($ctx->jurisdiction ?? 'unknown'),
            'job_summary=' . ($ctx->jobSummary ?? ''),
            'site_summary=' . ($ctx->siteSummary ?? ''),
            'activity_summary=' . ($ctx->activitySummary ?? ''),
            'document_type=' . ($ctx->documentType ?? 'unknown'),
            'task=GenerateComplianceSummary',
        ];
        return implode("\n", $lines);
    }

    /**
     * Minimal JSON schema used to normalise outputs across providers.
     * @return array<string,mixed>
     */
    private static function schema(): array
    {
        return [
            'type' => 'object',
            'required' => ['ok', 'summary', 'items'],
            'properties' => [
                'ok' => ['type' => 'boolean'],
                'summary' => ['type' => 'string'],
                'items' => [
                    'type' => 'array',
                    'items' => ['type' => 'object'],
                ],
                'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
                'confidence' => ['type' => 'number'],
            ],
        ];
    }
}
