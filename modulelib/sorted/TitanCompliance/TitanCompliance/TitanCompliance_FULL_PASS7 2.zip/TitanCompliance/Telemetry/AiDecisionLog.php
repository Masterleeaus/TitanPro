<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Telemetry;

use Illuminate\Support\Facades\Log;

/**
 * Records high-level AI decisions for accountability (not full prompt bodies).
 */
final class AiDecisionLog
{
    /**
     * @param array<string,mixed> $data
     */
    public function record(array $data): void
    {
        Log::channel('stack')->info('TitanCompliance::AiDecisionLog', $data);
    }
}
