<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Telemetry;

use Illuminate\Support\Facades\Log;

/**
 * Normalises exceptions into telemetry-friendly payloads.
 */
final class FailureCapture
{
    /**
     * @param array<string,mixed> $data
     */
    public function record(array $data): void
    {
        // Keep this conservative: do not log full prompt text here.
        Log::channel('stack')->info('TitanCompliance::FailureCapture', $data);
    }

    /**
     * @param string $action
     * @param array<string,mixed> $payload
     */
    public static function make(string $action, array $payload): string
    {
        $json = json_encode(['action' => $action, 'payload' => $payload], JSON_UNESCAPED_SLASHES) ?: '';
        return hash('sha256', $json);
    }
}
