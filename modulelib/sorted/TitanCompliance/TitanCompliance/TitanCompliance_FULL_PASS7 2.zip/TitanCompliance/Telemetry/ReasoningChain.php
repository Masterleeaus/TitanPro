<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Telemetry;

use Illuminate\Support\Facades\Log;

/**
 * Stores explainable reasoning steps (non-sensitive) for auditability.
 */
final class ReasoningChain
{
    /**
     * @param array<string,mixed> $data
     */
    public function record(array $data): void
    {
        // Keep this conservative: do not log full prompt text here.
        Log::channel('stack')->info('TitanCompliance::ReasoningChain', $data);
    }

    /**
     * @param string $action
     * @param array<string,mixed> $payload
     */
    public static function make(string $action, array $payload): string
    {
        $json = json_encode(['action' => $action, 'payload' => $payload], JSON_UNESCAPED_SLASHES) ?: '';
        return hash('sha256', $json);
    }
}
