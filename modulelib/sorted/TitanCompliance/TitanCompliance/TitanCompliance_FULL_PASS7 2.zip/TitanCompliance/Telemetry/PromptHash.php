<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Telemetry;

/**
 * Generates deterministic hashes for prompt payloads to correlate outputs without storing sensitive text.
 */
final class PromptHash
{
    /**
     * @param array<string,mixed> $payload
     */
    public static function make(string $action, array $payload): string
    {
        $json = json_encode(['action' => $action, 'payload' => $payload], JSON_UNESCAPED_SLASHES) ?: '';
        return hash('sha256', $json);
    }
}
