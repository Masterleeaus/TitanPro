<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Repositories\Contracts;

use Modules\TitanCompliance\Models\CompliancePack;

interface CompliancePackRepositoryInterface
{
    public function find(int $id): ?CompliancePack;

    public function save(CompliancePack $pack): CompliancePack;
}
