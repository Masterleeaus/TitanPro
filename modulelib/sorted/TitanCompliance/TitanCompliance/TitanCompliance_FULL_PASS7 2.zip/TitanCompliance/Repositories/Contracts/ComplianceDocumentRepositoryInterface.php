<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Repositories\Contracts;

use Modules\TitanCompliance\Models\ComplianceDocument;

interface ComplianceDocumentRepositoryInterface
{
    public function find(int $id): ?ComplianceDocument;

    public function save(ComplianceDocument $doc): ComplianceDocument;
}
