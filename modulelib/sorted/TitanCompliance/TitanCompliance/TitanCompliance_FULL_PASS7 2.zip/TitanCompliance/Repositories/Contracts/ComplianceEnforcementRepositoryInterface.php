<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Repositories\Contracts;

interface ComplianceEnforcementRepositoryInterface
{
    /**
     * Return finalized compliance packs linked to an external entity.
     * Host apps can implement link tables with their own FK strategy.
     */
    public function findFinalizedForEntity(string $action, int|string $entityId): array;
}
