<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Repositories\Eloquent;

use Modules\TitanCompliance\Models\ComplianceDocument;
use Modules\TitanCompliance\Repositories\Contracts\ComplianceDocumentRepositoryInterface;

final class ComplianceDocumentRepository implements ComplianceDocumentRepositoryInterface
{
    public function find(int $id): ?ComplianceDocument
    {
        return ComplianceDocument::query()->find($id);
    }

    public function save(ComplianceDocument $doc): ComplianceDocument
    {
        $doc->save();
        return $doc;
    }
}
