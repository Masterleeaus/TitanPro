<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Repositories\Eloquent;

use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Repositories\Contracts\ComplianceEnforcementRepositoryInterface;

final class ComplianceEnforcementRepository implements ComplianceEnforcementRepositoryInterface
{
    public function findFinalizedForEntity(string $action, int|string $entityId): array
    {
        // Default: look for packs where external_ref matches.
        return CompliancePack::query()
            ->where('external_action', $action)
            ->where('external_ref', (string)$entityId)
            ->where('status', 'finalized')
            ->get()
            ->all();
    }
}
