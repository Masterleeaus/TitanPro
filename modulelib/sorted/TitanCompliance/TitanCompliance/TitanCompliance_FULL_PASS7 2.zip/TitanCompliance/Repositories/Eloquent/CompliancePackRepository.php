<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Repositories\Eloquent;

use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Repositories\Contracts\CompliancePackRepositoryInterface;

final class CompliancePackRepository implements CompliancePackRepositoryInterface
{
    public function find(int $id): ?CompliancePack
    {
        return CompliancePack::query()->find($id);
    }

    public function save(CompliancePack $pack): CompliancePack
    {
        $pack->save();
        return $pack;
    }
}
