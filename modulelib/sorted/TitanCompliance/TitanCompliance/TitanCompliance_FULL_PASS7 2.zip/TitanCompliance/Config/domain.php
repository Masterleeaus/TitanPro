<?php
return [
    'enforcement_default_reason' => env('TITANCOMPLIANCE_ENFORCEMENT_REASON', 'Missing finalized compliance pack.'),
    'tables' => [
        'packs' => 'titan_compliance_packs',
        'documents' => 'titan_compliance_documents',
    ],
];
