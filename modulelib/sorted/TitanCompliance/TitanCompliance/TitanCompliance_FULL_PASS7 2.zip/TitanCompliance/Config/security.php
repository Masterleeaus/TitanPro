<?php
declare(strict_types=1);

return [
    'web_group' => ['web', 'auth', \Modules\TitanCompliance\Http\Middleware\AIFailsafeGuard::class, \Modules\TitanCompliance\Http\Middleware\AIMetricsMiddleware::class],
    'api_group' => ['api', 'auth:sanctum', \Modules\TitanCompliance\Http\Middleware\AIMetricsMiddleware::class],
    'api_key_header' => env('AIC_API_KEY_HEADER', 'X-API-Key'),
];
