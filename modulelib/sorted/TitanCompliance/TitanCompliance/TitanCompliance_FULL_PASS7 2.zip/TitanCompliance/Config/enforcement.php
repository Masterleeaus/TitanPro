<?php

declare(strict_types=1);

return [
    /*
    |--------------------------------------------------------------------------
    | Enforcement mode
    |--------------------------------------------------------------------------
    | off  - no enforcement
    | soft - warnings unless action explicitly required
    | hard - block requests when required actions are non-compliant
    */
    'mode' => env('TITANCOMPLIANCE_ENFORCEMENT_MODE', 'soft'),

    /*
    |--------------------------------------------------------------------------
    | Action gates
    |--------------------------------------------------------------------------
    */
    'actions' => [
        // Examples (set required=true in host .env/config to turn on)
        'job.start' => ['required' => env('TITANCOMPLIANCE_REQ_JOB_START', false)],
        'quote.approve' => ['required' => env('TITANCOMPLIANCE_REQ_QUOTE_APPROVE', false)],
        'invoice.issue' => ['required' => env('TITANCOMPLIANCE_REQ_INVOICE_ISSUE', false)],
    ],

    /*
    |--------------------------------------------------------------------------
    | Integration adapters
    |--------------------------------------------------------------------------
    | Host apps can override these bindings by changing the class names.
    */
    'adapters' => [
        'job' => \Modules\TitanCompliance\Integrations\Adapters\NullJobAdapter::class,
        'quote' => \Modules\TitanCompliance\Integrations\Adapters\NullQuoteAdapter::class,
        'invoice' => \Modules\TitanCompliance\Integrations\Adapters\NullInvoiceAdapter::class,
    ],
];
