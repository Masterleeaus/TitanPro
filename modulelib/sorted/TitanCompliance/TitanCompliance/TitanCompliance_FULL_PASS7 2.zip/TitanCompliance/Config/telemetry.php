<?php
declare(strict_types=1);

return [
    'enabled' => (bool) env('AIC_TELEMETRY_ENABLED', false),
    'prometheus' => [
        'enabled' => (bool) env('AIC_PROMETHEUS_ENABLED', false),
        // If you plug a real exporter, mount it here.
        'route' => env('AIC_PROMETHEUS_ROUTE', '/titancompliance/metrics'),
        'guard' => env('AIC_PROMETHEUS_GUARD', 'auth'), // use 'none' if you want public scrape (not recommended)
    ],
    'telescope' => [
        'tag' => 'titancompliance',
    ],
];
