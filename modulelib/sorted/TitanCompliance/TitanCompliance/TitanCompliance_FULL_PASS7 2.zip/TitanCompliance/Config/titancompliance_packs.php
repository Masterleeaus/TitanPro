<?php
return [
    'jurisdictions' => [
        'au.general' => \Modules\TitanCompliance\Jurisdictions\AU\General::class,
        'au.construction' => \Modules\TitanCompliance\Jurisdictions\AU\Construction::class,
        'au.electrical' => \Modules\TitanCompliance\Jurisdictions\AU\Electrical::class,
        'au.plumbing' => \Modules\TitanCompliance\Jurisdictions\AU\Plumbing::class,
        'au.asbestos' => \Modules\TitanCompliance\Jurisdictions\AU\Asbestos::class,
        'nz.general' => \Modules\TitanCompliance\Jurisdictions\NZ\General::class,
        'uk.general' => \Modules\TitanCompliance\Jurisdictions\UK\General::class,
        'eu.general' => \Modules\TitanCompliance\Jurisdictions\EU\General::class,
        'us.osha' => \Modules\TitanCompliance\Jurisdictions\US\OSHA::class,
    ],
    'industries' => [
        'builder' => \Modules\TitanCompliance\Industries\BuilderPack::class,
        'electrician' => \Modules\TitanCompliance\Industries\ElectricianPack::class,
        'plumber' => \Modules\TitanCompliance\Industries\PlumberPack::class,
        'roofer' => \Modules\TitanCompliance\Industries\RooferPack::class,
        'demolition' => \Modules\TitanCompliance\Industries\DemolitionPack::class,
        'facilities' => \Modules\TitanCompliance\Industries\FacilitiesPack::class,
        'cleaning' => \Modules\TitanCompliance\Industries\CleaningPack::class,
        'mining' => \Modules\TitanCompliance\Industries\MiningPack::class,
    ],
];
