<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Integrations\Adapters;

use Modules\TitanCompliance\Contracts\Integrations\JobAdapterInterface;
use Modules\TitanCompliance\Integrations\Dto\JobContextDto;

final class NullJobAdapter implements JobAdapterInterface
{
    public function resolveJobContext(int|string $jobId): ?JobContextDto
    {
        return new JobContextDto(jobId: $jobId);
    }
}
