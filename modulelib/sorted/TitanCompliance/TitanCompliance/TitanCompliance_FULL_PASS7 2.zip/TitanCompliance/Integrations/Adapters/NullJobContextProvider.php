<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Integrations\Adapters;

use Modules\TitanCompliance\Contracts\Integrations\JobContextProviderInterface;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class NullJobContextProvider implements JobContextProviderInterface
{
    public function buildFromJobId(int|string $jobId): ComplianceContext
    {
        return new ComplianceContext(
            tenantId: null,
            userId: null,
            trade: null,
            jurisdiction: null,
            siteAddress: null,
            documentType: null,
            extras: ['job_id' => $jobId, 'integration' => 'null'],
        );
    }
}
