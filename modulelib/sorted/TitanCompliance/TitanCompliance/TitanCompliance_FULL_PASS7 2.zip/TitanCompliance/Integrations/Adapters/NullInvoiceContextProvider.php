<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Integrations\Adapters;

use Modules\TitanCompliance\Contracts\Integrations\InvoiceContextProviderInterface;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class NullInvoiceContextProvider implements InvoiceContextProviderInterface
{
    public function buildFromInvoiceId(int|string $invoiceId): ComplianceContext
    {
        return new ComplianceContext(
            tenantId: null,
            userId: null,
            trade: null,
            jurisdiction: null,
            siteAddress: null,
            documentType: null,
            extras: ['invoice_id' => $invoiceId, 'integration' => 'null'],
        );
    }
}
