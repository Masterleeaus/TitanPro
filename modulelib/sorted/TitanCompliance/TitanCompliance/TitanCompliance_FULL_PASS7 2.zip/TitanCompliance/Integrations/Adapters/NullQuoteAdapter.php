<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Integrations\Adapters;

use Modules\TitanCompliance\Contracts\Integrations\QuoteAdapterInterface;
use Modules\TitanCompliance\Integrations\Dto\QuoteContextDto;

final class NullQuoteAdapter implements QuoteAdapterInterface
{
    public function resolveQuoteContext(int|string $quoteId): ?QuoteContextDto
    {
        return new QuoteContextDto(quoteId: $quoteId);
    }
}
