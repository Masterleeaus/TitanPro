<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Integrations\Adapters;

use Modules\TitanCompliance\Contracts\Integrations\InvoiceAdapterInterface;
use Modules\TitanCompliance\Integrations\Dto\InvoiceContextDto;

final class NullInvoiceAdapter implements InvoiceAdapterInterface
{
    public function resolveInvoiceContext(int|string $invoiceId): ?InvoiceContextDto
    {
        return new InvoiceContextDto(invoiceId: $invoiceId);
    }
}
