<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Integrations\Adapters;

use Modules\TitanCompliance\Contracts\Integrations\QuoteContextProviderInterface;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class NullQuoteContextProvider implements QuoteContextProviderInterface
{
    public function buildFromQuoteId(int|string $quoteId): ComplianceContext
    {
        return new ComplianceContext(
            tenantId: null,
            userId: null,
            trade: null,
            jurisdiction: null,
            siteAddress: null,
            documentType: null,
            extras: ['quote_id' => $quoteId, 'integration' => 'null'],
        );
    }
}
