<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Integrations\Dto;

final class JobContextDto
{
    public function __construct(
        public int|string $jobId,
        public ?int $tenantId = null,
        public ?int $userId = null,
        public ?string $industry = null,
        public ?string $jurisdiction = null,
        public ?string $siteAddress = null,
        public array $meta = [],
    ) {}
}
