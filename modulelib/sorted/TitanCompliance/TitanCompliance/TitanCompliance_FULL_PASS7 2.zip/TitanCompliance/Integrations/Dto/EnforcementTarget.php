<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Integrations\Dto;

final class EnforcementTarget
{
    public function __construct(
        public readonly string $type,
        public readonly int|string $id,
        public readonly ?string $action = null,
    ) {}
}
