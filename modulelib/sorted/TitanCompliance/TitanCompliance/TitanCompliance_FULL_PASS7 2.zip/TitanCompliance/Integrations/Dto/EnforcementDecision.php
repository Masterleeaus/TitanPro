<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Integrations\Dto;

final class EnforcementDecision
{
    public function __construct(
        public readonly bool $allowed,
        public readonly string $reason,
        public readonly array $details = [],
        public readonly string $level = 'warn' // 'warn'|'block'
    ) {}
}
