# TitanCompliance Delta (P8)
Date: 2025-10-01T23:01:20.542589Z

Adds:
- **ClientInterface** for provider-agnostic chat/ping.
- **Adapters:** OpenAI, Anthropic, Gemini (cURL-based minimal clients).
- **ClientBindingServiceProvider** binds the default provider per `config('titancompliance.ai.default')`.
- **ai:smoke** updated with `--live` to perform a real ping via the bound adapter.
- Docs partial describing adapters.

## Install
```bash
unzip TitanCompliance_Delta_P8.zip -d .
rsync -a Modules/TitanCompliance/ Modules/TitanCompliance/
php artisan config:clear && php artisan cache:clear
```

## Register provider (if not already auto-included)
```php
$this->app->register(\Modules\TitanCompliance\Providers\ClientBindingServiceProvider::class);
```

## Live connectivity test
```bash
php artisan ai:smoke --live
```
