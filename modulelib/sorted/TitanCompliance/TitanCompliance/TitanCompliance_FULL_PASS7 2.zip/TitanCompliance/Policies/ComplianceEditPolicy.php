<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Policies;

use App\Models\User;
use Modules\TitanCompliance\Models\CompliancePack;

final class ComplianceEditPolicy
{
    public function update(User $user, CompliancePack $pack): bool
    {
        return true;
    }
}
