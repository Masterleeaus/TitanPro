<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Policies;

use App\Models\User;

final class ComplianceLockPolicy
{
    public function lock(User $user): bool
    {
        return true;
    }
}
