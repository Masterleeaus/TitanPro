<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Policies;

use App\Models\User;

final class ComplianceSignPolicy
{
    public function sign(User $user): bool
    {
        return true;
    }
}
