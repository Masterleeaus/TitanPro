<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Policies;

use App\Models\User;

final class ComplianceEvidencePolicy
{
    public function create(User $user): bool
    {
        return true;
    }
}
