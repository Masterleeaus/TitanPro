<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Illuminate\Support\Facades\DB;
use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Models\ComplianceDocument;
use Modules\TitanCompliance\Models\ComplianceVersion;
use Modules\TitanCompliance\Enums\ComplianceStatus;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class ComplianceVersioningService
{
public function snapshot(CompliancePack $pack, ComplianceContext $context): ComplianceVersion
{
    $snapshot = [
        'pack' => $pack->toArray(),
        'documents' => $pack->documents()->get()->toArray(),
    ];

    return ComplianceVersion::query()->create([
        'pack_id' => $pack->id,
        'version' => (int) ($pack->versions()->max('version') ?? 0) + 1,
        'snapshot' => $snapshot,
        'created_by' => $context->userId,
    ]);
}

}
