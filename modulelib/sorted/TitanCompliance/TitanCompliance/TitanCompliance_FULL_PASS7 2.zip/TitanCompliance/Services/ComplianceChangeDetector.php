<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Modules\TitanCompliance\Models\ComplianceChange;
use Modules\TitanCompliance\Models\CompliancePack;

final class ComplianceChangeDetector
{
    public function recordChange(CompliancePack $pack, string $changeType, array $diff, string $subjectType = 'pack', ?int $subjectId = null, ?int $userId = null): ComplianceChange
    {
        return ComplianceChange::query()->create([
            'compliance_pack_id' => $pack->id,
            'subject_type' => $subjectType,
            'subject_id' => $subjectId,
            'change_type' => $changeType,
            'diff' => $diff,
            'created_by' => $userId,
        ]);
    }
}
