<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Illuminate\Support\Facades\DB;
use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Models\ComplianceDocument;
use Modules\TitanCompliance\Models\ComplianceVersion;
use Modules\TitanCompliance\Enums\ComplianceStatus;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class CompliancePackBuilder
{
public function upsert(array $payload, ComplianceContext $context): CompliancePack
{
    $pack = CompliancePack::query()->updateOrCreate(
        ['external_ref' => $payload['external_ref'] ?? null],
        [
            'title' => $payload['title'] ?? 'Compliance Pack',
            'status' => $payload['status'] ?? ComplianceStatus::Draft->value,
            'trade' => $payload['trade'] ?? $context->trade,
            'jurisdiction' => $payload['jurisdiction'] ?? $context->jurisdiction,
            'meta' => $payload['meta'] ?? [],
        ]
    );

    return $pack;
}

}
