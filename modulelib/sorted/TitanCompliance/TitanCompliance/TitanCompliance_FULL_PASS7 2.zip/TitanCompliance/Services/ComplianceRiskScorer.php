<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Illuminate\Support\Facades\DB;
use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Models\ComplianceDocument;
use Modules\TitanCompliance\Models\ComplianceVersion;
use Modules\TitanCompliance\Enums\ComplianceStatus;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class ComplianceRiskScorer
{
public function scorePack(CompliancePack $pack, ComplianceContext $context): void
{
    // Placeholder deterministic scoring; later passes can use AI + matrix scoring.
    $pack->risk_score = $pack->risk_score ?? 0;
    $pack->save();
}

    /**
     * Deterministic scoring for enforcement gates.
     *
     * @param array{ok:bool,missing:list<string>,context:array<string,mixed>} $validation
     */
    public function score(array $validation): int
    {
        $score = 100;
        if (!$validation['ok']) {
            $score -= 20 * count($validation['missing']);
        }
        return max(0, min(100, $score));
    }

}
