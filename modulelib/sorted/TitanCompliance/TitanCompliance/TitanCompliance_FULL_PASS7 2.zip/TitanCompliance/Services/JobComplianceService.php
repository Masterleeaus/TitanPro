<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Modules\TitanCompliance\Models\JobCompliance;
use Modules\TitanCompliance\Models\CompliancePack;

final class JobComplianceService
{
    public function linkPackToJob(int $jobId, CompliancePack $pack, string $status = 'draft'): JobCompliance
    {
        return JobCompliance::query()->updateOrCreate(
            ['job_id' => $jobId, 'compliance_pack_id' => $pack->id],
            ['status' => $status]
        );
    }
}
