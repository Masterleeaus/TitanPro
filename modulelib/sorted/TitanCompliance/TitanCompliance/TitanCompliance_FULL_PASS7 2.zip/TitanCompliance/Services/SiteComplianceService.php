<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Modules\TitanCompliance\Models\SiteCompliance;
use Modules\TitanCompliance\Models\CompliancePack;

final class SiteComplianceService
{
    public function linkPackToSite(int $siteId, CompliancePack $pack, string $status = 'draft'): SiteCompliance
    {
        return SiteCompliance::query()->updateOrCreate(
            ['site_id' => $siteId, 'compliance_pack_id' => $pack->id],
            ['status' => $status]
        );
    }
}
