<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Carbon\CarbonImmutable;
use Modules\TitanCompliance\Models\JobCompliance;
use Modules\TitanCompliance\Models\SiteCompliance;

final class ComplianceLockService
{
    public function lockJob(int $jobId, int $packId, ?int $userId = null, ?string $reason = null): int
    {
        return JobCompliance::query()
            ->where('job_id', $jobId)
            ->where('compliance_pack_id', $packId)
            ->update([
                'locked_at' => CarbonImmutable::now(),
                'locked_by' => $userId,
                'lock_reason' => $reason,
            ]);
    }

    public function lockSite(int $siteId, int $packId, ?int $userId = null, ?string $reason = null): int
    {
        return SiteCompliance::query()
            ->where('site_id', $siteId)
            ->where('compliance_pack_id', $packId)
            ->update([
                'locked_at' => CarbonImmutable::now(),
                'locked_by' => $userId,
                'lock_reason' => $reason,
            ]);
    }
}
