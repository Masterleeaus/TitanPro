<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Illuminate\Support\Facades\DB;
use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Models\ComplianceDocument;
use Modules\TitanCompliance\Models\ComplianceVersion;
use Modules\TitanCompliance\Enums\ComplianceStatus;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class ComplianceEngine
{
public function __construct(
    private readonly CompliancePackBuilder $packs,
    private readonly ComplianceValidator $validator,
    private readonly ComplianceRiskScorer $riskScorer,
    private readonly ComplianceDocumentAssembler $docs,
    private readonly ComplianceVersioningService $versions,
) {}

/**
 * Create or update a compliance pack and ensure it is versioned.
 */
public function upsertPack(array $payload, ComplianceContext $context): CompliancePack
{
    return DB::transaction(function () use ($payload, $context) {
        $pack = $this->packs->upsert($payload, $context);

        $this->validator->validatePack($pack, $context);
        $this->riskScorer->scorePack($pack, $context);

        $this->versions->snapshot($pack, $context);

        return $pack;
    });
}

public function assembleDocument(CompliancePack $pack, array $docPayload, ComplianceContext $context): ComplianceDocument
{
    return $this->docs->assemble($pack, $docPayload, $context);
}

}
