<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;
use Modules\TitanCompliance\Jurisdictions\Resolver as JurisdictionResolver;
use Modules\TitanCompliance\Industries\Resolver as IndustryResolver;

final class ComplianceRuleResolver
{
    public function __construct(
        private readonly JurisdictionResolver $jurisdictions = new JurisdictionResolver(),
        private readonly IndustryResolver $industries = new IndustryResolver(),
    ) {}

    /** @return array<int,string> */
    public function resolveRuleKeys(CompliancePack $pack, ComplianceContext $context): array
    {
        $trade = strtolower((string) ($pack->trade ?? $context->trade ?? ''));
        $jurisdiction = $pack->jurisdiction ?? $context->jurisdiction;

        $ctx = new ComplianceContext(
            tenantId: $context->tenantId,
            userId: $context->userId,
            trade: $trade ?: $context->trade,
            jurisdiction: $jurisdiction ?: $context->jurisdiction,
            siteAddress: $context->siteAddress,
            documentType: $context->documentType,
            extras: $context->extras,
        );

        $keys = [];
        $keys = array_merge($keys, $this->jurisdictions->resolveRuleKeys($ctx));
        $keys = array_merge($keys, $this->industries->resolveRuleKeys($ctx));

        $activities = $pack->meta['activities'] ?? [];
        $activitiesStr = is_string($activities)
            ? strtolower($activities)
            : strtolower(implode(',', (array) $activities));

        if (str_contains($activitiesStr, 'height') || str_contains($activitiesStr, 'roof')) $keys[] = 'falls.heights';
        if (str_contains($activitiesStr, 'weld') || str_contains($activitiesStr, 'grind')) $keys[] = 'hot_works';
        if (str_contains($activitiesStr, 'confined')) $keys[] = 'confined_spaces';

        return array_values(array_unique(array_filter($keys)));
    }
}
