<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Modules\TitanCompliance\Models\ComplianceAttachment;
use Modules\TitanCompliance\Models\CompliancePhoto;
use Modules\TitanCompliance\Models\ComplianceNote;

final class EvidenceIngestService
{
    public function addNote(int $packId, string $note, string $subjectType = 'pack', ?int $subjectId = null, ?int $userId = null): ComplianceNote
    {
        return ComplianceNote::query()->create([
            'compliance_pack_id' => $packId,
            'subject_type' => $subjectType,
            'subject_id' => $subjectId,
            'note' => $note,
            'created_by' => $userId,
        ]);
    }

    public function addAttachment(int $packId, array $payload): ComplianceAttachment
    {
        return ComplianceAttachment::query()->create($payload + ['compliance_pack_id' => $packId]);
    }

    public function addPhoto(int $packId, array $payload): CompliancePhoto
    {
        return CompliancePhoto::query()->create($payload + ['compliance_pack_id' => $packId]);
    }
}
