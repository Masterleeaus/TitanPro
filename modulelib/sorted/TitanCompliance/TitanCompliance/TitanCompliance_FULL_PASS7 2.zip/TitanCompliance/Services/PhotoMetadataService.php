<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

final class PhotoMetadataService
{
    public function extract(array $meta): array
    {
        // Placeholder for EXIF / device / geotag parsing.
        return [
            'taken_at' => $meta['taken_at'] ?? null,
            'gps_lat' => $meta['gps_lat'] ?? null,
            'gps_lng' => $meta['gps_lng'] ?? null,
            'device' => $meta['device'] ?? null,
        ];
    }
}
