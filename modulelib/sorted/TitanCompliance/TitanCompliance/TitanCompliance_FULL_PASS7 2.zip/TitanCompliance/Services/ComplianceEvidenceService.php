<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Illuminate\Support\Facades\DB;
use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Models\ComplianceDocument;
use Modules\TitanCompliance\Models\ComplianceVersion;
use Modules\TitanCompliance\Enums\ComplianceStatus;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class ComplianceEvidenceService
{
public function attachEvidence(ComplianceDocument $document, array $payload): void
{
    $document->evidences()->create([
        'type' => $payload['type'] ?? 'note',
        'label' => $payload['label'] ?? null,
        'payload' => $payload['payload'] ?? [],
    ]);
}

}
