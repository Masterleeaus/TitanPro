<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Modules\TitanCompliance\Support\Guards\EnforcementGuard;
use Modules\TitanCompliance\Repositories\Contracts\ComplianceEnforcementRepositoryInterface;
use Modules\TitanCompliance\Integrations\Dto\EnforcementDecision;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class ComplianceEnforcementService
{
    public function __construct(
        private readonly EnforcementGuard $guard,
        private readonly ComplianceEnforcementRepositoryInterface $repo,
    ) {}

    public function decide(string $action, ComplianceContext $context): EnforcementDecision
    {
        if (! $this->guard->enabled()) {
            return new EnforcementDecision(true, 'enforcement_off', ['action' => $action], 'warn');
        }

        // Soft mode: only enforce actions explicitly marked as required.
        if (! $this->guard->actionRequired($action)) {
            return new EnforcementDecision(true, 'action_not_required', ['action' => $action], 'warn');
        }

        $entityId = $context->extras['job_id'] ?? $context->extras['quote_id'] ?? $context->extras['invoice_id'] ?? null;
        if ($entityId === null) {
            return new EnforcementDecision(false, 'missing_entity_id', ['action' => $action], $this->guard->isHard() ? 'block' : 'warn');
        }

        $packs = $this->repo->findFinalizedForEntity($action, $entityId);
        if (count($packs) === 0) {
            return new EnforcementDecision(false, 'no_finalized_pack', ['action' => $action, 'entity_id' => (string)$entityId], $this->guard->isHard() ? 'block' : 'warn');
        }

        // Deterministic lightweight scoring using existing services.
        $validator = app(ComplianceValidator::class);
        $scorer = app(ComplianceRiskScorer::class);
        $validation = $validator->validateContext($context);
        $score = $scorer->score($validation);

        return new EnforcementDecision(true, 'ok', ['action' => $action, 'entity_id' => (string)$entityId, 'packs' => count($packs), 'score' => $score], 'warn');
    }
}
