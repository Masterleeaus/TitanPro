<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

final class ComplianceDiffService
{
    public function diff(array $before, array $after): array
    {
        // Minimal, deterministic diff for audit trails.
        $diff = [];
        foreach (array_unique(array_merge(array_keys($before), array_keys($after))) as $k) {
            $b = $before[$k] ?? null;
            $a = $after[$k] ?? null;
            if ($b !== $a) {
                $diff[$k] = ['before' => $b, 'after' => $a];
            }
        }
        return $diff;
    }
}
