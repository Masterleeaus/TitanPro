<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services\AI;

use Illuminate\Support\Facades\Config;
use Modules\TitanCompliance\Support\Contracts\ClientInterface;
use Modules\TitanCompliance\Telemetry\AiDecisionLog;
use Modules\TitanCompliance\Telemetry\PromptHash;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

/**
 * Produces plain-language explanations for computed scores and findings.
 */
final class ExplainabilityService
{
    public function __construct(
        private ClientInterface $client,
    ) {}

    /**
     * @param array<string,mixed> $payload
     * @return array<string,mixed>
     */
    public function run(string $action, ComplianceContext $ctx, array $payload): array
    {
        $guard = new CostGuard();
        $selector = new ModelSelector();

        $provider = (string) Config::get('titancompliance.ai.default', 'openai');
        $model = $selector->selectModel($action);

        $hash = PromptHash::make($action, $payload);
        $guard->assertWithinBudget($action);

        $raw = $this->client->chat($payload, $model);

        $norm = (new ResponseNormalizer())->normalise($raw);

        // Telemetry
        (new AiDecisionLog())->record([
            'action' => $action,
            'provider' => $provider,
            'model' => $model,
            'prompt_hash' => $hash,
            'tenant_id' => $ctx->tenantId,
            'user_id' => $ctx->userId,
            'ok' => (bool) ($norm['ok'] ?? false),
        ]);

        return $norm;
    }
}
