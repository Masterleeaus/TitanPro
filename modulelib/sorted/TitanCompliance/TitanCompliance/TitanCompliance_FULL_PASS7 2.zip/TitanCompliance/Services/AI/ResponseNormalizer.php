<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services\AI;

final class ResponseNormalizer
{
    /**
     * @param mixed $raw
     * @return array<string,mixed>
     */
    public function normalise(mixed $raw): array
    {
        // Expect adapters to return either array or JSON string; normalise to array.
        if (is_array($raw)) {
            return $raw;
        }
        if (is_string($raw)) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }

        return [
            'ok' => false,
            'summary' => 'Unparseable AI response',
            'items' => [],
            'warnings' => ['response_normaliser_unparseable'],
        ];
    }
}
