<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services\AI;

use Illuminate\Support\Facades\Config;

final class ModelSelector
{
    public function selectModel(string $action): ?string
    {
        // Allow per-action override, else use provider default.
        $overrides = (array) Config::get('titancompliance.ai.model_overrides', []);
        if (isset($overrides[$action]) && is_string($overrides[$action])) {
            return $overrides[$action];
        }

        $defaultProvider = (string) Config::get('titancompliance.ai.default', 'openai');
        $cfg = (array) Config::get('titancompliance.ai.providers.'.$defaultProvider, []);

        return isset($cfg['model_chat']) && is_string($cfg['model_chat']) ? $cfg['model_chat'] : null;
    }
}
