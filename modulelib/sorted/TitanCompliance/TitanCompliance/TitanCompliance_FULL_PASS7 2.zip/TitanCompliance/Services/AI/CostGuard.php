<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services\AI;

use Illuminate\Support\Facades\Config;
use RuntimeException;

final class CostGuard
{
    public function assertWithinBudget(string $action): void
    {
        // Placeholder budget guard: checks that budgets are configured (later passes: enforce token counters).
        $budgets = (array) Config::get('titancompliance.ai.budgets', []);
        if (empty($budgets)) {
            return;
        }
        if (!isset($budgets[$action])) {
            return;
        }
        $limit = (int) $budgets[$action];
        if ($limit < 1) {
            throw new RuntimeException('TitanCompliance budget for action '.$action.' is invalid.');
        }
    }
}
