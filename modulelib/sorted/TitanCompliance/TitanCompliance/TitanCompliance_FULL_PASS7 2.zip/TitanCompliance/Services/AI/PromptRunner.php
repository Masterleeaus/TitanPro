<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services\AI;

use Modules\TitanCompliance\AI\PromptRegistry;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class PromptRunner
{
    public function __construct(private ComplianceAiService $ai) {}

    /**
     * @return array<string,mixed>
     */
    public function run(string $action, ComplianceContext $ctx): array
    {
        $map = PromptRegistry::map();
        $cls = $map[$action] ?? null;
        if (!$cls || !method_exists($cls, 'build')) {
            return ['ok' => false, 'summary' => 'Unknown action', 'items' => [], 'warnings' => ['unknown_action']];
        }

        /** @var array<string,mixed> $payload */
        $payload = $cls::build($ctx);

        return $this->ai->run($action, $ctx, $payload);
    }
}
