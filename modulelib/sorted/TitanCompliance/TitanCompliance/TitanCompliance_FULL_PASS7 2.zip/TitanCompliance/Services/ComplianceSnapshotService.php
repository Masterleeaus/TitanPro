<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Models\ComplianceSnapshot;

final class ComplianceSnapshotService
{
    public function snapshot(CompliancePack $pack, string $subjectType = 'pack', ?int $subjectId = null, array $payload = [], ?int $userId = null): ComplianceSnapshot
    {
        $version = (int) (ComplianceSnapshot::query()
            ->where('compliance_pack_id', $pack->id)
            ->where('subject_type', $subjectType)
            ->where('subject_id', $subjectId)
            ->max('version') ?? 0) + 1;

        return ComplianceSnapshot::query()->create([
            'compliance_pack_id' => $pack->id,
            'subject_type' => $subjectType,
            'subject_id' => $subjectId,
            'version' => $version,
            'payload' => $payload,
            'created_by' => $userId,
        ]);
    }
}
