<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Illuminate\Support\Facades\DB;
use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Models\ComplianceDocument;
use Modules\TitanCompliance\Models\ComplianceVersion;
use Modules\TitanCompliance\Enums\ComplianceStatus;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class ComplianceDocumentAssembler
{
public function assemble(CompliancePack $pack, array $payload, ComplianceContext $context): ComplianceDocument
{
    return ComplianceDocument::query()->create([
        'pack_id' => $pack->id,
        'type' => $payload['type'] ?? $context->documentType?->value,
        'title' => $payload['title'] ?? 'Compliance Document',
        'content' => $payload['content'] ?? '',
        'meta' => $payload['meta'] ?? [],
    ]);
}

}
