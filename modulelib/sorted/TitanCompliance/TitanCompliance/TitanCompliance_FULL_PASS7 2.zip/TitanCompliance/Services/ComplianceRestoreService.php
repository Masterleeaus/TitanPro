<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Modules\TitanCompliance\Models\ComplianceSnapshot;

final class ComplianceRestoreService
{
    public function restoreToVersion(int $snapshotId): array
    {
        $snap = ComplianceSnapshot::query()->findOrFail($snapshotId);
        return $snap->payload ?? [];
    }
}
