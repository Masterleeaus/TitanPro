<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Illuminate\Support\Collection;
use Modules\TitanCompliance\Models\ComplianceChange;
use Modules\TitanCompliance\Models\ComplianceSnapshot;

final class ComplianceTimelineService
{
    public function timeline(int $packId, string $subjectType = 'pack', ?int $subjectId = null): Collection
    {
        $snapshots = ComplianceSnapshot::query()
            ->where('compliance_pack_id', $packId)
            ->where('subject_type', $subjectType)
            ->where('subject_id', $subjectId)
            ->get();

        $changes = ComplianceChange::query()
            ->where('compliance_pack_id', $packId)
            ->where('subject_type', $subjectType)
            ->where('subject_id', $subjectId)
            ->get();

        return $snapshots->concat($changes)->sortBy('created_at')->values();
    }
}
