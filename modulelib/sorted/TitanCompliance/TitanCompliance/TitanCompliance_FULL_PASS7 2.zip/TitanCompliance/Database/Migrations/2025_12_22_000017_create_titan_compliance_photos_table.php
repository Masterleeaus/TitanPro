<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('titan_compliance_photos', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('compliance_pack_id')->index();
            $table->string('subject_type', 32)->default('pack')->index();
            $table->unsignedBigInteger('subject_id')->nullable()->index();
            $table->string('disk', 60)->default('public');
            $table->string('path');
            $table->string('caption')->nullable();
            $table->timestamp('taken_at')->nullable()->index();
            $table->decimal('gps_lat', 10, 7)->nullable();
            $table->decimal('gps_lng', 10, 7)->nullable();
            $table->json('meta')->nullable();
            $table->unsignedBigInteger('uploaded_by')->nullable()->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_compliance_photos');
    }
};
