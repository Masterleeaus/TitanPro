<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('titan_compliance_versions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('pack_id')->constrained('titan_compliance_packs')->cascadeOnDelete();
            $table->unsignedInteger('version')->default(1);
            $table->unsignedBigInteger('created_by')->nullable()->index();
            $table->json('snapshot');
            $table->timestamps();
        });

    }

    public function down(): void
    {
        Schema::dropIfExists('titan_compliance_versions');

    }
};
