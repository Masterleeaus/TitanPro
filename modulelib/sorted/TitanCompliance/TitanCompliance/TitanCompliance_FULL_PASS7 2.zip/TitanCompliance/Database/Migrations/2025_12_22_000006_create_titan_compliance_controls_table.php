<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('titan_compliance_controls', function (Blueprint $table) {
            $table->id();
            $table->foreignId('hazard_id')->constrained('titan_compliance_hazards')->cascadeOnDelete();
            $table->string('control');
            $table->string('type')->nullable()->index();
            $table->timestamps();
        });

    }

    public function down(): void
    {
        Schema::dropIfExists('titan_compliance_controls');

    }
};
