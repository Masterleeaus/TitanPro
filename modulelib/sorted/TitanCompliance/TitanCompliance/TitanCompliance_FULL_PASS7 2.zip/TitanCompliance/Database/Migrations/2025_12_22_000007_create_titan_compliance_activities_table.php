<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('titan_compliance_activities', function (Blueprint $table) {
            $table->id();
            $table->foreignId('pack_id')->constrained('titan_compliance_packs')->cascadeOnDelete();
            $table->string('activity');
            $table->text('notes')->nullable();
            $table->timestamps();
        });

    }

    public function down(): void
    {
        Schema::dropIfExists('titan_compliance_activities');

    }
};
