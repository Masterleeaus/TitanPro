<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('titan_compliance_templates', function (Blueprint $table) {
            $table->id();
            $table->foreignId('jurisdiction_id')->nullable()->constrained('titan_compliance_jurisdictions')->nullOnDelete();
            $table->string('type')->index();
            $table->string('title');
            $table->longText('template')->nullable();
            $table->json('meta')->nullable();
            $table->timestamps();
        });

    }

    public function down(): void
    {
        Schema::dropIfExists('titan_compliance_templates');

    }
};
