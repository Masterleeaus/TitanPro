<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('titan_compliance_attachments', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('compliance_pack_id')->index();
            $table->string('subject_type', 32)->default('pack')->index();
            $table->unsignedBigInteger('subject_id')->nullable()->index();
            $table->string('filename');
            $table->string('mime', 120)->nullable();
            $table->string('disk', 60)->default('public');
            $table->string('path');
            $table->unsignedBigInteger('bytes')->default(0);
            $table->json('meta')->nullable();
            $table->unsignedBigInteger('uploaded_by')->nullable()->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_compliance_attachments');
    }
};
