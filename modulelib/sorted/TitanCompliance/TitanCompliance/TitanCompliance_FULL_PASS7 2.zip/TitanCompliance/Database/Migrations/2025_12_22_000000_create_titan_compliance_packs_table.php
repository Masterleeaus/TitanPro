<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('titan_compliance_packs', function (Blueprint $table) {
            $table->id();
            $table->string('external_ref')->nullable()->index();
            $table->string('title');
            $table->string('status')->default('draft')->index();
            $table->string('trade')->nullable()->index();
            $table->string('jurisdiction')->nullable()->index();
            $table->unsignedInteger('risk_score')->default(0);
            $table->json('meta')->nullable();
            $table->timestamps();
        });

    }

    public function down(): void
    {
        Schema::dropIfExists('titan_compliance_packs');

    }
};
