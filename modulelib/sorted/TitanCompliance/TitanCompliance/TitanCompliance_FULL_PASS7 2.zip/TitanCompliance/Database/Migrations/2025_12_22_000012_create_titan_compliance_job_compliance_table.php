<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('titan_compliance_job_compliance', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('job_id')->index();
            $table->unsignedBigInteger('compliance_pack_id')->index();
            $table->string('status', 50)->default('draft');
            $table->timestamp('locked_at')->nullable();
            $table->unsignedBigInteger('locked_by')->nullable()->index();
            $table->string('lock_reason', 64)->nullable();
            $table->timestamps();

            // We avoid foreign keys to external tables (jobs/sites/users) to keep this module portable.
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_compliance_job_compliance');
    }
};
