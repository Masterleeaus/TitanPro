<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('titan_compliance_changes', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('compliance_pack_id')->index();
            $table->string('subject_type', 32)->default('pack')->index();
            $table->unsignedBigInteger('subject_id')->nullable()->index();
            $table->string('change_type', 64)->index();
            $table->json('diff');
            $table->unsignedBigInteger('created_by')->nullable()->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_compliance_changes');
    }
};
