<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('titan_compliance_packs', function (Blueprint $table) {
            if (!Schema::hasColumn('titan_compliance_packs', 'external_action')) {
                $table->string('external_action')->nullable()->index();
            }
            if (!Schema::hasColumn('titan_compliance_packs', 'external_ref')) {
                $table->string('external_ref')->nullable()->index();
            }
        });
    }

    public function down(): void
    {
        Schema::table('titan_compliance_packs', function (Blueprint $table) {
            if (Schema::hasColumn('titan_compliance_packs', 'external_action')) {
                $table->dropColumn('external_action');
            }
            if (Schema::hasColumn('titan_compliance_packs', 'external_ref')) {
                $table->dropColumn('external_ref');
            }
        });
    }
};
