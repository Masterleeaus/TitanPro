<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('titan_compliance_evidences', function (Blueprint $table) {
            $table->id();
            $table->morphs('evidenceable');
            $table->string('type')->index();
            $table->string('label')->nullable();
            $table->json('payload')->nullable();
            $table->timestamps();
        });

    }

    public function down(): void
    {
        Schema::dropIfExists('titan_compliance_evidences');

    }
};
