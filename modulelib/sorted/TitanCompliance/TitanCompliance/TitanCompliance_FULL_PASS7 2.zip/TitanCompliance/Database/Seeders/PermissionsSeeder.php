<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\TitanCompliance\Support\Seeders\UsesSafeInsert;
use Modules\TitanCompliance\Support\Seeders\TenantAware;

final class PermissionsSeeder extends Seeder
{
    use UsesSafeInsert;

    public function run(): void
    {
        // Minimal assumption: table 'permissions' with unique 'name' and optional 'tenant_id' column.
        // If your schema differs, adjust table/columns accordingly.
        foreach ($this->permissions() as $permission) {
            $this->seedPermission('permissions', $permission, 'web');
        }
    }

    /** @return array<int,string> */
    protected function permissions(): array
    {
        return [
            'titancompliance.use',
            'titancompliance.view',
            'titancompliance.pack.create',
            'titancompliance.pack.update',
            'titancompliance.pack.delete',
            'titancompliance.document.create',
            'titancompliance.document.update',
            'titancompliance.document.delete',
            'titancompliance.audit.view',
            'titancompliance.jobs.link',
            'titancompliance.sites.link',
            'titancompliance.evidence.create',
            'titancompliance.snapshots.create',
            'titancompliance.timeline.view',
            'titancompliance.export',
            'titancompliance.lock',
            'titancompliance.sign',
        ];
    }

    protected function seedPermission(string $table, string $name, string $guard = 'web', ?int $tenantId = null): void
    {
        TenantAware::insertOnce($table, [
            'name'       => $name,
            'guard_name' => $guard,
            'created_at' => now(),
            'updated_at' => now(),
        ], ['name'], $tenantId);
    }
}
