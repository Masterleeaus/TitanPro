<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\ValueObjects;

final class EnforcementResult
{
    public function __construct(
        public bool $blocked,
        public ?string $reason = null,
        public array $details = [],
    ) {}

    public static function allow(array $details = []): self
    {
        return new self(false, null, $details);
    }

    public static function block(string $reason, array $details = []): self
    {
        return new self(true, $reason, $details);
    }
}
