<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\ValueObjects;

use Modules\TitanCompliance\Enums\DocumentType;

final class ComplianceContext
{
    public function __construct(
        public readonly ?int $tenantId,
        public readonly ?int $userId,
        public readonly ?string $trade,
        public readonly ?string $jurisdiction,
        public readonly ?string $siteAddress,
        public readonly ?DocumentType $documentType,
        /** @var array<string,mixed> */
        public readonly array $extras = [],
    ) {}

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'tenant_id' => $this->tenantId,
            'user_id' => $this->userId,
            'trade' => $this->trade,
            'jurisdiction' => $this->jurisdiction,
            'site_address' => $this->siteAddress,
            'document_type' => $this->documentType?->value,
            'extras' => $this->extras,
        ];
    }
}
