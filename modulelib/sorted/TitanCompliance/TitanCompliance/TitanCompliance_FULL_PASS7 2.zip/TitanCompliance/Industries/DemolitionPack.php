<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Industries;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class DemolitionPack implements IndustryPackInterface
{
    public function key(): string { return 'demolition'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'asbestos.awareness',
            'plant.equipment',
            'ppe.respiratory',
        ];
    }
}
