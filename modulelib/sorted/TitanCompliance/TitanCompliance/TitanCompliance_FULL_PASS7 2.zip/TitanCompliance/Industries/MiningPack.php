<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Industries;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class MiningPack implements IndustryPackInterface
{
    public function key(): string { return 'mining'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'confined_spaces',
            'plant.equipment',
            'ppe.respiratory',
        ];
    }
}
