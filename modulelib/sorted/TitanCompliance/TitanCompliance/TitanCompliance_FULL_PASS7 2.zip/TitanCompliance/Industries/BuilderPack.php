<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Industries;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class BuilderPack implements IndustryPackInterface
{
    public function key(): string { return 'builder'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'falls.heights',
            'plant.equipment',
            'ppe.basic',
        ];
    }
}
