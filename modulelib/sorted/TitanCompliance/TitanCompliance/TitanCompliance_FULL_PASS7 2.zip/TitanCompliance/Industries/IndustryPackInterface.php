<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Industries;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

interface IndustryPackInterface
{
    /** @return array<int,string> */
    public function ruleKeys(ComplianceContext $context): array;

    public function key(): string;
}
