<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Industries;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class PlumberPack implements IndustryPackInterface
{
    public function key(): string { return 'plumber'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'confined_spaces',
            'chemicals.basic',
            'ppe.basic',
        ];
    }
}
