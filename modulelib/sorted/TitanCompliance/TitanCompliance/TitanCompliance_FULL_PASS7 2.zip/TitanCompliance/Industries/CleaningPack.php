<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Industries;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class CleaningPack implements IndustryPackInterface
{
    public function key(): string { return 'cleaning'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'chemicals.basic',
            'ppe.basic',
            'manual_handling',
        ];
    }
}
