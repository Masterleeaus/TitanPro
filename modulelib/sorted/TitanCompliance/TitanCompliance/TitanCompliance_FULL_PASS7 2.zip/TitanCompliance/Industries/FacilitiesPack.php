<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Industries;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class FacilitiesPack implements IndustryPackInterface
{
    public function key(): string { return 'facilities'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'chemicals.basic',
            'manual_handling',
            'ppe.basic',
        ];
    }
}
