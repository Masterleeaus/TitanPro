<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Industries;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class RooferPack implements IndustryPackInterface
{
    public function key(): string { return 'roofer'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'falls.heights',
            'ppe.basic',
            'manual_handling',
        ];
    }
}
