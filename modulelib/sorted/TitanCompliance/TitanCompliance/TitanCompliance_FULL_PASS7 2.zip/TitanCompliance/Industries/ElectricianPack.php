<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Industries;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class ElectricianPack implements IndustryPackInterface
{
    public function key(): string { return 'electrician'; }

    public function ruleKeys(ComplianceContext $context): array
    {
        return [
            'electrical.isolation',
            'electrical.lockout_tagout',
            'ppe.electrical',
        ];
    }
}
