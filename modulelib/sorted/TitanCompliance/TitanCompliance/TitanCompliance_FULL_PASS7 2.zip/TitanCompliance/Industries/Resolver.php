<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Industries;

use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class Resolver
{
    /** @return array<int,string> */
    public function resolveRuleKeys(ComplianceContext $context): array
    {
        $map = (array) config('titancompliance_packs.industries', []);
        $trade = strtolower((string) ($context->trade ?? ''));
        if ($trade === '') return [];

        $cls = $map[$trade] ?? null;
        if (!is_string($cls) || !class_exists($cls)) return [];

        $pack = new $cls();
        return $pack instanceof IndustryPackInterface ? $pack->ruleKeys($context) : [];
    }
}
