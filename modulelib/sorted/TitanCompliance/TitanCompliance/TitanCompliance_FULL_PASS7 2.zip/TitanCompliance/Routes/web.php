<?php
declare(strict_types=1);

use Illuminate\Support\Facades\Route;
use Modules\TitanCompliance\Http\Controllers\JobComplianceController;
use Modules\TitanCompliance\Http\Controllers\SiteComplianceController;
use Modules\TitanCompliance\Http\Controllers\ComplianceEvidenceController;
use Modules\TitanCompliance\Http\Controllers\ComplianceSnapshotController;
use Modules\TitanCompliance\Http\Controllers\ComplianceAuditController;
use Modules\TitanCompliance\Http\Controllers\ComplianceExportController;

Route::prefix('titan-compliance')->group(function () {
    Route::post('jobs/{jobId}/packs/{packId}/link', [JobComplianceController::class, 'link'])->name('titancompliance.jobs.link');
    Route::post('sites/{siteId}/packs/{packId}/link', [SiteComplianceController::class, 'link'])->name('titancompliance.sites.link');

    Route::post('packs/{packId}/evidence/note', [ComplianceEvidenceController::class, 'addNote'])->name('titancompliance.evidence.note');
    Route::post('packs/{packId}/snapshots', [ComplianceSnapshotController::class, 'snapshot'])->name('titancompliance.snapshots.create');

    Route::get('audits', [ComplianceAuditController::class, 'index'])->name('titancompliance.audits.index');
    Route::get('packs/{packId}/export', [ComplianceExportController::class, 'show'])->name('titancompliance.packs.export');
});
