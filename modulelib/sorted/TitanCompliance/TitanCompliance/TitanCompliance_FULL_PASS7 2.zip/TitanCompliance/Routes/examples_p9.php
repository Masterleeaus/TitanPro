<?php
use Illuminate\Support\Facades\Route;

// API example (auth:sanctum)
Route::aicApi()->group(function () {
    // Route::post('/chat', [\Modules\TitanCompliance\Http\Controllers\ChatController::class, 'store'])->name('chat.store');
    // Route::get('/prompts', [\Modules\TitanCompliance\Http\Controllers\PromptController::class, 'index'])->name('prompts.index');
});

// Web example (auth + fail-safe guard)
Route::aicWeb()->group(function () {
    // Route::get('/dashboard', [\Modules\TitanCompliance\Http\Controllers\DashboardController::class, 'index'])->name('dashboard');
});
