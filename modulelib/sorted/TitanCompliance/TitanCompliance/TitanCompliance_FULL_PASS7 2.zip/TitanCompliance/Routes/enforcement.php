<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Route;
use Modules\TitanCompliance\Http\Controllers\Admin\ComplianceEnforcementController;

Route::middleware(['web'])
    ->prefix('titancompliance/admin')
    ->group(function () {
        Route::get('enforcement', [ComplianceEnforcementController::class, 'index'])->name('titancompliance.admin.enforcement');
    });
