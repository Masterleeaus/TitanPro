<?php

use Illuminate\Support\Facades\Route;
use Modules\TitanCompliance\Http\Controllers\EnforcementController;

Route::prefix('titancompliance')->group(function () {
    Route::post('/enforcement/decide', [EnforcementController::class, 'decide'])
        ->name('titancompliance.enforcement.decide');
});
