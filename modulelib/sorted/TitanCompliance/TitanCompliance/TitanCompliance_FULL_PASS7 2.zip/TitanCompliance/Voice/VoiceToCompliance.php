<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Voice;

final class VoiceToCompliance
{
    public function __construct(
        private readonly TranscriptParser $parser,
        private readonly HazardExtractor $hazards,
        private readonly ControlExtractor $controls,
        private readonly ConfidenceScorer $confidence,
    ) {}

    public function convert(string $transcript): array
    {
        $tokens = $this->parser->parse($transcript);
        return [
            'hazards' => $this->hazards->extract($tokens),
            'controls' => $this->controls->extract($tokens),
            'confidence' => $this->confidence->score($tokens),
            'raw' => $transcript,
        ];
    }
}
