<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Voice;

final class ConfidenceScorer
{
    public function score(array $tokens): int
    {
        return max(0, min(100, (int) round(count($tokens) * 4)));
    }
}
