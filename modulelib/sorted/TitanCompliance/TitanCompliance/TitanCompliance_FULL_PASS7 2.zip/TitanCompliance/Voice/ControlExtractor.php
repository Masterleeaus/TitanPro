<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Voice;

final class ControlExtractor
{
    public function extract(array $tokens): array
    {
        $keywords = ['ppe','gloves','mask','respirator','isolation','lockout','barrier','signage','permit','spotter'];
        return array_values(array_unique(array_intersect($tokens, $keywords)));
    }
}
