<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Voice;

final class HazardExtractor
{
    public function extract(array $tokens): array
    {
        $keywords = ['fall','falls','electric','shock','asbestos','chemical','confined','hotwork','manual','lift'];
        return array_values(array_unique(array_intersect($tokens, $keywords)));
    }
}
