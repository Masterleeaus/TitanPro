<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Voice;

final class ComplianceVoiceHandler
{
    public function __construct(
        private readonly VoiceToCompliance $voiceToCompliance,
    ) {}

    public function handle(string $transcript): array
    {
        return $this->voiceToCompliance->convert($transcript);
    }
}
