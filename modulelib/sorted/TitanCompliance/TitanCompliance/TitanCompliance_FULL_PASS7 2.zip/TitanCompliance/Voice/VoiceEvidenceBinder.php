<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Voice;

final class VoiceEvidenceBinder
{
    public function bind(array $extracted, array $meta = []): array
    {
        return ['type'=>'voice','meta'=>$meta,'extracted'=>$extracted];
    }
}
