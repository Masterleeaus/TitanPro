<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Voice;

final class OfflineQueue
{
    private array $queue = [];

    public function push(array $item): void { $this->queue[] = $item; }

    public function drain(): array { $out=$this->queue; $this->queue=[]; return $out; }
}
