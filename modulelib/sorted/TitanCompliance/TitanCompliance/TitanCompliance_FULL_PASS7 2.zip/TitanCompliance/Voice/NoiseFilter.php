<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Voice;

final class NoiseFilter
{
    public function filter(string $transcript): string
    {
        return preg_replace('/[^\p{L}\p{N}\s\-\,\.]/u', '', $transcript) ?? $transcript;
    }
}
