<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Voice;

final class FieldContextResolver
{
    public function resolve(array $meta = []): array
    {
        return [
            'captured_at' => $meta['captured_at'] ?? date('c'),
            'device' => $meta['device'] ?? null,
            'offline' => (bool)($meta['offline'] ?? false),
        ];
    }
}
