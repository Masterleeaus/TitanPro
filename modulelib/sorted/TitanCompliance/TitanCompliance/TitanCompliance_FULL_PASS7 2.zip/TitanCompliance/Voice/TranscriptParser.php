<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Voice;

final class TranscriptParser
{
    public function parse(string $transcript): array
    {
        $t = trim(mb_strtolower($transcript));
        return preg_split('/\s+/', $t) ?: [];
    }
}
