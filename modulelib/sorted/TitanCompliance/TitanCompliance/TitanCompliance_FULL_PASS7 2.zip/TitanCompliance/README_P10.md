# TitanCompliance — P10 Full Module (P2→P9 rolled up)
Built: 2025-10-01T23:12:05.919681Z

This is the consolidated module including:
- Config fix, quotas/caps, pricing
- Diagnostics (ai:smoke), Security/Telemetry providers
- Fail-safe Guard + Metrics collector
- Guard presets + macros (aicApi/aicWeb)
- Seeders hardened (TenantAware, UsesSafeInsert) + audit command
- Provider adapters (OpenAI/Anthropic/Gemini) + live ping
- Tightened OpenAPI (bearerAuth globally + paths)

Quick start:
```bash
php artisan config:clear && php artisan cache:clear
bash Modules/TitanCompliance/scripts/smoke.sh
```
If a provider key isn’t set, live ping will warn but not crash (non-zero exit tolerated in script).

To change guards:
- Edit `config('titancompliance.security')` and/or `.env` fail-safe toggles.

PASS4: Added jurisdiction + industry pack resolvers. Configure in Config/titancompliance_packs.php
\nPASS4: Added jurisdiction + industry pack resolvers. Configure in Config/titancompliance_packs.php


## PASS 4
- Added jurisdiction + industry packs and resolvers. Configure mappings in `Config/titancompliance_packs.php`.
