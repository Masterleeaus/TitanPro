<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Support\Guards;

use Illuminate\Support\Facades\Config;

final class EnforcementGuard
{
    public function mode(): string
    {
        return (string) Config::get('titancompliance.enforcement.mode', 'soft');
    }

    public function enabled(): bool
    {
        return $this->mode() !== 'off';
    }

    public function isHard(): bool
    {
        return $this->mode() === 'hard';
    }

    public function actionRequired(string $action): bool
    {
        return (bool) Config::get("titancompliance.enforcement.actions.{$action}.required", false);
    }
}
