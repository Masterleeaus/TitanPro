<?php

declare(strict_types=1);

namespace Modules\TitanCompliance\Support\Exceptions;

use RuntimeException;

class ComplianceEnforcementException extends RuntimeException
{
    public static function forAction(string $action, string $reason): self
    {
        return new self("Compliance enforcement blocked '{$action}': {$reason}");
    }
}
