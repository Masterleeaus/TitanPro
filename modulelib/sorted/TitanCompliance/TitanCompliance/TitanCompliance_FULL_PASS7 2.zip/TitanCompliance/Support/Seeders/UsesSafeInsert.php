<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Support\Seeders;

use Modules\TitanCompliance\Support\SeederHelpers;

trait UsesSafeInsert
{
    protected function insertOnce(string $table, array $data, array $uniqueKeys): void
    {
        SeederHelpers::insertIgnore($table, $data, $uniqueKeys);
    }
}
