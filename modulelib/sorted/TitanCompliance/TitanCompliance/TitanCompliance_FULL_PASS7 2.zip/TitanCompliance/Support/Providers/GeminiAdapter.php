<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Support\Providers;

use Modules\TitanCompliance\Support\Contracts\ClientInterface;

final class GeminiAdapter extends BaseAdapter implements ClientInterface
{
    public function ping(int $timeout = 15): bool
    {
        $model = urlencode($this->model ?? 'gemini-1.5-pro');
        $ch = curl_init('https://generativelanguage.googleapis.com/v1beta/models/'.$model);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_HTTPHEADER => [
                'User-Agent: '.$this->buildUserAgent(),
            ],
        ]);
        $resp = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        return $code > 0;
    }

    public function chat(array $messages, array $options = []): array
    {
        $model = $options['model'] ?? $this->model ?? 'gemini-1.5-pro';
        // PHP array syntax replacement
        $payload = [
            'contents' => [
                ['parts' => [['text' => ($messages[count($messages)-1]['content'] ?? '')]]]
            ]
        ];
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/'.urlencode($model).':generateContent?key='.$this->apiKey;
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'User-Agent: '.$this->buildUserAgent(),
            ],
        ]);
        $resp = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($code >= 200 && $code < 300 && $resp) {
            $j = json_decode($resp, true);
            $text = $j['candidates'][0]['content']['parts'][0]['text'] ?? '';
            return ['content'=>$text, 'usage'=>['input_tokens'=>0,'output_tokens'=>0]];
        }
        return ['content'=>'', 'usage'=>['input_tokens'=>0,'output_tokens'=>0]];
    }
}
