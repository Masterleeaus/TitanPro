<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Support\Contracts;

interface ClientInterface
{
    /**
     * Lightweight connectivity test. Returns true on success.
     */
    public function ping(int $timeout = 15): bool;

    /**
     * Minimal chat call signature.
     * @param array $messages Array of ['role'=>'user|system|assistant','content'=>'...']
     * @param array $options  ['model'=>string, 'max_tokens'=>int, 'temperature'=>float, ...]
     * @return array ['content'=>string, 'usage'=>['input_tokens'=>int,'output_tokens'=>int]]
     */
    public function chat(array $messages, array $options = []): array;
}
