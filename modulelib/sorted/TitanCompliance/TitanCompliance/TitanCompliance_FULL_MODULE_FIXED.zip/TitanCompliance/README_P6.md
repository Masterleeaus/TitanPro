# TitanCompliance Delta (P6)
Date: 2025-10-01T22:56:43.418029Z

Adds:
- **SecurityServiceProvider** + `Config/security.php` with guard presets.
- Route macros: `Route::aicApi()` and `Route::aicWeb()` for clean grouping.
- **Seeder trait** `Support/Seeders/UsesSafeInsert.php` to standardize idempotent inserts.
- **OpenAPI security** partial declaring `bearerAuth` (Sanctum-friendly).

## Use
In `Routes/api.php`:
```php
Route::aicApi()->group(function () {
    // Route::post('/chat', [ChatController::class, 'store'])->name('chat.store');
});
```

In `Routes/web.php`:
```php
Route::aicWeb()->group(function () {
    // Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
});
```

Seeders:
```php
use Modules\TitanCompliance\Support\Seeders\UsesSafeInsert;

class MySeeder extends Seeder {
  use UsesSafeInsert;
  public function run(): void {
    $this->insertOnce('permissions', ['name'=>'titancompliance.manage', 'guard_name'=>'web'], ['name']);
  }
}
```

OpenAPI:
- Merge `Docs/partials/openapi-security.yaml` into your main `Docs/openapi.yaml` and add `security:` blocks to protected paths.
