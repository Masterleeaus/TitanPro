<?php

use Illuminate\Support\Facades\Route;
use Modules\TitanCompliance\Http\Controllers\TitanComplianceController;

Route::get('/', [TitanComplianceController::class, 'index'])->name('index');
Route::get('/audits', [TitanComplianceController::class, 'audits'])->name('audits');
Route::get('/reports', [TitanComplianceController::class, 'reports'])->name('reports');
