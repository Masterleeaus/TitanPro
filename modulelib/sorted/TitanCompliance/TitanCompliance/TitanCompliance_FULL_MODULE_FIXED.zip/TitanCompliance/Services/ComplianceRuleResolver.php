<?php
declare(strict_types=1);

namespace Modules\TitanCompliance\Services;

use Illuminate\Support\Facades\DB;
use Modules\TitanCompliance\Models\CompliancePack;
use Modules\TitanCompliance\Models\ComplianceDocument;
use Modules\TitanCompliance\Models\ComplianceVersion;
use Modules\TitanCompliance\Enums\ComplianceStatus;
use Modules\TitanCompliance\ValueObjects\ComplianceContext;

final class ComplianceRuleResolver
{
/**
 * Resolve a list of rule identifiers applicable for the pack/context.
 *
 * @return array<int,string>
 */
public function resolveRuleKeys(CompliancePack $pack, ComplianceContext $context): array
{
    // Minimal deterministic resolver for Pass 1; later will use jurisdiction packs.
    $keys = [];

    if (($pack->trade ?? $context->trade) === 'electrician') {
        $keys[] = 'electrical.lockout_tagout';
    }

    if (str_contains((string) ($pack->meta['activities'] ?? ''), 'heights')) {
        $keys[] = 'falls.heights';
    }

    return array_values(array_unique($keys));
}

}
