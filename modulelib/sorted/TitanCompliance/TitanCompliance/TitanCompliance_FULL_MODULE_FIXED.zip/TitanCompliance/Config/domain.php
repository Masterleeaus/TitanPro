<?php
return [
    'tables' => [
        'packs' => 'titan_compliance_packs',
        'documents' => 'titan_compliance_documents',
    ],
];
