<?php

namespace Modules\TitanCompliance\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;

class TitanComplianceServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titancompliance');

        Route::middleware(['web','auth'])
            ->prefix('account/titan/compliance')
            ->name('titan.compliance.')
            ->group(__DIR__ . '/../routes/account.php');
    }
}
