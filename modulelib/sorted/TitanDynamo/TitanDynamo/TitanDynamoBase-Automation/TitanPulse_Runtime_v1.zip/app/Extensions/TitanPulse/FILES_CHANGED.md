
# FILES CHANGED

## Added
- System/Core/PulseKernel/* imported and adapted from Workflow core
- System/Core/PulseEngine/* imported and adapted from AiSocialMedia runtime
- System/Services/PulseRuntimeManager.php
- System/Console/Commands/PulseRuntimeInspectCommand.php
- README_RUNTIME.md

## Updated
- System/TitanPulseServiceProvider.php
- CHANGELOG.md
- POST_STEPS.md
- ROLLBACK.md
