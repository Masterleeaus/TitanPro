
# ROLLBACK

- Remove `app/Extensions/TitanPulse/System/Core/PulseKernel`
- Remove `app/Extensions/TitanPulse/System/Core/PulseEngine`
- Revert `System/TitanPulseServiceProvider.php`
- Clear caches: `php artisan optimize:clear`
