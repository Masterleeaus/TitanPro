
# POST STEPS

1. Upload `app/Extensions/TitanPulse`
2. Clear caches: `php artisan optimize:clear`
3. Run Pulse worker: `php artisan titan:pulse-run --limit=200`
4. Optional inspect command: `php artisan titan:pulse-runtime:inspect`
5. Review imported runtime classes under `System/Core/PulseKernel` and `System/Core/PulseEngine`
