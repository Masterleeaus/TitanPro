<?php

use App\Http\Controllers\TitanRuntime\TitanRuntimeTemplateController;
use Illuminate\Support\Facades\Route;

Route::middleware(['web', 'auth'])
    ->prefix('api/titan-runtime/templates')
    ->group(function () {
        Route::get('/', [TitanRuntimeTemplateController::class, 'index'])
            ->name('api.titan-runtime.templates.index');
        Route::post('/render', [TitanRuntimeTemplateController::class, 'render'])
            ->name('api.titan-runtime.templates.render');
    });
