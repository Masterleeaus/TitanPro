<?php

use App\Http\Controllers\TitanRuntime\TitanRuntimeProviderController;
use Illuminate\Support\Facades\Route;

Route::middleware(['web', 'auth'])
    ->prefix('api/titan-runtime')
    ->group(function () {
        Route::get('/providers', [TitanRuntimeProviderController::class, 'index'])
            ->name('api.titan-runtime.providers');
        Route::get('/providers/boot', [TitanRuntimeProviderController::class, 'boot'])
            ->name('api.titan-runtime.providers.boot');
    });
