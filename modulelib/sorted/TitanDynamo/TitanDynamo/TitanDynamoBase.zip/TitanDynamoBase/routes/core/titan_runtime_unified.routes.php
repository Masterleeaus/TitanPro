<?php
use Illuminate\Support\Facades\Route;
Route::middleware(['web','auth'])->prefix('api/titan-runtime/unified')->group(function(){
    Route::get('/boot', fn() => app(\App\Services\TitanRuntime\Engines\UnifiedRuntimeEngine::class)->boot());
});
