<?php

use App\Http\Controllers\TitanRuntime\TitanRuntimePackController;
use Illuminate\Support\Facades\Route;

Route::middleware(['web', 'auth'])
    ->prefix('api/titan-runtime/packs')
    ->group(function () {
        Route::get('/', [TitanRuntimePackController::class, 'index'])
            ->name('api.titan-runtime.packs.index');
        Route::get('/schema', [TitanRuntimePackController::class, 'schema'])
            ->name('api.titan-runtime.packs.schema');
    });
