<?php

use App\Http\Controllers\TitanDynamoApiController;
use Illuminate\Support\Facades\Route;

Route::prefix('api/automation')->group(function () {
    Route::post('dispatch', [TitanDynamoApiController::class, 'dispatch']);
    Route::get('status/{id}', [TitanDynamoApiController::class, 'status']);
    Route::get('receipt/{id}', [TitanDynamoApiController::class, 'receipt']);
});
