# Integration Map

This artifact is part of the Titan four-system split:

- **Titan Zero** = conversation, channels, governance, plugins, Nexus
- **Titan Signal** = sensing, normalization, provider aggregation, envelopes
- **Titan Rewind** = history, snapshots, replay, rollback context
- **Titan Dynamo** = automation, dispatch, provider flow, execution receipts

## Shared integration rules
- `team_id` is the tenant boundary.
- `company_id` remains only for legacy compatibility when present.
- Each system should expose a thin service/contract boundary.
- Zero owns approval and user-facing explanation.
- Side systems own their internal engines and state.
- Evidence and audit references should be portable across systems.

## Required seams
- Zero consumes Signal envelopes and summaries.
- Zero launches Rewind lookups and receives timeline summaries.
- Zero submits approved work to Dynamo and receives receipts/status.
- Rewind can reference Signal events and Dynamo receipts.
- Dynamo can emit Signal events and Rewind audit markers.


## Package focus
Titan Dynamo keeps automation, dispatch, provider flow, and execution receipts.
