# Zero Integration

Zero should:
- approve work
- submit an execution request
- read receipts and status
- surface explanations back to users

Dynamo should:
- own execution internals
- emit status callbacks
- publish signals for notable events
