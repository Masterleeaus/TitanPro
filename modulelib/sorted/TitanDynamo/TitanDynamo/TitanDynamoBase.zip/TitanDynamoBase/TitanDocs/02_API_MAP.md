# API Map

- POST /api/automation/dispatch
- GET /api/automation/status/{id}
- GET /api/automation/receipt/{id}

Titan Dynamo executes after Zero approval and returns receipts back to Zero.
