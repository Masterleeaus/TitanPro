# Titan Dynamo Dev Prompt

Build Titan Dynamo as the automation and dispatch side system.
Preserve runtime orchestration code already present.
Priorities:
1. execution receipts
2. provider flow hardening
3. trigger/rule expansion
4. Zero handoff + callback contracts
5. Signal and Rewind markers for execution events
