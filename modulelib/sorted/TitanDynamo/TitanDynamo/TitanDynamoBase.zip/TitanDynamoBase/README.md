# Titan Dynamo

Automation dispatch and execution side system for Zero.

This pass hardens the split by adding API seams, docs, and connector-ready contracts.
