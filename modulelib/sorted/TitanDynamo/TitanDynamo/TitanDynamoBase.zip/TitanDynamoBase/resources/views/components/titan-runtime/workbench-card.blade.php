@props(['state'=>[]])
<x-titan-runtime.card title="Titan Runtime Workbench">
    <div x-data="window.TitanRuntimeWorkbench(@js($state))" x-init="init()" class="grid gap-4 xl:grid-cols-[1.1fr_.9fr]">
        <div class="space-y-4">
            @include('panel.user.titan-runtime.partials.context-strip')
            @include('panel.user.titan-runtime.partials.pack-memory-strip')
            @include('panel.user.titan-runtime.partials.plugin-quick-actions')
            @include('panel.user.titan-runtime.partials.chat-thread')
            @include('panel.user.titan-runtime.partials.prompt-bar')
        </div>
        <div class="space-y-4">
            @include('panel.user.titan-runtime.partials.schema-meta-strip')
            @include('panel.user.titan-runtime.partials.canvas-schema', ['schema' => $state['canvas'] ?? []])
            @include('panel.user.titan-runtime.partials.pack-list-pane')
            @include('panel.user.titan-runtime.partials.donor-pane')
            @include('panel.user.titan-runtime.partials.donor-activation-pane')
            @include('panel.user.titan-runtime.partials.artifact-pane')
            @include('panel.user.titan-runtime.partials.signal-timeline')
            @include('panel.user.titan-runtime.partials.plugin-pane')
        </div>
    </div>
</x-titan-runtime.card>
