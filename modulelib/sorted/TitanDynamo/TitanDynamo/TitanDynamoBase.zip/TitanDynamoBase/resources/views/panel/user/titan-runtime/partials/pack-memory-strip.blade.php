<div class="rounded-2xl border border-black/10 bg-white px-4 py-3">
    <div class="text-[11px] uppercase text-black/45">Pack Memory</div>
    <div class="text-sm font-semibold" x-text="memory.aichatpro?.summary || 'No pack memory'"></div>
</div>
