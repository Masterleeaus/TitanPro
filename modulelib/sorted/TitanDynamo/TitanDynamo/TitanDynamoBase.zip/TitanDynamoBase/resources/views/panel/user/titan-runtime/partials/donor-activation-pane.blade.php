<div class="space-y-3">
    <div class="flex items-center justify-between">
        <strong class="text-sm">Donor Activation</strong>
        <span class="text-[11px] text-black/40">Runtime</span>
    </div>
    <div class="rounded-2xl border border-black/10 bg-white px-4 py-3">
        <div class="text-[11px] uppercase text-black/45">Action</div>
        <div class="text-sm font-semibold">Use prompt: “activate donor providers”</div>
    </div>
</div>
