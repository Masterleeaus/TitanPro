<div class="space-y-3">
    <div class="flex items-center justify-between">
        <strong class="text-sm">Loaded Packs</strong>
        <span class="text-[11px] text-black/40">AiChatPro</span>
    </div>
    <template x-if="packItems.length === 0">
        <div class="rounded-2xl border border-dashed border-black/10 p-6 text-center text-sm text-black/50">No packs loaded.</div>
    </template>
    <template x-for="item in packItems" :key="item.label">
        <div class="rounded-xl border border-black/10 px-3 py-2">
            <div class="text-xs uppercase text-black/45" x-text="item.label"></div>
            <div class="text-sm text-black/75" x-text="item.value"></div>
        </div>
    </template>
</div>
