<?php

return [
    'name' => 'Titan Dynamo',
    'route' => [
        'prefix' => 'dashboard/user/titan-dynamo',
        'name' => 'dashboard.user.titan-dynamo.',
        'middleware' => ['web', 'auth', 'updateUserActivity'],
    ],
    'tenant_column' => 'team_id',
    'receipt_table' => 'tz_dynamo_receipts',
    'job_table' => 'tz_dynamo_jobs',
];
