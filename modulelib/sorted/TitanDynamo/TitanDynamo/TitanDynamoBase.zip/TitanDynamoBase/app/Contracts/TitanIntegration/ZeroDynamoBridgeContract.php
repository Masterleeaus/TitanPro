<?php

namespace App\Contracts\TitanIntegration;

interface ZeroDynamoBridgeContract
{
    public function submit(string $intent, array $payload = []): array;
    public function status(string $receiptId): array;
    public function callback(array $payload): array;
}
