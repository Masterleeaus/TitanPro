<?php
namespace App\Http\Controllers\TitanRuntime;
use App\Http\Controllers\Controller;
use App\Services\TitanRuntime\Engines\RuntimeOrchestrator;
use Illuminate\Http\Request;
class TitanRuntimeApiController extends Controller{
public function dispatch(Request $request,RuntimeOrchestrator $orchestrator){
$prompt=(string)$request->input('prompt','');
return response()->json($orchestrator->handle($prompt));
}}