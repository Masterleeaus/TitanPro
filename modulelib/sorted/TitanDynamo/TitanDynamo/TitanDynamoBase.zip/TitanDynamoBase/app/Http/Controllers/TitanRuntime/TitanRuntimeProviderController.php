<?php

namespace App\Http\Controllers\TitanRuntime;

use App\Http\Controllers\Controller;
use App\Services\TitanRuntime\Engines\ProviderFlowEngine;
use App\Services\TitanRuntime\Registry\ProviderRegistry;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TitanRuntimeProviderController extends Controller
{
    public function index(ProviderRegistry $providers): JsonResponse
    {
        return response()->json([
            'providers' => $providers->all(),
        ]);
    }

    public function boot(Request $request, ProviderFlowEngine $flows): JsonResponse
    {
        $provider = (string) $request->query('provider', 'titanzero-dashboard');

        return response()->json($flows->payload($provider));
    }
}
