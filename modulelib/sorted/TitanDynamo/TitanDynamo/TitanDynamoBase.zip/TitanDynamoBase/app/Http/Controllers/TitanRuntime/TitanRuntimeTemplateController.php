<?php

namespace App\Http\Controllers\TitanRuntime;

use App\Http\Controllers\Controller;
use App\Services\TitanRuntime\Engines\PromptTemplateEngine;
use App\Services\TitanRuntime\Registry\PromptTemplateRegistry;
use Illuminate\Http\Request;

class TitanRuntimeTemplateController extends Controller
{
    public function index(PromptTemplateRegistry $templates)
    {
        return response()->json([
            'templates' => $templates->all(),
        ]);
    }

    public function render(Request $request, PromptTemplateEngine $engine)
    {
        return response()->json(
            $engine->render(
                (string) $request->input('template'),
                (array) $request->input('input', [])
            )
        );
    }
}
