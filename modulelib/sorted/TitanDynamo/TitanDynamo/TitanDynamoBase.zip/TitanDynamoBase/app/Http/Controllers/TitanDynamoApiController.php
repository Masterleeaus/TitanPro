<?php

namespace App\Http\Controllers;

use App\Services\TitanRuntime\Execution\JobQueue;
use App\Services\TitanRuntime\Execution\PipelineExecutor;
use App\Services\TitanRuntime\Execution\ReceiptRepository;
use App\Services\TitanRuntime\Execution\RuleEngine;
use App\Services\TitanRuntime\Execution\TriggerEngine;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TitanDynamoApiController extends Controller
{
    public function __construct(
        protected TriggerEngine $triggers,
        protected RuleEngine $rules,
        protected PipelineExecutor $pipelines,
        protected JobQueue $queue,
        protected ReceiptRepository $receipts,
    ) {
    }

    public function dispatch(Request $request): JsonResponse
    {
        $job = $this->rules->prepare($request->all());
        $receipt = $this->queue->push($job);
        return response()->json($receipt);
    }

    public function status(string $id): JsonResponse
    {
        return response()->json($this->receipts->status($id));
    }

    public function receipt(string $id): JsonResponse
    {
        return response()->json($this->receipts->find($id));
    }
}
