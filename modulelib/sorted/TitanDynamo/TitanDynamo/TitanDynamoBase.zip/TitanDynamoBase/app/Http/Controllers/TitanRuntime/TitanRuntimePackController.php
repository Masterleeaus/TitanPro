<?php

namespace App\Http\Controllers\TitanRuntime;

use App\Http\Controllers\Controller;
use App\Services\TitanRuntime\Engines\PackLoaderEngine;
use App\Services\TitanRuntime\Presenters\PackPresenter;
use Illuminate\Http\JsonResponse;

class TitanRuntimePackController extends Controller
{
    public function index(PackLoaderEngine $packs): JsonResponse
    {
        return response()->json([
            'packs' => $packs->loaded(),
        ]);
    }

    public function schema(PackLoaderEngine $packs, PackPresenter $presenter): JsonResponse
    {
        return response()->json(
            $presenter->toSchema($packs->loaded())
        );
    }
}
