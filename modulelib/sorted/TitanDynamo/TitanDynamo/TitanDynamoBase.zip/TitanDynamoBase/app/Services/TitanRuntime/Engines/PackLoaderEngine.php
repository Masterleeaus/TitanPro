<?php

namespace App\Services\TitanRuntime\Engines;

use App\Services\TitanRuntime\Registry\PackRegistry;

class PackLoaderEngine
{
    public function __construct(protected PackRegistry $packs)
    {
    }

    public function loaded(): array
    {
        return array_map(function (array $pack) {
            return [
                'key' => $pack['key'],
                'label' => $pack['label'],
                'group' => $pack['group'],
                'type' => $pack['type'],
                'loaded' => true,
            ];
        }, $this->packs->all());
    }

    public function resolveMemoryContext(): array
    {
        return [
            'pack_memory' => [
                'summary' => 'AiChatPro memory packs available for prompt/context enrichment.',
                'packs' => array_map(fn ($pack) => $pack['label'], $this->packs->all()),
            ],
        ];
    }
}
