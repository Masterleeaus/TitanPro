<?php

namespace App\Services\TitanRuntime\Execution;

class JobQueue
{
    public function push(array $job): array
    {
        return [
            'ok' => true,
            'receipt_id' => uniqid('dyn_', true),
            'job' => $job,
            'status' => 'queued',
        ];
    }
}
