<?php

namespace App\Services\TitanRuntime\Execution;

class PipelineExecutor
{
    public function run(array $job): array
    {
        return ['ok' => true, 'job' => $job, 'status' => 'executed'];
    }
}
