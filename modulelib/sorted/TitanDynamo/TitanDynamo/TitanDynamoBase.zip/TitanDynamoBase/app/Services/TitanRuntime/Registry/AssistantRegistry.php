<?php

namespace App\Services\TitanRuntime\Registry;

class AssistantRegistry
{
    public function all(): array
    {
        return [
            ['key' => 'work-ai', 'label' => 'Work AI', 'capabilities' => ['jobs.lookup', 'tambo.form', 'a2ui.card', 'a2ui.form', 'template.service_quote']],
            ['key' => 'memory-ai', 'label' => 'Memory AI', 'capabilities' => ['packs.list', 'packs.memory', 'donor.inventory', 'donor.activate']],
            ['key' => 'signal-ai', 'label' => 'Signal AI', 'capabilities' => ['signals.inspect']],
            ['key' => 'social-ai', 'label' => 'Social AI', 'capabilities' => ['chatbot.lead_capture', 'chatbot.knowledge_lookup']],
        ];
    }

    public function match(array $plugin): array
    {
        foreach ($this->all() as $assistant) {
            if (in_array($plugin['key'] ?? '', $assistant['capabilities'])) {
                return $assistant;
            }
        }
        return $this->all()[0];
    }
}
