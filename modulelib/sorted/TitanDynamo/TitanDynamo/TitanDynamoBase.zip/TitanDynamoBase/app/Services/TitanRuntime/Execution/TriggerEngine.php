<?php

namespace App\Services\TitanRuntime\Execution;

class TriggerEngine
{
    public function detect(array $payload): array
    {
        return ['ok' => true, 'triggers' => $payload['triggers'] ?? []];
    }
}
