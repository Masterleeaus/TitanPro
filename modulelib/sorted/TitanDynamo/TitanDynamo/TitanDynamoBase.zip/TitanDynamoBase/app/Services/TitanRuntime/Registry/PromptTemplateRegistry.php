<?php

namespace App\Services\TitanRuntime\Registry;

class PromptTemplateRegistry
{
    public function all(): array
    {
        return [
            [
                'key' => 'service_quote',
                'name' => 'Service Quote',
                'module' => 'service-console',
                'tone' => 'professional',
                'prompt' => 'Generate a concise service quote with scope, exclusions, and next steps.',
                'fields' => ['customer_name', 'service_type', 'site_notes', 'price_range'],
            ],
            [
                'key' => 'job_summary',
                'name' => 'Job Summary',
                'module' => 'work-hub',
                'tone' => 'clear',
                'prompt' => 'Summarise the job, key risks, access instructions, and completion checklist.',
                'fields' => ['job_number', 'site_name', 'access_notes', 'risk_notes'],
            ],
            [
                'key' => 'payment_followup',
                'name' => 'Payment Follow-up',
                'module' => 'money-manager',
                'tone' => 'firm',
                'prompt' => 'Draft a payment follow-up that is direct, courteous, and references overdue balance.',
                'fields' => ['customer_name', 'invoice_number', 'balance_due', 'due_date'],
            ],
        ];
    }

    public function find(string $key): ?array
    {
        foreach ($this->all() as $template) {
            if (($template['key'] ?? null) === $key) {
                return $template;
            }
        }

        return null;
    }
}
