<?php

namespace App\Services\TitanRuntime\Execution;

class ReceiptRepository
{
    public function status(string $id): array
    {
        return ['ok' => true, 'receipt_id' => $id, 'status' => 'queued'];
    }

    public function find(string $id): array
    {
        return ['ok' => true, 'receipt_id' => $id, 'events' => []];
    }
}
