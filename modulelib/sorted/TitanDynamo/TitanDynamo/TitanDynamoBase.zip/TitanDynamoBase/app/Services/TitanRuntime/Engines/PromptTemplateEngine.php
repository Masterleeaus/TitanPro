<?php

namespace App\Services\TitanRuntime\Engines;

use App\Services\TitanRuntime\Registry\PromptTemplateRegistry;

class PromptTemplateEngine
{
    public function __construct(protected PromptTemplateRegistry $templates)
    {
    }

    public function render(string $key, array $input = []): array
    {
        $template = $this->templates->find($key);

        if (! $template) {
            return [
                'found' => false,
                'key' => $key,
                'content' => null,
            ];
        }

        $lines = [];
        $lines[] = $template['prompt'];

        foreach (($template['fields'] ?? []) as $field) {
            $label = ucwords(str_replace('_', ' ', $field));
            $value = $input[$field] ?? '[missing]';
            $lines[] = $label . ': ' . $value;
        }

        return [
            'found' => true,
            'key' => $key,
            'template' => $template,
            'content' => implode("\n", $lines),
        ];
    }
}
