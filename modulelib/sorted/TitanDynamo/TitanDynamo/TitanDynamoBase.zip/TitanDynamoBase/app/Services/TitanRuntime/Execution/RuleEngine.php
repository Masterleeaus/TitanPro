<?php

namespace App\Services\TitanRuntime\Execution;

class RuleEngine
{
    public function prepare(array $job): array
    {
        $job['prepared'] = true;
        return $job;
    }
}
