<?php

namespace App\Services\TitanRuntime\Registry;

class PackRegistry
{
    public function all(): array
    {
        return [
            [
                'key' => 'aichatpro.filechat',
                'label' => 'AiChatPro FileChat',
                'group' => 'aichatpro',
                'type' => 'provider',
                'source' => 'External/AiChatPro/FileChat',
            ],
            [
                'key' => 'aichatpro.folders',
                'label' => 'AiChatPro Folders',
                'group' => 'aichatpro',
                'type' => 'provider',
                'source' => 'External/AiChatPro/Folders',
            ],
            [
                'key' => 'aichatpro.memory',
                'label' => 'AiChatPro Memory',
                'group' => 'aichatpro',
                'type' => 'memory',
                'source' => 'External/AiChatPro/Memory',
            ],
        ];
    }

    public function find(string $key): ?array
    {
        foreach ($this->all() as $pack) {
            if (($pack['key'] ?? null) === $key) {
                return $pack;
            }
        }
        return null;
    }
}
