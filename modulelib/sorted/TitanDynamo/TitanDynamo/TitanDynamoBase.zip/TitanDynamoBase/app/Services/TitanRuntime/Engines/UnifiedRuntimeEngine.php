<?php
namespace App\Services\TitanRuntime\Engines;

class UnifiedRuntimeEngine
{
    public function __construct(
        protected PluginDispatchEngine $dispatch,
        protected MemoryEngine $memory,
        protected DonorIntegrationEngine $donor,
        protected DonorFinalAbsorptionEngine $absorb,
    ) {}

    public function boot(): array
    {
        return [
            'memory'=>$this->memory->buildContext(),
            'donor'=>$this->donor->scan(),
            'absorption'=>$this->absorb->absorb(),
        ];
    }

    public function run(string $prompt): array
    {
        return $this->dispatch->execute($prompt);
    }
}
