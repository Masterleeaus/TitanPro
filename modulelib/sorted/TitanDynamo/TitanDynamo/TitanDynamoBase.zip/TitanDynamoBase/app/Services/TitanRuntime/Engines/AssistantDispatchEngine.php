<?php

namespace App\Services\TitanRuntime\Engines;

use App\Services\TitanRuntime\Registry\AssistantRegistry;

class AssistantDispatchEngine
{
    public function __construct(
        protected AssistantRegistry $assistants
    ) {}

    public function assign(array $plugin): array
    {
        return $this->assistants->match($plugin);
    }
}
