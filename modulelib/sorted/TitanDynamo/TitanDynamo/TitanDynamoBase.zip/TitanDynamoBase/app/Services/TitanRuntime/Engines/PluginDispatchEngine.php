<?php
namespace App\Services\TitanRuntime\Engines;

use App\Services\TitanRuntime\Registry\PluginRegistry;

class PluginDispatchEngine
{
    public function __construct(
        protected PluginRegistry $plugins,
        protected DonorFinalAbsorptionEngine $absorb
    ) {}

    public function resolve(string $prompt): array
    {
        $p = strtolower($prompt);
        if (str_contains($p,'absorb')) return $this->plugins->find('donor.absorb');
        if (str_contains($p,'activate')) return $this->plugins->find('donor.activate');
        if (str_contains($p,'donor')) return $this->plugins->find('donor.inventory');
        return $this->plugins->find('jobs.lookup');
    }

    public function execute(string $prompt): array
    {
        $plugin = $this->resolve($prompt);

        if (($plugin['key']??'')==='donor.absorb') {
            $res = $this->absorb->absorb();
            return ['plugin'=>$plugin,'result'=>[
                'kind'=>'card',
                'title'=>'Donor Absorption Complete',
                'body'=>$res['message']
            ]];
        }

        return ['plugin'=>$plugin,'result'=>[
            'kind'=>'text',
            'body'=>'Handled: '.$prompt
        ]];
    }
}
