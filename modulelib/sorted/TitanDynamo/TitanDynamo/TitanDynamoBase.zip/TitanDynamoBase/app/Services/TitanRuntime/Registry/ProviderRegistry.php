<?php

namespace App\Services\TitanRuntime\Registry;

class ProviderRegistry
{
    public function all(): array
    {
        return [
            [
                'key' => 'titanzero-dashboard',
                'label' => 'Titan Zero Dashboard',
                'type' => 'surface',
                'runtime' => 'native',
            ],
            [
                'key' => 'external-chatbot',
                'label' => 'External Chatbot',
                'type' => 'provider',
                'runtime' => 'shared',
                'extension' => 'Chatbot',
            ],
            [
                'key' => 'voice-chatbot',
                'label' => 'Voice Chatbot',
                'type' => 'provider',
                'runtime' => 'shared',
                'extension' => 'ChatbotVoice',
            ],
        ];
    }
}
