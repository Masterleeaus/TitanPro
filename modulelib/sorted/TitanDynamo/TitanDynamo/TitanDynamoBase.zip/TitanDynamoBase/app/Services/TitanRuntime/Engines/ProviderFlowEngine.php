<?php

namespace App\Services\TitanRuntime\Engines;

use App\Services\TitanRuntime\Registry\ProviderRegistry;

class ProviderFlowEngine
{
    public function __construct(protected ProviderRegistry $providers)
    {
    }

    public function resolve(string $providerKey = 'titanzero-dashboard'): array
    {
        foreach ($this->providers->all() as $provider) {
            if (($provider['key'] ?? null) === $providerKey) {
                return $provider;
            }
        }

        return $this->providers->all()[0];
    }

    public function payload(string $providerKey = 'titanzero-dashboard'): array
    {
        $provider = $this->resolve($providerKey);

        return [
            'provider' => $provider,
            'runtime' => 'shared',
            'channel' => $provider['type'] ?? 'surface',
        ];
    }
}
