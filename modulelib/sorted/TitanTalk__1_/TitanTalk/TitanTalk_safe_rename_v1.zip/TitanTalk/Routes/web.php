<?php
use Illuminate\Support\Facades\Route;
use Modules\TitanTalk\Http\Controllers\AIConverseController;

// Optional plan gate middleware if your app has it; otherwise adjust as needed.
Route::middleware(['web'])
    ->prefix('aiconverse')
    ->group(function () {
        Route::get('/', [AIConverseController::class, 'index'])->name('titantalk.index');
        Route::get('/ping', fn() => 'AIConverse OK')->name('titantalk.ping');
    });
