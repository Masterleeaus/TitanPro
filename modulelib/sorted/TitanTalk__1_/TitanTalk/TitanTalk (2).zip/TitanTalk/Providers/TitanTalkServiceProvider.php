<?php

namespace Modules\TitanTalk\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;

class TitanTalkServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titantalk');

        Route::middleware(['web','auth'])
            ->prefix('account/titan/talk')
            ->name('titan.talk.')
            ->group(__DIR__ . '/../routes/account.php');
    }
}
