<?php

namespace Modules\TitanTalk\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Routing\Router;
use Modules\TitanTalk\Http\Middleware\InjectTitanTalkMenu;
use Modules\TitanTalk\Http\Middleware\EnsureTenantContext;
use Modules\TitanTalk\Http\Middleware\EnforceTitanTalkPermissions;

class TitanTalkServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        // NOTE:
        // - Routes are registered by Modules\TitanTalk\Providers\RouteServiceProvider
        // - Views are registered by Modules\TitanTalk\Providers\ViewServiceProvider
        // This provider is responsible for module-level runtime wiring that WorkSuite
        // does not do automatically (e.g. safe sidebar injection without core edits).

        /** @var Router $router */
        $router = $this->app['router'];

        // Register + apply the menu injector middleware so the module shows in the
        // WorkSuite sidebar without modifying core views.
        $router->aliasMiddleware('titantalk.menu', InjectTitanTalkMenu::class);
        $router->pushMiddlewareToGroup('web', InjectTitanTalkMenu::class);

        // Useful aliases for routes inside this module.
        $router->aliasMiddleware('titantalk.tenant', EnsureTenantContext::class);
        $router->aliasMiddleware('titantalk.perm', EnforceTitanTalkPermissions::class);
    }
}
