<?php
use Illuminate\Support\Facades\Route;

// Inbound webhooks (no auth; protect with secrets at your edge if desired)
Route::post('/titantalk/hook/{channel}', 'WebhookController@receive');

// Optional: Web test endpoint (auth)
Route::middleware(['auth'])->get('/titantalk/widget', function(){ return view('titantalk::partials.widget'); })->name('titantalk.widget');
