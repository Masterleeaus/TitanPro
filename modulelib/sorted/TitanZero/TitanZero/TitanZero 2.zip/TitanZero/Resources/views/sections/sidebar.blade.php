@php
// Worksuite Sidebar Injection for Titan Zero
// This file is included by Worksuite's sidebar renderer when module view exists.
@endphp

<li class="nav-item">
  <a class="nav-link" href="{{ url('account/titan/zero') }}">
    <i class="ti ti-sparkles"></i>
    <span>Titan Zero</span>
  </a>
</li>

<li class="nav-item">
  <a class="nav-link" href="{{ url('account/titan/zero/coaches') }}">
    <i class="ti ti-users"></i>
    <span>Coaches</span>
  </a>
</li>

<li class="nav-item">
  <a class="nav-link" href="{{ url('account/titan/zero/coaches/business') }}">
    <i class="ti ti-briefcase"></i>
    <span>Business Coach</span>
  </a>
</li>

<li class="nav-item">
  <a class="nav-link" href="{{ url('account/titan/zero/coaches/foreman') }}">
    <i class="ti ti-helmet"></i>
    <span>Foreman Coach</span>
  </a>
</li>

<li class="nav-item">
  <a class="nav-link" href="{{ url('account/titan/zero/coaches/compliance') }}">
    <i class="ti ti-shield-check"></i>
    <span>Standards & Compliance</span>
  </a>
</li>
