{{-- Legacy include (some builds may include this) --}}
@includeIf('titanzero::sections.hr.sidebar')
