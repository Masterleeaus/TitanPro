{{-- Titan Zero sidebar (Worksuite X-menu component style) --}}

<x-menu-item icon="sparkles" :text="'Titan Zero'">
    <x-slot name="iconPath">
        {{-- Minimal spark icon paths (Worksuite expects <path> elements in iconPath slot) --}}
        <path d="M12 2l1.2 4.2L17.4 8l-4.2 1.2L12 13.4l-1.2-4.2L6.6 8l4.2-1.8L12 2z"/>
        <path d="M5 12l.8 2.6L8.4 16l-2.6.8L5 19.4l-.8-2.6L1.6 16l2.6-1.4L5 12z"/>
        <path d="M18.5 12.5l.6 1.9 1.9.6-1.9.6-.6 1.9-.6-1.9-1.9-.6 1.9-.6.6-1.9z"/>
    </x-slot>

    {{-- IMPORTANT: Worksuite collapsible menus expect this wrapper for spacing + toggle --}}
    <div class="accordionItemContent ">
        <x-sub-menu-item :link="url('account/titan/zero')" :text="'Open Titan Zero'" />
        <x-sub-menu-item :link="url('account/titan/zero/coaches')" :text="'Coaches'" />
        <x-sub-menu-item :link="url('account/titan/zero/coaches/business')" :text="'Business Coach'" />
        <x-sub-menu-item :link="url('account/titan/zero/coaches/foreman')" :text="'Foreman Coach'" />
        <x-sub-menu-item :link="url('account/titan/zero/coaches/compliance')" :text="'Standards & Compliance'" />
    </div>
</x-menu-item>
