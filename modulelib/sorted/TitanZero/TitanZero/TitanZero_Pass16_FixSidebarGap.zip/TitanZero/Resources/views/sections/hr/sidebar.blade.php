{{-- Titan Zero sidebar (Worksuite X-menu component style) --}}

<x-menu-item icon="sparkles" :text="'Titan Zero'">
    {{-- IMPORTANT: do not wrap submenu in custom divs; Worksuite component handles collapse/spacing --}}
    <x-sub-menu-item :link="url('account/titan/zero')" :text="'Open Titan Zero'" />
    <x-sub-menu-item :link="url('account/titan/zero/coaches')" :text="'Coaches'" />
    <x-sub-menu-item :link="url('account/titan/zero/coaches/business')" :text="'Business Coach'" />
    <x-sub-menu-item :link="url('account/titan/zero/coaches/foreman')" :text="'Foreman Coach'" />
    <x-sub-menu-item :link="url('account/titan/zero/coaches/compliance')" :text="'Standards & Compliance'" />
</x-menu-item>
