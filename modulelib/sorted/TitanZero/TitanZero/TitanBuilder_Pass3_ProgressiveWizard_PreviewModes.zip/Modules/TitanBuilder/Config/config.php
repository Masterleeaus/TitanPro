<?php
return [
    'name' => 'TitanBuilder',
    'builder_steps' => ['identity', 'appearance', 'knowledge', 'runtime', 'surface', 'deployment', 'preview'],
    'legacy_builder_steps' => ['configure', 'customize', 'train', 'embed', 'channel'],
    'preview_modes' => [
        'widget' => ['label' => 'Widget'],
        'portal' => ['label' => 'Portal'],
        'pwa' => ['label' => 'PWA'],
        'command' => ['label' => 'Command'],
    ],
    'presets' => [
        'assistant' => ['label' => 'Assistant', 'icon' => 'assistant'],
        'external_chatbot' => ['label' => 'External Chatbot', 'icon' => 'chat'],
        'titan_go' => ['label' => 'Titan Go', 'icon' => 'mobile'],
        'titan_command' => ['label' => 'Titan Command', 'icon' => 'command'],
        'portal' => ['label' => 'Portal', 'icon' => 'globe'],
        'widget' => ['label' => 'Widget', 'icon' => 'widget'],
    ],
    'default_embed_width' => 420,
    'default_embed_height' => 745,
    'integrated_plugins' => [
        'agent' => true,
        'messenger' => true,
        'telegram' => true,
        'voice' => true,
        'whatsapp' => true,
    ],
];
