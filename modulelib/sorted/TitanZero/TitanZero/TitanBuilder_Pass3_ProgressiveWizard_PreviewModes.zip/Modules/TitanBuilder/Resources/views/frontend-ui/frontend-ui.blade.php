{{-- This is the frontend ui --}}

@if ($is_editor)
    @include('titanbuilder::frontend-ui.frontend-ui-editor')
@else
    @include('titanbuilder::frontend-ui.frontend-ui-frontpage')
@endif
