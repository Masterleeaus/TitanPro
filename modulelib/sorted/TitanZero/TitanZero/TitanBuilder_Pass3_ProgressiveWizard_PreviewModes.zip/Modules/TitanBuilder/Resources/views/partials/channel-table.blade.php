<div class="mt-8 rounded-2xl border border-heading-foreground/10 bg-background/70 p-5">
    <div class="mb-4 flex items-center justify-between gap-3">
        <div>
            <h3 class="text-sm font-semibold text-heading-foreground">@lang('Integrated plugin matrix')</h3>
            <p class="text-xs text-heading-foreground/50">@lang('Pass 1 folds the channel/assistant plugins into the module so they can be cleaned and refactored in-place before final Worksuite integration.')</p>
        </div>
    </div>

    <div class="overflow-x-auto">
        <table class="min-w-full text-left text-xs">
            <thead>
                <tr class="border-b border-heading-foreground/10 text-heading-foreground/60">
                    <th class="py-2 pe-4">@lang('Plugin')</th>
                    <th class="py-2 pe-4">@lang('Type')</th>
                    <th class="py-2 pe-4">@lang('Status')</th>
                    <th class="py-2">@lang('Notes')</th>
                </tr>
            </thead>
            <tbody>
                @foreach(($integratedPlugins ?? []) as $plugin)
                    <tr class="border-b border-heading-foreground/5 align-top">
                        <td class="py-3 pe-4 font-medium">{{ $plugin['label'] }}</td>
                        <td class="py-3 pe-4 uppercase">{{ $plugin['type'] }}</td>
                        <td class="py-3 pe-4">{{ ucfirst($plugin['status']) }}</td>
                        <td class="py-3 text-heading-foreground/60">{{ $plugin['description'] }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
