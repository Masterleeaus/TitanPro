@extends('layouts.app')
@section('content')
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">Titan Builder</h2>
            <p class="text-muted mb-0">Build assistants, external chatbots, widgets, PWAs, portals and command surfaces from one authoring workspace. Draft persistence and preview modes are now part of the core builder.</p>
        </div>
        <a class="btn btn-primary" href="{{ route('titan.builder.builder', 'assistant') }}">Open Titan Builder</a>
    </div>

    <div class="row g-3 mb-4">
        @foreach($presets as $key => $preset)
            <div class="col-md-4 col-xl-3">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <div class="text-uppercase text-muted small mb-2">Preset</div>
                        <h5 class="card-title">{{ $preset['label'] }}</h5>
                        <p class="card-text text-muted">Key: {{ $key }}</p>
                        <a class="btn btn-outline-primary" href="{{ route('titan.builder.builder', $key) }}">Build {{ $preset['label'] }}</a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>

    <div class="card shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
            <strong>Assistant Registry</strong>
            <span class="badge bg-secondary">{{ $assistants->count() }} loaded</span>
        </div>
        <div class="table-responsive">
            <table class="table mb-0 align-middle">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Preset</th>
                        <th>Status</th>
                        <th>Updated</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                @forelse($assistants as $assistant)
                    <tr>
                        <td>{{ $assistant->title }}</td>
                        <td><span class="badge bg-light text-dark">{{ $assistant->preset_key }}</span></td>
                        <td><span class="badge bg-primary">{{ $assistant->status }}</span></td>
                        <td>{{ optional($assistant->updated_at)->diffForHumans() }}</td>
                        <td class="text-end">
                            <a class="btn btn-sm btn-outline-primary" href="{{ route('titan.builder.builder', ['preset' => $assistant->preset_key, 'assistant' => $assistant->id]) }}">Edit</a>
                            <a class="btn btn-sm btn-outline-secondary" href="{{ route('titan.builder.preview', ['preset' => $assistant->preset_key, 'assistant' => $assistant->id]) }}">Preview</a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">No assistants saved yet. Use the builder to create your first assistant.</td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
