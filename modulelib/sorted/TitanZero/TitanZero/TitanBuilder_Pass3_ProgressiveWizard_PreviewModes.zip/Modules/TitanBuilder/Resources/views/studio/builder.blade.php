@extends('layouts.app')
@section('content')
<div class="container-fluid py-3">
    <div class="row g-3">
        <div class="col-lg-8">
            <div class="card shadow-sm mb-3 border-0">
                <div class="card-body d-flex flex-wrap align-items-center justify-content-between gap-3">
                    <div>
                        <div class="text-uppercase text-muted small">Titan Builder</div>
                        <h4 class="mb-1">{{ $assistant?->title ?: ($presets[$preset]['label'] ?? 'Assistant') }}</h4>
                        <div class="small text-muted">Progressive draft save, resume support, and live surface preview are now enabled.</div>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-outline-secondary" id="tb-save-draft">Save Draft</button>
                        <a class="btn btn-primary" href="{{ route('titan.builder.preview', ['preset' => $preset, 'assistant' => $assistant?->id]) }}">Open Full Preview</a>
                    </div>
                </div>
            </div>
            @include('titanbuilder::home.edit-window.edit-window')
        </div>
        <div class="col-lg-4">
            <div class="card shadow-sm sticky-top" style="top: 1rem;">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <strong>Live Preview</strong>
                        <div class="small text-muted">Widget, portal, PWA and command surfaces</div>
                    </div>
                    <select class="form-select form-select-sm w-auto" id="tb-preview-mode">
                        @foreach($previewModes as $modeKey => $mode)
                            <option value="{{ $modeKey }}" @selected(($previewState['preview_mode'] ?? 'widget') === $modeKey)>{{ $mode['label'] }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="card-body" style="min-height: 760px; background: #f6f7fb;">
                    @include('titanbuilder::home.frontend-ui-preview', ['assistant' => $assistant ?? null, 'previewState' => $previewState])
                </div>
            </div>
        </div>
    </div>
</div>
@push('script')
<script>
window.titanBuilderDraft = {
    assistantId: {{ $assistant?->id ?: 'null' }},
    presetKey: @json($preset),
    saveUrl: @json(route('titan.builder.save-draft')),
    previewUrl: @json(route('titan.builder.preview-state')),
    previewMode: @json($previewState['preview_mode'] ?? 'widget'),
    csrf: @json(csrf_token()),
};
</script>
@endpush
@endsection
