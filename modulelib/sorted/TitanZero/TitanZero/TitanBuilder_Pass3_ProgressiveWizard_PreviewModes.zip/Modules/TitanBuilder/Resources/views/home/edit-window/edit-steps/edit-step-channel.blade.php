{{-- Editing Step 5 - Channel --}}
<div
    class="col-start-1 col-end-1 row-start-1 row-end-1 transition-all"
    data-step="5"
    x-data="externalChatbotChannel"
    x-show="editingStep === 5"
    x-transition:enter-start="opacity-0 -translate-x-3"
    x-transition:enter-end="opacity-100 translate-x-0"
    x-transition:leave-start="opacity-100 translate-x-0"
    x-transition:leave-end="opacity-0 translate-x-3"
>
    <h2 class="mb-3.5">@lang('Channel Plugins')</h2>
    <p class="mb-3 text-xs/5 opacity-60 lg:max-w-[360px]">
        @lang('These plugins are now integrated directly into the module so the builder can configure them without depending on separate external extensions.')
    </p>

    @include('titanbuilder::home.channel-plugins.channel-grid', ['integratedPlugins' => $integratedPlugins ?? []])
    @include('titanbuilder::partials.channel-table', ['integratedPlugins' => $integratedPlugins ?? []])
</div>

@push('script')
<script>
(() => {
    document.addEventListener('alpine:init', () => {
        Alpine.data('externalChatbotChannel', () => ({
            activeTab: 'channel',
            fetching: false,
            storeChannelFetch: false,
            channelFetch: false,
            chatbotChannels: [],
            init() {
                this.chatbotChannels = (this.integratedPlugins || []).map(plugin => ({
                    id: plugin.key,
                    channel: plugin.label,
                    status: plugin.status,
                    type: plugin.type,
                }));
            },
            integratedPlugins: @js($integratedPlugins ?? []),
            copyToClipboard(text) {
                navigator.clipboard.writeText(text).then(() => toastr.success('Copied'));
            },
        }));
    });
})();
</script>
@endpush
