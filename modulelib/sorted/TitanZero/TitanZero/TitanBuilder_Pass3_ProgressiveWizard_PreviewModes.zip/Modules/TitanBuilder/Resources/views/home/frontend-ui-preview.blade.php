{{-- This is the frontend ui but with some changes for the editor --}}
@php($mode = $previewState['preview_mode'] ?? 'widget')
<div class="mb-3 d-flex align-items-center justify-content-between text-xs text-slate-500">
    <span>Preview mode: <strong class="text-slate-700 text-uppercase">{{ $mode }}</strong></span>
    @if(!empty($assistant))<span>Assistant #{{ $assistant->id }} · {{ $assistant->title }}</span>@endif
</div>

@push('css')
<style>
    .lqd-chatbot-preview .lqd-ext-chatbot-window { width: var(--lqd-ext-chat-window-w); height: var(--lqd-ext-chat-window-h); }
    .tb-preview-shell{border-radius:28px;padding:14px;background:linear-gradient(180deg,#eef2ff 0%,#f8fafc 100%);}
    .tb-preview-shell[data-mode="pwa"], .tb-preview-shell[data-mode="command"]{background:linear-gradient(180deg,#111827 0%,#1f2937 100%);}
    .tb-preview-toolbar{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap}
    .tb-chip{font-size:11px;padding:4px 10px;border-radius:999px;background:#fff;border:1px solid rgba(15,23,42,.08);color:#475569}
    .tb-preview-shell[data-mode="pwa"] .tb-chip,.tb-preview-shell[data-mode="command"] .tb-chip{background:rgba(255,255,255,.08);color:#e2e8f0;border-color:rgba(255,255,255,.08)}
</style>
@endpush

<div class="lqd-chatbot-preview sticky bottom-8 tb-preview-shell" data-mode="{{ $mode }}">
    <div class="tb-preview-toolbar">
        <span class="tb-chip">{{ $previewState['surface_label'] ?? 'Assistant Surface' }}</span>
        <span class="tb-chip">{{ ucfirst($mode) }} simulation</span>
        <span class="tb-chip">Draft save enabled</span>
    </div>
    @include('titanbuilder::frontend-ui.frontend-ui', [
        'is_editor' => true,
        'is_iframe' => false,
        'previewState' => $previewState ?? [],
    ])
</div>
