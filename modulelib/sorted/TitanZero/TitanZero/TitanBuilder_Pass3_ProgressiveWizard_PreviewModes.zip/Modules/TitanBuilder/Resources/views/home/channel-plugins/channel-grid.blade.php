<div class="mt-10 lqd-social-media-cards-grid gap-3 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3">
    @forelse(($integratedPlugins ?? []) as $plugin)
        @include($plugin['view'], ['plugin' => $plugin])
    @empty
        <div class="rounded-2xl border border-dashed p-6 text-sm text-heading-foreground/60">
            @lang('No integrated plugins detected yet.')
        </div>
    @endforelse
</div>
