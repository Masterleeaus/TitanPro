<div class="rounded-sm lqd-social-media-card flex flex-col border p-5 text-heading-foreground transition-all hover:scale-[1.02] hover:border-heading-foreground/10 hover:shadow-lg hover:shadow-black/5">
    <div class="mb-4 flex items-center justify-between gap-3">
        <div class="flex items-center gap-3">
            @if(!empty($plugin['icon']))
                <img class="h-8 w-8" src="{{ asset($plugin['icon']) }}" alt="{{ $plugin['label'] }}" />
            @else
                <div class="flex h-8 w-8 items-center justify-center rounded-full bg-heading-foreground/10 text-[10px] font-bold uppercase">
                    {{ strtoupper(substr($plugin['key'], 0, 2)) }}
                </div>
            @endif
            <div>
                <h4 class="text-base font-semibold text-inherit">{{ $plugin['label'] }}</h4>
                <p class="text-xs text-heading-foreground/60">{{ $plugin['description'] }}</p>
            </div>
        </div>
        <span class="rounded-full bg-emerald-500/10 px-2 py-1 text-[10px] font-semibold uppercase text-emerald-600">{{ $plugin['status'] }}</span>
    </div>

    @if(!empty($plugin['credentials']))
        <div class="grid gap-2">
            @foreach($plugin['credentials'] as $field)
                <div class="rounded-lg bg-heading-foreground/5 px-3 py-2 text-xs">
                    <div class="font-medium text-heading-foreground">{{ $field['label'] }}</div>
                    <div class="text-heading-foreground/50">{{ $field['name'] }}</div>
                </div>
            @endforeach
        </div>
    @endif

    <div class="mt-4 flex items-center justify-between text-xs text-heading-foreground/50">
        <span>{{ strtoupper($plugin['type']) }}</span>
        <span>v{{ $plugin['version'] }}</span>
    </div>
</div>
