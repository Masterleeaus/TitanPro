<?php
namespace Modules\TitanBuilder\Services;

class EmbedCodeService
{
    public function render(string $uuid, int $width = 420, int $height = 745): string
    {
        return '<script defer src="/modules/titanbuilder/js/external-chatbot.js" data-chatbot-uuid="' . e($uuid) . '" data-iframe-width="' . $width . '" data-iframe-height="' . $height . '"></script>';
    }
}
