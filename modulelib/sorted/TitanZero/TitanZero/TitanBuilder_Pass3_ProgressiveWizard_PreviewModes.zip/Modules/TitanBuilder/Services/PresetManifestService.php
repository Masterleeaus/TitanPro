<?php
namespace Modules\TitanBuilder\Services;

class PresetManifestService
{
    public function all(): array
    {
        return config('titanbuilder.presets', []);
    }
}
