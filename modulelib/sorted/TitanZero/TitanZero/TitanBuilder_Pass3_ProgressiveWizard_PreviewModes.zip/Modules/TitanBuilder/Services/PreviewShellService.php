<?php
namespace Modules\TitanBuilder\Services;

class PreviewShellService
{
    public function defaults(): array
    {
        return [
            'position' => 'right',
            'avatar' => 'avatar-1.png',
            'trigger_avatar_size' => 64,
        ];
    }
}
