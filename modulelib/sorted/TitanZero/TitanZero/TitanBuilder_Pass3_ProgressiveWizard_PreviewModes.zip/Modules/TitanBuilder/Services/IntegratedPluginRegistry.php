<?php
namespace Modules\TitanBuilder\Services;

use Illuminate\Support\Arr;
use Illuminate\Support\Facades\File;

class IntegratedPluginRegistry
{
    public function all(): array
    {
        $plugins = [];
        $base = module_path('TitanBuilder', 'Support/IntegratedPlugins');

        foreach (['ChatbotAgent', 'ChatbotMessenger', 'ChatbotTelegram', 'ChatbotVoice', 'ChatbotWhatsapp'] as $folder) {
            $path = $base . DIRECTORY_SEPARATOR . $folder;
            if (!File::isDirectory($path)) {
                continue;
            }

            $manifest = [];
            $manifestPath = $path . DIRECTORY_SEPARATOR . 'extension.json';
            if (File::exists($manifestPath)) {
                $manifest = json_decode(File::get($manifestPath), true) ?: [];
            }

            $key = strtolower(str_replace('Chatbot', '', $folder));
            $plugins[] = [
                'key' => $key ?: strtolower($folder),
                'folder' => $folder,
                'label' => Arr::get($manifest, 'name', $folder),
                'description' => Arr::get($manifest, 'description', ''),
                'version' => Arr::get($manifest, 'version', '0.0.0'),
                'type' => $this->typeFor($folder),
                'icon' => $this->iconFor($folder),
                'view' => $this->viewFor($folder),
                'credentials' => $this->credentialsFor($folder),
                'status' => 'integrated',
            ];
        }

        return $plugins;
    }

    protected function typeFor(string $folder): string
    {
        return match ($folder) {
            'ChatbotVoice' => 'voice',
            'ChatbotAgent' => 'assistant',
            default => 'channel',
        };
    }

    protected function iconFor(string $folder): ?string
    {
        return match ($folder) {
            'ChatbotMessenger' => 'modules/titanbuilder/integrated-plugins/ChatbotMessenger/icons/facebook-messenger.svg',
            'ChatbotTelegram' => 'modules/titanbuilder/integrated-plugins/ChatbotTelegram/icons/telegram.svg',
            'ChatbotWhatsapp' => 'modules/titanbuilder/integrated-plugins/ChatbotWhatsapp/icons/whatsapp.svg',
            'ChatbotVoice' => null,
            'ChatbotAgent' => null,
            default => null,
        };
    }

    protected function viewFor(string $folder): string
    {
        return 'titanbuilder::home.channel-plugins.plugin-card';
    }

    protected function credentialsFor(string $folder): array
    {
        return match ($folder) {
            'ChatbotMessenger' => [
                ['name' => 'app_id', 'label' => 'App ID'],
                ['name' => 'app_secret', 'label' => 'App Secret'],
                ['name' => 'page_name', 'label' => 'Page Name'],
                ['name' => 'access_token', 'label' => 'Access Token'],
                ['name' => 'verify_token', 'label' => 'Verify Token'],
            ],
            'ChatbotTelegram' => [
                ['name' => 'telegram_bot_name', 'label' => 'Telegram Bot Name'],
                ['name' => 'telegram_token', 'label' => 'Telegram Token'],
            ],
            'ChatbotWhatsapp' => [
                ['name' => 'whatsapp_sid', 'label' => 'WhatsApp SID'],
                ['name' => 'whatsapp_token', 'label' => 'WhatsApp Token'],
                ['name' => 'whatsapp_phone', 'label' => 'WhatsApp Phone'],
                ['name' => 'whatsapp_sandbox_phone', 'label' => 'Sandbox Phone'],
                ['name' => 'whatsapp_environment', 'label' => 'Environment'],
            ],
            'ChatbotVoice' => [
                ['name' => 'voice_mode', 'label' => 'Voice Mode'],
                ['name' => 'device_capabilities', 'label' => 'Device Capabilities'],
            ],
            'ChatbotAgent' => [
                ['name' => 'panel_mount', 'label' => 'Panel Mount'],
                ['name' => 'assistant_scope', 'label' => 'Assistant Scope'],
            ],
            default => [],
        };
    }
}
