<?php
namespace Modules\TitanBuilder\Services;

use Illuminate\Support\Arr;
use Modules\TitanBuilder\Entities\Assistant;
use Modules\TitanBuilder\Entities\AssistantChannel;
use Modules\TitanBuilder\Entities\AssistantEmbed;
use Modules\TitanBuilder\Entities\AssistantSource;
use Modules\TitanBuilder\Entities\AssistantStyle;

class BuilderStateService
{
    public function persist(array $payload, ?Assistant $assistant = null): Assistant
    {
        $assistant ??= new Assistant();

        $identity = Arr::get($payload, 'identity', []);
        $appearance = Arr::get($payload, 'appearance', []);
        $knowledge = Arr::get($payload, 'knowledge', []);
        $runtime = Arr::get($payload, 'runtime', []);
        $surface = Arr::get($payload, 'surface', []);
        $deployment = Arr::get($payload, 'deployment', []);
        $preview = Arr::get($payload, 'preview', []);

        $assistant->fill([
            'title' => Arr::get($identity, 'title', $assistant->title ?: 'Untitled Assistant'),
            'preset_key' => Arr::get($payload, 'preset_key', $assistant->preset_key ?: 'assistant'),
            'status' => Arr::get($payload, 'status', $assistant->status ?: 'draft'),
            'identity_json' => $identity,
            'runtime_json' => $runtime,
            'wizard_state_json' => [
                'current_step' => (int) Arr::get($payload, 'current_step', $assistant->draft_step ?: 1),
                'completed_steps' => array_values(array_unique(array_filter((array) Arr::get($payload, 'completed_steps', [])))),
                'last_step_key' => Arr::get($payload, 'last_step_key'),
            ],
            'preview_state_json' => $preview,
            'deployment_json' => $deployment,
            'draft_step' => (int) Arr::get($payload, 'current_step', $assistant->draft_step ?: 1),
            'last_saved_at' => now(),
        ]);
        $assistant->save();

        AssistantStyle::query()->updateOrCreate(
            ['assistant_id' => $assistant->id],
            [
                'company_id' => $assistant->company_id,
                'avatar_path' => Arr::get($appearance, 'avatar_path'),
                'logo_path' => Arr::get($appearance, 'logo_path'),
                'color_primary' => Arr::get($appearance, 'color_primary'),
                'color_secondary' => Arr::get($appearance, 'color_secondary'),
                'gradient_css' => Arr::get($appearance, 'gradient_css'),
                'layout_variant' => Arr::get($appearance, 'layout_variant'),
                'bubble_style' => Arr::get($appearance, 'bubble_style'),
                'typography_json' => Arr::get($appearance, 'typography', []),
                'style_json' => $appearance,
            ]
        );

        foreach ((array) Arr::get($knowledge, 'sources', []) as $index => $source) {
            AssistantSource::query()->updateOrCreate(
                ['assistant_id' => $assistant->id, 'source_type' => Arr::get($source, 'source_type', 'text'), 'title' => Arr::get($source, 'title', 'Source '.($index+1))],
                [
                    'company_id' => $assistant->company_id,
                    'source_ref' => Arr::get($source, 'source_ref'),
                    'content_text' => Arr::get($source, 'content_text'),
                    'meta_json' => $source,
                    'status' => Arr::get($source, 'status', 'draft'),
                ]
            );
        }

        foreach ((array) Arr::get($deployment, 'channels', []) as $channel) {
            AssistantChannel::query()->updateOrCreate(
                ['assistant_id' => $assistant->id, 'channel_key' => Arr::get($channel, 'channel_key')],
                [
                    'company_id' => $assistant->company_id,
                    'channel_label' => Arr::get($channel, 'channel_label'),
                    'status' => Arr::get($channel, 'status', 'draft'),
                    'config_json' => $channel,
                    'eligibility_json' => Arr::get($channel, 'eligibility'),
                ]
            );
        }

        if ($surface) {
            AssistantEmbed::query()->updateOrCreate(
                ['assistant_id' => $assistant->id, 'embed_type' => Arr::get($surface, 'embed_type', 'widget')],
                [
                    'company_id' => $assistant->company_id,
                    'embed_key' => Arr::get($surface, 'embed_key'),
                    'mount_target' => Arr::get($surface, 'mount_target'),
                    'width' => Arr::get($surface, 'width'),
                    'height' => Arr::get($surface, 'height'),
                    'config_json' => $surface,
                ]
            );
        }

        return $assistant->fresh();
    }
}
