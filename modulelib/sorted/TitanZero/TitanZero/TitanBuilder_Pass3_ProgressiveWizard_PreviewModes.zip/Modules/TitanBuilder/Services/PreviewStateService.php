<?php
namespace Modules\TitanBuilder\Services;

use Illuminate\Support\Arr;
use Modules\TitanBuilder\Entities\Assistant;

class PreviewStateService
{
    public function for(?Assistant $assistant = null, array $overrides = []): array
    {
        $identity = (array) ($assistant?->identity_json ?? []);
        $runtime = (array) ($assistant?->runtime_json ?? []);
        $preview = (array) ($assistant?->preview_state_json ?? []);
        $deployment = (array) ($assistant?->deployment_json ?? []);

        $state = array_replace_recursive([
            'title' => Arr::get($identity, 'title', $assistant?->title ?: 'Titan Assistant'),
            'bubble_message' => Arr::get($identity, 'bubble_message', 'Ask me anything'),
            'welcome_message' => Arr::get($identity, 'welcome_message', 'How can I help today?'),
            'position' => 'right',
            'color' => '#6d5efc',
            'trigger_background' => '#111827',
            'header_bg_type' => 'gradient',
            'header_bg_gradient' => 'linear-gradient(135deg,#6d5efc 0%,#8b5cf6 100%)',
            'header_bg_color' => '#6d5efc',
            'header_bg_image' => null,
            'show_logo' => false,
            'show_date_and_time' => true,
            'is_articles' => true,
            'is_contact' => true,
            'is_links' => true,
            'is_attachment' => true,
            'is_emoji' => true,
            'avatar' => 'modules/titanbuilder/avatars/avatar-1.png',
            'trigger_avatar_size' => 64,
            'preview_mode' => Arr::get($preview, 'preview_mode', 'widget'),
            'surface_label' => Arr::get($deployment, 'surface_label', 'Widget Surface'),
            'quick_actions' => ['Book now', 'Talk to support', 'Track job'],
        ], $runtime, $preview, $overrides);

        return $state;
    }
}
