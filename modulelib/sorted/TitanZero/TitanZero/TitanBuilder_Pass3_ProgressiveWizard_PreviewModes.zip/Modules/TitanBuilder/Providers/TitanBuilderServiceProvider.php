<?php
namespace Modules\TitanBuilder\Providers;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;
use Modules\TitanBuilder\Services\IntegratedPluginRegistry;

class TitanBuilderServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../Config/config.php', 'titanbuilder');
        $this->app->singleton(IntegratedPluginRegistry::class, fn () => new IntegratedPluginRegistry());
    }

    public function boot(): void
    {
        $this->loadViewsFrom(__DIR__ . '/../Resources/views', 'titanbuilder');
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');
        $this->loadRoutesFrom(__DIR__ . '/../Routes/web.php');
        $this->publishes([
            __DIR__ . '/../Resources/assets' => public_path('modules/titanbuilder'),
        ], 'titanbuilder-assets');
        $this->publishes([
            __DIR__ . '/../Resources/assets' => public_path('modules/titansurfacestudio'),
        ], 'titansurfacestudio-assets-legacy');
    }
}
