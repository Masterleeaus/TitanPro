# Pass 2 — Titan Builder rename + core assistant anchor

## Done
- renamed module namespace/surface to TitanBuilder
- moved route prefix to `dashboard/user/titan-builder`
- added legacy redirect from old route
- added core assistant schema anchors (`tz_core_assistants`, styles, sources, channels, embeds)
- added assistant registry-backed index
- preserved richer builder and preview shell from v3 base

## Notes
- legacy `ext_titan_surface_*` tables are still present for compatibility and donor preservation
- builder still renders legacy step blade names while new config exposes Titan Builder terminology
- next pass should map step persistence into `tz_core_assistant_*` records and upgrade preview sync
