# TitanBuilder Pass 1 - Plugin Integration

## What changed
- Removed `__MACOSX`, `._*`, and `.DS_Store` archive residue.
- Moved plugin donor folders from `Support/Donor/*` into `Support/IntegratedPlugins/*` for in-module ownership.
- Preserved the core Chatbot donor under `Support/Donor/Chatbot` for later builder/preview merges.
- Added `IntegratedPluginRegistry` service to discover integrated plugins from local manifests.
- Replaced external channel extension includes with module-owned channel cards.
- Added a local integrated-plugin matrix to the Channel step.
- Switched builder shell includes to the local module namespace.

## Integrated plugins in this pass
- ChatbotAgent
- ChatbotMessenger
- ChatbotTelegram
- ChatbotVoice
- ChatbotWhatsapp

## Deferred to later passes
- Runtime execution wiring
- Real credential persistence endpoints
- Full rename to TitanBuilder
- Schema remap from `ext_titan_surface_*` to final `tz_core_*`
