# Pass 3 — Progressive Wizard Persistence + Preview Modes

## What changed
- Added structured progressive draft persistence to `tz_core_assistants`
- Added `BuilderStateService` to write assistant, style, source, channel, and embed records
- Added `PreviewStateService` to normalize live preview state
- Added `save-draft` and `preview-state` routes/controller actions
- Upgraded builder screen with save-draft action and preview-mode selector
- Upgraded preview shell with mode simulation chips and mode-aware container styling
- Corrected frontend preview asset reference to TitanBuilder module path

## Intent
This pass keeps the rich builder intact while making it resumable and preview-driven before deeper runtime integration.
