# TitanBuilder v3

This pass ports the chatbot builder donor into a Worksuite-native multi-builder module.

## Build targets
- Assistant
- Chatbot
- Titan Go
- Titan Command
- Portal

## Donor ported intact
- 5-step builder shell (Configure / Customize / Train / Embed / Channel)
- frontend preview views
- training tabs
- avatars
- external chatbot JS
- chatbot System donor preserved under `Support/Donor/`
- messenger / telegram / whatsapp / voice donors preserved for later passes

## New module tables
- ext_titan_surface_builders
- ext_titan_surface_themes
- ext_titan_surface_sources
- ext_titan_surface_channels
- ext_titan_surface_deployments
- ext_titan_surface_presets
