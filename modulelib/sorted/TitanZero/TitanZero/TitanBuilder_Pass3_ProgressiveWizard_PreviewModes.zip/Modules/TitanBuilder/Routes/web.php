<?php
use Illuminate\Support\Facades\Route;
use Modules\TitanBuilder\Http\Controllers\TitanBuilderController;

Route::middleware(['web', 'auth'])->group(function () {
    Route::redirect('dashboard/titan-surface-studio', 'dashboard/user/titan-builder');

    Route::prefix('dashboard/user/titan-builder')->name('titan.builder.')->group(function () {
        Route::get('/', [TitanBuilderController::class, 'index'])->name('index');
        Route::get('/builder/{preset?}', [TitanBuilderController::class, 'builder'])->name('builder');
        Route::post('/builder/save-draft', [TitanBuilderController::class, 'saveDraft'])->name('save-draft');
        Route::get('/builder/preview-state', [TitanBuilderController::class, 'previewState'])->name('preview-state');
        Route::get('/preview/{preset?}', [TitanBuilderController::class, 'preview'])->name('preview');
    });
});
