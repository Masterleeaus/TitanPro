<?php
namespace Modules\TitanBuilder\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\TitanBuilder\Entities\Assistant;
use Modules\TitanBuilder\Services\BuilderStateService;
use Modules\TitanBuilder\Services\IntegratedPluginRegistry;
use Modules\TitanBuilder\Services\PreviewStateService;

class TitanBuilderController extends Controller
{
    public function __construct(
        protected IntegratedPluginRegistry $pluginRegistry,
        protected BuilderStateService $builderStateService,
        protected PreviewStateService $previewStateService,
    ) {
    }

    public function index()
    {
        $assistants = Assistant::query()->latest()->take(24)->get();

        return view('titanbuilder::index', [
            'presets' => config('titanbuilder.presets', []),
            'integratedPlugins' => $this->pluginRegistry->all(),
            'assistants' => $assistants,
        ]);
    }

    public function builder(Request $request, ?string $preset = 'assistant')
    {
        $assistant = null;
        if ($request->filled('assistant')) {
            $assistant = Assistant::query()->find($request->integer('assistant'));
            if ($assistant) {
                $preset = $assistant->preset_key ?: $preset;
            }
        }

        $previewState = $this->previewStateService->for($assistant, ['preview_mode' => $request->get('mode', $assistant?->preview_state_json['preview_mode'] ?? 'widget')]);

        return view('titanbuilder::studio.builder', [
            'preset' => $preset,
            'assistant' => $assistant,
            'steps' => config('titanbuilder.legacy_builder_steps', []),
            'mappedSteps' => config('titanbuilder.builder_steps', []),
            'presets' => config('titanbuilder.presets', []),
            'previewModes' => config('titanbuilder.preview_modes', []),
            'previewState' => $previewState,
            'integratedPlugins' => $this->pluginRegistry->all(),
            'avatars' => collect(range(1, 5))->map(fn ($i) => [
                'id' => $i,
                'avatar' => asset("modules/titanbuilder/avatars/avatar-{$i}.png"),
                'avatar_url' => asset("modules/titanbuilder/avatars/avatar-{$i}.png"),
            ]),
            'hasIntegratedChannels' => collect($this->pluginRegistry->all())->contains(fn ($plugin) => $plugin['type'] === 'channel'),
        ]);
    }

    public function preview(Request $request, ?string $preset = 'assistant')
    {
        $assistant = $request->filled('assistant') ? Assistant::query()->find($request->integer('assistant')) : null;
        if ($assistant) {
            $preset = $assistant->preset_key ?: $preset;
        }

        return view('titanbuilder::frontend-ui.frontend-ui-editor', [
            'preset' => $preset,
            'assistant' => $assistant,
            'integratedPlugins' => $this->pluginRegistry->all(),
            'previewState' => $this->previewStateService->for($assistant, ['preview_mode' => $request->get('mode', $assistant?->preview_state_json['preview_mode'] ?? 'widget')]),
        ]);
    }

    public function saveDraft(Request $request): JsonResponse
    {
        $assistant = $request->filled('assistant_id') ? Assistant::query()->find($request->integer('assistant_id')) : null;
        $payload = $request->validate([
            'assistant_id' => ['nullable', 'integer'],
            'preset_key' => ['nullable', 'string', 'max:100'],
            'status' => ['nullable', 'string', 'max:30'],
            'current_step' => ['nullable', 'integer', 'min:1', 'max:12'],
            'completed_steps' => ['nullable', 'array'],
            'last_step_key' => ['nullable', 'string', 'max:100'],
            'identity' => ['nullable', 'array'],
            'appearance' => ['nullable', 'array'],
            'knowledge' => ['nullable', 'array'],
            'runtime' => ['nullable', 'array'],
            'surface' => ['nullable', 'array'],
            'deployment' => ['nullable', 'array'],
            'preview' => ['nullable', 'array'],
        ]);

        $assistant = $this->builderStateService->persist($payload, $assistant);

        return response()->json([
            'ok' => true,
            'assistant_id' => $assistant->id,
            'title' => $assistant->title,
            'draft_step' => $assistant->draft_step,
            'preview' => $this->previewStateService->for($assistant),
            'message' => 'Draft saved',
        ]);
    }

    public function previewState(Request $request): JsonResponse
    {
        $assistant = $request->filled('assistant') ? Assistant::query()->find($request->integer('assistant')) : null;

        return response()->json([
            'ok' => true,
            'preview' => $this->previewStateService->for($assistant, $request->all()),
        ]);
    }
}
