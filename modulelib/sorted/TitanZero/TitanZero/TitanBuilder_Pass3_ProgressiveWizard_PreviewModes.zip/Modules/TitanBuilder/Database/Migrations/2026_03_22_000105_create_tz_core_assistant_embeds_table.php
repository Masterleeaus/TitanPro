<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('tz_core_assistant_embeds', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('assistant_id')->index();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('embed_type', 50)->index();
            $table->string('embed_key')->nullable()->index();
            $table->string('mount_target')->nullable()->index();
            $table->unsignedInteger('width')->nullable();
            $table->unsignedInteger('height')->nullable();
            $table->json('config_json')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('tz_core_assistant_embeds'); }
};
