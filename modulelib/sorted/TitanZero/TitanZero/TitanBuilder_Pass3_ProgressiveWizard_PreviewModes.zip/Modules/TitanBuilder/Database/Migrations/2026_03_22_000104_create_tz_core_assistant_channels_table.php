<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('tz_core_assistant_channels', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('assistant_id')->index();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('channel_key', 50)->index();
            $table->string('channel_label')->nullable();
            $table->string('status', 30)->default('draft')->index();
            $table->json('config_json')->nullable();
            $table->json('eligibility_json')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('tz_core_assistant_channels'); }
};
