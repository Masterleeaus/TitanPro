<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(): void { Schema::create('ext_titan_surface_deployments', function (Blueprint $table) {
$table->id(); $table->unsignedBigInteger('builder_id')->index(); $table->string('deployment_type')->index(); $table->string('uuid')->nullable()->index(); $table->longText('embed_code')->nullable(); $table->json('options')->nullable(); $table->json('meta_json')->nullable(); $table->timestamps();}); }
public function down(): void { Schema::dropIfExists('ext_titan_surface_deployments'); }};
