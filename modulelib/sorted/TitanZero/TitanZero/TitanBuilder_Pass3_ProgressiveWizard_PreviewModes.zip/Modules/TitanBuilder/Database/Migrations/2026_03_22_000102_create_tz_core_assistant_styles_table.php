<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('tz_core_assistant_styles', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('assistant_id')->index();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('avatar_path')->nullable();
            $table->string('logo_path')->nullable();
            $table->string('color_primary', 30)->nullable();
            $table->string('color_secondary', 30)->nullable();
            $table->text('gradient_css')->nullable();
            $table->string('layout_variant', 50)->nullable();
            $table->string('bubble_style', 50)->nullable();
            $table->json('typography_json')->nullable();
            $table->json('style_json')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('tz_core_assistant_styles'); }
};
