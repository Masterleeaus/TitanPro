<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('tz_core_assistant_sources', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('assistant_id')->index();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('source_type', 50)->index();
            $table->string('title')->nullable();
            $table->text('source_ref')->nullable();
            $table->longText('content_text')->nullable();
            $table->json('meta_json')->nullable();
            $table->string('status', 30)->default('draft')->index();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('tz_core_assistant_sources'); }
};
