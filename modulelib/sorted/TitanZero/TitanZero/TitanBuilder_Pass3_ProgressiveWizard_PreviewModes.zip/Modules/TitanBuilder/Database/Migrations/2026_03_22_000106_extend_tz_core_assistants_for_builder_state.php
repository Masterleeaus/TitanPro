<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('tz_core_assistants', function (Blueprint $table) {
            if (!Schema::hasColumn('tz_core_assistants', 'wizard_state_json')) {
                $table->json('wizard_state_json')->nullable()->after('runtime_json');
            }
            if (!Schema::hasColumn('tz_core_assistants', 'preview_state_json')) {
                $table->json('preview_state_json')->nullable()->after('wizard_state_json');
            }
            if (!Schema::hasColumn('tz_core_assistants', 'deployment_json')) {
                $table->json('deployment_json')->nullable()->after('preview_state_json');
            }
            if (!Schema::hasColumn('tz_core_assistants', 'last_saved_at')) {
                $table->timestamp('last_saved_at')->nullable()->after('deployment_json');
            }
        });
    }
    public function down(): void {
        Schema::table('tz_core_assistants', function (Blueprint $table) {
            foreach (['wizard_state_json','preview_state_json','deployment_json','last_saved_at'] as $column) {
                if (Schema::hasColumn('tz_core_assistants', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
