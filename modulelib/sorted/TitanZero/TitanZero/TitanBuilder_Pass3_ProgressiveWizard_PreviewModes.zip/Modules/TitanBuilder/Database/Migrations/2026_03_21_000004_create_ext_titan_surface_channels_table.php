<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(): void { Schema::create('ext_titan_surface_channels', function (Blueprint $table) {
$table->id(); $table->unsignedBigInteger('builder_id')->index(); $table->string('channel_type')->index(); $table->string('status')->default('inactive')->index(); $table->string('channel_identifier')->nullable(); $table->json('options')->nullable(); $table->json('meta_json')->nullable(); $table->timestamps();}); }
public function down(): void { Schema::dropIfExists('ext_titan_surface_channels'); }};
