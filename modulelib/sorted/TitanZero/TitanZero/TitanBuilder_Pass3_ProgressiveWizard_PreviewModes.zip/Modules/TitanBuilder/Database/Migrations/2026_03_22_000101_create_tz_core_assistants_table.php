<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('tz_core_assistants', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('title');
            $table->string('preset_key', 100)->default('assistant')->index();
            $table->string('status', 30)->default('draft')->index();
            $table->json('identity_json')->nullable();
            $table->json('runtime_json')->nullable();
            $table->unsignedTinyInteger('draft_step')->default(1);
            $table->timestamp('published_at')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('tz_core_assistants'); }
};
