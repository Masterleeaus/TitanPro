<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
  Schema::create('ext_titan_surface_builders', function (Blueprint $table) {
   $table->id(); $table->unsignedBigInteger('company_id')->nullable(); $table->unsignedBigInteger('user_id')->nullable();
   $table->string('name'); $table->string('slug')->nullable()->index(); $table->string('preset')->default('assistant')->index();
   $table->string('status')->default('draft')->index(); $table->json('options')->nullable(); $table->json('meta_json')->nullable(); $table->timestamps();
  });
 }
 public function down(): void { Schema::dropIfExists('ext_titan_surface_builders'); }
};
