<?php
namespace Modules\TitanBuilder\Entities;

use Illuminate\Database\Eloquent\Model;

class AssistantChannel extends Model
{
    protected $table = 'tz_core_assistant_channels';
    protected $fillable = ['assistant_id','company_id','channel_key','channel_label','status','config_json','eligibility_json'];
    protected $casts = ['config_json' => 'array','eligibility_json' => 'array'];
}
