<?php
namespace Modules\TitanBuilder\Entities;

use Illuminate\Database\Eloquent\Model;

class AssistantSource extends Model
{
    protected $table = 'tz_core_assistant_sources';
    protected $fillable = ['assistant_id','company_id','source_type','title','source_ref','content_text','meta_json','status'];
    protected $casts = ['meta_json' => 'array'];
}
