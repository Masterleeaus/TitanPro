<?php
namespace Modules\TitanBuilder\Entities;

use Illuminate\Database\Eloquent\Model;

class SurfaceDeployment extends Model
{
    protected $table = 'ext_titan_surface_deployments';
    protected $guarded = [];
    protected $casts = [
        'options' => 'array',
        'meta_json' => 'array',
    ];
}
