<?php
namespace Modules\TitanBuilder\Entities;

use Illuminate\Database\Eloquent\Model;

class SurfaceChannel extends Model
{
    protected $table = 'ext_titan_surface_channels';
    protected $guarded = [];
    protected $casts = [
        'options' => 'array',
        'meta_json' => 'array',
    ];
}
