<?php
namespace Modules\TitanBuilder\Entities;

use Illuminate\Database\Eloquent\Model;

class Assistant extends Model
{
    protected $table = 'tz_core_assistants';

    protected $fillable = [
        'company_id',
        'user_id',
        'title',
        'preset_key',
        'status',
        'identity_json',
        'runtime_json',
        'wizard_state_json',
        'preview_state_json',
        'deployment_json',
        'draft_step',
        'published_at',
        'last_saved_at',
    ];

    protected $casts = [
        'identity_json' => 'array',
        'runtime_json' => 'array',
        'wizard_state_json' => 'array',
        'preview_state_json' => 'array',
        'deployment_json' => 'array',
        'published_at' => 'datetime',
        'last_saved_at' => 'datetime',
    ];
}
