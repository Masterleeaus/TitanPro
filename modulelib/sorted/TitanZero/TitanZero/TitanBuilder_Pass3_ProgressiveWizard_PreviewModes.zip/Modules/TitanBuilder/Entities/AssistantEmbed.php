<?php
namespace Modules\TitanBuilder\Entities;

use Illuminate\Database\Eloquent\Model;

class AssistantEmbed extends Model
{
    protected $table = 'tz_core_assistant_embeds';
    protected $fillable = ['assistant_id','company_id','embed_type','embed_key','mount_target','width','height','config_json'];
    protected $casts = ['config_json' => 'array'];
}
