<?php
namespace Modules\TitanBuilder\Entities;

use Illuminate\Database\Eloquent\Model;

class SurfaceBuilder extends Model
{
    protected $table = 'ext_titan_surface_builders';
    protected $guarded = [];
    protected $casts = [
        'options' => 'array',
        'meta_json' => 'array',
    ];
}
