<?php
namespace Modules\TitanBuilder\Entities;

use Illuminate\Database\Eloquent\Model;

class SurfacePreset extends Model
{
    protected $table = 'ext_titan_surface_presets';
    protected $guarded = [];
    protected $casts = [
        'options' => 'array',
        'meta_json' => 'array',
    ];
}
