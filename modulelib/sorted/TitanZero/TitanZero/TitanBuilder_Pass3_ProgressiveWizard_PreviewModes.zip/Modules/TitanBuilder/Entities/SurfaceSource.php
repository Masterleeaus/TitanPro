<?php
namespace Modules\TitanBuilder\Entities;

use Illuminate\Database\Eloquent\Model;

class SurfaceSource extends Model
{
    protected $table = 'ext_titan_surface_sources';
    protected $guarded = [];
    protected $casts = [
        'options' => 'array',
        'meta_json' => 'array',
    ];
}
