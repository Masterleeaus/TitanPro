<?php
namespace Modules\TitanBuilder\Entities;

use Illuminate\Database\Eloquent\Model;

class AssistantStyle extends Model
{
    protected $table = 'tz_core_assistant_styles';
    protected $fillable = ['assistant_id','company_id','avatar_path','logo_path','color_primary','color_secondary','gradient_css','layout_variant','bubble_style','typography_json','style_json'];
    protected $casts = ['typography_json' => 'array','style_json' => 'array'];
}
