<?php

namespace Modules\TitanZero\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\View;

class TitanZeroServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        // Ensure Worksuite layout variables exist without overriding core composers.
        View::composer('*', function ($view) {
            $data = $view->getData();

            if (!array_key_exists('unreadMessagesCount', $data)) {
                $view->with('unreadMessagesCount', 0);
            }

            if (!array_key_exists('worksuitePlugins', $data)) {
                $view->with('worksuitePlugins', []);
            }

            if (!array_key_exists('customLink', $data)) {
                $view->with('customLink', []);
            }

            if (!array_key_exists('pageTitle', $data)) {
                $view->with('pageTitle', 'Titan Zero');
            }

            // Global Titan Zero bubble injection (Pass 2)
            try {
                if (config('titanzero.global_injection', true)) {
                    $factory = $view->getFactory();
                    $factory->startPush('styles', view('titanzero::partials.bubble.styles')->render());
                    $factory->startPush('scripts', view('titanzero::partials.bubble.container')->render());
                    $factory->startPush('scripts', view('titanzero::partials.bubble.scripts')->render());
                }
            } catch (\Throwable $e) {
                // Never break page render if injection fails
            }

        });


        // Views (support both Resources/ and resources/ casing)
        $viewsA = __DIR__ . '/../Resources/views';
        $viewsB = __DIR__ . '/../resources/views';

        if (is_dir($viewsA)) {
            $this->loadViewsFrom($viewsA, 'titanzero');
        } elseif (is_dir($viewsB)) {
            $this->loadViewsFrom($viewsB, 'titanzero');
        }

        // Load module routes (web)
        foreach ([__DIR__ . '/../Routes/web.php', __DIR__ . '/../routes/web.php'] as $routes) {
            if (file_exists($routes)) {
                $this->loadRoutesFrom($routes);
                break;
            }
        }

        // Account routes (Worksuite account-prefixed area)
        foreach ([__DIR__ . '/../routes/account.php', __DIR__ . '/../Routes/account.php'] as $accountRoutes) {
            if (file_exists($accountRoutes)) {
                Route::middleware(['web','auth'])
                    ->prefix('account/titan/assist')
                    ->name('titan.assist.')
                    ->group($accountRoutes);
                break;
            }
        }
    }

        // Publish public assets
        if ($this->app->runningInConsole()) {
            $this->publishes([
                __DIR__ . '/../Public/vendor/titanzero' => public_path('vendor/titanzero'),
            ], 'titanzero-assets');
        }

}
