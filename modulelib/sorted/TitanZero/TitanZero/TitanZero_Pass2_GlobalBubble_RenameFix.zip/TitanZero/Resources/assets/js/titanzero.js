(function () {
  function qs(sel){ return document.querySelector(sel); }

  function getContext(){
    const ctx = {
      url: window.location.href,
      title: document.title,
      headings: Array.from(document.querySelectorAll('h1,h2,h3')).slice(0,10).map(h=>h.innerText.trim()).filter(Boolean),
      forms: []
    };

    const forms = Array.from(document.querySelectorAll('form')).slice(0,3);
    forms.forEach((form)=>{
      const fields = Array.from(form.querySelectorAll('input,textarea,select')).slice(0,40).map(el=>{
        const type = (el.getAttribute('type')||'').toLowerCase();
        const name = el.getAttribute('name') || el.id || '';
        if(!name) return null;
        if(['password','hidden'].includes(type)) return null;
        if(name.toLowerCase().includes('token') || name.toLowerCase().includes('password')) return null;

        let value = '';
        if(el.tagName === 'SELECT'){
          value = el.options[el.selectedIndex]?.text || '';
        } else {
          value = (el.value || '').toString();
        }
        // light redaction
        if(value.length > 200) value = value.slice(0,200) + '…';
        return {name, type: el.tagName.toLowerCase(), value};
      }).filter(Boolean);
      if(fields.length) ctx.forms.push({fields});
    });

    return ctx;
  }

  function renderContext(){
    const pre = qs('#tz-context-preview');
    if(!pre) return;
    pre.textContent = JSON.stringify(getContext(), null, 2);
  }

  function toggle(open){
    const panel = qs('#tz-panel');
    if(!panel) return;
    panel.setAttribute('aria-hidden', open ? 'false' : 'true');
    panel.classList.toggle('is-open', !!open);
    if(open) renderContext();
  }

  document.addEventListener('click', function(e){
    if(e.target && (e.target.id === 'tz-bubble-btn' || e.target.closest('#tz-bubble-btn'))){
      const panel = qs('#tz-panel');
      const open = panel && panel.classList.contains('is-open');
      toggle(!open);
    }
    if(e.target && (e.target.id === 'tz-panel-close' || e.target.closest('#tz-panel-close'))){
      toggle(false);
    }
    if(e.target && (e.target.id === 'tz-refresh-context' || e.target.closest('#tz-refresh-context'))){
      renderContext();
    }
    if(e.target && (e.target.id === 'tz-ping' || e.target.closest('#tz-ping'))){
      fetch('/titan-zero/ping', {credentials:'same-origin'})
        .then(r=>r.json()).then(j=>alert('Titan Zero: ' + (j.status||'ok')))
        .catch(()=>alert('Titan Zero: ping failed'));
    }
  });

})();