@if (function_exists('user') && user() && (empty(user()->modules) || (in_array('titanzero', user()->modules) || in_array('titanassist', user()->modules))))
    <x-menu-item icon="sparkles" :text="__('Titan Zero')">
        <x-slot name="iconPath">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" aria-hidden="true" focusable="false">
                <path d="M256 48l22 66 66 22-66 22-22 66-22-66-66-22 66-22 22-66zm-170 196l14 42 42 14-42 14-14 42-14-42-42-14 42-14 14-42zm340 0l14 42 42 14-42 14-14 42-14-42-42-14 42-14 14-42z"/>
            </svg>
        </x-slot>

        <div class="accordionItemContent pb-2">
            @if(\Illuminate\Support\Facades\Route::has('titan-zero.index'))
                <x-sub-menu-item :link="route('titan-zero.index')" :text="__('Dashboard')" />
            @endif

            @if(\Illuminate\Support\Facades\Route::has('titan-zero.help'))
                <x-sub-menu-item :link="route('titan-zero.help')" :text="__('Help')" />
            @endif

            @if(\Illuminate\Support\Facades\Route::has('titan-zero.chat'))
                <x-sub-menu-item :link="route('titan-zero.chat')" :text="__('Chat')" />
            @endif

            @if(\Illuminate\Support\Facades\Route::has('titan-zero.generators'))
                <x-sub-menu-item :link="route('titan-zero.generators')" :text="__('Generators')" />
            @endif

            @if(\Illuminate\Support\Facades\Route::has('titan-zero.templates'))
                <x-sub-menu-item :link="route('titan-zero.templates')" :text="__('Templates')" />
            @endif
        </div>
    </x-menu-item>
@endif
