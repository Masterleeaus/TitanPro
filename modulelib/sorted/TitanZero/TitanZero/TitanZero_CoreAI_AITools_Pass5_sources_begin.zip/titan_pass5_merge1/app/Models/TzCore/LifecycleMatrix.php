<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class LifecycleMatrix extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_lifecycle_matrix';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'required_personas' => 'array',
        'automation_eligibility' => 'array',
        'token_budget_defaults' => 'array',
        'escalation_defaults' => 'array',
        'is_active' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
