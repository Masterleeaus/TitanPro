<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class TokenDistribution extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_token_distribution';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'token_budget' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
