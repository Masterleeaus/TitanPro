<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class ExecutionPolicy extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_execution_policies';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'policy_requirements' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
