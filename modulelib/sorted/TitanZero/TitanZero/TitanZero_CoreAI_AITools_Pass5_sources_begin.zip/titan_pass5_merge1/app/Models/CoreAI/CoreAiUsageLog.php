<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;
use App\Models\User;
use App\Traits\HasCompany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CoreAiUsageLog extends BaseModel
{
    use HasCompany;

    protected $table = 'coreai_usage_logs';

    protected $guarded = ['id'];

    protected $casts = [
        'request_meta' => 'array',
        'response_meta' => 'array',
        'usage_date' => 'date',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}

