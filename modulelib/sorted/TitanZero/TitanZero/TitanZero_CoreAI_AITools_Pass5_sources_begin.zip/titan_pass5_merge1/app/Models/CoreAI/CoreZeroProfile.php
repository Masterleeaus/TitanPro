<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CoreZeroProfile extends BaseModel
{
    protected $table = 'tz_core_zero_profiles';

    protected $guarded = ['id'];

    protected $casts = [
        'profile_meta' => 'array',
    ];
}
