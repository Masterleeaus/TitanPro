<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class AssistantStyle extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_assistant_styles';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'style_payload' => 'array',

        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
