<?php

declare(strict_types=1);

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RuntimeMemory extends Model
{
    use HasFactory;

    protected $table = 'ai_runtime_memories';

    protected $fillable = [
        'company_id',
        'scope',
        'scope_key',
        'assistant_id',
        'entity_type',
        'entity_id',
        'memory_kind',
        'payload',
        'evidence_payload',
        'is_audit_locked',
        'expires_at',
        'last_used_at',
    ];

    protected $casts = [
        'payload' => 'array',
        'evidence_payload' => 'array',
        'is_audit_locked' => 'boolean',
        'expires_at' => 'datetime',
        'last_used_at' => 'datetime',
    ];
}
