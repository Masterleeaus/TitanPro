<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class AssistantSource extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_assistant_sources';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'source_config' => 'array',
        'processing_state' => 'array',

        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
