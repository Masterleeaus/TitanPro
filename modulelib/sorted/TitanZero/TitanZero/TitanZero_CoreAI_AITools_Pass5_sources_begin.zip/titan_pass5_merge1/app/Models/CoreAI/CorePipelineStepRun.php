<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CorePipelineStepRun extends BaseModel
{
    protected $table = 'tz_core_pipeline_step_runs';

    protected $guarded = ['id'];

    protected $casts = [
        'input_payload' => 'array',
        'output_payload' => 'array',
        'confidence_score' => 'float',
    ];
}
