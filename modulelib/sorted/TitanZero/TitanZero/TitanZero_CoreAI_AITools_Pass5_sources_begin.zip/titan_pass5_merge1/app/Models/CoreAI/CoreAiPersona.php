<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CoreAiPersona extends BaseModel
{
    protected $table = 'tz_core_ai_personas';

    protected $guarded = ['id'];

    protected $casts = [
        'allowed_lifecycle_stages' => 'array',
        'training_pack' => 'array',
    ];
}
