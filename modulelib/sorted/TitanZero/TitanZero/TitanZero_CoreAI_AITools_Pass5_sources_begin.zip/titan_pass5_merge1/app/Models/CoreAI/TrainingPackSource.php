<?php

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Model;

class TrainingPackSource extends Model
{
    protected $table = 'ai_training_pack_sources';

    protected $guarded = [];

    protected $casts = [
        'meta_json' => 'array',
    ];
}
