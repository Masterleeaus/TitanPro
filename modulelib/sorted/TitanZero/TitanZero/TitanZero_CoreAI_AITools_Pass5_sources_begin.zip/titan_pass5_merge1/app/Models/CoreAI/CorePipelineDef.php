<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CorePipelineDef extends BaseModel
{
    protected $table = 'tz_core_pipeline_defs';

    protected $guarded = ['id'];

    public function steps()
    {
        return $this->hasMany(CorePipelineStep::class, 'pipeline_def_id')->orderBy('step_order');
    }
}
