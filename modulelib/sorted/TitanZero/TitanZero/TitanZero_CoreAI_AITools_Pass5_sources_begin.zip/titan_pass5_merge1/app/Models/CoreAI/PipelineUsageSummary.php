<?php

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PipelineUsageSummary extends Model
{
    use HasFactory;

    protected $table = 'ai_pipeline_usage';

    protected $guarded = [];

    protected $casts = [
        'meta_json' => 'array',
        'total_tokens' => 'integer',
        'total_cost' => 'float',
        'soft_quota_triggered' => 'boolean',
    ];
}
