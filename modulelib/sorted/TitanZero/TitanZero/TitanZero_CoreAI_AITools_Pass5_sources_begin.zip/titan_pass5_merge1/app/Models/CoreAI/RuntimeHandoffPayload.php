<?php

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Model;

class RuntimeHandoffPayload extends Model
{
    protected $table = 'ai_runtime_handoff_payloads';

    protected $guarded = [];
}
