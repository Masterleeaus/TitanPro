<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class DecisionTraceReplay extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_decision_trace_replays';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'trace_payload' => 'array',
        'replay_payload' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
