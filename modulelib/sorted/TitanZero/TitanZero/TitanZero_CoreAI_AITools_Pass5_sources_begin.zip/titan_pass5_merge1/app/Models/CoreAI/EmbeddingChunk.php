<?php

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmbeddingChunk extends Model
{
    use HasFactory;

    protected $table = 'ai_embedding_chunks';

    protected $guarded = [];

    protected $casts = [
        'embedding_vector' => 'array',
        'meta_json' => 'array',
        'chunk_tokens' => 'integer',
        'stage_weight' => 'float',
    ];
}
