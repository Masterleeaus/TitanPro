<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class TenantConfidenceProfile extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_tenant_confidence_profiles';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'weight_overrides' => 'array',
        'threshold_overrides' => 'array',
        'lifecycle_overrides' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
