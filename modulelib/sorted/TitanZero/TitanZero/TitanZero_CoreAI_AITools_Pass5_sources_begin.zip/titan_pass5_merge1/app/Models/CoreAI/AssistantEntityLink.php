<?php

declare(strict_types=1);

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AssistantEntityLink extends Model
{
    use HasFactory;

    protected $table = 'ai_assistant_entity_links';

    protected $fillable = [
        'assistant_id',
        'company_id',
        'entity_type',
        'entity_id',
    ];

    public function assistant(): BelongsTo
    {
        return $this->belongsTo(AssistantProfile::class, 'assistant_id');
    }
}
