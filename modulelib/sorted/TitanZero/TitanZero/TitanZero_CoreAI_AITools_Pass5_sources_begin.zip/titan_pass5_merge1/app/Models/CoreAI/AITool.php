<?php
namespace App\Models\CoreAI;
use Illuminate\Database\Eloquent\Model;
class AITool extends Model { protected $table="ai_tools"; protected $guarded=[]; protected $casts=["input_schema"=>"array","output_schema"=>"array","meta"=>"array"]; }
