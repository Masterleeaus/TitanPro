<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CorePipelineStep extends BaseModel
{
    protected $table = 'tz_core_pipeline_steps';

    protected $guarded = ['id'];

    protected $casts = [
        'temperature' => 'float',
        'output_schema' => 'array',
    ];
}
