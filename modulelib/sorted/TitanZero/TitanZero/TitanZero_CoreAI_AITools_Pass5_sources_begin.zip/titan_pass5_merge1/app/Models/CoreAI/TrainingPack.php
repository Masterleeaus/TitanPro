<?php

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Model;

class TrainingPack extends Model
{
    protected $table = 'ai_training_packs';

    protected $guarded = [];

    protected $casts = [
        'meta_json' => 'array',
        'stage_filters' => 'array',
        'is_active' => 'boolean',
    ];
}
