<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class AssistantKnowledgeLink extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_assistant_knowledge_links';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'link_payload' => 'array',

        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
