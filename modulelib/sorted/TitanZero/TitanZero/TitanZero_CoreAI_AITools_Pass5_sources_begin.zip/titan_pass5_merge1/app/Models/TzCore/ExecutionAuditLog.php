<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class ExecutionAuditLog extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_execution_audit_log';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'reason_codes' => 'array',
        'context_payload' => 'array',
        'trace_payload' => 'array',
        'decision_recorded_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
