<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class EscalationTarget extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_escalation_targets';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'metadata' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
