<?php
namespace App\Models\CoreAI;
use Illuminate\Database\Eloquent\Model;
class PipelineStep extends Model { protected $table="ai_pipeline_steps"; protected $guarded=[]; protected $casts=["input_payload"=>"array","output_payload"=>"array"]; }
