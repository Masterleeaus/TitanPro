<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;
use App\Models\User;
use App\Traits\HasCompany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CoreAiExport extends BaseModel
{
    use HasCompany;

    protected $table = 'coreai_exports';

    protected $guarded = ['id'];

    protected $casts = [
        'payload_meta' => 'array',
        'export_filters' => 'array',
        'generated_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}

