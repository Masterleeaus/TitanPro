<?php
namespace App\Models\CoreAI;
use Illuminate\Database\Eloquent\Model;
class AttachmentClass extends Model
{
    protected $table = 'ai_attachment_classes';
    protected $guarded = [];
    protected $casts = ['scores' => 'array'];
}
