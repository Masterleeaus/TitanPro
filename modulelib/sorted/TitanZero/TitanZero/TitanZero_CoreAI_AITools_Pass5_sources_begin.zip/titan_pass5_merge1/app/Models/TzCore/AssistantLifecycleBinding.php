<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class AssistantLifecycleBinding extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_assistant_lifecycle_bindings';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'binding_rules' => 'array',
        'binding_meta' => 'array',

        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
