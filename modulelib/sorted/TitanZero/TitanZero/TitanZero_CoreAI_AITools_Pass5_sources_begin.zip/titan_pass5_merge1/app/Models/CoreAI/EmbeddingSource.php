<?php

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmbeddingSource extends Model
{
    use HasFactory;

    protected $table = 'ai_embedding_sources';

    protected $guarded = [];

    protected $casts = [
        'meta_json' => 'array',
        'is_platform_default' => 'boolean',
        'is_active' => 'boolean',
    ];
}
