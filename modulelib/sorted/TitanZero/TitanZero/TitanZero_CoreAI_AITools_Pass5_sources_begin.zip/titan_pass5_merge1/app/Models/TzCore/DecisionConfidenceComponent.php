<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class DecisionConfidenceComponent extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_decision_confidence_components';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'component_payload' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
