<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;
use App\Models\User;
use App\Traits\HasCompany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CoreAiMemory extends BaseModel
{
    use HasCompany;

    protected $table = 'coreai_memories';

    protected $guarded = ['id'];

    protected $casts = [
        'meta_json' => 'array',
        'memory_payload' => 'array',
        'expires_at' => 'datetime',
        'retention_until' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}

