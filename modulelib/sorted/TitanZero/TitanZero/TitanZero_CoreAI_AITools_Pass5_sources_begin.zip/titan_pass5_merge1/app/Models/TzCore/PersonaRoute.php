<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class PersonaRoute extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_persona_routes';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'persona_sequence' => 'array',
        'token_budget' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
