<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class AssistantEmbed extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_assistant_embeds';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'embed_config' => 'array',
        'domain_allowlist' => 'array',

        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
