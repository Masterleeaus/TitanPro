<?php
namespace App\Models\CoreAI;
use Illuminate\Database\Eloquent\Model;
class PromptCategory extends Model { protected $table="ai_prompt_categories"; protected $guarded=[]; protected $casts=["meta"=>"array"]; }
