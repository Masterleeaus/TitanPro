<?php

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmbeddingPersonaMap extends Model
{
    use HasFactory;

    protected $table = 'ai_embedding_persona_map';

    protected $guarded = [];

    protected $casts = [
        'meta_json' => 'array',
        'is_active' => 'boolean',
    ];
}
