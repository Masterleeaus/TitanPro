<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class AssistantPersona extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_assistant_personas';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'persona_config' => 'array',
        'authority_scope' => 'array',

        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
