<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CoreAiConfidenceScore extends BaseModel
{
    protected $table = 'tz_core_ai_confidence_scores';

    protected $guarded = ['id'];

    protected $casts = [
        'score' => 'float',
        'factors' => 'array',
    ];
}
