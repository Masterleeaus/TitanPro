<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class AssistantDispatchTrace extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_assistant_dispatch_traces';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'dispatch_payload' => 'array',
        'decision_trace' => 'array',
        'reason_codes' => 'array',
        'dispatched_at' => 'datetime',

        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
