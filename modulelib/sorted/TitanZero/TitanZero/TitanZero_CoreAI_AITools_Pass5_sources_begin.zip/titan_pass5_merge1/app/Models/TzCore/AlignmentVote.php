<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class AlignmentVote extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_alignment_votes';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'vote_payload' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
