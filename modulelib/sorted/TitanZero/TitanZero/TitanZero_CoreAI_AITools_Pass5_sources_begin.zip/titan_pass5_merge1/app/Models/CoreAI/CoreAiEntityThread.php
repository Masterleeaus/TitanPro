<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CoreAiEntityThread extends BaseModel
{
    protected $table = 'tz_core_ai_entity_threads';

    protected $guarded = ['id'];

    protected $casts = [
        'context_snapshot' => 'array',
    ];
}
