<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CoreAiAudit extends BaseModel
{
    protected $table = 'tz_core_ai_audits';

    protected $guarded = ['id'];

    protected $casts = [
        'request_payload' => 'array',
        'response_payload' => 'array',
        'confidence_score' => 'float',
    ];
}
