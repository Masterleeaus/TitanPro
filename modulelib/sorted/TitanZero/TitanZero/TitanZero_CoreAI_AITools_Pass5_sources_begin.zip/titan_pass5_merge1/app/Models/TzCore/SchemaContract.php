<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class SchemaContract extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_schema_contracts';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'missing_fields' => 'array',
        'violations' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
