<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CoreAiPromptTemplate extends BaseModel
{
    protected $table = 'tz_core_ai_prompt_templates';

    protected $guarded = ['id'];

    protected $casts = [
        'meta' => 'array',
    ];
}
