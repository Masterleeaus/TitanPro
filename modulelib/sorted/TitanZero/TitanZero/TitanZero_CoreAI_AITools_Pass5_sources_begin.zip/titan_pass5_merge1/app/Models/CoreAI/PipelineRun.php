<?php
namespace App\Models\CoreAI;
use Illuminate\Database\Eloquent\Model;
class PipelineRun extends Model { protected $table="ai_pipeline_runs"; protected $guarded=[]; protected $casts=["meta"=>"array"]; }
