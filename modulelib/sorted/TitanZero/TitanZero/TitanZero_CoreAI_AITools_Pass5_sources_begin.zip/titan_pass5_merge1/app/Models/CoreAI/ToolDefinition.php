<?php

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Model;

class ToolDefinition extends Model
{
    protected $table = 'ai_tools';
    protected $guarded = [];
}
