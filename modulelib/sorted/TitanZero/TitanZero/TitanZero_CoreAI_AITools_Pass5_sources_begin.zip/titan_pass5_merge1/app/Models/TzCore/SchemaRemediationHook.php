<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class SchemaRemediationHook extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_schema_remediation_hooks';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'hook_payload' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
