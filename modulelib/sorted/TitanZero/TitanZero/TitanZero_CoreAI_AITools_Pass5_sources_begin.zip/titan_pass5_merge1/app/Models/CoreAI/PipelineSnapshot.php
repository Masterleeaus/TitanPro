<?php
namespace App\Models\CoreAI;
use Illuminate\Database\Eloquent\Model;
class PipelineSnapshot extends Model { protected $table="ai_pipeline_snapshots"; protected $guarded=[]; protected $casts=["payload"=>"array"]; }
