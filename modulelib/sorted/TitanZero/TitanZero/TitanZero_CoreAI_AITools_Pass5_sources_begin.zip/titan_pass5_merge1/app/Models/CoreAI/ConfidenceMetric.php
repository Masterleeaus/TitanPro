<?php
namespace App\Models\CoreAI;
use Illuminate\Database\Eloquent\Model;
class ConfidenceMetric extends Model { protected $table="ai_confidence_metrics"; protected $guarded=[]; protected $casts=["meta"=>"array"]; }
