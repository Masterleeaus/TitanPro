<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class PolicyReasonCode extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_policy_reason_codes';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'metadata' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
