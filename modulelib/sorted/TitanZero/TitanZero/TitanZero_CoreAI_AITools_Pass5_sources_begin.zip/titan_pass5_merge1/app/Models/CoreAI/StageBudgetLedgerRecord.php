<?php

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Model;

class StageBudgetLedgerRecord extends Model
{
    protected $table = 'ai_stage_budget_ledgers';

    protected $guarded = [];
}
