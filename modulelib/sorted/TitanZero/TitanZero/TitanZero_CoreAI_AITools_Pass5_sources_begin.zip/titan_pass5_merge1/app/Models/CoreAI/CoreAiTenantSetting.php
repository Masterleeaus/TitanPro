<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CoreAiTenantSetting extends BaseModel
{
    protected $table = 'tz_core_ai_tenant_settings';

    protected $guarded = ['id'];

    protected $casts = [
        'settings' => 'array',
    ];
}
