<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class AssistantChannel extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_assistant_channels';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'channel_config' => 'array',
        'deployment_state' => 'array',
        'last_dispatched_at' => 'datetime',

        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
