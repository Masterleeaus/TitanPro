<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CoreAiThreadMessage extends BaseModel
{
    protected $table = 'tz_core_ai_thread_messages';

    protected $guarded = ['id'];

    protected $casts = [
        'meta' => 'array',
    ];
}
