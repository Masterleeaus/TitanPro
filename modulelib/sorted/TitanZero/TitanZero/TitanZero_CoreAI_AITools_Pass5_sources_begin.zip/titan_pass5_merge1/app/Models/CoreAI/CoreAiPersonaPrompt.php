<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CoreAiPersonaPrompt extends BaseModel
{
    protected $table = 'tz_core_ai_persona_prompts';

    protected $guarded = ['id'];
}
