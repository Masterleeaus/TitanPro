<?php
namespace App\Models\CoreAI;
use Illuminate\Database\Eloquent\Model;
class AttachmentLink extends Model
{
    protected $table = 'ai_attachment_links';
    protected $guarded = [];
}
