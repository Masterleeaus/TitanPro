<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class Assistant extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_assistants';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'capabilities' => 'array',
        'policy_overrides' => 'array',
        'settings' => 'array',

        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
