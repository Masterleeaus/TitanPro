<?php

declare(strict_types=1);

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DecisionEnvelopeRecord extends Model
{
    use HasFactory;

    protected $table = 'ai_decision_envelopes';

    protected $fillable = [
        'envelope_id',
        'company_id',
        'assistant_id',
        'lifecycle_id',
        'entity_type',
        'entity_id',
        'schema_version',
        'confidence',
        'validation_status',
        'retrieval_sources',
        'telemetry',
        'payload',
        'meta',
        'hash',
    ];

    protected $casts = [
        'retrieval_sources' => 'array',
        'telemetry' => 'array',
        'payload' => 'array',
        'meta' => 'array',
        'confidence' => 'float',
    ];
}
