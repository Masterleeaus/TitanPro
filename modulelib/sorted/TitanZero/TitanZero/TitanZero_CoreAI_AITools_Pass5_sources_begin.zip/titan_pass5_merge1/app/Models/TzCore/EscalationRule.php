<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class EscalationRule extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_escalation_rules';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'rule_payload' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
