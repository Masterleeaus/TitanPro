<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class PolicyOverride extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_policy_overrides';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'override_payload' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
