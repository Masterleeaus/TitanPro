<?php

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Model;

class AuditEvent extends Model
{
    protected $table = 'ai_audit_events';

    protected $guarded = [];
}
