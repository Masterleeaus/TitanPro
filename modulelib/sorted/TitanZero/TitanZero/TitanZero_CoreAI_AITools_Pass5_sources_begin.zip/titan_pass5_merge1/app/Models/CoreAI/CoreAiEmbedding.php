<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;
use App\Models\User;
use App\Traits\HasCompany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CoreAiEmbedding extends BaseModel
{
    use HasCompany;

    protected $table = 'coreai_embeddings';

    protected $guarded = ['id'];

    protected $casts = [
        'source_meta' => 'array',
        'chunk_meta' => 'array',
        'embedding_meta' => 'array',
        'indexed_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}

