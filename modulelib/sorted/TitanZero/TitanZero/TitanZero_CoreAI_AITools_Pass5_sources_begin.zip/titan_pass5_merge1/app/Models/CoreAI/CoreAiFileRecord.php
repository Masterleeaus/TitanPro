<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CoreAiFileRecord extends BaseModel
{
    protected $table = 'tz_core_ai_file_records';

    protected $guarded = ['id'];

    protected $casts = [
        'classification' => 'array',
        'attachment_meta' => 'array',
        'is_pipeline_attached' => 'boolean',
    ];
}
