<?php

namespace App\Models\TzCore\Concerns;

use Illuminate\Database\Eloquent\Builder;

trait HasCoreDecisionScopes
{
    public function scopeForCompany(Builder $query, int|string|null $companyId): Builder
    {
        return $query->where('company_id', $companyId);
    }

    public function scopeForProcess(Builder $query, ?string $processId): Builder
    {
        return $query->where('process_id', $processId);
    }

    public function scopeForLifecycle(Builder $query, ?string $lifecycleEvent): Builder
    {
        return $query->where('lifecycle_event', $lifecycleEvent);
    }

    public function scopeRecentFirst(Builder $query): Builder
    {
        return $query->orderByDesc('id');
    }
}
