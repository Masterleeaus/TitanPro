<?php

declare(strict_types=1);

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AssistantProfile extends Model
{
    use HasFactory;

    protected $table = 'ai_assistants';

    protected $fillable = [
        'company_id',
        'name',
        'slug',
        'persona_key',
        'assistant_role',
        'settings',
        'permissions',
        'is_active',
    ];

    protected $casts = [
        'settings' => 'array',
        'permissions' => 'array',
        'is_active' => 'boolean',
    ];

    public function links(): HasMany
    {
        return $this->hasMany(AssistantEntityLink::class, 'assistant_id');
    }
}
