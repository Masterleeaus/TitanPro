<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;
use App\Models\User;
use App\Traits\HasCompany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CoreAiToolRegistry extends BaseModel
{
    use HasCompany;

    protected $table = 'coreai_tool_registry';

    protected $guarded = ['id'];

    protected $casts = [
        'tool_schema' => 'array',
        'tool_meta' => 'array',
        'is_enabled' => 'boolean',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}

