<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;
use App\Models\User;
use App\Traits\HasCompany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CoreAiAssistant extends BaseModel
{
    use HasCompany;

    protected $table = 'coreai_assistants';

    protected $guarded = ['id'];

    protected $casts = [
        'permissions_json' => 'array',
        'persona_defaults' => 'array',
        'scope_meta' => 'array',
        'is_active' => 'boolean',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}

