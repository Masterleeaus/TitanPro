<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class DecisionConfidence extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_decision_confidence';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'confidence_components' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
