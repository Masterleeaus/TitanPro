<?php

namespace App\Models\CoreAI;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TokenUsageLedger extends Model
{
    use HasFactory;

    protected $table = 'ai_token_usage';

    protected $guarded = [];

    protected $casts = [
        'meta_json' => 'array',
        'input_tokens' => 'integer',
        'output_tokens' => 'integer',
        'total_tokens' => 'integer',
        'cost_amount' => 'float',
        'soft_quota_triggered' => 'boolean',
    ];
}
