<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class PersonaAlignment extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_persona_alignment';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'alignment_payload' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
