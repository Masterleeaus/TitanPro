<?php
namespace App\Models\CoreAI;
use Illuminate\Database\Eloquent\Model;
class AttachmentIndex extends Model
{
    protected $table = 'ai_attachment_index';
    protected $guarded = [];
    protected $casts = [
        'metadata' => 'array',
        'extracted_text' => 'array',
    ];
}
