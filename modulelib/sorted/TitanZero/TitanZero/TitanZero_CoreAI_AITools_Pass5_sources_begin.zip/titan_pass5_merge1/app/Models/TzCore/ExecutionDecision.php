<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class ExecutionDecision extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_execution_decisions';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'reason_codes' => 'array',
        'decision_payload' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
