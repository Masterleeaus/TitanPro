<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class ZeroRefinement extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_zero_refinements';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'refinement_payload' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
