<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CorePipelineRun extends BaseModel
{
    protected $table = 'tz_core_pipeline_runs';

    protected $guarded = ['id'];

    protected $casts = [
        'input_context' => 'array',
        'final_output' => 'array',
    ];

    public function stepRuns()
    {
        return $this->hasMany(CorePipelineStepRun::class, 'pipeline_run_id')->orderBy('step_order');
    }
}
