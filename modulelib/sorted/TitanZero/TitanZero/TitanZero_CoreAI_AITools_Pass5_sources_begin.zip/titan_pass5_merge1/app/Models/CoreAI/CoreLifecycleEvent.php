<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;

class CoreLifecycleEvent extends BaseModel
{
    protected $table = 'tz_core_lifecycle_events';

    protected $guarded = ['id'];

    protected $casts = [
        'pipeline' => 'array',
        'meta' => 'array',
    ];
}
