<?php

namespace App\Models\CoreAI;

use App\Models\BaseModel;
use App\Models\User;
use App\Traits\HasCompany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CoreAiPromptTest extends BaseModel
{
    use HasCompany;

    protected $table = 'coreai_prompt_tests';

    protected $guarded = ['id'];

    protected $casts = [
        'input_payload' => 'array',
        'output_payload' => 'array',
        'metrics_json' => 'array',
        'executed_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}

