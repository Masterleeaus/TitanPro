<?php

namespace App\Models\TzCore;

use App\Models\TzCore\Concerns\HasCoreDecisionScopes;
use Illuminate\Database\Eloquent\Model;

class AuditIndex extends Model
{
    use HasCoreDecisionScopes;

    public const TABLE = 'tz_core_audit_indexes';

    protected $table = self::TABLE;

    protected $guarded = [];

    protected $casts = [
        'index_payload' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
