<?php

namespace App\Http\Controllers\CoreAI;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use App\Models\CoreAI\CoreAiAudit;
use App\Models\CoreAI\CoreAiEntityThread;
use App\Models\CoreAI\CoreAiUsageLog;
use App\Models\CoreAI\CorePipelineRun;
use App\Services\CoreAI\AiOrchestrator;
use App\Services\CoreAI\Lifecycle\PipelineRegistry;
use App\Services\CoreAI\Lifecycle\PipelineRunner;
use App\Services\CoreAI\Metering\UsageAggregator;
use Illuminate\Http\Request;

class CoreAiController extends AccountBaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'CoreAI';
    }

    public function index(UsageAggregator $usageAggregator)
    {
        $companyId = company()->id;
        $this->usageCount = CoreAiUsageLog::where('company_id', $companyId)->count();
        $this->auditCount = CoreAiAudit::where('company_id', $companyId)->count();
        $this->threadCount = CoreAiEntityThread::where('company_id', $companyId)->count();
        $this->pipelineRunCount = CorePipelineRun::where('company_id', $companyId)->count();
        $this->usageSummary = $usageAggregator->summarize($companyId);
        $this->pipelines = config('core_ai.lifecycle_pipelines', []);
        $this->personas = config('core_ai.personas', []);

        return view('core-ai.index', $this->data);
    }

    public function zero(Request $request, AiOrchestrator $orchestrator)
    {
        $result = $orchestrator->runZero([
            'company_id' => company()->id,
            'user_id' => user()->id,
            'entity_type' => $request->get('entity_type'),
            'entity_id' => $request->get('entity_id'),
            'event_type' => $request->get('event_type', 'default'),
            'assistant_slug' => $request->get('assistant_slug'),
            'lifecycle_stage' => $request->get('lifecycle_stage'),
            'messages' => $request->filled('message') ? [['role' => 'user', 'content' => $request->get('message')]] : [],
            'message' => $request->get('message'),
        ]);

        return Reply::successWithData('Zero persona executed.', ['result' => $result]);
    }

    public function pipelineBootstrap(PipelineRegistry $registry)
    {
        $result = $registry->sync(company()->id);

        return Reply::successWithData('CoreAI pipelines synced.', ['result' => $result]);
    }

    public function pipeline(Request $request, PipelineRunner $runner)
    {
        $eventType = (string) $request->get('event_type');
        abort_unless(array_key_exists($eventType, config('core_ai.lifecycle_pipelines', [])), 404);

        $result = $runner->run($eventType, [
            'company_id' => company()->id,
            'user_id' => user()->id,
            'entity_type' => $request->get('entity_type'),
            'entity_id' => $request->get('entity_id'),
            'assistant_slug' => $request->get('assistant_slug'),
            'lifecycle_stage' => $request->get('lifecycle_stage'),
            'messages' => $request->filled('message') ? [['role' => 'user', 'content' => $request->get('message')]] : [],
            'message' => $request->get('message'),
        ]);

        return Reply::successWithData('Pipeline executed.', [
            'event_type' => $eventType,
            'run_id' => $result['run']->id,
            'outputs' => $result['outputs'],
            'final' => $result['final'],
        ]);
    }
}
