<?php

namespace App\Http\Controllers\CoreAI\Api;

use App\Http\Controllers\Controller;
use App\Services\TitanCoreAI\CoreAiRuntimeBridge;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CoreAiRuntimeController extends Controller
{
    public function __invoke(Request $request, CoreAiRuntimeBridge $bridge): JsonResponse
    {
        $payload = $request->all();
        $payload['company_id'] = (int) ($payload['company_id'] ?? $request->user()?->company_id ?? $request->user()?->id ?? 0);
        $payload['user_id'] = (int) ($payload['user_id'] ?? $request->user()?->id ?? 0);

        return response()->json([
            'ok' => true,
            'result' => $bridge->orchestrate($payload),
        ]);
    }
}
