<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Loaders;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

/**
 * TASK 6: Retrieval Pack Loader - Tenant Customization
 * Layers tenant overrides on platform defaults for SOP/pricing/upsell packs
 */
final class TenantRetrievalPackOverrider
{
    private const CACHE_TTL = 3600; // 1 hour

    /**
     * Load retrieval pack with tenant overrides applied
     */
    public static function loadWithOverrides(
        string $persona,
        int $tenantId,
    ): array {
        $cacheKey = "retrieval_pack_override:{$persona}:{$tenantId}";

        return Cache::remember($cacheKey, self::CACHE_TTL, function () use ($persona, $tenantId) {
            $platformPack = self::getPlatformPack($persona);
            $tenantOverride = self::getTenantOverride($persona, $tenantId);

            return self::merge($platformPack, $tenantOverride);
        });
    }

    /**
     * Apply tenant overrides
     */
    public static function applyOverrides(
        array $platformPack,
        int $tenantId,
        string $persona,
    ): array {
        $override = self::getTenantOverride($persona, $tenantId);
        return self::merge($platformPack, $override);
    }

    /**
     * Register new tenant override
     */
    public static function registerOverride(
        int $tenantId,
        string $persona,
        array $override,
    ): void {
        DB::table('tenant_retrieval_pack_overrides')->updateOrInsert(
            ['tenant_id' => $tenantId, 'persona' => $persona],
            [
                'override_pack' => json_encode($override),
                'updated_at' => now(),
            ]
        );

        // Clear cache
        Cache::forget("retrieval_pack_override:{$persona}:{$tenantId}");
    }

    /**
     * Validate override doesn't break shared logic
     */
    public static function validateOverride(array $override): bool
    {
        // Cannot override persona type or core decision logic
        $forbidden = ['persona_type', 'decision_framework', 'escalation_criteria'];

        foreach ($forbidden as $field) {
            if (isset($override[$field])) {
                return false; // Cannot override critical fields
            }
        }

        return true;
    }

    private static function getPlatformPack(string $persona): array
    {
        // Load from database or cache
        return [
            'type' => 'sops',
            'source' => 'platform_default',
            'version' => '1.0',
            'content' => self::getPlatformContent($persona),
        ];
    }

    private static function getTenantOverride(string $persona, int $tenantId): ?array
    {
        $record = DB::table('tenant_retrieval_pack_overrides')
            ->where('tenant_id', $tenantId)
            ->where('persona', $persona)
            ->first();

        if (!$record) {
            return null;
        }

        return json_decode($record->override_pack, true);
    }

    private static function merge(array $platform, ?array $tenant): array
    {
        if (!$tenant) {
            return $platform;
        }

        // Tenant overrides apply to 'guides' section only
        $merged = $platform;
        
        if (isset($tenant['guides'])) {
            // Deep merge guides
            $merged['guides'] = array_merge(
                $platform['guides'] ?? [],
                $tenant['guides']
            );
        }

        if (isset($tenant['sources'])) {
            // Append sources
            $merged['sources'] = array_merge(
                $platform['sources'] ?? [],
                $tenant['sources']
            );
        }

        $merged['customized'] = true;
        $merged['tenant_id'] = $tenant['tenant_id'] ?? null;

        return $merged;
    }

    private static function getPlatformContent(string $persona): array
    {
        return match ($persona) {
            'Logic' => [
                'decision_framework' => '5-step: Define, Gather, Analyze, Decide, Document',
                'risk_levels' => 'Low: <$1k, Medium: $1k-$5k, High: >$5k',
            ],
            'Finance' => [
                'payment_terms' => 'Net 30 standard, Net 7 for early payment',
                'thresholds' => 'Flag >$5k, Escalate >$20k',
            ],
            'Creative' => [
                'tone' => 'Friendly, benefit-focused, action-oriented',
                'upsell_timing' => 'After job completion within 24 hours',
            ],
            'Macro' => [
                'relationship_strategy' => 'Repeat: maintain, New: onboard, Risk: escalate',
            ],
            'Micro' => [
                'enrichment_order' => 'Customer → Job → Invoice → Feedback',
                'missing_data_defaults' => 'Use company averages',
            ],
            default => [],
        };
    }
}
