<?php

namespace App\Services\CoreAI;

class ConfidenceScorer
{
    public function score(array $signals = []): float
    {
        $weights = array_filter([
            $signals['provider_success'] ?? null,
            $signals['structured_output'] ?? null,
            $signals['has_context'] ?? null,
            $signals['within_boundary'] ?? null,
        ], static fn ($value) => $value !== null);

        if (empty($weights)) {
            return 0.5;
        }

        return round(array_sum(array_map(static fn ($value) => (float) $value, $weights)) / count($weights), 2);
    }
}
