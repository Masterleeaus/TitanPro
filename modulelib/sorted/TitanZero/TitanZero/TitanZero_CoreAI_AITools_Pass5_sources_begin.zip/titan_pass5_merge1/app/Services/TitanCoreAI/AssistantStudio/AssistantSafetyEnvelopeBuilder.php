<?php

namespace App\Services\TitanCoreAI\AssistantStudio;

use App\Services\TitanCoreAI\AssistantStudio\DTOs\AssistantDeploymentContext;

final class AssistantSafetyEnvelopeBuilder
{
    public function build(AssistantDeploymentContext $context, array $decision, array $dispatch): array
    {
        return [
            'assistant_id' => $context->assistantId,
            'company_id' => $context->companyId,
            'process_id' => $context->processId,
            'lifecycle_event' => $context->lifecycleEvent,
            'channel' => $context->channel,
            'decision_outcome' => $decision['outcome'] ?? 'hold',
            'approval_mode' => $decision['approval_mode'] ?? 'MANUAL_REQUIRED',
            'confidence_score' => (float) ($decision['confidence_score'] ?? 0.0),
            'rollback_eligible' => (bool) ($decision['rollback_eligible'] ?? false),
            'dispatch_allowed' => (bool) ($dispatch['dispatch_allowed'] ?? false),
            'reason_codes' => array_values(array_unique(array_merge(
                (array) ($decision['reason_codes'] ?? []),
                (array) ($dispatch['reason_codes'] ?? [])
            ))),
            'payload' => $context->payload,
        ];
    }
}
