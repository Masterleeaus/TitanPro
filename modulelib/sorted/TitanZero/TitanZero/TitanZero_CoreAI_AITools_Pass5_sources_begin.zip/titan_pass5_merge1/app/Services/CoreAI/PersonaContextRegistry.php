<?php

namespace App\Services\CoreAI;

class PersonaContextRegistry
{
    public function forPersona(string $persona, array $input = []): array
    {
        return [
            'persona' => $persona,
            'allowed_lifecycle_stages' => app(PersonaRegistry::class)->get($persona)['allowed_lifecycle_stages'] ?? [],
            'input' => $input,
        ];
    }
}
