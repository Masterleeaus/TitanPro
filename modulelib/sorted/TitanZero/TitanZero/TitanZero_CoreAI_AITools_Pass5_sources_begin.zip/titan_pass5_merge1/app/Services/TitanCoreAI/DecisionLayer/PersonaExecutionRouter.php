<?php

namespace App\Services\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\Contracts\PersonaRouterInterface;
use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\LifecycleProfileRegistry;
use App\Services\TitanCoreAI\DecisionLayer\Resolvers\TokenBudgetAllocator;
use App\Services\TitanCoreAI\DecisionLayer\Support\PersonaSequenceMerger;

final class PersonaExecutionRouter implements PersonaRouterInterface
{
    public function __construct(
        private readonly LifecycleSafetyMatrix $matrix,
        private readonly TokenBudgetAllocator $tokenBudgetAllocator,
        private readonly LifecycleProfileRegistry $profiles,
        private readonly PersonaSequenceMerger $sequenceMerger,
    ) {
    }

    public function route(DecisionContext $context, float $confidenceScore, array $schemaReport = []): array
    {
        $matrix = $this->matrix->forEvent($context->lifecycleEvent);
        $profile = $this->profiles->forContext($context);
        $profileRouting = $profile->routingProfile($context);
        $matrixPersonas = (array) ($matrix['required_personas'] ?? ['Logic', 'Zero']);
        $dynamic = [];

        if (!($schemaReport['valid'] ?? false) && ($profileRouting['force_logic_on_schema_failure'] ?? true)) {
            $dynamic[] = 'Logic';
        }

        if ($confidenceScore < 0.75 && ($profileRouting['force_zero_on_low_confidence'] ?? true)) {
            $dynamic[] = 'Zero';
        }

        if ($context->financialExposure >= (float) ($profileRouting['prepend_finance_threshold'] ?? 500.0)) {
            $dynamic[] = 'Finance';
        }

        if (($context->payload['customer_sentiment'] ?? 'neutral') === 'negative') {
            $dynamic[] = 'Macro';
        }

        $personas = $this->sequenceMerger->merge($dynamic, $matrixPersonas);
        $budget = $this->tokenBudgetAllocator->allocate($personas, $context->riskLevel, $context->financialExposure, $context->missingFields);

        return [
            'persona_sequence' => $personas,
            'token_budget' => $budget,
            'approval_required' => $confidenceScore < ($matrix['minimum_confidence'] ?? 0.80),
            'automation_allowed' => (bool) ($matrix['automation_allowed'] ?? false),
            'matrix' => $matrix,
            'profile' => $profileRouting,
        ];
    }
}
