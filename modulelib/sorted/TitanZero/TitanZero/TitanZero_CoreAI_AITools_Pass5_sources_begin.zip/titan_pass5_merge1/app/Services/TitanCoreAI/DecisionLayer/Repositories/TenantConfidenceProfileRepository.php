<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Repositories;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

final class TenantConfidenceProfileRepository extends BaseDecisionRepository
{
    protected function table(): string
    {
        return 'tz_core_tenant_confidence_profiles';
    }

    public function persist(array $data): void
    {
        $this->insert($data);
    }

    public function persistForProcess(array $data): void
    {
        $uniqueBy = ['company_id', 'process_id', 'lifecycle_event'];
        $this->upsert([$data], $uniqueBy, ['company_id', 'profile_key', 'weight_overrides', 'threshold_overrides', 'lifecycle_overrides', 'updated_at']);
    }

    public function forCompanyAndLifecycle(int|string|null $companyId, string $lifecycleEvent, int $limit = 50): Collection
    {
        return DB::table($this->table())
            ->when($companyId !== null, fn ($query) => $query->where('company_id', $companyId))
            ->where('lifecycle_event', $lifecycleEvent)
            ->orderByDesc('id')
            ->limit($limit)
            ->get();
    }
}
