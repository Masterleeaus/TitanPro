<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Repositories;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

final class ExecutionDecisionRepository extends BaseDecisionRepository
{
    protected function table(): string
    {
        return 'tz_core_execution_decisions';
    }

    public function persist(array $data): void
    {
        $this->insert($data);
    }

    public function persistForProcess(array $data): void
    {
        $uniqueBy = ['company_id', 'process_id', 'lifecycle_event'];
        $this->upsert([$data], $uniqueBy, ['company_id', 'process_id', 'lifecycle_event', 'outcome', 'approval_mode', 'automation_allowed', 'reason_codes', 'decision_payload', 'updated_at']);
    }

    public function forCompanyAndLifecycle(int|string|null $companyId, string $lifecycleEvent, int $limit = 50): Collection
    {
        return DB::table($this->table())
            ->when($companyId !== null, fn ($query) => $query->where('company_id', $companyId))
            ->where('lifecycle_event', $lifecycleEvent)
            ->orderByDesc('id')
            ->limit($limit)
            ->get();
    }
}
