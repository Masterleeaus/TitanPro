<?php
namespace App\Services\TitanCoreAI\DecisionLayer\Components;
final class FinancialExposureCalculator
{
    public function calculate(float $exposure): float
    {
        return match (true) {
            $exposure <= 0 => 1.0,
            $exposure < 250 => 0.95,
            $exposure < 1000 => 0.82,
            $exposure < 2500 => 0.68,
            $exposure < 10000 => 0.48,
            default => 0.25,
        };
    }
}
