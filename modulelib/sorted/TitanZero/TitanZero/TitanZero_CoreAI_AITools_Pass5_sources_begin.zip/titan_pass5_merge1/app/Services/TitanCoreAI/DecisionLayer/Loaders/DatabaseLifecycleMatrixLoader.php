<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Loaders;

use App\Services\TitanCoreAI\DecisionLayer\Repositories\LifecycleSafetyMatrixRepository;

class DatabaseLifecycleMatrixLoader
{
    public function __construct(private LifecycleSafetyMatrixRepository $repository) {}

    public function load(string $event): array
    {
        return $this->repository->findByLifecycleEvent($event) ?? [];
    }
}
