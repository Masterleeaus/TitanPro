<?php

namespace App\Services\TitanCoreAI\AssistantStudio;

use App\Services\TitanCoreAI\AssistantStudio\DTOs\AssistantDeploymentContext;
use App\Services\TitanCoreAI\AssistantStudio\Repositories\AssistantDispatchTraceRepository;

final class AssistantDispatchTraceWriter
{
    public function __construct(private readonly AssistantDispatchTraceRepository $traces)
    {
    }

    public function write(AssistantDeploymentContext $context, array $envelope, array $decision, array $dispatch): array
    {
        $trace = $this->traces->record([
            'company_id' => $context->companyId,
            'assistant_id' => $context->assistantId,
            'process_id' => $context->processId,
            'lifecycle_event' => $context->lifecycleEvent,
            'channel_key' => $context->channel,
            'dispatch_status' => (string) ($dispatch['dispatch_mode'] ?? 'hold'),
            'reason_codes' => $envelope['reason_codes'] ?? [],
            'dispatch_payload' => $envelope,
            'decision_trace' => [
                'decision' => $decision,
                'dispatch' => $dispatch,
            ],
            'dispatched_at' => now(),
        ]);

        return $trace->toArray();
    }
}
