<?php
namespace App\Services\TitanCoreAI\DecisionLayer\Components;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionMath;
final class PolicyAlignmentCalculator
{
    public function calculate(array $policyRequirements, array $schemaReport): float
    {
        $requirements = max(1, count($policyRequirements));
        $hits = 0;
        foreach ($policyRequirements as $key => $required) {
            if (($schemaReport['policy_flags'][$key] ?? null) === $required) {
                $hits++;
            }
        }
        return DecisionMath::clamp($hits / $requirements);
    }
}
