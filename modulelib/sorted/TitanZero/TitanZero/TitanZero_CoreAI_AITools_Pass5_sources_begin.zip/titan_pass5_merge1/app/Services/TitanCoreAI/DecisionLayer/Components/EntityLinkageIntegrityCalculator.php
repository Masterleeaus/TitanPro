<?php
namespace App\Services\TitanCoreAI\DecisionLayer\Components;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionMath;
final class EntityLinkageIntegrityCalculator
{
    public function calculate(array $schemaReport): float
    {
        $required = max(1, (int) ($schemaReport['relationship_count'] ?? 0));
        $unresolved = count($schemaReport['unresolved_relationships'] ?? []);
        return DecisionMath::clamp(1 - ($unresolved / $required));
    }
}
