<?php

namespace App\Services\TitanCoreAI;

use App\Services\CoreAI\Runtime\CoreAiLifecycleRuntimeManager;

class CoreAiRuntimeBridge
{
    public function __construct(
        protected CoreAiLifecycleRuntimeManager $manager,
    ) {
    }

    public function orchestrate(array $payload = []): array
    {
        return $this->manager->handle($payload);
    }
}
