<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Resolvers;

use App\Services\TitanCoreAI\DecisionLayer\Enums\ApprovalMode;
use App\Services\TitanCoreAI\DecisionLayer\Support\ConfidenceThresholds;

final class ApprovalModeResolver
{
    public function resolve(float $confidence, bool $schemaValid, bool $needsFinanceReview, bool $blocked): string
    {
        if ($blocked || ! $schemaValid) return ApprovalMode::Blocked->value;
        if ($needsFinanceReview) return ApprovalMode::FinanceApproval->value;
        if ($confidence >= ConfidenceThresholds::autoExecute()) return ApprovalMode::AutoExecute->value;
        if ($confidence >= ConfidenceThresholds::zeroReview()) return ApprovalMode::ZeroReview->value;
        if ($confidence >= ConfidenceThresholds::specialistEscalation()) return ApprovalMode::ManagerApproval->value;
        return ApprovalMode::ManualRequired->value;
    }
}
