<?php

namespace App\Services\CoreAI;

use App\Models\CoreAI\CoreAiAudit;

class AiAuditLogger
{
    public function log(array $payload = []): ?CoreAiAudit
    {
        if (empty($payload['company_id'])) {
            return null;
        }

        return CoreAiAudit::create([
            'company_id' => $payload['company_id'],
            'user_id' => $payload['user_id'] ?? null,
            'persona' => $payload['persona'] ?? 'Zero',
            'event_type' => $payload['event_type'] ?? 'default',
            'entity_type' => $payload['entity_type'] ?? null,
            'entity_id' => $payload['entity_id'] ?? null,
            'decision_summary' => $payload['decision_summary'] ?? null,
            'request_payload' => $payload['request_payload'] ?? null,
            'response_payload' => $payload['response_payload'] ?? null,
            'confidence_score' => $payload['confidence_score'] ?? 0,
        ]);
    }
}
