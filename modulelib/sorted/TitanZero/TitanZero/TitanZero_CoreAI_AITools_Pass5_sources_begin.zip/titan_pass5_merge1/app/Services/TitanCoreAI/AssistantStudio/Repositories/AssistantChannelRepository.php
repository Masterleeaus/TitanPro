<?php

namespace App\Services\TitanCoreAI\AssistantStudio\Repositories;

use App\Models\TzCore\AssistantChannel;

final class AssistantChannelRepository
{
    public function activeChannel(int|string $companyId, string $assistantId, string $channel): ?AssistantChannel
    {
        return AssistantChannel::query()
            ->forCompany($companyId)
            ->where('assistant_id', $assistantId)
            ->where('channel_key', $channel)
            ->where('is_active', 1)
            ->latest('id')
            ->first();
    }
}
