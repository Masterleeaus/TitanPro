<?php

namespace App\Services\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\Components\ContradictionPenaltyCalculator;
use App\Services\TitanCoreAI\DecisionLayer\Components\EntityLinkageIntegrityCalculator;
use App\Services\TitanCoreAI\DecisionLayer\Components\FinancialExposureCalculator;
use App\Services\TitanCoreAI\DecisionLayer\Components\HistoricalCorrectionFrequencyCalculator;
use App\Services\TitanCoreAI\DecisionLayer\Components\MissingEnrichmentPenaltyCalculator;
use App\Services\TitanCoreAI\DecisionLayer\Components\PersonaAgreementCalculator;
use App\Services\TitanCoreAI\DecisionLayer\Components\PolicyAlignmentCalculator;
use App\Services\TitanCoreAI\DecisionLayer\Components\SchemaCompletenessCalculator;
use App\Services\TitanCoreAI\DecisionLayer\Components\SignalValidationStatusCalculator;
use App\Services\TitanCoreAI\DecisionLayer\Contracts\DecisionEngineInterface;
use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Support\ConfidenceComponentNormalizer;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionBandResolver;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionMath;
use App\Services\TitanCoreAI\DecisionLayer\Support\TenantConfidenceProfileResolver;

final class DecisionConfidenceEngine implements DecisionEngineInterface
{
    public function __construct(
        private readonly SchemaCompletenessCalculator $schemaCompleteness,
        private readonly EntityLinkageIntegrityCalculator $entityIntegrity,
        private readonly SignalValidationStatusCalculator $signalValidation,
        private readonly PersonaAgreementCalculator $personaAgreement,
        private readonly FinancialExposureCalculator $financialExposure,
        private readonly PolicyAlignmentCalculator $policyAlignment,
        private readonly MissingEnrichmentPenaltyCalculator $missingEnrichment,
        private readonly ContradictionPenaltyCalculator $contradictionPenalty,
        private readonly HistoricalCorrectionFrequencyCalculator $historicalCorrection,
        private readonly ConfidenceComponentNormalizer $componentNormalizer,
        private readonly DecisionBandResolver $bandResolver,
        private readonly TenantConfidenceProfileResolver $profileResolver,
    ) {
    }

    public function score(DecisionContext $context, array $schemaReport = [], array $alignment = []): array
    {
        $components = $this->componentNormalizer->normalize([
            'schema_completeness' => $this->schemaCompleteness->calculate($schemaReport),
            'entity_linkage_integrity' => $this->entityIntegrity->calculate($schemaReport),
            'signal_validation_status' => $this->signalValidation->calculate($context->payload),
            'persona_agreement' => $this->personaAgreement->calculate($alignment),
            'financial_exposure' => $this->financialExposure->calculate($context->financialExposure),
            'policy_alignment' => $this->policyAlignment->calculate($context->policyRequirements, $schemaReport),
            'missing_enrichment_penalty' => $this->missingEnrichment->calculate($context->missingFields),
            'contradiction_penalty' => $this->contradictionPenalty->calculate($alignment),
            'historical_correction_frequency' => $this->historicalCorrection->calculate($context->payload),
        ]);

        $profile = $this->profileResolver->resolve($context->companyId, $context->lifecycleEvent);
        $weights = array_replace((array) config('tz_core_decision.weights', []), (array) ($profile['weight_overrides'] ?? []));
        $score = round(DecisionMath::clamp(DecisionMath::weighted($components, $weights)), 4);
        $schemaValid = (bool) ($schemaReport['valid'] ?? false);
        $band = $this->bandResolver->resolve($score);
        $thresholds = array_replace((array) config('tz_core_decision.confidence', []), (array) ($profile['threshold_overrides'] ?? []));
        $automationThreshold = (float) ($thresholds['automation'] ?? 0.92);

        return [
            'confidence_score' => $score,
            'confidence_components' => $components,
            'requires_escalation' => !$schemaValid || in_array($band, ['manual', 'specialist_escalation'], true),
            'automation_eligible' => $schemaValid && $score >= $automationThreshold,
            'band' => $band,
            'weighted_inputs' => $weights,
            'thresholds' => $thresholds,
            'profile' => $profile,
        ];
    }
}
