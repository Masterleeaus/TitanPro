<?php

namespace App\Services\CoreAI;

class PersonaRegistry
{
    public function all(): array
    {
        return (array) config('core_ai.personas', []);
    }

    public function get(string $persona): array
    {
        return $this->all()[$persona] ?? [];
    }

    public function exists(string $persona): bool
    {
        return !empty($this->get($persona));
    }
}
