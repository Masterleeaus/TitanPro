<?php

namespace App\Services\TitanCoreAI\AssistantStudio\Repositories;

use App\Models\TzCore\AssistantLifecycleBinding;

final class AssistantLifecycleBindingRepository
{
    public function activeBinding(int|string $companyId, string $assistantId, string $lifecycleEvent): ?AssistantLifecycleBinding
    {
        return AssistantLifecycleBinding::query()
            ->forCompany($companyId)
            ->where('assistant_id', $assistantId)
            ->where('lifecycle_event', $lifecycleEvent)
            ->where('is_active', 1)
            ->latest('id')
            ->first();
    }

    public function upsertBinding(array $attributes, array $values): AssistantLifecycleBinding
    {
        AssistantLifecycleBinding::query()->updateOrCreate($attributes, $values);

        return AssistantLifecycleBinding::query()->where($attributes)->latest('id')->firstOrFail();
    }
}
