<?php
namespace App\Services\TitanCoreAI\DecisionLayer\Components;
final class PersonaAgreementCalculator
{
    public function calculate(array $alignment): float
    {
        return (float) ($alignment['alignment_score'] ?? 0.0);
    }
}
