<?php

namespace App\Services\TitanCoreAI\AssistantStudio;

use App\Services\TitanCoreAI\AssistantStudio\DTOs\AssistantDeploymentContext;

final class AssistantStudioDecisionBridge
{
    public function __construct(
        private readonly AssistantExecutionPolicyAdapter $policyAdapter,
        private readonly AssistantDeploymentEligibilityService $eligibilityService,
        private readonly AssistantChannelDispatchRouter $dispatchRouter,
        private readonly AssistantSafetyEnvelopeBuilder $envelopeBuilder,
        private readonly AssistantDispatchTraceWriter $traceWriter,
    ) {
    }

    public function process(AssistantDeploymentContext $context): array
    {
        $decision = $this->policyAdapter->evaluate($context);
        $eligibility = $this->eligibilityService->evaluate($context, $decision);
        $dispatch = $this->dispatchRouter->dispatch($context, $eligibility);
        $envelope = $this->envelopeBuilder->build($context, $decision, $dispatch);
        $trace = $this->traceWriter->write($context, $envelope, $decision, $dispatch);

        return compact('decision', 'eligibility', 'dispatch', 'envelope', 'trace');
    }
}
