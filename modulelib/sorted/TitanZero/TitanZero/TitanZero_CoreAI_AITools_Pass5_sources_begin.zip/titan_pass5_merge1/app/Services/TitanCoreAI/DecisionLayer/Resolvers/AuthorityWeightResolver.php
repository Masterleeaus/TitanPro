<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Resolvers;

final class AuthorityWeightResolver
{
    public function weightFor(string $persona, string $lifecycleEvent = '', string $riskLevel = 'low'): float
    {
        $base = (float) config('tz_core_decision.authority_weights.' . $persona, 1.0);

        if ($riskLevel === 'critical' && in_array($persona, ['Logic', 'Finance', 'Zero'], true)) {
            $base += 0.20;
        }

        if ($lifecycleEvent === 'negative_feedback_remediation' && $persona === 'Creative') {
            $base += 0.15;
        }

        return $base;
    }
}
