<?php

namespace App\Services\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\LifecycleProfileRegistry;
use App\Services\TitanCoreAI\DecisionLayer\Support\AlignmentNarrativeBuilder;
use App\Services\TitanCoreAI\DecisionLayer\Support\ZeroDecisionNormalizer;

final class ZeroArbitrationLayer
{
    public function __construct(
        private readonly LifecycleProfileRegistry $profiles,
        private readonly ZeroDecisionNormalizer $decisionNormalizer,
        private readonly AlignmentNarrativeBuilder $narrativeBuilder,
    ) {
    }

    public function refine(DecisionContext $context, array $signals): array
    {
        $profile = $this->profiles->forContext($context)->zeroProfile($context);
        $final = $this->decisionNormalizer->normalize((string) ($signals['execution']['outcome'] ?? 'hold'));

        return [
            'final_decision' => $final,
            'normalized_tone' => $profile['tone'] ?? 'operational',
            'schema_valid' => (bool) (($signals['schema']['valid'] ?? false)),
            'risk_classification' => $context->riskLevel,
            'consensus_decision' => $signals['alignment']['consensus_decision'] ?? 'hold',
            'alignment_narrative' => $this->narrativeBuilder->build($signals['alignment']),
            'persona_sequence' => $signals['routing']['persona_sequence'] ?? [],
            'execution_eligibility' => $signals['execution']['approval_mode'] ?? 'MANUAL_REQUIRED',
            'profile' => $profile,
        ];
    }
}
