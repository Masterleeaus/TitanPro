<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Resolvers;

use App\Services\TitanCoreAI\DecisionLayer\Memory\PipelineStageMemory;

/**
 * TASK 2: Persona Execution Router - Sequence Optimization
 * Optimizes persona routing order based on confidence and dependencies
 */
final class PersonaSequenceOptimizer
{
    /**
     * Optimize persona sequence based on dependencies and costs
     */
    public static function optimize(
        array $personas,
        float $confidence,
        int $financialExposure,
    ): array {
        // Remove duplicates while preserving order
        $personas = array_unique($personas);

        // Ensure Zero is always last
        $personas = array_filter($personas, fn($p) => $p !== 'Zero');
        $personas[] = 'Zero';

        // Reorder based on dependency graph
        return self::reorderByDependencies($personas, $confidence);
    }

    /**
     * Can skip persona if prior stage already solved it
     */
    public static function canSkipPersona(
        string $persona,
        PipelineStageMemory $memory,
        float $confidenceThreshold = 0.95,
    ): bool {
        // Zero consolidation never skipped
        if ($persona === 'Zero') {
            return false;
        }

        // Check if any prior persona reached very high confidence
        foreach ($memory->confidences() as $priorPersona => $priorConfidence) {
            if ($priorConfidence >= $confidenceThreshold) {
                // Can skip lower-priority personas
                return self::canSkipAfter($persona, $priorPersona);
            }
        }

        return false;
    }

    /**
     * Estimate execution time for persona sequence
     */
    public static function estimateExecutionTime(array $personas): int
    {
        $timings = [
            'Micro' => 200,      // ms
            'Logic' => 800,
            'Finance' => 600,
            'Creative' => 700,
            'Macro' => 500,
            'Zero' => 300,
        ];

        $total = 0;
        foreach ($personas as $persona) {
            $total += $timings[$persona] ?? 500;
        }

        return $total;
    }

    private static function reorderByDependencies(array $personas, float $confidence): array
    {
        // Priority order based on dependencies
        $priority = ['Micro', 'Logic', 'Finance', 'Creative', 'Macro', 'Zero'];

        $reordered = [];
        foreach ($priority as $persona) {
            if (in_array($persona, $personas)) {
                $reordered[] = $persona;
            }
        }

        return $reordered;
    }

    private static function canSkipAfter(string $persona, string $priorPersona): bool
    {
        // Logic doesn't skip others
        if ($priorPersona === 'Logic') {
            return in_array($persona, ['Creative', 'Micro']);
        }

        // Finance doesn't skip Logic or others
        if ($priorPersona === 'Finance') {
            return false;
        }

        // Creative doesn't skip others
        if ($priorPersona === 'Creative') {
            return in_array($persona, ['Micro']);
        }

        return false;
    }
}
