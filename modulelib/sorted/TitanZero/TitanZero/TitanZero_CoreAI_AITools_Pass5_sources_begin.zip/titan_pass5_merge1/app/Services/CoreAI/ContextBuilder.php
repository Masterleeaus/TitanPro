<?php

namespace App\Services\CoreAI;

use App\Services\CoreAI\Assistants\AssistantResolver;
use App\Services\CoreAI\FileIntelligence\LifecycleAttachmentResolver;
use App\Services\CoreAI\Memory\LifecycleMemoryBinder;
use App\Services\CoreAI\Memory\MemoryContextBuilder;
use App\Services\CoreAI\Memory\MemoryLocator;
use App\Services\CoreAI\Memory\MemoryTouchService;
use App\Services\CoreAI\Multimodal\AttachmentPayloadNormalizer;
use App\Services\CoreAI\Vector\RetrievalIndex;
use App\Services\CoreAI\Vector\RetrievalQueryBuilder;

class ContextBuilder
{
    public function __construct(
        protected MemoryContextBuilder $memoryContextBuilder,
        protected LifecycleAttachmentResolver $attachmentResolver,
        protected MemoryLocator $memoryLocator,
        protected LifecycleMemoryBinder $lifecycleMemoryBinder,
        protected AttachmentPayloadNormalizer $attachmentPayloadNormalizer,
        protected RetrievalQueryBuilder $retrievalQueryBuilder,
        protected RetrievalIndex $retrievalIndex,
        protected AssistantResolver $assistantResolver,
        protected MemoryTouchService $memoryTouchService,
    ) {
    }

    public function build(array $payload = []): array
    {
        $scope = [
            'company_id' => (int) ($payload['company_id'] ?? 0),
            'entity_type' => $payload['entity_type'] ?? null,
            'entity_id' => $payload['entity_id'] ?? null,
            'lifecycle_stage' => $payload['lifecycle_stage'] ?? null,
        ];

        $memories = $this->memoryLocator->forEntity(
            $scope['company_id'],
            $scope['entity_type'],
            $scope['entity_id'],
            $scope['lifecycle_stage']
        );

        $memoryContext = $this->memoryContextBuilder->build($memories);
        $attachments = $this->attachmentResolver->resolve($payload);
        $normalizedAttachments = $this->attachmentPayloadNormalizer->normalize($attachments);
        $assistant = $this->assistantResolver->resolve($payload);
        $retrievalQuery = $this->retrievalQueryBuilder->build($payload, $memoryContext);
        $retrieval = $scope['company_id'] > 0
            ? $this->retrievalIndex->search($scope['company_id'], $retrievalQuery, $payload)
            : [];

        $envelope = [
            'scope' => $scope,
            'assistant' => $assistant,
            'memory' => $memoryContext,
            'attachments' => $normalizedAttachments,
            'retrieval' => $retrieval,
            'input' => $payload,
        ];

        if ($memories->count()) {
            $envelope = $this->lifecycleMemoryBinder->bind($envelope, $memories, $scope['lifecycle_stage']);
            $this->memoryTouchService->touch($memories);
        }

        return $envelope;
    }
}
