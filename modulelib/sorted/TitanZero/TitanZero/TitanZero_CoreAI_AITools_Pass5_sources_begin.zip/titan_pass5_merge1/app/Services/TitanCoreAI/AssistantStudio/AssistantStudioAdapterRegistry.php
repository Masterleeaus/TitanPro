<?php

namespace App\Services\TitanCoreAI\AssistantStudio;

final class AssistantStudioAdapterRegistry
{
    public function __construct(private readonly array $adapters = [])
    {
    }

    public function has(string $key): bool
    {
        return array_key_exists($key, $this->adapters);
    }

    public function get(string $key): ?string
    {
        return $this->adapters[$key] ?? null;
    }

    public function all(): array
    {
        return $this->adapters;
    }
}
