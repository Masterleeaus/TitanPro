<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Resolvers;

final class TokenBudgetAllocator
{
    public function allocate(array $personas, string $riskLevel, float $financialExposure, array $missingFields = []): array
    {
        $totalBudget = (int) config('tz_core_decision.risk_budgets.' . $riskLevel, config('tz_core_decision.default_total_token_budget', 4000));

        if ($financialExposure > 1500) {
            $totalBudget += 600;
        }

        $totalBudget += count($missingFields) * 120;
        $personas = array_values(array_unique($personas));

        $weights = [];
        foreach ($personas as $persona) {
            $weights[$persona] = match ($persona) {
                'Zero' => 1.5,
                'Finance', 'Logic' => 1.2,
                'Macro' => 1.1,
                default => 1.0,
            };
        }

        $sumWeights = max(1, array_sum($weights));
        $result = [];
        foreach ($weights as $persona => $weight) {
            $result[$persona] = (int) floor(($totalBudget * $weight) / $sumWeights);
        }

        return $result;
    }
}
