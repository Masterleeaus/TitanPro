<?php

namespace App\Services\TitanCoreAI\AssistantStudio\Repositories;

use App\Models\TzCore\AssistantDispatchTrace;

final class AssistantDispatchTraceRepository
{
    public function record(array $payload): AssistantDispatchTrace
    {
        return AssistantDispatchTrace::query()->create($payload);
    }
}
