<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Persistence;

use App\Services\TitanCoreAI\DecisionLayer\Repositories\ExecutionAuditLogRepository;

class ReasonCodePersister
{
    public function __construct(private ExecutionAuditLogRepository $repository) {}

    public function persist(array $reasonCodes, array $context = []): array
    {
        return $this->repository->create([
            'company_id' => $context['company_id'] ?? null,
            'process_id' => $context['process_id'] ?? null,
            'lifecycle_event' => $context['lifecycle_event'] ?? null,
            'event_type' => 'decision_reason_codes',
            'payload' => ['reason_codes' => array_values($reasonCodes), 'context' => $context],
        ]);
    }
}
