<?php

namespace App\Services\CoreAI;

class ZeroConsolidator
{
    public function consolidate(array $stageOutputs = [], array $context = []): array
    {
        $summary = collect($stageOutputs)
            ->map(function ($output, $persona) {
                $status = $output['status'] ?? 'unknown';
                $summary = $output['summary'] ?? ($output['content'] ?? '');
                return trim("{$persona}: {$status}" . ($summary ? " - {$summary}" : ''));
            })
            ->filter()
            ->values()
            ->all();

        return [
            'persona' => 'Zero',
            'status' => 'consolidated',
            'summary' => implode("\n", $summary),
            'next_step' => $context['event_type'] ?? 'default',
        ];
    }
}
