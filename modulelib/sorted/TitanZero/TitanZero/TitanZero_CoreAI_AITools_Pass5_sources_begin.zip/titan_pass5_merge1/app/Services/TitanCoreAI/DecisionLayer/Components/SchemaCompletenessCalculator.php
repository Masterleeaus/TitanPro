<?php
namespace App\Services\TitanCoreAI\DecisionLayer\Components;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionMath;
final class SchemaCompletenessCalculator
{
    public function calculate(array $schemaReport): float
    {
        $required = max(1, (int) ($schemaReport['required_count'] ?? 0));
        $missing = count($schemaReport['missing_fields'] ?? []);
        return DecisionMath::clamp(1 - ($missing / $required));
    }
}
