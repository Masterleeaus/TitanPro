<?php

namespace App\Services\TitanCoreAI\AssistantStudio;

use App\Services\TitanCoreAI\AssistantStudio\DTOs\AssistantDeploymentContext;

final class AssistantDeploymentEligibilityService
{
    public function __construct(private readonly AssistantLifecycleBindingResolver $bindings)
    {
    }

    public function evaluate(AssistantDeploymentContext $context, array $decision): array
    {
        $binding = $this->bindings->resolve($context->companyId, $context->assistantId, $context->lifecycleEvent);
        $assistantActive = (bool) ($context->assistant['is_active'] ?? false);
        $channelAllowed = (bool) ($context->channelConfig['is_active'] ?? true);
        $confidence = (float) ($decision['confidence_score'] ?? 0.0);
        $allowed = $assistantActive
            && $channelAllowed
            && ($binding['valid'] ?? false)
            && in_array(($decision['outcome'] ?? 'hold'), ['execute', 'escalate'], true)
            && $confidence >= 0.50;

        return [
            'allowed' => $allowed,
            'binding' => $binding,
            'reason_codes' => array_values(array_unique(array_merge(
                (array) ($binding['reason_codes'] ?? []),
                $assistantActive ? [] : ['ASSISTANT_INACTIVE'],
                $channelAllowed ? [] : ['ASSISTANT_CHANNEL_DISABLED'],
                $confidence >= 0.50 ? [] : ['ASSISTANT_CONFIDENCE_TOO_LOW']
            ))),
        ];
    }
}
