<?php
namespace App\Services\TitanCoreAI\DecisionLayer\Components;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionMath;
final class MissingEnrichmentPenaltyCalculator
{
    public function calculate(array $missingFields): float
    {
        return DecisionMath::clamp(1 - (count($missingFields) * 0.08));
    }
}
