<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Persistence;

use App\Services\TitanCoreAI\DecisionLayer\Repositories\PipelineStateRepository;

class PipelineStatePersister
{
    public function __construct(private PipelineStateRepository $repository) {}

    public function persist(array $payload): array
    {
        return $this->repository->create($payload);
    }
}
