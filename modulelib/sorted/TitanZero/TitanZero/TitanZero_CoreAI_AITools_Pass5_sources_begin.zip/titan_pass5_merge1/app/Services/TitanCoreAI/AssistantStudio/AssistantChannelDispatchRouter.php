<?php

namespace App\Services\TitanCoreAI\AssistantStudio;

use App\Services\TitanCoreAI\AssistantStudio\DTOs\AssistantDeploymentContext;
use App\Services\TitanCoreAI\AssistantStudio\Repositories\AssistantChannelRepository;

final class AssistantChannelDispatchRouter
{
    public function __construct(private readonly AssistantChannelRepository $channels)
    {
    }

    public function dispatch(AssistantDeploymentContext $context, array $eligibility): array
    {
        $channel = $this->channels->activeChannel($context->companyId, $context->assistantId, $context->channel);

        if (!$channel) {
            return [
                'dispatch_allowed' => false,
                'reason_codes' => ['ASSISTANT_CHANNEL_MISSING'],
                'channel' => null,
                'dispatch_mode' => 'hold',
            ];
        }

        $channelConfig = $channel->channel_config ?? [];
        $enabledEvents = (array) ($channelConfig['enabled_lifecycle_events'] ?? []);
        $eventAllowed = $enabledEvents === [] || in_array($context->lifecycleEvent, $enabledEvents, true);
        $tenantAllowed = (bool) ($context->tenantSettings['assistant_channels_enabled'] ?? true);
        $eligibilityAllowed = (bool) ($eligibility['allowed'] ?? false);

        return [
            'dispatch_allowed' => $eventAllowed && $tenantAllowed && $eligibilityAllowed,
            'reason_codes' => array_values(array_filter([
                $eventAllowed ? null : 'ASSISTANT_CHANNEL_EVENT_BLOCKED',
                $tenantAllowed ? null : 'ASSISTANT_CHANNEL_TENANT_DISABLED',
                $eligibilityAllowed ? null : 'ASSISTANT_DEPLOYMENT_NOT_ELIGIBLE',
            ])),
            'channel' => $channel->toArray(),
            'dispatch_mode' => $eventAllowed && $tenantAllowed && $eligibilityAllowed ? 'dispatch' : 'hold',
        ];
    }
}
