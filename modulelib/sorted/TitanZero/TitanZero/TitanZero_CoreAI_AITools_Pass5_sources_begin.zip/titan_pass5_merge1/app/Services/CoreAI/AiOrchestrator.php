<?php
namespace App\Services\CoreAI;

use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

final class AiOrchestrator
{
    public function __construct(
        private readonly ZeroConsolidator $zeroConsolidator,
        private readonly UsageMeter $usageMeter,
        private readonly PersonaRegistry $personaRegistry,
    ) {
    }

    public function registerTenantSettings(int $tenantId, array $settings): void
    {
        DB::table('tenant_ai_settings')->updateOrInsert(
            ['tenant_id' => $tenantId],
            [
                'provider' => $settings['provider'] ?? config('core_ai.default_provider', 'openai'),
                'quota_tokens' => $settings['quota'] ?? 10_000_000,
                'escalation_threshold' => $settings['threshold'] ?? 0.7,
                'persona_permissions' => json_encode($settings['personas'] ?? ['Zero']),
                'updated_at' => now(),
            ],
        );
    }

    public function getTenantSettings(int $tenantId): ?array
    {
        $row = DB::table('tenant_ai_settings')->where('tenant_id', $tenantId)->first();

        if (! $row) {
            return null;
        }

        $settings = (array) $row;
        $settings['persona_permissions'] = json_decode($settings['persona_permissions'] ?? '[]', true) ?: [];

        return $settings;
    }

    public function resolveTenantSettings(int $tenantId): array
    {
        $settings = $this->getTenantSettings($tenantId) ?? [];

        return [
            'provider' => $settings['provider'] ?? config('core_ai.default_provider', 'openai'),
            'quota_tokens' => (int) ($settings['quota_tokens'] ?? 10_000_000),
            'escalation_threshold' => (float) ($settings['escalation_threshold'] ?? 0.7),
            'persona_permissions' => $settings['persona_permissions'] ?? array_keys($this->personaRegistry->all()),
        ];
    }

    public function validateProviderKey(int $tenantId, string $key): bool
    {
        return $tenantId > 0 && str($key)->length() > 10;
    }

    public function runZero(array $payload = []): array
    {
        $personas = Arr::only((array) ($payload['persona_outputs'] ?? []), $this->resolveAllowedPersonas($payload));

        if ($personas === []) {
            $personas = [
                'Zero' => [
                    'status' => 'direct',
                    'summary' => (string) ($payload['message'] ?? 'No message provided.'),
                ],
            ];
        }

        $result = $this->zeroConsolidator->consolidate($personas, [
            'event_type' => $payload['event_type'] ?? $payload['lifecycle_stage'] ?? 'default',
        ]);

        $this->usageMeter->record([
            'company_id' => $payload['company_id'] ?? 0,
            'user_id' => $payload['user_id'] ?? null,
            'provider' => $payload['provider'] ?? config('core_ai.default_provider', 'openai'),
            'model' => $payload['model'] ?? config('core_ai.default_model', 'gpt-4.1-mini'),
            'persona' => 'Zero',
            'prompt_tokens' => 0,
            'completion_tokens' => 0,
            'total_tokens' => 0,
            'estimated_cost' => 0,
            'meta' => json_encode(['source' => 'runZero', 'entity_type' => $payload['entity_type'] ?? null]),
        ]);

        return $result;
    }

    public function orchestrate(array $payload = []): array
    {
        $tenantSettings = $this->resolveTenantSettings((int) ($payload['company_id'] ?? 0));
        $pipeline = (string) ($payload['lifecycle_event'] ?? $payload['event_type'] ?? 'booking_to_job');
        $requested = (array) ($payload['persona_sequence'] ?? config("core_ai.lifecycle_pipelines.{$pipeline}.personas", ['Zero']));
        $allowed = array_values(array_intersect($requested, $this->resolveAllowedPersonas($payload)));

        if ($allowed === []) {
            $allowed = ['Zero'];
        }

        $stageOutputs = [];
        foreach ($allowed as $persona) {
            $stageOutputs[$persona] = [
                'status' => 'prepared',
                'summary' => sprintf('%s prepared for %s', $persona, $pipeline),
                'tokens_used' => 0,
            ];
        }

        $final = $this->zeroConsolidator->consolidate($stageOutputs, ['event_type' => $pipeline]);

        return [
            'pipeline' => $pipeline,
            'tenant_settings' => $tenantSettings,
            'persona_sequence' => $allowed,
            'stage_outputs' => $stageOutputs,
            'final' => $final,
        ];
    }

    private function resolveAllowedPersonas(array $payload): array
    {
        $companyId = (int) ($payload['company_id'] ?? 0);
        $settings = $companyId > 0 ? $this->resolveTenantSettings($companyId) : [];

        return (array) ($settings['persona_permissions'] ?? array_keys($this->personaRegistry->all()));
    }
}
