<?php

namespace App\Services\TitanCoreAI\AssistantStudio;

use App\Services\TitanCoreAI\AssistantStudio\DTOs\AssistantDeploymentContext;
use App\Services\TitanCoreAI\DecisionLayer\CoreAIDecisionOrchestrator;
use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;

final class AssistantExecutionPolicyAdapter
{
    public function __construct(private readonly CoreAIDecisionOrchestrator $orchestrator)
    {
    }

    public function evaluate(AssistantDeploymentContext $context): array
    {
        $decision = $this->orchestrator->handle(new DecisionContext(
            companyId: $context->companyId,
            processId: $context->processId,
            lifecycleEvent: $context->lifecycleEvent,
            riskLevel: (string) ($context->payload['risk_level'] ?? 'medium'),
            financialExposure: (float) ($context->payload['financial_exposure'] ?? 0.0),
            missingFields: (array) ($context->payload['missing_fields'] ?? []),
            payload: $context->payload,
            tenantSettings: $context->tenantSettings,
            personaOutputs: (array) ($context->payload['persona_outputs'] ?? []),
        ));

        return [
            'outcome' => $decision->outcome,
            'approval_mode' => $decision->approvalMode,
            'confidence_score' => $decision->confidenceScore,
            'reason_codes' => $decision->reasonCodes,
            'trace' => $decision->trace,
            'audit' => $decision->audit,
            'rollback_eligible' => (bool) ($decision->trace['execution']['rollback_eligible'] ?? false),
        ];
    }
}
