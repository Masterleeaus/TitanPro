<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Resolvers;

use App\Services\TitanCoreAI\DecisionLayer\Enums\ApprovalMode;
use App\Services\TitanCoreAI\DecisionLayer\Enums\ExecutionOutcome;

final class ExecutionOutcomeResolver
{
    public function resolve(string $approvalMode): string
    {
        return match ($approvalMode) {
            ApprovalMode::AutoExecute->value => ExecutionOutcome::Execute->value,
            ApprovalMode::ZeroReview->value, ApprovalMode::ManagerApproval->value, ApprovalMode::FinanceApproval->value => ExecutionOutcome::Hold->value,
            ApprovalMode::ManualRequired->value => ExecutionOutcome::Escalate->value,
            default => ExecutionOutcome::Reject->value,
        };
    }
}
