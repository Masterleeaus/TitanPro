<?php

namespace App\Services\TitanCoreAI\AssistantStudio\DTOs;

final class AssistantDeploymentContext
{
    public function __construct(
        public readonly int|string $companyId,
        public readonly string $assistantId,
        public readonly string $processId,
        public readonly string $lifecycleEvent,
        public readonly string $channel,
        public readonly array $assistant = [],
        public readonly array $binding = [],
        public readonly array $channelConfig = [],
        public readonly array $tenantSettings = [],
        public readonly array $payload = [],
    ) {
    }

    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'assistant_id' => $this->assistantId,
            'process_id' => $this->processId,
            'lifecycle_event' => $this->lifecycleEvent,
            'channel' => $this->channel,
            'assistant' => $this->assistant,
            'binding' => $this->binding,
            'channel_config' => $this->channelConfig,
            'tenant_settings' => $this->tenantSettings,
            'payload' => $this->payload,
        ];
    }
}
