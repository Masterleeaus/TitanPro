<?php
namespace App\Services\TitanCoreAI\DecisionLayer\Components;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionMath;
final class HistoricalCorrectionFrequencyCalculator
{
    public function calculate(array $payload): float
    {
        $corrections = (int) ($payload['historical_corrections'] ?? 0);
        return DecisionMath::clamp(1 - min(0.80, $corrections * 0.05));
    }
}
