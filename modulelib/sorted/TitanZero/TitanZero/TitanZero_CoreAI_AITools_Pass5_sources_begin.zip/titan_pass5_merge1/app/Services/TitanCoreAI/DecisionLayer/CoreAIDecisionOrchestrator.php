<?php

namespace App\Services\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionResult;
use App\Services\TitanCoreAI\DecisionLayer\Support\AuditDecisionIndexer;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionAuditWriter;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionPersistenceManager;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionTraceBuilder;
use App\Services\TitanCoreAI\DecisionLayer\Support\SchemaAutoRemediationRegistry;

final class CoreAIDecisionOrchestrator
{
    public function __construct(
        private readonly SchemaValidatorContracts $schemaValidator,
        private readonly PersonaAgreementAnalyzer $alignmentAnalyzer,
        private readonly DecisionConfidenceEngine $confidenceEngine,
        private readonly PersonaExecutionRouter $personaExecutionRouter,
        private readonly LifecycleExecutionPolicyEngine $policyEngine,
        private readonly EscalationDecisionRouter $escalationRouter,
        private readonly ExecutionEligibilityGate $executionGate,
        private readonly ZeroArbitrationLayer $zeroArbitrationLayer,
        private readonly DecisionTraceBuilder $traceBuilder,
        private readonly DecisionPersistenceManager $persistenceManager,
        private readonly DecisionAuditWriter $auditWriter,
        private readonly SchemaAutoRemediationRegistry $remediationRegistry,
        private readonly AuditDecisionIndexer $auditIndexer,
    ) {
    }

    public function handle(DecisionContext $context, array $personaOutputs = []): DecisionResult
    {
        $personaOutputs = $personaOutputs !== [] ? $personaOutputs : $context->personaOutputs();

        $schema = $this->schemaValidator->validate($context);
        $alignment = $this->alignmentAnalyzer->analyze($context->lifecycleEvent, $context->riskLevel, $personaOutputs);
        $confidence = $this->confidenceEngine->score($context, $schema, $alignment);
        $routing = $this->personaExecutionRouter->route($context, $confidence['confidence_score'], $schema);
        $policy = $this->policyEngine->resolve($context, $schema, $confidence['confidence_score']);
        $gate = $this->executionGate->decide($context, [
            'schema' => $schema,
            'alignment' => $alignment,
            'confidence' => $confidence,
            'policy' => $policy,
        ]);
        $escalation = $this->escalationRouter->route($context, $schema, $alignment, $confidence['confidence_score']);
        $zero = $this->zeroArbitrationLayer->refine($context, [
            'schema' => $schema,
            'alignment' => $alignment,
            'confidence' => $confidence,
            'policy' => $policy,
            'execution' => $gate,
            'routing' => $routing,
        ]);
        $remediations = $this->remediationRegistry->suggest($context->lifecycleEvent, $schema['violations'] ?? [], $context->payload);

        $trace = $this->traceBuilder->build($context, $schema, $alignment, $confidence, $routing, $policy, $gate, $escalation, $zero);
        $trace['remediation_suggestions'] = $remediations;
        $this->persistenceManager->persist($context, $schema, $alignment, $confidence, $routing, $policy, $gate, $escalation, $zero, $trace);

        $audit = [
            'company_id' => $context->companyId,
            'process_id' => $context->processId,
            'lifecycle_event' => $context->lifecycleEvent,
            'outcome' => $gate['outcome'],
            'reason_codes' => $gate['reason_codes'],
            'context_payload' => $context->toArray(),
            'trace_payload' => $trace,
            'event_source' => 'worksuite',
            'reason_hash' => sha1(json_encode($gate['reason_codes'] ?? [])),
            'decision_recorded_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ];
        $this->auditWriter->write($audit);
        $this->auditIndexer->index($audit, $trace, $gate);

        return new DecisionResult(
            outcome: $gate['outcome'],
            approvalMode: $gate['approval_mode'],
            confidenceScore: $confidence['confidence_score'],
            personaSequence: $routing['persona_sequence'],
            tokenBudget: $routing['token_budget'],
            reasonCodes: $gate['reason_codes'],
            escalations: $escalation,
            zeroRefinement: $zero,
            audit: $audit,
            trace: $trace,
        );
    }
}
