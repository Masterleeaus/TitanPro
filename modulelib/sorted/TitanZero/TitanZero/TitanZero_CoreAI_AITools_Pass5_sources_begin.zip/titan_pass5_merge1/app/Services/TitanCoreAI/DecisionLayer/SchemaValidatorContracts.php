<?php

namespace App\Services\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\Contracts\SchemaValidatorInterface;
use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\RuleRegistry\LifecycleRuleRegistry;
use App\Services\TitanCoreAI\DecisionLayer\SchemaRules\BookingToJobSchemaRule;
use App\Services\TitanCoreAI\DecisionLayer\SchemaRules\JobCompletionSchemaRule;
use App\Services\TitanCoreAI\DecisionLayer\SchemaRules\InvoicePaymentSchemaRule;
use App\Services\TitanCoreAI\DecisionLayer\SchemaRules\NegativeFeedbackSchemaRule;
use App\Services\TitanCoreAI\DecisionLayer\SchemaRules\StaffAbsenceSchemaRule;

final class SchemaValidatorContracts implements SchemaValidatorInterface
{
    public function __construct(
        private readonly LifecycleRuleRegistry $registry,
        private readonly BookingToJobSchemaRule $bookingRule,
        private readonly JobCompletionSchemaRule $completionRule,
        private readonly InvoicePaymentSchemaRule $paymentRule,
        private readonly NegativeFeedbackSchemaRule $feedbackRule,
        private readonly StaffAbsenceSchemaRule $absenceRule,
    ) {
    }

    public function validate(DecisionContext $context): array
    {
        $rules = $this->registry->rulesFor($context->lifecycleEvent);
        $payload = $context->payload;

        $missingFields = [];
        foreach ($rules['required_fields'] as $field) {
            if (($payload[$field] ?? null) === null || $payload[$field] === '') {
                $missingFields[] = $field;
            }
        }

        $unresolvedRelationships = [];
        foreach ($rules['required_relationships'] as $relationship) {
            if (!($payload['relationships'][$relationship] ?? false)) {
                $unresolvedRelationships[] = $relationship;
            }
        }

        $financialViolations = [];
        foreach ($rules['financial_fields'] as $field) {
            if (isset($payload[$field]) && !is_numeric($payload[$field])) {
                $financialViolations[] = $field;
            }
        }

        $policyFlags = $this->policyFlagsForEvent($context->lifecycleEvent, $payload);
        $violations = array_merge($missingFields, $unresolvedRelationships, $financialViolations);

        return [
            'valid' => $violations === [],
            'missing_fields' => $missingFields,
            'unresolved_relationships' => $unresolvedRelationships,
            'financial_violations' => $financialViolations,
            'violations' => $violations,
            'required_count' => count($rules['required_fields']),
            'relationship_count' => count($rules['required_relationships']),
            'policy_flags' => $policyFlags,
            'rule_hits' => array_keys(array_filter($policyFlags)),
        ];
    }

    private function policyFlagsForEvent(string $event, array $payload): array
    {
        return match ($event) {
            'booking_to_job' => $this->bookingRule->policyFlags($payload),
            'job_completion_processing' => $this->completionRule->policyFlags($payload),
            'invoice_payment_confirmation' => $this->paymentRule->policyFlags($payload),
            'negative_feedback_remediation' => $this->feedbackRule->policyFlags($payload),
            'staff_absence_replacement' => $this->absenceRule->policyFlags($payload),
            default => [],
        };
    }
}
