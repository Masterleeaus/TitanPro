<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Resolvers;

class RollbackEligibilityResolver
{
    public function resolve(array $decision): array
    {
        $eligible = in_array($decision['outcome'] ?? 'hold', ['execute', 'auto_execute'], true)
            && ($decision['schema_valid'] ?? false)
            && ! ($decision['financial_settled'] ?? false);

        return [
            'rollback_eligible' => $eligible,
            'rollback_mode' => $eligible ? 'soft' : 'none',
        ];
    }
}
