<?php
namespace App\Services\TitanCoreAI\DecisionLayer\Components;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionMath;
final class ContradictionPenaltyCalculator
{
    public function calculate(array $alignment): float
    {
        $contradictions = count($alignment['contradictions'] ?? []);
        return DecisionMath::clamp(1 - ($contradictions * 0.15));
    }
}
