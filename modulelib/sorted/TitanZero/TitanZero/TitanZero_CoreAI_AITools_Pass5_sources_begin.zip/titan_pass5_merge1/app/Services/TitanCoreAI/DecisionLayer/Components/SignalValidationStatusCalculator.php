<?php
namespace App\Services\TitanCoreAI\DecisionLayer\Components;
final class SignalValidationStatusCalculator
{
    public function calculate(array $payload): float
    {
        return match ($payload['signal_validation_status'] ?? 'unknown') {
            'verified' => 1.0,
            'partial' => 0.70,
            'pending' => 0.50,
            'failed' => 0.10,
            default => 0.40,
        };
    }
}
