<?php

namespace App\Services\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\LifecycleProfileRegistry;

final class EscalationDecisionRouter
{
    public function __construct(private readonly LifecycleProfileRegistry $profiles)
    {
    }

    public function route(DecisionContext $context, array $schema, array $alignment, float $confidenceScore): array
    {
        $profile = $this->profiles->forContext($context)->escalationProfile($context);

        if (!($schema['valid'] ?? false)) {
            return ['target' => 'Logic', 'trigger_code' => 'schema_violation', 'profile' => $profile];
        }

        if (($alignment['alignment_score'] ?? 1.0) < ($profile['alignment_floor'] ?? 0.60)) {
            return ['target' => 'Zero', 'trigger_code' => 'persona_conflict', 'profile' => $profile];
        }

        if ($context->financialExposure >= ($profile['high_financial_threshold'] ?? 1000.0)) {
            return ['target' => 'Finance', 'trigger_code' => 'financial_exposure', 'profile' => $profile];
        }

        if ($confidenceScore < ($profile['manual_floor'] ?? 0.50)) {
            return ['target' => 'HumanReviewer', 'trigger_code' => 'low_confidence', 'profile' => $profile];
        }

        return ['target' => 'Zero', 'trigger_code' => 'standard_review', 'profile' => $profile];
    }
}
