<?php

namespace App\Services\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\Support\PersonaOutputNormalizer;
use App\Services\TitanCoreAI\DecisionLayer\Resolvers\AuthorityWeightResolver;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionMath;

final class PersonaAgreementAnalyzer
{
    public function __construct(
        private readonly PersonaOutputNormalizer $normalizer,
        private readonly AuthorityWeightResolver $authorityWeightResolver,
    ) {
    }

    public function analyze(string $lifecycleEvent, string $riskLevel, array $personaOutputs): array
    {
        $normalized = $this->normalizer->normalize($personaOutputs);

        if ($normalized === []) {
            return [
                'alignment_score' => 0.0,
                'consensus_decision' => 'hold',
                'contradictions' => ['missing_persona_outputs'],
                'weighted_votes' => [],
            ];
        }

        $weightedVotes = [];
        foreach ($normalized as $persona => $payload) {
            $weight = $this->authorityWeightResolver->weightFor($persona, $lifecycleEvent, $riskLevel);
            $decision = $payload['decision'];
            $weightedVotes[$decision] = ($weightedVotes[$decision] ?? 0.0) + ($payload['confidence'] * $weight);
        }

        arsort($weightedVotes);
        $topDecision = array_key_first($weightedVotes);
        $values = array_values($weightedVotes);
        $top = $values[0] ?? 0.0;
        $second = $values[1] ?? 0.0;
        $alignment = $top > 0 ? DecisionMath::clamp(($top - $second) / max($top, 0.0001)) : 0.0;

        $contradictions = [];
        if (count($weightedVotes) > 1 && abs($top - $second) < 0.35) {
            $contradictions[] = 'close_vote_conflict';
        }

        foreach ($normalized as $persona => $payload) {
            if ($payload['decision'] !== $topDecision) {
                $contradictions[] = strtolower($persona) . '_opposed';
            }
        }

        return [
            'alignment_score' => round($alignment, 4),
            'consensus_decision' => $topDecision,
            'contradictions' => array_values(array_unique($contradictions)),
            'weighted_votes' => $weightedVotes,
            'normalized_outputs' => $normalized,
        ];
    }
}
