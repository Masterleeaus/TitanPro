<?php

namespace App\Services\CoreAI;

class PersonaPromptRegistry
{
    public function systemPrompt(string $persona, array $context = []): string
    {
        $personaConfig = app(PersonaRegistry::class)->get($persona);
        $role = $personaConfig['role'] ?? 'AI assistant';
        $boundary = $personaConfig['authority_boundary'] ?? 'Stay within provided context.';

        return trim(implode("\n\n", [
            "You are {$persona}.",
            "Role: {$role}.",
            "Authority boundary: {$boundary}.",
            'Return concise, structured output that can be audited and passed to later stages.',
            !empty($context['event_type']) ? 'Lifecycle event: ' . $context['event_type'] : '',
        ]));
    }
}
