<?php

namespace App\Services\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\Repositories\LifecycleSafetyMatrixRepository;

final class LifecycleSafetyMatrix
{
    public function __construct(
        private readonly LifecycleSafetyMatrixRepository $repository,
    ) {
    }

    public function forEvent(string $lifecycleEvent): array
    {
        $row = $this->repository->findByLifecycleEvent($lifecycleEvent);

        if ($row !== null) {
            return $row;
        }

        return config('tz_core_decision.lifecycle_matrix.' . $lifecycleEvent, [
            'minimum_confidence' => 0.80,
            'required_personas' => ['Logic', 'Zero'],
            'approval_mode' => 'MANUAL_REQUIRED',
            'automation_allowed' => false,
        ]);
    }
}
