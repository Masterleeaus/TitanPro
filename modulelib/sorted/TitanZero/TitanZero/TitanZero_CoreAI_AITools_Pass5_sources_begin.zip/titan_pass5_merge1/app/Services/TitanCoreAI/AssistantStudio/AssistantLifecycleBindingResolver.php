<?php

namespace App\Services\TitanCoreAI\AssistantStudio;

use App\Services\TitanCoreAI\AssistantStudio\Repositories\AssistantLifecycleBindingRepository;
use App\Services\TitanCoreAI\DecisionLayer\LifecycleSafetyMatrix;

final class AssistantLifecycleBindingResolver
{
    public function __construct(
        private readonly AssistantLifecycleBindingRepository $bindings,
        private readonly LifecycleSafetyMatrix $matrix,
    ) {
    }

    public function resolve(int|string $companyId, string $assistantId, string $lifecycleEvent): array
    {
        $binding = $this->bindings->activeBinding($companyId, $assistantId, $lifecycleEvent);
        $matrix = $this->matrix->forEvent($lifecycleEvent);

        if (!$binding) {
            return [
                'valid' => false,
                'binding_found' => false,
                'reason_codes' => ['ASSISTANT_BINDING_MISSING'],
                'binding' => [],
                'matrix' => $matrix,
            ];
        }

        $bindingRules = $binding->binding_rules ?? [];
        $requiredPersonas = (array) ($matrix['required_personas'] ?? []);
        $boundPersonas = (array) ($bindingRules['personas'] ?? []);
        $missingPersonas = array_values(array_diff($requiredPersonas, $boundPersonas));

        return [
            'valid' => $missingPersonas === [],
            'binding_found' => true,
            'reason_codes' => $missingPersonas === [] ? [] : ['ASSISTANT_BINDING_PERSONA_GAP'],
            'binding' => $binding->toArray(),
            'matrix' => $matrix,
            'missing_personas' => $missingPersonas,
        ];
    }
}
