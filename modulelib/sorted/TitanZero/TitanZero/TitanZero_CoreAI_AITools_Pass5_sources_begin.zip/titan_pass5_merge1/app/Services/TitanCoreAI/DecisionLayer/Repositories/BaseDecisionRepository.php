<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Repositories;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

abstract class BaseDecisionRepository
{
    abstract protected function table(): string;

    public function insert(array $data): void
    {
        DB::table($this->table())->insert($data);
    }

    public function insertMany(array $rows): void
    {
        if ($rows === []) {
            return;
        }

        DB::table($this->table())->insert($rows);
    }

    public function updateById(int $id, array $data): int
    {
        return DB::table($this->table())->where('id', $id)->update($data);
    }

    public function upsert(array $rows, array $uniqueBy, array $updateColumns): void
    {
        if ($rows === []) {
            return;
        }

        DB::table($this->table())->upsert($rows, $uniqueBy, $updateColumns);
    }

    public function findLatestByProcess(int|string|null $companyId, ?string $processId): ?object
    {
        return DB::table($this->table())
            ->when($companyId !== null, fn ($query) => $query->where('company_id', $companyId))
            ->when($processId !== null, fn ($query) => $query->where('process_id', $processId))
            ->orderByDesc('id')
            ->first();
    }

    public function findLatestByLifecycle(int|string|null $companyId, string $lifecycleEvent): ?object
    {
        return DB::table($this->table())
            ->when($companyId !== null, fn ($query) => $query->where('company_id', $companyId))
            ->where('lifecycle_event', $lifecycleEvent)
            ->orderByDesc('id')
            ->first();
    }

    public function allForCompany(int|string|null $companyId, int $limit = 100): Collection
    {
        return DB::table($this->table())
            ->when($companyId !== null, fn ($query) => $query->where('company_id', $companyId))
            ->orderByDesc('id')
            ->limit($limit)
            ->get();
    }
}
