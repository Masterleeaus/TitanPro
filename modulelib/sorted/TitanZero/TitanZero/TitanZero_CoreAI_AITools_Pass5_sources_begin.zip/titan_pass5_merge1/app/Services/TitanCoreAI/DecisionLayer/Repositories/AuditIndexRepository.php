<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Repositories;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

final class AuditIndexRepository extends BaseDecisionRepository
{
    protected function table(): string
    {
        return 'tz_core_audit_indexes';
    }

    public function persist(array $data): void
    {
        $this->insert($data);
    }

    public function persistForProcess(array $data): void
    {
        $uniqueBy = ['company_id', 'process_id', 'lifecycle_event'];
        $this->upsert([$data], $uniqueBy, ['company_id', 'process_id', 'lifecycle_event', 'index_key', 'index_payload', 'updated_at']);
    }

    public function forCompanyAndLifecycle(int|string|null $companyId, string $lifecycleEvent, int $limit = 50): Collection
    {
        return DB::table($this->table())
            ->when($companyId !== null, fn ($query) => $query->where('company_id', $companyId))
            ->where('lifecycle_event', $lifecycleEvent)
            ->orderByDesc('id')
            ->limit($limit)
            ->get();
    }
}
