<?php

namespace App\Services\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\Contracts\ExecutionGateInterface;
use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionReasonCodeSet;

final class ExecutionEligibilityGate implements ExecutionGateInterface
{
    public function decide(DecisionContext $context, array $signals): array
    {
        $schema = $signals['schema'];
        $alignment = $signals['alignment'];
        $confidence = $signals['confidence'];
        $policy = $signals['policy'];

        $policyBlocked = (bool) ($policy['blocked'] ?? false);
        $schemaValid = (bool) ($schema['valid'] ?? false);
        $alignmentScore = (float) ($alignment['alignment_score'] ?? 0.0);
        $confidenceScore = (float) ($confidence['confidence_score'] ?? 0.0);
        $automationEnabled = (bool) ($context->tenantSettings['automation_enabled'] ?? true);

        $outcome = 'hold';
        $approvalMode = (string) ($policy['approval_mode'] ?? 'MANUAL_REQUIRED');

        if ($policyBlocked || !$schemaValid || $approvalMode === 'BLOCKED') {
            $outcome = 'reject';
            $approvalMode = 'MANUAL_REQUIRED';
        } elseif ($automationEnabled && $approvalMode === 'AUTO_EXECUTE' && $confidenceScore >= 0.92 && $alignmentScore >= 0.70) {
            $outcome = 'execute';
        } elseif ($approvalMode === 'FINANCE_APPROVAL') {
            $outcome = 'escalate';
        } elseif ($confidenceScore >= 0.75) {
            $outcome = 'escalate';
            $approvalMode = 'ZERO_REVIEW';
        } elseif ($confidenceScore >= 0.50) {
            $outcome = 'escalate';
            $approvalMode = 'MANAGER_APPROVAL';
        }

        return [
            'outcome' => $outcome,
            'approval_mode' => $approvalMode,
            'reason_codes' => DecisionReasonCodeSet::fromSignals([
                'schema_valid' => $schemaValid,
                'alignment_score' => $alignmentScore,
                'confidence_score' => $confidenceScore,
                'financial_exposure' => $context->financialExposure,
                'financial_mode' => $approvalMode,
                'policy_blocked' => $policyBlocked,
                'requires_zero_review' => $approvalMode === 'ZERO_REVIEW',
                'automation_denied' => $outcome !== 'execute',
                'manual_required' => $approvalMode === 'MANUAL_REQUIRED',
            ]),
            'rollback_eligible' => in_array($context->lifecycleEvent, ['job_completion_processing', 'invoice_payment_confirmation'], true),
            'automation_enabled' => $automationEnabled,
        ];
    }
}
