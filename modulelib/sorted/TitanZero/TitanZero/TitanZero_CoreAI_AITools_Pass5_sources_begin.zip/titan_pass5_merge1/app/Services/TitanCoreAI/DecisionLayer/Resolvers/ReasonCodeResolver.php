<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Resolvers;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;

final class ReasonCodeResolver
{
    public function resolve(DecisionContext $context, array $schemaReport, array $alignment, string $approvalMode, float $confidence): array
    {
        $codes = [];
        if (! ($schemaReport['valid'] ?? false)) $codes[] = 'SCHEMA_INVALID';
        if (! empty($context->missingFields)) $codes[] = 'MISSING_FIELDS';
        if (! empty($alignment['contradictions'] ?? [])) $codes[] = 'ALIGNMENT_CONFLICT';
        if (($context->tenantSettings['automation_enabled'] ?? true) === false) $codes[] = 'TENANT_AUTOMATION_DISABLED';
        if ($confidence < 0.75) $codes[] = 'LOW_CONFIDENCE';
        if ($approvalMode === 'ZERO_REVIEW') $codes[] = 'ZERO_REVIEW_REQUIRED';
        if ($context->financialExposure > ($context->tenantSettings['max_automation_financial_exposure'] ?? config('tz_core_decision.max_automation_financial_exposure'))) $codes[] = 'FINANCIAL_REVIEW';
        return array_values(array_unique($codes));
    }
}
