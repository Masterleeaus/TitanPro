<?php

namespace App\Services\TitanCoreAI\DecisionLayer\Loaders;

class FallbackLifecycleMatrixLoader
{
    public function load(string $event, array $registry): array
    {
        return $registry[$event] ?? [];
    }
}
