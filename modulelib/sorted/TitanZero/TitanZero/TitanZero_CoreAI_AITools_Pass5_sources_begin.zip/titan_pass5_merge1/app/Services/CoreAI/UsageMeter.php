<?php

namespace App\Services\CoreAI;

use App\Models\CoreAI\CoreAiUsageLog;

class UsageMeter
{
    public function record(array $payload = []): ?CoreAiUsageLog
    {
        if (empty($payload['company_id'])) {
            return null;
        }

        return CoreAiUsageLog::create([
            'company_id' => $payload['company_id'],
            'user_id' => $payload['user_id'] ?? null,
            'provider' => $payload['provider'] ?? config('core_ai.default_provider'),
            'model' => $payload['model'] ?? config('core_ai.default_model'),
            'persona' => $payload['persona'] ?? config('core_ai.default_persona'),
            'prompt_tokens' => $payload['prompt_tokens'] ?? 0,
            'completion_tokens' => $payload['completion_tokens'] ?? 0,
            'total_tokens' => $payload['total_tokens'] ?? 0,
            'estimated_cost' => $payload['estimated_cost'] ?? 0,
            'meta' => $payload['meta'] ?? null,
        ]);
    }
}
