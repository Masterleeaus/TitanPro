<?php

namespace App\Services\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\LifecycleProfileRegistry;
use App\Services\TitanCoreAI\DecisionLayer\Support\FinancialThresholdMap;
use App\Services\TitanCoreAI\DecisionLayer\Support\PolicyOverrideRegistry;
use App\Services\TitanCoreAI\DecisionLayer\Support\TenantConfidenceProfileResolver;

final class LifecycleExecutionPolicyEngine
{
    public function __construct(
        private readonly LifecycleSafetyMatrix $matrix,
        private readonly LifecycleProfileRegistry $profiles,
        private readonly FinancialThresholdMap $thresholdMap,
        private readonly PolicyOverrideRegistry $overrides,
        private readonly TenantConfidenceProfileResolver $profileResolver,
    ) {
    }

    public function resolve(DecisionContext $context, array $schema, float $confidenceScore): array
    {
        $matrix = $this->matrix->forEvent($context->lifecycleEvent);
        $profile = $this->profiles->forContext($context)->policyProfile($context);
        $tenantProfile = $this->profileResolver->resolve($context->companyId, $context->lifecycleEvent);
        $thresholds = $this->thresholdMap->thresholds();
        $flags = (array) ($context->payload['regulatory_flags'] ?? []);
        $blockedFlags = array_intersect($flags, (array) ($profile['blocked_regulatory_flags'] ?? []));
        $blocked = !$schema['valid'] || $blockedFlags !== [];

        $approvalMode = 'MANUAL_REQUIRED';
        if ($blocked) {
            $approvalMode = 'BLOCKED';
        } elseif ($context->financialExposure >= ($thresholds['finance_approval'] ?? 2500)) {
            $approvalMode = 'FINANCE_APPROVAL';
        } elseif ($confidenceScore >= (($tenantProfile['threshold_overrides']['automation'] ?? 0.92)) && $context->financialExposure <= ($thresholds['auto_execute'] ?? 250)) {
            $approvalMode = 'AUTO_EXECUTE';
        } elseif ($confidenceScore >= (($tenantProfile['threshold_overrides']['zero_review'] ?? 0.75))) {
            $approvalMode = 'ZERO_REVIEW';
        } else {
            $approvalMode = 'MANAGER_APPROVAL';
        }

        $override = $this->overrides->resolve($context->companyId, $context->lifecycleEvent);
        $approvalMode = $override['approval_mode'] ?? $approvalMode;

        return [
            'approval_mode' => $approvalMode,
            'blocked' => $blocked,
            'blocked_flags' => array_values($blockedFlags),
            'minimum_confidence' => (float) ($matrix['minimum_confidence'] ?? 0.80),
            'matrix' => $matrix,
            'profile' => $profile,
            'tenant_profile' => $tenantProfile,
            'override' => $override,
            'automation_allowed' => (bool) ($override['automation_allowed'] ?? ($approvalMode === 'AUTO_EXECUTE')),
        ];
    }
}
