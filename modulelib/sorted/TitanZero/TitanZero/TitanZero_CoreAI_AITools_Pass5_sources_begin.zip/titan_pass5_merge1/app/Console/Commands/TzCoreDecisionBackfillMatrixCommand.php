<?php

namespace App\Console\Commands;

use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionLifecycleMap;
use Illuminate\Console\Command;

final class TzCoreDecisionBackfillMatrixCommand extends Command
{
    protected $signature = 'tz:core-decision:backfill-matrix';

    protected $description = 'Print the lifecycle event backfill pairs that should exist in tz_core_lifecycle_matrix.';

    public function handle(DecisionLifecycleMap $map): int
    {
        $this->info('Lifecycle event normalization pairs');

        foreach ($map->all() as $source => $target) {
            $this->line(sprintf('%s => %s', $source, $target));
        }

        return self::SUCCESS;
    }
}
