<?php

namespace App\Console\Commands;

use App\Services\TitanCoreAI\AssistantStudio\AssistantStudioAdapterRegistry;
use Illuminate\Console\Command;

final class TzCoreAssistantStudioDiagnoseCommand extends Command
{
    protected $signature = 'tz-core:assistant-studio-diagnose';

    protected $description = 'Show Assistant Studio backend adapter availability for Dev-3 control-plane integrations.';

    public function handle(AssistantStudioAdapterRegistry $registry): int
    {
        $this->info('Assistant Studio adapter registry');
        foreach ($registry->all() as $key => $class) {
            $this->line($key.': '.$class);
        }

        return self::SUCCESS;
    }
}
