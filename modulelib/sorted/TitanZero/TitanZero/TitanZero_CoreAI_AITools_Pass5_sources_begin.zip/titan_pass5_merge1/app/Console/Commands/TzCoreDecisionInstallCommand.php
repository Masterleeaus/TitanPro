<?php

namespace App\Console\Commands;

use App\Services\TitanCoreAI\DecisionLayer\Integration\DecisionHealthReport;
use App\Services\TitanCoreAI\DecisionLayer\Integration\DecisionLayerInstaller;
use Illuminate\Console\Command;

final class TzCoreDecisionInstallCommand extends Command
{
    protected $signature = 'tz:core-decision:install {--report : Also print the health report}';

    protected $description = 'Print the Titan CoreAI decision-layer install plan for Worksuite integration.';

    public function handle(DecisionLayerInstaller $installer, DecisionHealthReport $report): int
    {
        $plan = $installer->installPlan();

        $this->info('Titan CoreAI Decision Layer install plan');
        foreach ($plan['steps'] as $index => $step) {
            $this->line(sprintf('%d. %s', $index + 1, $step));
        }

        $this->newLine();
        $this->info('Post-install checks');
        foreach ($plan['post_install_checks'] as $check) {
            $this->line('- '.$check);
        }

        if ((bool) $this->option('report')) {
            $this->newLine();
            $this->info(json_encode($report->generate(), JSON_PRETTY_PRINT));
        }

        return self::SUCCESS;
    }
}
