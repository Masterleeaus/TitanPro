<?php

namespace App\Console\Commands;

use App\Services\CoreAI\Lifecycle\PipelineRegistry;
use Illuminate\Console\Command;

class CoreAiBootstrapCommand extends Command
{
    protected $signature = 'coreai:bootstrap {company_id=0 : Tenant/company identifier}';

    protected $description = 'Bootstrap CoreAI runtime pipeline definitions into storage.';

    public function handle(PipelineRegistry $registry): int
    {
        $companyId = (int) $this->argument('company_id');
        $result = $registry->sync($companyId);

        $this->info('CoreAI pipelines synced.');
        $this->table(['metric', 'value'], [
            ['company_id', $companyId],
            ['pipelines', count($result['pipelines'] ?? [])],
            ['personas', count($result['personas'] ?? [])],
        ]);

        return self::SUCCESS;
    }
}
