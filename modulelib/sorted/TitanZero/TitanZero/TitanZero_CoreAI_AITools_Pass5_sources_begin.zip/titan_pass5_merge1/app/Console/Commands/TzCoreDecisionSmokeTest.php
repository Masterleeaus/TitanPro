<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\TitanCoreAI\DecisionLayer\CoreAIDecisionOrchestrator;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionContextFactory;

class TzCoreDecisionSmokeTest extends Command
{
    protected $signature = 'tzcore:decision-smoke {event=booking_to_job}';
    protected $description = 'Run a smoke test for the Titan CoreAI decision layer';

    public function handle(DecisionContextFactory $factory, CoreAIDecisionOrchestrator $orchestrator): int
    {
        $context = $factory->make([
            'company_id' => 1,
            'process_id' => 'smoke-001',
            'lifecycle_event' => $this->argument('event'),
            'payload' => [
                'booking_id' => 10,
                'customer_id' => 20,
                'site_id' => 30,
                'scheduled_start' => now()->toIso8601String(),
                'quoted_amount' => 180.00,
                'relationships' => [
                    'booking.customer' => true,
                    'booking.site' => true,
                ],
                'signal_validation_status' => 'verified',
                'persona_outputs' => [
                    'Micro' => ['decision' => 'execute', 'confidence' => 0.86],
                    'Finance' => ['decision' => 'execute', 'confidence' => 0.82],
                    'Logic' => ['decision' => 'execute', 'confidence' => 0.90],
                    'Zero' => ['decision' => 'execute', 'confidence' => 0.88],
                ],
            ],
            'policy_requirements' => [
                'requires_customer_verification' => false,
                'site_access_resolved' => false,
            ],
        ]);

        $result = $orchestrator->handle($context);
        $this->line(json_encode($result->toArray(), JSON_PRETTY_PRINT));

        return self::SUCCESS;
    }
}
