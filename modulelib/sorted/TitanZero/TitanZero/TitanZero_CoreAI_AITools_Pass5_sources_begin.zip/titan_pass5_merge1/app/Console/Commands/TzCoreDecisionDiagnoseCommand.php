<?php

namespace App\Console\Commands;

use App\Services\TitanCoreAI\DecisionLayer\Diagnostics\DecisionDiagnosticsSuite;
use Illuminate\Console\Command;

final class TzCoreDecisionDiagnoseCommand extends Command
{
    protected $signature = 'tzcore:decision:diagnose {company_id} {lifecycle_event} {--violations=}';
    protected $description = 'Inspect tenant confidence tuning, policy overrides, and remediation hooks.';

    public function handle(DecisionDiagnosticsSuite $suite): int
    {
        $violations = array_values(array_filter(explode(',', (string) $this->option('violations'))));
        $snapshot = $suite->snapshot((int) $this->argument('company_id'), (string) $this->argument('lifecycle_event'), $violations);
        $this->line(json_encode($snapshot, JSON_PRETTY_PRINT));

        return self::SUCCESS;
    }
}
