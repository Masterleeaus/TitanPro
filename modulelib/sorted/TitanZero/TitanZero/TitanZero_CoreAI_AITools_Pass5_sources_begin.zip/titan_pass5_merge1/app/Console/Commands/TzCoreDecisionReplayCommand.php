<?php

namespace App\Console\Commands;

use App\Services\TitanCoreAI\DecisionLayer\Diagnostics\DecisionReplayService;
use Illuminate\Console\Command;

final class TzCoreDecisionReplayCommand extends Command
{
    protected $signature = 'tzcore:decision:replay {trace : Path to JSON trace file}';
    protected $description = 'Replay a stored decision trace through the Dev 3 control layer.';

    public function handle(DecisionReplayService $service): int
    {
        $path = (string) $this->argument('trace');
        if (!is_file($path)) {
            $this->error('Trace file not found.');
            return self::FAILURE;
        }

        $payload = json_decode((string) file_get_contents($path), true) ?: [];
        $result = $service->replay($payload);

        $this->info('Replay completed.');
        $this->line('Changed fields: '.implode(', ', $result['diff']['changed'] ?? []));

        return self::SUCCESS;
    }
}
