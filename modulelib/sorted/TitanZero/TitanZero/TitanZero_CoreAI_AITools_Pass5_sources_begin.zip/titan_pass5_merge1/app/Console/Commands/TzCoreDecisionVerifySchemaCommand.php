<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;

class TzCoreDecisionVerifySchemaCommand extends Command
{
    protected $signature = 'tzcore:decision-verify-schema';
    protected $description = 'Check the cumulative delta for company_id doctrine and duplicate migration hazards';

    public function handle(): int
    {
        $migrationPath = database_path('migrations');
        $files = File::exists($migrationPath) ? File::files($migrationPath) : [];
        $issues = [];

        foreach ($files as $file) {
            if (!str_contains($file->getFilename(), 'tz_core_')) {
                continue;
            }

            $contents = File::get($file->getPathname());

            if (str_contains($contents, "string('company_id')")) {
                $issues[] = $file->getFilename() . ': string company_id still present';
            }

            if (str_contains($contents, "index(['process_id'])") && !str_contains($contents, "process_id")) {
                $issues[] = $file->getFilename() . ': process_id indexed but not declared';
            }
        }

        if ($issues === []) {
            $this->info('tz_core schema verification passed.');
            return self::SUCCESS;
        }

        foreach ($issues as $issue) {
            $this->error($issue);
        }

        return self::FAILURE;
    }
}
