<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Services\CoreAI\Runtime\RuntimeBootstrapper;
use App\Services\CoreAI\Runtime\RuntimeOrchestratorSupport;
use App\Services\CoreAI\Repositories\CoreAIRepositoryRegistry;

class CoreAIRuntimeServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../../config/coreai_runtime.php', 'coreai_runtime');

        $this->app->singleton(CoreAIRepositoryRegistry::class, fn () => new CoreAIRepositoryRegistry());
        $this->app->singleton(RuntimeBootstrapper::class, fn ($app) => new RuntimeBootstrapper($app));
        $this->app->singleton(RuntimeOrchestratorSupport::class, fn ($app) => new RuntimeOrchestratorSupport($app));
    }

    public function boot(): void
    {
        $this->publishes([
            __DIR__ . '/../../config/coreai_runtime.php' => config_path('coreai_runtime.php'),
        ], 'coreai-runtime-config');
    }
}
