<?php

namespace App\Providers;

use App\Services\CoreAI\Runtime\CoreAiLifecycleRuntimeManager;
use App\Services\TitanCoreAI\CoreAiRuntimeBridge;
use Illuminate\Support\ServiceProvider;

class TitanCoreAiAggregateServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(config_path('core_ai.php'), 'core_ai');

        if (file_exists(config_path('coreai.php'))) {
            $this->mergeConfigFrom(config_path('coreai.php'), 'coreai');
        }

        $this->app->singleton(CoreAiRuntimeBridge::class, function ($app) {
            return new CoreAiRuntimeBridge(
                $app->make(CoreAiLifecycleRuntimeManager::class),
            );
        });
    }

    public function boot(): void
    {
        if (file_exists(config_path('titan_core_ai_bridge.php'))) {
            $this->mergeConfigFrom(config_path('titan_core_ai_bridge.php'), 'titan_core_ai_bridge');
        }
    }
}
