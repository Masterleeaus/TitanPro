<?php

namespace App\Providers;

use App\Console\Commands\TzCoreDecisionBackfillMatrixCommand;
use App\Console\Commands\TzCoreDecisionDiagnoseCommand;
use App\Console\Commands\TzCoreDecisionInstallCommand;
use App\Console\Commands\TzCoreDecisionReplayCommand;
use App\Console\Commands\TzCoreDecisionSmokeTest;
use App\Console\Commands\TzCoreDecisionVerifySchemaCommand;
use App\Console\Commands\TzCoreAssistantStudioDiagnoseCommand;
use App\Services\TitanCoreAI\DecisionLayer\Contracts\DecisionEngineInterface;
use App\Services\TitanCoreAI\DecisionLayer\Contracts\ExecutionGateInterface;
use App\Services\TitanCoreAI\DecisionLayer\Contracts\PersonaRouterInterface;
use App\Services\TitanCoreAI\DecisionLayer\Contracts\SchemaValidatorInterface;
use App\Services\TitanCoreAI\DecisionLayer\Contracts\ZeroArbitrationInterface;
use App\Services\TitanCoreAI\DecisionLayer\DecisionConfidenceEngine;
use App\Services\TitanCoreAI\DecisionLayer\Diagnostics\DecisionDiagnosticsSuite;
use App\Services\TitanCoreAI\DecisionLayer\Diagnostics\DecisionReplayService;
use App\Services\TitanCoreAI\DecisionLayer\ExecutionEligibilityGate;
use App\Services\TitanCoreAI\DecisionLayer\Integration\DecisionAdapterRegistry;
use App\Services\TitanCoreAI\DecisionLayer\Integration\DecisionHealthReport;
use App\Services\TitanCoreAI\DecisionLayer\Integration\DecisionLayerInstaller;
use App\Services\TitanCoreAI\DecisionLayer\Integration\DecisionLayerManifest;
use App\Services\TitanCoreAI\DecisionLayer\Integration\DecisionPayloadNormalizer;
use App\Services\TitanCoreAI\DecisionLayer\Integration\WorksuiteLifecycleEventBridge;
use App\Services\TitanCoreAI\DecisionLayer\PersonaExecutionRouter;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\BookingToJobLifecycleProfile;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\InvoicePaymentLifecycleProfile;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\JobCompletionLifecycleProfile;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\LifecycleProfileRegistry;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\NegativeFeedbackLifecycleProfile;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\StaffAbsenceLifecycleProfile;
use App\Services\TitanCoreAI\DecisionLayer\SchemaValidatorContracts;
use App\Services\TitanCoreAI\DecisionLayer\Support\AuditDecisionIndexer;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionLifecycleMap;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionReplayDiff;
use App\Services\TitanCoreAI\DecisionLayer\Support\PolicyOverrideRegistry;
use App\Services\TitanCoreAI\DecisionLayer\Support\SchemaAutoRemediationRegistry;
use App\Services\TitanCoreAI\DecisionLayer\Support\TenantConfidenceProfileResolver;
use App\Services\TitanCoreAI\DecisionLayer\Support\TenantDecisionSettings;
use App\Services\TitanCoreAI\DecisionLayer\ZeroArbitrationLayer;
use App\Services\TitanCoreAI\AssistantStudio\AssistantChannelDispatchRouter;
use App\Services\TitanCoreAI\AssistantStudio\AssistantDeploymentEligibilityService;
use App\Services\TitanCoreAI\AssistantStudio\AssistantDispatchTraceWriter;
use App\Services\TitanCoreAI\AssistantStudio\AssistantExecutionPolicyAdapter;
use App\Services\TitanCoreAI\AssistantStudio\AssistantLifecycleBindingResolver;
use App\Services\TitanCoreAI\AssistantStudio\AssistantSafetyEnvelopeBuilder;
use App\Services\TitanCoreAI\AssistantStudio\AssistantStudioAdapterRegistry;
use App\Services\TitanCoreAI\AssistantStudio\AssistantStudioDecisionBridge;
use App\Services\TitanCoreAI\AssistantStudio\Repositories\AssistantChannelRepository;
use App\Services\TitanCoreAI\AssistantStudio\Repositories\AssistantDispatchTraceRepository;
use App\Services\TitanCoreAI\AssistantStudio\Repositories\AssistantLifecycleBindingRepository;
use Illuminate\Support\ServiceProvider;

final class TzCoreDecisionServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__.'/../../config/tz_core_decision.php', 'tz_core_decision');

        $this->app->singleton(LifecycleProfileRegistry::class, function () {
            return new LifecycleProfileRegistry([
                new BookingToJobLifecycleProfile(),
                new JobCompletionLifecycleProfile(),
                new InvoicePaymentLifecycleProfile(),
                new NegativeFeedbackLifecycleProfile(),
                new StaffAbsenceLifecycleProfile(),
            ]);
        });

        $this->app->singleton(DecisionLifecycleMap::class, fn () => new DecisionLifecycleMap(config('tz_core_decision.lifecycle_event_map', [])));
        $this->app->singleton(DecisionLayerManifest::class, fn () => new DecisionLayerManifest(config('tz_core_decision.manifest', [])));
        $this->app->singleton(TenantDecisionSettings::class, fn () => new TenantDecisionSettings(config('tz_core_decision.tenant_defaults', [])));
        $this->app->singleton(DecisionPayloadNormalizer::class);
        $this->app->singleton(DecisionAdapterRegistry::class);
        $this->app->singleton(WorksuiteLifecycleEventBridge::class);
        $this->app->singleton(DecisionHealthReport::class);
        $this->app->singleton(DecisionLayerInstaller::class);
        $this->app->singleton(TenantConfidenceProfileResolver::class);
        $this->app->singleton(PolicyOverrideRegistry::class);
        $this->app->singleton(SchemaAutoRemediationRegistry::class);
        $this->app->singleton(DecisionReplayDiff::class);
        $this->app->singleton(AuditDecisionIndexer::class);
        $this->app->singleton(DecisionReplayService::class);
        $this->app->singleton(DecisionDiagnosticsSuite::class);

        $this->app->singleton(AssistantLifecycleBindingRepository::class);
        $this->app->singleton(AssistantChannelRepository::class);
        $this->app->singleton(AssistantDispatchTraceRepository::class);
        $this->app->singleton(AssistantLifecycleBindingResolver::class);
        $this->app->singleton(AssistantChannelDispatchRouter::class);
        $this->app->singleton(AssistantSafetyEnvelopeBuilder::class);
        $this->app->singleton(AssistantExecutionPolicyAdapter::class);
        $this->app->singleton(AssistantDeploymentEligibilityService::class);
        $this->app->singleton(AssistantDispatchTraceWriter::class);
        $this->app->singleton(AssistantStudioDecisionBridge::class);
        $this->app->singleton(AssistantStudioAdapterRegistry::class, fn () => new AssistantStudioAdapterRegistry(config('tz_core_decision.assistant_studio.adapter_registry', [])));

        $this->app->bind(DecisionEngineInterface::class, DecisionConfidenceEngine::class);
        $this->app->bind(PersonaRouterInterface::class, PersonaExecutionRouter::class);
        $this->app->bind(SchemaValidatorInterface::class, SchemaValidatorContracts::class);
        $this->app->bind(ExecutionGateInterface::class, ExecutionEligibilityGate::class);
        $this->app->bind(ZeroArbitrationInterface::class, ZeroArbitrationLayer::class);
    }

    public function boot(): void
    {
        $this->publishes([
            __DIR__.'/../../config/tz_core_decision.php' => config_path('tz_core_decision.php'),
        ], 'tz-core-decision-config');

        if ($this->app->runningInConsole()) {
            $this->commands([
                TzCoreDecisionSmokeTest::class,
                TzCoreDecisionInstallCommand::class,
                TzCoreDecisionBackfillMatrixCommand::class,
                TzCoreDecisionReplayCommand::class,
                TzCoreDecisionDiagnoseCommand::class,
                TzCoreDecisionVerifySchemaCommand::class,
                TzCoreAssistantStudioDiagnoseCommand::class,
            ]);
        }
    }
}
