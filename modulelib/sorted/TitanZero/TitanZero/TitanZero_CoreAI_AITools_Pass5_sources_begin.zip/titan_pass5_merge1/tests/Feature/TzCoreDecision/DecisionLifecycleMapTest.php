<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionLifecycleMap;
use PHPUnit\Framework\TestCase;

final class DecisionLifecycleMapTest extends TestCase
{
    public function test_it_normalizes_source_event_names(): void
    {
        $map = new DecisionLifecycleMap([
            'booking_created' => 'booking_to_job',
            'job_completed' => 'job_completion_processing',
        ]);

        $this->assertSame('booking_to_job', $map->normalize('booking_created'));
        $this->assertSame('job_completion_processing', $map->normalize('job_completed'));
        $this->assertSame('invoice_paid', $map->normalize('invoice_paid'));
    }
}
