<?php

namespace Tests\Feature\TzCoreDecision;

use PHPUnit\Framework\TestCase;

class MigrationConsistencyTest extends TestCase
{
    public function test_no_string_company_id_left_in_tz_core_migrations(): void
    {
        $paths = glob(__DIR__ . '/../../../database/migrations/*tz_core*.php');
        $contents = implode("\n", array_map('file_get_contents', $paths));

        $this->assertStringNotContainsString("string('company_id')", $contents);
        $this->assertStringNotContainsString("index(['process_id']);", $contents);
    }
}
