<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\CoreAIDecisionOrchestrator;
use PHPUnit\Framework\TestCase;

class CoreAIDecisionOrchestratorTest extends TestCase
{
    public function test_class_exists(): void
    {
        $this->assertTrue(class_exists(CoreAIDecisionOrchestrator::class));
    }
}
