<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Repositories\ExecutionAuditLogRepository;
use PHPUnit\Framework\TestCase;

final class ExecutionAuditLogRepositoryStubTest extends TestCase
{
    public function test_repository_class_exists(): void
    {
        $this->assertTrue(class_exists(ExecutionAuditLogRepository::class));
    }
}
