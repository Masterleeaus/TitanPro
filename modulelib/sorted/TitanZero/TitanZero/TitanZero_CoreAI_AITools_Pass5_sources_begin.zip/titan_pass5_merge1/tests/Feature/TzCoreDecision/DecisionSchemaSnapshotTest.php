<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionSchemaSnapshot;
use PHPUnit\Framework\TestCase;

final class DecisionSchemaSnapshotTest extends TestCase
{
    public function test_it_captures_core_schema_and_execution_flags(): void
    {
        $snapshot = new DecisionSchemaSnapshot();
        $data = $snapshot->capture([
            'required_fields_present' => true,
            'field_types_valid' => true,
            'entity_relationships_resolved' => false,
            'financial_values_verified' => true,
        ], [
            'policy_outcome' => 'ZERO_REVIEW',
        ], [
            'outcome' => 'hold',
        ]);

        $this->assertSame('ZERO_REVIEW', $data['policy_outcome']);
        $this->assertSame('hold', $data['execution_outcome']);
        $this->assertFalse($data['entity_relationships_resolved']);
    }
}
