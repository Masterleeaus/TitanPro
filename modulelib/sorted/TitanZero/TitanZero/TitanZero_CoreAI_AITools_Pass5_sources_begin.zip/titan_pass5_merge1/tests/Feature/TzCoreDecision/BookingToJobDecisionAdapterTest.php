<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Integration\Adapters\BookingToJobDecisionAdapter;
use PHPUnit\Framework\TestCase;

class BookingToJobDecisionAdapterTest extends TestCase
{
    public function test_adapter_marks_missing_customer_id(): void
    {
        $adapter = new BookingToJobDecisionAdapter();
        $payload = $adapter->adapt([
            'event_type' => 'booking_created',
            'company_id' => 1,
            'booking_id' => 22,
            'quoted_amount' => 185.50,
        ]);

        $this->assertSame('booking_to_job', $payload['lifecycle_event']);
        $this->assertContains('customer_id', $payload['missing_fields']);
        $this->assertSame(185.50, $payload['financial_exposure']);
    }
}
