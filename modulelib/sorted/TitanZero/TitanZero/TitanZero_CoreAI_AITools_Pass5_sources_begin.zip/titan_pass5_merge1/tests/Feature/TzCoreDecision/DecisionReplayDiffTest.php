<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionReplayDiff;
use PHPUnit\Framework\TestCase;

class DecisionReplayDiffTest extends TestCase
{
    public function test_it_detects_changed_fields(): void
    {
        $diff = (new DecisionReplayDiff())->compare([
            'outcome' => 'hold',
            'confidence' => 0.71,
        ], [
            'outcome' => 'execute',
            'confidence' => 0.93,
        ]);

        $this->assertSame(2, $diff['count']);
        $this->assertContains('outcome', $diff['changed']);
    }
}
