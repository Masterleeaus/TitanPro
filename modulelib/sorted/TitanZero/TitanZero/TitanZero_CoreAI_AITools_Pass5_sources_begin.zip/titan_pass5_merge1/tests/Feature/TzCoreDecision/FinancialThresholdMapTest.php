<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Support\FinancialThresholdMap;
use PHPUnit\Framework\TestCase;

final class FinancialThresholdMapTest extends TestCase
{
    public function test_returns_thresholds_array(): void
    {
        $map = new FinancialThresholdMap();
        $this->assertIsArray($map->thresholds());
    }
}
