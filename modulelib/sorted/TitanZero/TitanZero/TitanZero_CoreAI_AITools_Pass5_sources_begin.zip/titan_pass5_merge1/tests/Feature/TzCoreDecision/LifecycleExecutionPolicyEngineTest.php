<?php

namespace Tests\Feature\TzCoreDecision;

use PHPUnit\Framework\TestCase;
use App\Services\TitanCoreAI\DecisionLayer\LifecycleExecutionPolicyEngine;
use App\Services\TitanCoreAI\DecisionLayer\LifecycleSafetyMatrix;
use App\Services\TitanCoreAI\DecisionLayer\Repositories\LifecycleSafetyMatrixRepository;
use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;

class LifecycleExecutionPolicyEngineTest extends TestCase
{
    public function test_it_blocks_hard_financial_thresholds(): void
    {
        $repo = new class extends LifecycleSafetyMatrixRepository {
            public function findByLifecycleEvent(string $lifecycleEvent): ?array {
                return ['minimum_confidence' => 0.90, 'required_personas' => ['Finance', 'Logic', 'Zero'], 'approval_mode' => 'FINANCE_APPROVAL', 'automation_allowed' => false];
            }
        };

        $engine = new LifecycleExecutionPolicyEngine(new LifecycleSafetyMatrix($repo));
        $context = new DecisionContext(1, 'p', 'invoice_payment_confirmation', 'critical', [], [], 20000);

        $result = $engine->resolve($context, ['valid' => true], 0.96);

        $this->assertTrue($result['blocked']);
    }
}
