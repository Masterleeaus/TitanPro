<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Diagnostics\DecisionDiagnosticsSuite;
use App\Services\TitanCoreAI\DecisionLayer\Support\PolicyOverrideRegistry;
use App\Services\TitanCoreAI\DecisionLayer\Support\SchemaAutoRemediationRegistry;
use App\Services\TitanCoreAI\DecisionLayer\Support\TenantConfidenceProfileResolver;
use PHPUnit\Framework\TestCase;

class DecisionDiagnosticsSuiteTest extends TestCase
{
    public function test_it_builds_snapshot(): void
    {
        $profiles = new class extends TenantConfidenceProfileResolver {
            public function __construct() {}
            public function resolve(int $companyId, string $lifecycleEvent): array { return ['profile_key' => 'demo']; }
        };
        $overrides = new class extends PolicyOverrideRegistry {
            public function __construct() {}
            public function resolve(int $companyId, string $lifecycleEvent): array { return ['approval_mode' => 'ZERO_REVIEW']; }
        };
        $remediations = new class extends SchemaAutoRemediationRegistry {
            public function __construct() {}
            public function suggest(string $lifecycleEvent, array $violations, array $payload = []): array { return [['violation_key' => 'missing_customer_id']]; }
        };

        $suite = new DecisionDiagnosticsSuite($profiles, $overrides, $remediations);
        $snapshot = $suite->snapshot(7, 'booking_to_job', ['missing_customer_id']);

        $this->assertSame('demo', $snapshot['confidence_profile']['profile_key']);
        $this->assertSame('ZERO_REVIEW', $snapshot['policy_overrides']['approval_mode']);
        $this->assertSame('missing_customer_id', $snapshot['remediation_hooks'][0]['violation_key']);
    }
}
