<?php

namespace Tests\Feature\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\Policies\FinancialThresholdEvaluator;
use PHPUnit\Framework\TestCase;

class FinancialThresholdEvaluatorTest extends TestCase
{
    public function test_it_selects_correct_threshold_band(): void
    {
        $evaluator = new FinancialThresholdEvaluator();
        $this->assertSame('auto_execute', $evaluator->evaluate(100));
        $this->assertSame('manager_approval', $evaluator->evaluate(700));
        $this->assertSame('finance_approval', $evaluator->evaluate(2000));
        $this->assertSame('blocked', $evaluator->evaluate(8000));
    }
}
