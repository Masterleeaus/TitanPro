<?php

namespace Tests\Feature\TzCoreDecision;

use App\Console\Commands\TzCoreDecisionVerifySchemaCommand;
use PHPUnit\Framework\TestCase;

class TzCoreDecisionVerifySchemaCommandTest extends TestCase
{
    public function test_command_exists(): void
    {
        $this->assertTrue(class_exists(TzCoreDecisionVerifySchemaCommand::class));
    }
}
