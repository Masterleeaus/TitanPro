<?php

namespace Tests\Feature\TzCoreDecision;

use PHPUnit\Framework\TestCase;
use App\Services\TitanCoreAI\DecisionLayer\ZeroArbitrationLayer;
use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;

class ZeroArbitrationLayerTest extends TestCase
{
    public function test_it_normalizes_negative_feedback_tone_to_empathetic(): void
    {
        $layer = new ZeroArbitrationLayer();
        $context = new DecisionContext(1, 'p', 'negative_feedback_remediation', 'high');

        $result = $layer->refine($context, [
            'schema' => ['valid' => true],
            'alignment' => ['consensus_decision' => 'hold'],
            'confidence' => ['band' => 'zero_review'],
            'execution' => ['outcome' => 'escalate', 'approval_mode' => 'MANAGER_APPROVAL'],
            'routing' => ['persona_sequence' => ['Creative', 'Logic', 'Zero']],
        ]);

        $this->assertSame('empathetic', $result['normalized_tone']);
    }
}
