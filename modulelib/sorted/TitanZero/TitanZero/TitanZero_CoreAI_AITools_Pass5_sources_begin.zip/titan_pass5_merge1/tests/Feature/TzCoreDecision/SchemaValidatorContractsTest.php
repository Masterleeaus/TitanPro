<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\SchemaValidatorContracts;
use PHPUnit\Framework\TestCase;

class SchemaValidatorContractsTest extends TestCase
{
    public function test_it_detects_missing_fields(): void
    {
        $service = new SchemaValidatorContracts();
        $report = $service->validate(new DecisionContext(1, 'p2', 'booking_to_job', 'low', ['company_id' => 1]));
        $this->assertFalse($report['valid']);
    }
}
