<?php

namespace Tests\Feature\TitanCoreAI\AssistantStudio;

use App\Services\TitanCoreAI\AssistantStudio\AssistantSafetyEnvelopeBuilder;
use App\Services\TitanCoreAI\AssistantStudio\DTOs\AssistantDeploymentContext;
use PHPUnit\Framework\TestCase;

class AssistantSafetyEnvelopeBuilderTest extends TestCase
{
    public function test_it_merges_decision_and_dispatch_reason_codes(): void
    {
        $context = new AssistantDeploymentContext(1, 'ast-1', 'p-1', 'job_completion_processing', 'webchat');
        $envelope = (new AssistantSafetyEnvelopeBuilder())->build($context, [
            'outcome' => 'execute',
            'approval_mode' => 'AUTO_EXECUTE',
            'confidence_score' => 0.96,
            'reason_codes' => ['ZERO_REVIEW_REQUIRED'],
        ], [
            'dispatch_allowed' => true,
            'reason_codes' => ['CHANNEL_READY'],
        ]);

        self::assertContains('ZERO_REVIEW_REQUIRED', $envelope['reason_codes']);
        self::assertContains('CHANNEL_READY', $envelope['reason_codes']);
    }
}
