<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Repositories\PolicyOverrideRepository;
use App\Services\TitanCoreAI\DecisionLayer\Support\PolicyOverrideRegistry;
use PHPUnit\Framework\TestCase;

class PolicyOverrideRegistryTest extends TestCase
{
    public function test_it_merges_multiple_override_payloads(): void
    {
        $repository = new class extends PolicyOverrideRepository {
            public function findActive(string $lifecycleEvent, int $companyId): array
            {
                return [
                    ['override_payload' => json_encode(['automation_allowed' => false])],
                    ['override_payload' => json_encode(['approval_mode' => 'MANAGER_APPROVAL'])],
                ];
            }
        };

        $registry = new PolicyOverrideRegistry($repository);
        $resolved = $registry->resolve(1, 'negative_feedback_remediation');

        $this->assertFalse($resolved['automation_allowed']);
        $this->assertSame('MANAGER_APPROVAL', $resolved['approval_mode']);
    }
}
