<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\InvoicePaymentLifecycleProfile;
use PHPUnit\Framework\TestCase;

final class InvoicePaymentLifecycleProfileTest extends TestCase
{
    public function test_profile_key_matches_event(): void
    {
        $context = new DecisionContext(
            companyId: 1,
            processId: 'proc-1',
            lifecycleEvent: 'invoice_payment_confirmation',
            riskLevel: 'medium',
            missingFields: [],
            financialExposure: 0,
            policyRequirements: [],
            tenantSettings: [],
            payload: [],
            personaOutputs: [],
        );

        $profile = new InvoicePaymentLifecycleProfile();

        $this->assertSame('invoice_payment_confirmation', $profile->key());
        $this->assertSame('invoice_payment_confirmation', $profile->zeroProfile($context)['event_key']);
    }
}
