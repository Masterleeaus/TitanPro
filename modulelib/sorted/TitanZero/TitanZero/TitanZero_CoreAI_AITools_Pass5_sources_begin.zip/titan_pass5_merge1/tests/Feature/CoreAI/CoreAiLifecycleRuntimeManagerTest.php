<?php

namespace Tests\Feature\CoreAI;

use App\Services\CoreAI\AiOrchestrator;
use App\Services\CoreAI\Runtime\CoreAiLifecycleRuntimeManager;
use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionResult;
use App\Services\TitanCoreAI\DecisionLayer\Integration\WorksuiteLifecycleEventBridge;
use PHPUnit\Framework\TestCase;

class CoreAiLifecycleRuntimeManagerTest extends TestCase
{
    public function test_it_merges_runtime_and_decision_results(): void
    {
        $runtime = $this->createMock(AiOrchestrator::class);
        $bridge = $this->createMock(WorksuiteLifecycleEventBridge::class);

        $runtime->expects($this->once())
            ->method('orchestrate')
            ->willReturn([
                'tenant_settings' => ['provider' => 'openai'],
                'stage_outputs' => ['Zero' => ['status' => 'prepared', 'summary' => 'ok']],
                'final' => ['persona' => 'Zero', 'status' => 'consolidated'],
            ]);

        $bridge->expects($this->once())
            ->method('handle')
            ->willReturn(new DecisionResult(
                outcome: 'approved',
                approvalMode: 'auto',
                confidenceScore: 0.91,
                personaSequence: ['Zero'],
                tokenBudget: ['Zero' => 1200],
                reasonCodes: ['schema_valid'],
                escalations: [],
                zeroRefinement: ['summary' => 'approved'],
                audit: ['id' => 1],
                trace: ['id' => 2],
            ));

        $manager = new CoreAiLifecycleRuntimeManager($runtime, $bridge);
        $result = $manager->handle(['company_id' => 12, 'lifecycle_event' => 'booking_to_job']);

        $this->assertSame('approved', $result['decision']['outcome']);
        $this->assertSame('openai', $result['runtime']['tenant_settings']['provider']);
        $this->assertSame('consolidated', $result['runtime']['final']['status']);
    }
}
