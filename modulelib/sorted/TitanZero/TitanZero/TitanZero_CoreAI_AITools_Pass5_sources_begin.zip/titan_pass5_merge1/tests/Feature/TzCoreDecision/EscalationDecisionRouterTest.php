<?php

namespace Tests\Feature\TzCoreDecision;

use PHPUnit\Framework\TestCase;
use App\Services\TitanCoreAI\DecisionLayer\EscalationDecisionRouter;
use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;

class EscalationDecisionRouterTest extends TestCase
{
    public function test_it_routes_schema_violations_to_logic(): void
    {
        $router = new EscalationDecisionRouter();
        $context = new DecisionContext(1, 'p', 'booking_to_job', 'medium');

        $result = $router->route($context, ['valid' => false], ['alignment_score' => 1.0], 0.90);

        $this->assertSame('Logic', $result['target']);
    }
}
