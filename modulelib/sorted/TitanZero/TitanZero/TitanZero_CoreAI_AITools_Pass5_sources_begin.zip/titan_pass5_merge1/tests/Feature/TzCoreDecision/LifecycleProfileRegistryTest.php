<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\BookingToJobLifecycleProfile;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\LifecycleProfileRegistry;
use PHPUnit\Framework\TestCase;

final class LifecycleProfileRegistryTest extends TestCase
{
    public function test_resolves_profile_for_context(): void
    {
        $registry = new LifecycleProfileRegistry([new BookingToJobLifecycleProfile()]);
        $context = new DecisionContext(1, 'proc-1', 'booking_to_job', 'low', [], 0, [], [], [], []);

        $this->assertSame('booking_to_job', $registry->forContext($context)->key());
    }
}
