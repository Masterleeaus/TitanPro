<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Integration\Adapters\InvoicePaymentDecisionAdapter;
use PHPUnit\Framework\TestCase;

class InvoicePaymentDecisionAdapterTest extends TestCase
{
    public function test_adapter_requires_payment_reference(): void
    {
        $adapter = new InvoicePaymentDecisionAdapter();
        $payload = $adapter->adapt([
            'event_type' => 'invoice_paid',
            'company_id' => 7,
            'invoice_id' => 90,
            'invoice_amount' => 600,
            'paid_amount' => 600,
        ]);

        $this->assertContains('payment_reference', $payload['missing_fields']);
        $this->assertSame('invoice_payment_confirmation', $payload['lifecycle_event']);
    }
}
