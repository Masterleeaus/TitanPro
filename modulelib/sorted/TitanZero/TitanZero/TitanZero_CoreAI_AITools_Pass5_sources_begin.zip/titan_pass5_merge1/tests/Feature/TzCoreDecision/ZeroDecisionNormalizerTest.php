<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Support\ZeroDecisionNormalizer;
use PHPUnit\Framework\TestCase;

final class ZeroDecisionNormalizerTest extends TestCase
{
    public function test_maps_aliases_to_core_outcomes(): void
    {
        $normalizer = new ZeroDecisionNormalizer();
        $this->assertSame('execute', $normalizer->normalize('approve'));
        $this->assertSame('reject', $normalizer->normalize('deny'));
    }
}
