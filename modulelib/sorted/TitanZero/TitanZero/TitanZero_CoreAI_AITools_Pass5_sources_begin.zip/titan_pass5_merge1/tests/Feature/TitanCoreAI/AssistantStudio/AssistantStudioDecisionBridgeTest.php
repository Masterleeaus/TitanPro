<?php

namespace Tests\Feature\TitanCoreAI\AssistantStudio;

use App\Services\TitanCoreAI\AssistantStudio\AssistantStudioDecisionBridge;
use App\Services\TitanCoreAI\AssistantStudio\AssistantExecutionPolicyAdapter;
use App\Services\TitanCoreAI\AssistantStudio\AssistantDeploymentEligibilityService;
use App\Services\TitanCoreAI\AssistantStudio\AssistantChannelDispatchRouter;
use App\Services\TitanCoreAI\AssistantStudio\AssistantSafetyEnvelopeBuilder;
use App\Services\TitanCoreAI\AssistantStudio\AssistantDispatchTraceWriter;
use App\Services\TitanCoreAI\AssistantStudio\DTOs\AssistantDeploymentContext;
use PHPUnit\Framework\TestCase;

class AssistantStudioDecisionBridgeTest extends TestCase
{
    public function test_it_returns_full_processing_bundle(): void
    {
        $policy = new class extends AssistantExecutionPolicyAdapter { public function __construct() {} public function evaluate(AssistantDeploymentContext $context): array { return ['outcome' => 'execute', 'approval_mode' => 'AUTO_EXECUTE', 'confidence_score' => 0.93, 'reason_codes' => ['AUTO_OK'], 'trace' => [], 'audit' => [], 'rollback_eligible' => true]; } };
        $eligibility = new class extends AssistantDeploymentEligibilityService { public function __construct() {} public function evaluate(AssistantDeploymentContext $context, array $decision): array { return ['allowed' => true, 'binding' => [], 'reason_codes' => []]; } };
        $dispatch = new class extends AssistantChannelDispatchRouter { public function __construct() {} public function dispatch(AssistantDeploymentContext $context, array $eligibility): array { return ['dispatch_allowed' => true, 'reason_codes' => [], 'channel' => ['channel_key' => 'webchat'], 'dispatch_mode' => 'dispatch']; } };
        $trace = new class extends AssistantDispatchTraceWriter { public function __construct() {} public function write(AssistantDeploymentContext $context, array $envelope, array $decision, array $dispatch): array { return ['trace_written' => true]; } };

        $bridge = new AssistantStudioDecisionBridge($policy, $eligibility, $dispatch, new AssistantSafetyEnvelopeBuilder(), $trace);
        $result = $bridge->process(new AssistantDeploymentContext(1, 'ast-1', 'p-1', 'booking_to_job', 'webchat'));

        self::assertTrue($result['dispatch']['dispatch_allowed']);
        self::assertSame('execute', $result['decision']['outcome']);
        self::assertTrue($result['trace']['trace_written']);
    }
}
