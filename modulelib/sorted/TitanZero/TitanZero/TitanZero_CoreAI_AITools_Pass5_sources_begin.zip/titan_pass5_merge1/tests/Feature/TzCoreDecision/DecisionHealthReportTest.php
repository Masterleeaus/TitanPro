<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Integration\DecisionHealthReport;
use App\Services\TitanCoreAI\DecisionLayer\Integration\DecisionLayerManifest;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionLifecycleMap;
use PHPUnit\Framework\TestCase;

final class DecisionHealthReportTest extends TestCase
{
    public function test_it_reports_merge_ready_state(): void
    {
        $report = new DecisionHealthReport(
            new DecisionLayerManifest([
                'module' => 'Titan CoreAI Decision Layer',
                'version' => '0.7.0-delta',
                'tenant_column' => 'company_id',
                'supports' => ['decision_confidence'],
            ]),
            new DecisionLifecycleMap(['booking_created' => 'booking_to_job'])
        );

        $data = $report->generate();

        $this->assertSame('ready_for_merge', $data['status']);
        $this->assertSame('company_id', $data['tenant_column']);
    }
}
