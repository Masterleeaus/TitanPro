<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\LifecycleSafetyMatrix;
use App\Services\TitanCoreAI\DecisionLayer\PersonaExecutionRouter;
use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Resolvers\TokenBudgetAllocator;
use PHPUnit\Framework\TestCase;

class PersonaExecutionRouterTest extends TestCase
{
    public function test_it_builds_persona_sequence(): void
    {
        $router = new PersonaExecutionRouter(new LifecycleSafetyMatrix(), new TokenBudgetAllocator());
        $route = $router->route(new DecisionContext(1, 'p3', 'booking_to_job', 'medium', []), 0.8, ['valid' => true]);
        $this->assertContains('zero', $route['persona_sequence']);
    }
}
