<?php

namespace Tests\Feature\TitanCoreAI\AssistantStudio;

use App\Services\TitanCoreAI\AssistantStudio\AssistantLifecycleBindingResolver;
use App\Services\TitanCoreAI\AssistantStudio\Repositories\AssistantLifecycleBindingRepository;
use App\Services\TitanCoreAI\DecisionLayer\LifecycleSafetyMatrix;
use PHPUnit\Framework\TestCase;

class AssistantLifecycleBindingResolverTest extends TestCase
{
    public function test_it_flags_missing_required_personas(): void
    {
        $repo = new class extends AssistantLifecycleBindingRepository {
            public function activeBinding(int|string $companyId, string $assistantId, string $lifecycleEvent): ?\App\Models\TzCore\AssistantLifecycleBinding
            {
                $binding = new \App\Models\TzCore\AssistantLifecycleBinding();
                $binding->binding_rules = ['personas' => ['Micro', 'Logic']];
                return $binding;
            }
        };

        $matrix = new LifecycleSafetyMatrix([
            'booking_to_job' => ['required_personas' => ['Micro', 'Logic', 'Zero']],
        ]);

        $result = (new AssistantLifecycleBindingResolver($repo, $matrix))->resolve(1, 'ast-1', 'booking_to_job');

        self::assertFalse($result['valid']);
        self::assertContains('Zero', $result['missing_personas']);
    }
}
