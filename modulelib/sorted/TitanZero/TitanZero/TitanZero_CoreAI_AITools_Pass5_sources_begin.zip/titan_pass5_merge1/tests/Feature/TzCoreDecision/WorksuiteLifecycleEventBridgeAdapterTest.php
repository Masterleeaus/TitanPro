<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Integration\WorksuiteLifecycleEventBridge;
use PHPUnit\Framework\TestCase;

class WorksuiteLifecycleEventBridgeAdapterTest extends TestCase
{
    public function test_class_exists(): void
    {
        $this->assertTrue(class_exists(WorksuiteLifecycleEventBridge::class));
    }
}
