<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Repositories\AuditIndexRepository;
use App\Services\TitanCoreAI\DecisionLayer\Support\AuditDecisionIndexer;
use PHPUnit\Framework\TestCase;

class AuditDecisionIndexerTest extends TestCase
{
    public function test_it_indexes_minimal_audit_payload(): void
    {
        $captured = [];
        $repository = new class($captured) extends AuditIndexRepository {
            public array $captured = [];
            public function __construct(array $captured = []) { $this->captured = $captured; }
            public function insert(array $data): void { $this->captured = $data; }
        };

        $indexer = new AuditDecisionIndexer($repository);
        $indexer->index([
            'company_id' => 4,
            'process_id' => 'p-1',
            'lifecycle_event' => 'job_completion_processing',
            'outcome' => 'hold',
        ], [
            'confidence' => ['confidence_score' => 0.74],
        ], [
            'approval_mode' => 'MANAGER_APPROVAL',
            'reason_codes' => ['LOW_CONFIDENCE'],
        ]);

        $this->assertSame('p-1', $repository->captured['process_id']);
        $this->assertSame('MANAGER_APPROVAL', $repository->captured['approval_mode']);
    }
}
