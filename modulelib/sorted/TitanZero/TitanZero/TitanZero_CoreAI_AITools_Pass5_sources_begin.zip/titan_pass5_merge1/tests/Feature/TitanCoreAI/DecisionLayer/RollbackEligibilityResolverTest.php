<?php

namespace Tests\Feature\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\Resolvers\RollbackEligibilityResolver;
use PHPUnit\Framework\TestCase;

class RollbackEligibilityResolverTest extends TestCase
{
    public function test_it_marks_rollback_eligible_for_clean_executed_decisions(): void
    {
        $resolver = new RollbackEligibilityResolver();
        $result = $resolver->resolve([
            'outcome' => 'execute',
            'schema_valid' => true,
            'financial_settled' => false,
        ]);

        $this->assertTrue($result['rollback_eligible']);
        $this->assertSame('soft', $result['rollback_mode']);
    }
}
