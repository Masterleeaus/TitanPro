<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\StaffAbsenceLifecycleProfile;
use PHPUnit\Framework\TestCase;

final class StaffAbsenceLifecycleProfileTest extends TestCase
{
    public function test_profile_key_matches_event(): void
    {
        $context = new DecisionContext(
            companyId: 1,
            processId: 'proc-1',
            lifecycleEvent: 'staff_absence_replacement_handling',
            riskLevel: 'medium',
            missingFields: [],
            financialExposure: 0,
            policyRequirements: [],
            tenantSettings: [],
            payload: [],
            personaOutputs: [],
        );

        $profile = new StaffAbsenceLifecycleProfile();

        $this->assertSame('staff_absence_replacement_handling', $profile->key());
        $this->assertSame('staff_absence_replacement_handling', $profile->zeroProfile($context)['event_key']);
    }
}
