<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\JobCompletionLifecycleProfile;
use PHPUnit\Framework\TestCase;

final class JobCompletionLifecycleProfileTest extends TestCase
{
    public function test_profile_key_matches_event(): void
    {
        $context = new DecisionContext(
            companyId: 1,
            processId: 'proc-1',
            lifecycleEvent: 'job_completion_processing',
            riskLevel: 'medium',
            missingFields: [],
            financialExposure: 0,
            policyRequirements: [],
            tenantSettings: [],
            payload: [],
            personaOutputs: [],
        );

        $profile = new JobCompletionLifecycleProfile();

        $this->assertSame('job_completion_processing', $profile->key());
        $this->assertSame('job_completion_processing', $profile->zeroProfile($context)['event_key']);
    }
}
