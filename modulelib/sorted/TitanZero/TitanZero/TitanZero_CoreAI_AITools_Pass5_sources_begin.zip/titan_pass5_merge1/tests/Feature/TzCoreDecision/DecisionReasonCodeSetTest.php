<?php

namespace Tests\Feature\TzCoreDecision;

use PHPUnit\Framework\TestCase;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionReasonCodeSet;

class DecisionReasonCodeSetTest extends TestCase
{
    public function test_it_collects_reason_codes_from_multiple_failure_signals(): void
    {
        $codes = DecisionReasonCodeSet::fromSignals([
            'schema_valid' => false,
            'alignment_score' => 0.40,
            'confidence_score' => 0.45,
            'financial_exposure' => 2000,
            'financial_mode' => 'FINANCE_APPROVAL',
            'policy_blocked' => true,
            'requires_zero_review' => true,
            'automation_denied' => true,
            'manual_required' => true,
        ]);

        $this->assertContains('schema_block', $codes);
        $this->assertContains('low_confidence', $codes);
        $this->assertContains('policy_blocked', $codes);
    }
}
