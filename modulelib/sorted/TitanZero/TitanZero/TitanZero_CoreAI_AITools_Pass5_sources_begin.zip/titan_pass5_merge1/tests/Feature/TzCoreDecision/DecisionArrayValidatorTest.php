<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionArrayValidator;
use PHPUnit\Framework\TestCase;

final class DecisionArrayValidatorTest extends TestCase
{
    public function test_it_reports_missing_required_keys(): void
    {
        $validator = new DecisionArrayValidator();
        $result = $validator->validate([
            'company_id' => 1,
            'lifecycle_event' => 'booking_to_job',
        ], ['company_id', 'process_id', 'lifecycle_event']);

        $this->assertFalse($result['valid']);
        $this->assertSame(['process_id'], $result['missing']);
    }
}
