<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Repositories\SchemaRemediationHookRepository;
use App\Services\TitanCoreAI\DecisionLayer\Support\SchemaAutoRemediationRegistry;
use PHPUnit\Framework\TestCase;

class SchemaAutoRemediationRegistryTest extends TestCase
{
    public function test_it_returns_matching_hook_suggestions(): void
    {
        $repository = new class extends SchemaRemediationHookRepository {
            public function forLifecycle(string $lifecycleEvent): array
            {
                return [[
                    'violation_key' => 'missing_staff_assignment',
                    'hook_type' => 'fill_default',
                    'target_field' => 'staff_assignment_mode',
                    'hook_payload' => json_encode(['default' => 'manual_dispatch']),
                ]];
            }
        };

        $registry = new SchemaAutoRemediationRegistry($repository);
        $hooks = $registry->suggest('booking_to_job', ['missing_staff_assignment']);

        $this->assertCount(1, $hooks);
        $this->assertSame('manual_dispatch', $hooks[0]['suggested_patch']['staff_assignment_mode']);
    }
}
