<?php

namespace Tests\Feature\TzCoreDecision;

use PHPUnit\Framework\TestCase;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionContextFactory;

class DecisionContextFactoryTest extends TestCase
{
    public function test_it_infers_risk_from_financial_exposure(): void
    {
        $factory = new DecisionContextFactory();
        $context = $factory->make([
            'company_id' => 1,
            'process_id' => 'p-1',
            'lifecycle_event' => 'invoice_payment_confirmation',
            'financial_exposure' => 3000,
        ]);

        $this->assertSame('high', $context->riskLevel);
    }
}
