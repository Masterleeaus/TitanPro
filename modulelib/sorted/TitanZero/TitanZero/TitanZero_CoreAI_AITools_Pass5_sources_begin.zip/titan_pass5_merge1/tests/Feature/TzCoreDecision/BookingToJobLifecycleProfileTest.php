<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\BookingToJobLifecycleProfile;
use PHPUnit\Framework\TestCase;

final class BookingToJobLifecycleProfileTest extends TestCase
{
    public function test_profile_key_matches_event(): void
    {
        $context = new DecisionContext(
            companyId: 1,
            processId: 'proc-1',
            lifecycleEvent: 'booking_to_job',
            riskLevel: 'medium',
            missingFields: [],
            financialExposure: 0,
            policyRequirements: [],
            tenantSettings: [],
            payload: [],
            personaOutputs: [],
        );

        $profile = new BookingToJobLifecycleProfile();

        $this->assertSame('booking_to_job', $profile->key());
        $this->assertSame('booking_to_job', $profile->zeroProfile($context)['event_key']);
    }
}
