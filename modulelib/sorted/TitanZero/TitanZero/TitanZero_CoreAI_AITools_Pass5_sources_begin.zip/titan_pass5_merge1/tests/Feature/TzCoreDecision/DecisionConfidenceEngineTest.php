<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\DecisionConfidenceEngine;
use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use PHPUnit\Framework\TestCase;

class DecisionConfidenceEngineTest extends TestCase
{
    public function test_it_scores_confidence(): void
    {
        $this->assertTrue(class_exists(DecisionConfidenceEngine::class));
        $context = new DecisionContext(1, 'p1', 'booking_to_job', 'medium', ['signal_validation_score' => 0.9]);
        $this->assertSame('booking_to_job', $context->lifecycleEvent);
    }
}
