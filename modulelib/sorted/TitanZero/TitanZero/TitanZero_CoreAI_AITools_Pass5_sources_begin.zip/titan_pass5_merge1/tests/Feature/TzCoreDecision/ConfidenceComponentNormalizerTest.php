<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Support\ConfidenceComponentNormalizer;
use PHPUnit\Framework\TestCase;

final class ConfidenceComponentNormalizerTest extends TestCase
{
    public function test_normalizes_component_bounds(): void
    {
        $normalizer = new ConfidenceComponentNormalizer();
        $result = $normalizer->normalize(['a' => 1.4, 'b' => -1, 'c' => 0.44444]);

        $this->assertSame(['a' => 1.0, 'b' => 0.0, 'c' => 0.4444], $result);
    }
}
