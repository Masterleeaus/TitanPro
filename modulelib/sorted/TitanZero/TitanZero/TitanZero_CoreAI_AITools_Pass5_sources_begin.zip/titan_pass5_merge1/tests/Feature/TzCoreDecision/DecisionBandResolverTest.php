<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionBandResolver;
use PHPUnit\Framework\TestCase;

final class DecisionBandResolverTest extends TestCase
{
    public function test_resolves_expected_band(): void
    {
        $resolver = new DecisionBandResolver();
        $this->assertSame('automation', $resolver->resolve(0.93));
        $this->assertSame('manual', $resolver->resolve(0.20));
    }
}
