<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Repositories\TenantConfidenceProfileRepository;
use App\Services\TitanCoreAI\DecisionLayer\Support\TenantConfidenceProfileResolver;
use PHPUnit\Framework\TestCase;

class TenantConfidenceProfileResolverTest extends TestCase
{
    public function test_it_returns_default_when_profile_missing(): void
    {
        $repository = new class extends TenantConfidenceProfileRepository {
            public function findActiveForCompany(int $companyId): ?array
            {
                return null;
            }
        };

        $resolver = new TenantConfidenceProfileResolver($repository);
        $profile = $resolver->resolve(44, 'booking_to_job');

        $this->assertSame([], $profile['weight_overrides']);
        $this->assertSame([], $profile['threshold_overrides']);
    }
}
