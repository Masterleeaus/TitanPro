<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Support\PersonaSequenceMerger;
use PHPUnit\Framework\TestCase;

final class PersonaSequenceMergerTest extends TestCase
{
    public function test_merges_without_duplicates(): void
    {
        $merger = new PersonaSequenceMerger();
        $this->assertSame(['Micro', 'Finance', 'Zero'], $merger->merge(['Micro', 'Finance'], ['Finance', 'Zero']));
    }
}
