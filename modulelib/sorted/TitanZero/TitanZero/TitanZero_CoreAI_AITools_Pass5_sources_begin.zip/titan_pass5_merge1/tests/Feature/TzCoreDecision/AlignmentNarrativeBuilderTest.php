<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Support\AlignmentNarrativeBuilder;
use PHPUnit\Framework\TestCase;

final class AlignmentNarrativeBuilderTest extends TestCase
{
    public function test_builds_human_readable_summary(): void
    {
        $builder = new AlignmentNarrativeBuilder();
        $text = $builder->build(['consensus_decision' => 'execute', 'alignment_score' => 0.83, 'contradictions' => [['a' => 1]]]);

        $this->assertStringContainsString('execute', $text);
        $this->assertStringContainsString('0.83', $text);
    }
}
