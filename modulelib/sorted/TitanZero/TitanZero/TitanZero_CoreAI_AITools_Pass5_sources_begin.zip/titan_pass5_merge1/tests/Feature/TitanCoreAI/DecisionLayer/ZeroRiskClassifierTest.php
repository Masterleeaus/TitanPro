<?php

namespace Tests\Feature\TitanCoreAI\DecisionLayer;

use App\Services\TitanCoreAI\DecisionLayer\Zero\ZeroRiskClassifier;
use PHPUnit\Framework\TestCase;

class ZeroRiskClassifierTest extends TestCase
{
    public function test_it_returns_high_for_low_confidence_or_high_exposure(): void
    {
        $classifier = new ZeroRiskClassifier();
        $this->assertSame('high', $classifier->classify(0.40, 100, true));
        $this->assertSame('high', $classifier->classify(0.90, 6000, true));
    }
}
