<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Integration\DecisionPayloadNormalizer;
use App\Services\TitanCoreAI\DecisionLayer\Support\DecisionLifecycleMap;
use PHPUnit\Framework\TestCase;

final class DecisionPayloadNormalizerTest extends TestCase
{
    public function test_it_normalizes_payload_for_bridge_usage(): void
    {
        $normalizer = new DecisionPayloadNormalizer(new DecisionLifecycleMap([
            'booking_created' => 'booking_to_job',
        ]));

        $normalized = $normalizer->normalize([
            'company_id' => 44,
            'event' => 'booking_created',
            'amount' => 320,
            'payload' => ['job_id' => 51],
        ]);

        $this->assertSame(44, $normalized['company_id']);
        $this->assertSame('booking_to_job', $normalized['lifecycle_event']);
        $this->assertSame(320.0, $normalized['financial_exposure']);
        $this->assertSame('worksuite', $normalized['payload']['source']);
    }
}
