<?php

namespace Tests\Feature\TitanCoreAI\AssistantStudio;

use App\Services\TitanCoreAI\AssistantStudio\AssistantDeploymentEligibilityService;
use App\Services\TitanCoreAI\AssistantStudio\AssistantLifecycleBindingResolver;
use App\Services\TitanCoreAI\AssistantStudio\DTOs\AssistantDeploymentContext;
use PHPUnit\Framework\TestCase;

class AssistantDeploymentEligibilityServiceTest extends TestCase
{
    public function test_it_requires_binding_and_minimum_confidence(): void
    {
        $resolver = new class extends AssistantLifecycleBindingResolver {
            public function __construct() {}
            public function resolve(int|string $companyId, string $assistantId, string $lifecycleEvent): array
            {
                return ['valid' => true, 'reason_codes' => []];
            }
        };

        $service = new AssistantDeploymentEligibilityService($resolver);
        $context = new AssistantDeploymentContext(1, 'ast-1', 'p-1', 'booking_to_job', 'webchat', ['is_active' => true], [], ['is_active' => true], [], []);

        $result = $service->evaluate($context, ['outcome' => 'execute', 'confidence_score' => 0.94]);

        self::assertTrue($result['allowed']);
    }
}
