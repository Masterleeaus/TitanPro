<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\Integration\DecisionAdapterRegistry;
use PHPUnit\Framework\TestCase;

class DecisionAdapterRegistryTest extends TestCase
{
    public function test_class_exists(): void
    {
        $this->assertTrue(class_exists(DecisionAdapterRegistry::class));
    }
}
