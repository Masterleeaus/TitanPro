<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\ExecutionEligibilityGate;
use App\Services\TitanCoreAI\DecisionLayer\Resolvers\ExecutionOutcomeResolver;
use App\Services\TitanCoreAI\DecisionLayer\Resolvers\ReasonCodeResolver;
use PHPUnit\Framework\TestCase;

class ExecutionEligibilityGateTest extends TestCase
{
    public function test_it_returns_outcome(): void
    {
        $gate = new ExecutionEligibilityGate(new ExecutionOutcomeResolver(), new ReasonCodeResolver());
        $result = $gate->decide(new DecisionContext(1, 'p4', 'booking_to_job', 'medium', []), ['policy' => ['approval_mode' => 'AUTO_EXECUTE'], 'schema' => ['valid' => true], 'alignment' => [], 'confidence' => ['confidence_score' => 0.95]]);
        $this->assertSame('execute', $result['outcome']);
    }
}
