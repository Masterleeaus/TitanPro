<?php

namespace Tests\Feature\TzCoreDecision;

use App\Services\TitanCoreAI\DecisionLayer\DTOs\DecisionContext;
use App\Services\TitanCoreAI\DecisionLayer\Profiles\NegativeFeedbackLifecycleProfile;
use PHPUnit\Framework\TestCase;

final class NegativeFeedbackLifecycleProfileTest extends TestCase
{
    public function test_profile_key_matches_event(): void
    {
        $context = new DecisionContext(
            companyId: 1,
            processId: 'proc-1',
            lifecycleEvent: 'negative_feedback_remediation',
            riskLevel: 'medium',
            missingFields: [],
            financialExposure: 0,
            policyRequirements: [],
            tenantSettings: [],
            payload: [],
            personaOutputs: [],
        );

        $profile = new NegativeFeedbackLifecycleProfile();

        $this->assertSame('negative_feedback_remediation', $profile->key());
        $this->assertSame('negative_feedback_remediation', $profile->zeroProfile($context)['event_key']);
    }
}
