<?php

return [
    'default_provider' => env('COREAI_DEFAULT_PROVIDER', 'openai'),
    'default_reasoning_model' => env('COREAI_DEFAULT_REASONING_MODEL', 'gpt-4.1-mini'),
    'default_embedding_model' => env('COREAI_DEFAULT_EMBEDDING_MODEL', 'text-embedding-3-small'),
    'default_image_model' => env('COREAI_DEFAULT_IMAGE_MODEL', 'gpt-image-1'),
    'default_export_disk' => env('COREAI_EXPORT_DISK', 'local'),
    'memory' => [
        'max_entries_per_scope' => (int) env('COREAI_MEMORY_MAX_ENTRIES', 200),
        'default_retention_days' => (int) env('COREAI_MEMORY_RETENTION_DAYS', 90),
        'audit_retention_days' => (int) env('COREAI_MEMORY_AUDIT_RETENTION_DAYS', 365),
    ],
    'metering' => [
        'soft_quota_warning_ratio' => (float) env('COREAI_SOFT_QUOTA_WARNING_RATIO', 0.85),
    ],
    'multimodal' => [
        'image_mime_types' => ['image/jpeg', 'image/png', 'image/webp'],
        'document_mime_types' => [
            'application/pdf',
            'text/markdown',
            'text/plain',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-excel',
        ],
    ],
    'routing' => [
        'fallback_provider' => env('COREAI_FALLBACK_PROVIDER', 'openai'),
    ],
    'exports' => [
        'json_prefix' => env('COREAI_EXPORT_JSON_PREFIX', 'coreai/exports'),
    ],
];
