<?php

return [
    'memory' => [
        'default_ttl_minutes' => 720,
        'evidence_tags' => ['audit', 'decision', 'compliance', 'customer-impact'],
    ],
    'retrieval' => [
        'default_limit' => 8,
        'allowed_sources' => ['tenant', 'platform-default'],
    ],
    'budgets' => [
        'default_stage_token_budget' => 12000,
        'warn_at_percent' => 80,
    ],
    'telemetry' => [
        'emit_runtime_frames' => true,
        'rollup_window_minutes' => 60,
    ],
    'handoff' => [
        'persist_dev3_payloads' => true,
        'integrity_hash' => 'sha256',
    ],
];
