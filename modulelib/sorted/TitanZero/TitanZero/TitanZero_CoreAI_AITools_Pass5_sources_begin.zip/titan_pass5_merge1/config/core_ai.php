<?php

return array_replace_recursive(require __DIR__ . '/coreai.php', [
    'default_model' => env('COREAI_DEFAULT_MODEL', env('COREAI_DEFAULT_REASONING_MODEL', 'gpt-4.1-mini')),
    'default_persona' => env('COREAI_DEFAULT_PERSONA', 'Zero'),
    'default_temperature' => (float) env('COREAI_DEFAULT_TEMPERATURE', 0.2),
    'default_max_tokens' => (int) env('COREAI_DEFAULT_MAX_TOKENS', 1200),
    'providers' => [
        'openai' => [
            'enabled' => env('COREAI_OPENAI_ENABLED', true),
            'api_key' => env('OPENAI_API_KEY'),
            'base_url' => env('OPENAI_BASE_URL', 'https://api.openai.com/v1'),
            'reasoning_model' => env('COREAI_OPENAI_REASONING_MODEL', env('COREAI_DEFAULT_REASONING_MODEL', 'gpt-4.1-mini')),
            'embedding_model' => env('COREAI_OPENAI_EMBEDDING_MODEL', env('COREAI_DEFAULT_EMBEDDING_MODEL', 'text-embedding-3-small')),
            'image_model' => env('COREAI_OPENAI_IMAGE_MODEL', env('COREAI_DEFAULT_IMAGE_MODEL', 'gpt-image-1')),
        ],
    ],
    'personas' => [
        'Micro' => ['slug' => 'micro', 'label' => 'Micro', 'temperature' => 0.1, 'max_tokens' => 500],
        'Logic' => ['slug' => 'logic', 'label' => 'Logic', 'temperature' => 0.1, 'max_tokens' => 900],
        'Finance' => ['slug' => 'finance', 'label' => 'Finance', 'temperature' => 0.05, 'max_tokens' => 900],
        'Creative' => ['slug' => 'creative', 'label' => 'Creative', 'temperature' => 0.5, 'max_tokens' => 900],
        'Macro' => ['slug' => 'macro', 'label' => 'Macro', 'temperature' => 0.2, 'max_tokens' => 900],
        'Entropy' => ['slug' => 'entropy', 'label' => 'Entropy', 'temperature' => 0.35, 'max_tokens' => 800],
        'Zero' => ['slug' => 'zero', 'label' => 'Zero', 'temperature' => 0.15, 'max_tokens' => 1200],
    ],
    'lifecycle_pipelines' => [
        'booking_to_job' => ['personas' => ['Micro', 'Logic', 'Finance', 'Zero']],
        'job_completed' => ['personas' => ['Micro', 'Logic', 'Creative', 'Zero']],
        'invoice_paid' => ['personas' => ['Finance', 'Logic', 'Zero']],
        'negative_feedback' => ['personas' => ['Logic', 'Creative', 'Entropy', 'Zero']],
        'staff_absence' => ['personas' => ['Micro', 'Logic', 'Macro', 'Zero']],
    ],
]);
