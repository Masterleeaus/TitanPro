<?php

return [
    'weights' => [
        'schema_completeness' => 0.18,
        'entity_linkage_integrity' => 0.12,
        'signal_validation_status' => 0.10,
        'persona_agreement' => 0.16,
        'financial_exposure' => 0.10,
        'policy_alignment' => 0.12,
        'missing_enrichment_penalty' => 0.08,
        'contradiction_penalty' => 0.08,
        'historical_correction_frequency' => 0.06,
    ],

    'confidence' => [
        'automation' => 0.92,
        'zero_review' => 0.75,
        'specialist_escalation' => 0.50,
    ],

    'financial_thresholds' => [
        'auto_execute' => 250,
        'zero_review' => 1000,
        'finance_approval' => 2500,
        'blocked' => 10000,
    ],

    'reason_codes' => [
        'SCHEMA_BLOCK',
        'PERSONA_CONFLICT',
        'LOW_CONFIDENCE',
        'FINANCIAL_RISK',
        'POLICY_BLOCKED',
        'ZERO_REVIEW_REQUIRED',
        'AUTOMATION_DENIED',
        'MANUAL_REVIEW_REQUIRED',
    ],

    'max_automation_financial_exposure' => 1000,

    'tenant_defaults' => [
        'automation_enabled' => true,
        'zero_required' => true,
        'max_automation_financial_exposure' => 1000,
        'allow_negative_feedback_auto_credit' => false,
        'allow_staff_absence_auto_reassignment' => false,
    ],

    'tenant_profile_defaults' => [
        'weight_overrides' => [],
        'threshold_overrides' => [],
        'lifecycle_overrides' => [],
    ],

    'diagnostics' => [
        'enable_replay_persistence' => true,
        'enable_audit_indexing' => true,
        'enable_schema_remediation_suggestions' => true,
    ],

    'manifest' => [
        'module' => 'Titan CoreAI Decision Layer',
        'version' => '1.0.0-delta-pass10',
        'owner' => 'AI Core Developer 3',
        'tenant_column' => 'company_id',
        'table_prefix' => 'tz_core_',
        'supports' => [
            'decision_confidence',
            'schema_contracts',
            'execution_policy',
            'escalation_governance',
            'zero_arbitration',
            'rollback_eligibility',
            'diagnostics',
            'trace_replay',
            'policy_overrides',
            'worksuite_inbound_adapters',
            'db_consistency_repairs',
        ],
    ],

    'lifecycle_event_map' => [
        'booking_created' => 'booking_to_job',
        'booking_promoted' => 'booking_to_job',
        'job_completed' => 'job_completion_processing',
        'invoice_paid' => 'invoice_payment_confirmation',
        'feedback_negative' => 'negative_feedback_remediation',
        'staff_absent' => 'staff_absence_replacement',
    ],

    'payload_versions' => [
        'worksuite' => 'v1',
    ],

    'integration' => [
        'worksuite' => [
            'process_id_prefix' => 'tzcore',
            'event_source' => 'worksuite',
            'prefer_company_id' => true,
            'adapters' => [
                'booking_created' => 'booking_to_job',
                'job_completed' => 'job_completion_processing',
                'invoice_paid' => 'invoice_payment_confirmation',
                'feedback_negative' => 'negative_feedback_remediation',
                'staff_absent' => 'staff_absence_replacement',
            ],
        ],
    ],


    'assistant_studio' => [
        'enabled' => true,
        'channel_defaults' => [
            'assistant_channels_enabled' => true,
            'default_dispatch_mode' => 'hold',
        ],
        'adapter_registry' => [
            'binding_resolver' => \App\Services\TitanCoreAI\AssistantStudio\AssistantLifecycleBindingResolver::class,
            'execution_policy' => \App\Services\TitanCoreAI\AssistantStudio\AssistantExecutionPolicyAdapter::class,
            'eligibility' => \App\Services\TitanCoreAI\AssistantStudio\AssistantDeploymentEligibilityService::class,
            'dispatch_router' => \App\Services\TitanCoreAI\AssistantStudio\AssistantChannelDispatchRouter::class,
            'safety_envelope' => \App\Services\TitanCoreAI\AssistantStudio\AssistantSafetyEnvelopeBuilder::class,
            'decision_bridge' => \App\Services\TitanCoreAI\AssistantStudio\AssistantStudioDecisionBridge::class,
        ],
    ],
];
