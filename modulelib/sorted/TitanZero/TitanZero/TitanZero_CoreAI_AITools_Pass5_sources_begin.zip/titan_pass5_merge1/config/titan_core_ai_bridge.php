<?php

return [
    'runtime_service' => App\Services\CoreAI\AiOrchestrator::class,
    'decision_service' => App\Services\TitanCoreAI\DecisionLayer\CoreAIDecisionOrchestrator::class,
    'bridge_service' => App\Services\TitanCoreAI\CoreAiRuntimeBridge::class,
    'module_surface' => 'Modules/AITools',
];
