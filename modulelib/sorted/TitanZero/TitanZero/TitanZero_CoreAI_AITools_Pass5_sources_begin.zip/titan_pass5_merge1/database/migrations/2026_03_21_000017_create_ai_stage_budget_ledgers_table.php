<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_stage_budget_ledgers', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('pipeline_run_id')->nullable();
            $table->string('step_key')->nullable();
            $table->string('persona_key')->nullable();
            $table->unsignedInteger('budget_tokens')->default(0);
            $table->unsignedInteger('used_tokens')->default(0);
            $table->unsignedInteger('remaining_tokens')->default(0);
            $table->decimal('cost_estimate', 12, 4)->default(0);
            $table->longText('meta_json')->nullable();
            $table->timestamps();

            $table->index(['pipeline_run_id', 'step_key']);
            $table->index(['persona_key']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_stage_budget_ledgers');
    }
};
