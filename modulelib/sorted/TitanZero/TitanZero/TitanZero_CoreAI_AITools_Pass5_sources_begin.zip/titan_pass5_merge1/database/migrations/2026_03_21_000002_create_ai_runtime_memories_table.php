<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_runtime_memories', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('scope')->index();
            $table->string('scope_key')->index();
            $table->unsignedBigInteger('assistant_id')->nullable()->index();
            $table->string('entity_type')->nullable()->index();
            $table->string('entity_id')->nullable()->index();
            $table->string('memory_kind')->default('reasoning_buffer')->index();
            $table->json('payload')->nullable();
            $table->json('evidence_payload')->nullable();
            $table->boolean('is_audit_locked')->default(false)->index();
            $table->timestamp('expires_at')->nullable()->index();
            $table->timestamp('last_used_at')->nullable()->index();
            $table->timestamps();

            $table->index(['company_id', 'scope', 'scope_key'], 'ai_runtime_mem_scope_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_runtime_memories');
    }
};
