<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tz_core_ai_memories', function (Blueprint $table) {
            if (!Schema::hasColumn('tz_core_ai_memories', 'memory_key')) {
                $table->string('memory_key')->nullable()->after('memory_kind');
            }
            if (!Schema::hasColumn('tz_core_ai_memories', 'memory_value')) {
                $table->json('memory_value')->nullable()->after('memory_key');
            }
        });

        Schema::table('tz_core_ai_embeddings', function (Blueprint $table) {
            if (!Schema::hasColumn('tz_core_ai_embeddings', 'metadata')) {
                $table->json('metadata')->nullable()->after('training_binding');
            }
            if (!Schema::hasColumn('tz_core_ai_embeddings', 'training_pack')) {
                $table->string('training_pack')->nullable()->after('metadata');
            }
        });

        Schema::table('tz_core_ai_file_records', function (Blueprint $table) {
            if (!Schema::hasColumn('tz_core_ai_file_records', 'source_type')) {
                $table->string('source_type')->nullable()->after('company_id');
            }
            if (!Schema::hasColumn('tz_core_ai_file_records', 'source_key')) {
                $table->string('source_key')->nullable()->after('source_type');
            }
            if (!Schema::hasColumn('tz_core_ai_file_records', 'metadata')) {
                $table->json('metadata')->nullable()->after('attachment_meta');
            }
        });
    }

    public function down(): void
    {
        // additive normalization only
    }
};
