<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_tools', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('tool_key')->unique();
            $table->string('name');
            $table->string('channel')->nullable();
            $table->json('input_schema')->nullable();
            $table->json('output_schema')->nullable();
            $table->json('meta')->nullable();
            $table->timestamps();
        });
        Schema::create('ai_tool_persona_map', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('tool_id')->index();
            $table->string('persona_key')->index();
            $table->json('meta')->nullable();
            $table->timestamps();
        });
        Schema::create('ai_tool_entity_scope', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('tool_id')->index();
            $table->string('entity_type')->index();
            $table->string('lifecycle_stage')->nullable()->index();
            $table->json('meta')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('ai_tool_entity_scope');
        Schema::dropIfExists('ai_tool_persona_map');
        Schema::dropIfExists('ai_tools');
    }
};
