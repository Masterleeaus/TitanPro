<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        foreach (['ai_stage_transitions','ai_retry_metrics','ai_stage_duration','ai_schema_failures','ai_consolidation_corrections'] as $name) {
            Schema::create($name, function (Blueprint $table) use ($name) {
                $table->id();
                $table->unsignedBigInteger('company_id')->nullable()->index();
                $table->unsignedBigInteger('pipeline_run_id')->nullable()->index();
                $table->string('stage')->nullable()->index();
                $table->string('type')->nullable()->index();
                $table->unsignedInteger('duration_ms')->nullable();
                $table->json('payload')->nullable();
                $table->timestamps();
            });
        }
    }
    public function down(): void {
        foreach (['ai_consolidation_corrections','ai_schema_failures','ai_stage_duration','ai_retry_metrics','ai_stage_transitions'] as $name) {
            Schema::dropIfExists($name);
        }
    }
};
