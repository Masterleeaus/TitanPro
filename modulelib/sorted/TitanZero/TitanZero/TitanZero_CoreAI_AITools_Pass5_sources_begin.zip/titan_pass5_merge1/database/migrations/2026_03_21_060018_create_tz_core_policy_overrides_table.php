<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        
Schema::create('tz_core_policy_overrides', function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('company_id')->index();
    $table->string('lifecycle_event')->index();
    $table->string('override_key')->index();
    $table->json('override_payload');
    $table->unsignedInteger('priority')->default(100);
    $table->boolean('is_active')->default(true)->index();
    $table->timestamp('expires_at')->nullable();
    $table->timestamps();
});
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_policy_overrides');
    }
};
