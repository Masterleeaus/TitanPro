<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        
Schema::create('tz_core_persona_routes', function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('company_id')->nullable()->index();
    $table->string('process_id')->nullable()->index();
    $table->string('lifecycle_event')->nullable()->index();
    $table->string('risk_level')->nullable()->index();
    $table->json('persona_sequence')->nullable();
    $table->json('token_budget')->nullable();
    $table->boolean('escalation_required')->default(false)->index();
    $table->boolean('approval_required')->default(false)->index();
    $table->boolean('automation_allowed')->default(false)->index();
    $table->timestamps();
    $table->index(['company_id', 'lifecycle_event'], 'tz_core_routes_company_event_index');
});
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_persona_routes');
    }
};
