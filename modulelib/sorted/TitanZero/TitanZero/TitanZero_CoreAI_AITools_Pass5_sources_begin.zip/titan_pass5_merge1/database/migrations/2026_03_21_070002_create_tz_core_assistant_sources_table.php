<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('tz_core_assistant_sources', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('assistant_id')->index();
            $table->string('source_type')->index();
            $table->string('source_key')->index();
            $table->json('source_config')->nullable();
            $table->json('processing_state')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('tz_core_assistant_sources'); }
};