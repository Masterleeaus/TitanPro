<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_envelope_lineage', function (Blueprint $table) {
            $table->id();
            $table->string('envelope_id')->index();
            $table->string('parent_envelope_id')->nullable()->index();
            $table->string('root_envelope_id')->nullable()->index();
            $table->string('lifecycle_id')->nullable()->index();
            $table->json('meta')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_envelope_lineage');
    }
};
