<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_runtime_handoffs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable();
            $table->string('handoff_type', 120);
            $table->string('source_ref', 120)->nullable();
            $table->string('target_ref', 120)->nullable();
            $table->string('schema_version', 120)->nullable();
            $table->json('payload')->nullable();
            $table->string('payload_hash', 128)->nullable();
            $table->timestamps();
            $table->index(['company_id', 'handoff_type']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_runtime_handoffs');
    }
};
