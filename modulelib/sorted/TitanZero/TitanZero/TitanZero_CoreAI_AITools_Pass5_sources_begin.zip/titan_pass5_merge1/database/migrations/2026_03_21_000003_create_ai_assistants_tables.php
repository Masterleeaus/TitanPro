<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_assistants', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('name');
            $table->string('slug')->index();
            $table->string('persona_key')->default('zero')->index();
            $table->string('assistant_role')->default('lifecycle_assistant')->index();
            $table->json('settings')->nullable();
            $table->json('permissions')->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();

            $table->unique(['company_id', 'slug'], 'ai_assistants_company_slug_unique');
        });

        Schema::create('ai_assistant_entity_links', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('assistant_id')->index();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('entity_type')->index();
            $table->string('entity_id')->index();
            $table->timestamps();

            $table->unique(['assistant_id', 'entity_type', 'entity_id'], 'ai_assistant_entity_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_assistant_entity_links');
        Schema::dropIfExists('ai_assistants');
    }
};
