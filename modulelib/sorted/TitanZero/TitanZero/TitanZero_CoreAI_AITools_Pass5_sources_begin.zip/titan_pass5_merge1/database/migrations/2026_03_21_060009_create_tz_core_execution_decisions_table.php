<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        
Schema::create('tz_core_execution_decisions', function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('company_id')->nullable()->index();
    $table->string('process_id')->nullable()->index();
    $table->string('lifecycle_event')->nullable()->index();
    $table->string('outcome')->nullable()->index();
    $table->string('approval_mode')->nullable()->index();
    $table->boolean('automation_allowed')->default(false)->index();
    $table->json('reason_codes')->nullable();
    $table->json('decision_payload')->nullable();
    $table->timestamps();
});
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_execution_decisions');
    }
};
