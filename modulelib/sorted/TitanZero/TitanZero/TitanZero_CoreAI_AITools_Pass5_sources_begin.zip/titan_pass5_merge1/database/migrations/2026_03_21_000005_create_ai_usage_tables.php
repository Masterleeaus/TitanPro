<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_token_usage', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('provider_key')->index();
            $table->string('model_key')->nullable();
            $table->string('persona_key')->nullable()->index();
            $table->string('lifecycle_stage')->nullable()->index();
            $table->string('pipeline_run_key')->nullable()->index();
            $table->unsignedInteger('input_tokens')->default(0);
            $table->unsignedInteger('output_tokens')->default(0);
            $table->unsignedInteger('total_tokens')->default(0);
            $table->decimal('cost_amount', 12, 4)->default(0);
            $table->boolean('soft_quota_triggered')->default(false);
            $table->json('meta_json')->nullable();
            $table->timestamps();
        });

        Schema::create('ai_pipeline_usage', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('pipeline_run_key')->index();
            $table->string('lifecycle_event_key')->nullable()->index();
            $table->unsignedInteger('total_tokens')->default(0);
            $table->decimal('total_cost', 12, 4)->default(0);
            $table->boolean('soft_quota_triggered')->default(false);
            $table->json('meta_json')->nullable();
            $table->timestamps();
        });

        Schema::create('ai_provider_usage', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('provider_key')->index();
            $table->string('billing_window')->index();
            $table->unsignedInteger('total_tokens')->default(0);
            $table->decimal('total_cost', 12, 4)->default(0);
            $table->json('meta_json')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_provider_usage');
        Schema::dropIfExists('ai_pipeline_usage');
        Schema::dropIfExists('ai_token_usage');
    }
};
