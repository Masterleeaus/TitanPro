<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_runtime_handoff_payloads', function (Blueprint $table) {
            $table->id();
            $table->string('handoff_type');
            $table->unsignedBigInteger('company_id')->nullable();
            $table->string('lifecycle_event_key')->nullable();
            $table->string('persona_key')->nullable();
            $table->longText('payload_json');
            $table->timestamps();

            $table->index(['handoff_type', 'company_id']);
            $table->index(['lifecycle_event_key', 'persona_key']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_runtime_handoff_payloads');
    }
};
