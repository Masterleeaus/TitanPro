<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('tz_core_assistant_dispatch_traces', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('assistant_id')->index();
            $table->string('process_id')->index();
            $table->string('lifecycle_event')->index();
            $table->string('channel_key')->index();
            $table->string('dispatch_status')->default('hold')->index();
            $table->json('reason_codes')->nullable();
            $table->json('dispatch_payload')->nullable();
            $table->json('decision_trace')->nullable();
            $table->timestamp('dispatched_at')->nullable()->index();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('tz_core_assistant_dispatch_traces'); }
};