<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tz_core_ai_memories', function (Blueprint $table) {
            if (!Schema::hasColumn('tz_core_ai_memories', 'memory_payload')) {
                $table->json('memory_payload')->nullable()->after('summary');
            }
            if (!Schema::hasColumn('tz_core_ai_memories', 'meta')) {
                $table->json('meta')->nullable()->after('retention_flags');
            }
        });

        Schema::table('tz_core_ai_embeddings', function (Blueprint $table) {
            if (!Schema::hasColumn('tz_core_ai_embeddings', 'chunk_meta')) {
                $table->json('chunk_meta')->nullable()->after('embedding_vector');
            }
            if (!Schema::hasColumn('tz_core_ai_embeddings', 'training_binding')) {
                $table->json('training_binding')->nullable()->after('chunk_meta');
            }
        });
    }

    public function down(): void
    {
        // additive repair only
    }
};
