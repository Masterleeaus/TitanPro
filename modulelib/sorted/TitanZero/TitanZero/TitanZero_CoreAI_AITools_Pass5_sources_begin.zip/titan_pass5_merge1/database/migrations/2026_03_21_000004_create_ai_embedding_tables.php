<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_embedding_sources', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable();
            $table->string('source_key')->index();
            $table->string('name');
            $table->string('source_type')->index();
            $table->boolean('is_platform_default')->default(false);
            $table->boolean('is_active')->default(true);
            $table->json('meta_json')->nullable();
            $table->timestamps();
        });

        Schema::create('ai_embedding_chunks', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('source_id')->index();
            $table->string('chunk_key')->index();
            $table->string('title')->nullable();
            $table->string('persona_key')->nullable()->index();
            $table->string('lifecycle_stage')->nullable()->index();
            $table->longText('body');
            $table->json('embedding_vector')->nullable();
            $table->unsignedInteger('chunk_tokens')->default(0);
            $table->decimal('stage_weight', 8, 3)->default(1);
            $table->json('meta_json')->nullable();
            $table->timestamps();
        });

        Schema::create('ai_embedding_persona_map', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('source_id')->index();
            $table->string('persona_key')->index();
            $table->string('lifecycle_stage')->nullable()->index();
            $table->boolean('is_active')->default(true);
            $table->json('meta_json')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_embedding_persona_map');
        Schema::dropIfExists('ai_embedding_chunks');
        Schema::dropIfExists('ai_embedding_sources');
    }
};
