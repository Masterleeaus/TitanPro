<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tz_core_ai_memories', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->unsignedBigInteger('assistant_id')->nullable()->index();
            $table->string('assistant_slug')->nullable()->index();
            $table->string('entity_type')->nullable()->index();
            $table->unsignedBigInteger('entity_id')->nullable()->index();
            $table->string('lifecycle_stage')->nullable()->index();
            $table->string('memory_kind')->default('entity_context')->index();
            $table->string('summary')->nullable();
            $table->json('memory_payload')->nullable();
            $table->json('retention_flags')->nullable();
            $table->json('meta')->nullable();
            $table->boolean('is_pinned')->default(false);
            $table->timestamp('expires_at')->nullable();
            $table->timestamp('last_used_at')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_ai_embeddings', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('source_type')->default('markdown')->index();
            $table->string('source_key')->nullable()->index();
            $table->string('entity_type')->nullable()->index();
            $table->unsignedBigInteger('entity_id')->nullable()->index();
            $table->string('lifecycle_stage')->nullable()->index();
            $table->string('chunk_hash')->index();
            $table->longText('chunk_text');
            $table->json('embedding_vector')->nullable();
            $table->json('chunk_meta')->nullable();
            $table->json('training_binding')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_ai_assistants', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('name');
            $table->string('slug')->index();
            $table->string('assistant_type')->default('owner')->index();
            $table->string('entity_type')->nullable()->index();
            $table->unsignedBigInteger('entity_id')->nullable()->index();
            $table->json('permissions')->nullable();
            $table->json('persona_inheritance')->nullable();
            $table->json('entity_binding')->nullable();
            $table->json('meta')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('tz_core_ai_exports', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('export_type')->index();
            $table->string('format')->default('json')->index();
            $table->string('status')->default('prepared')->index();
            $table->json('payload')->nullable();
            $table->json('meta')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_ai_prompt_tests', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('persona')->nullable()->index();
            $table->string('scenario_key')->index();
            $table->json('input_payload')->nullable();
            $table->json('expected_schema')->nullable();
            $table->json('actual_output')->nullable();
            $table->json('regression_meta')->nullable();
            $table->decimal('score', 6, 2)->default(0);
            $table->timestamps();
        });

        Schema::create('tz_core_ai_tool_registry', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('name');
            $table->string('slug')->index();
            $table->string('tool_group')->default('general')->index();
            $table->json('tool_schema')->nullable();
            $table->json('meta')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('tz_core_ai_file_records', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('entity_type')->nullable()->index();
            $table->unsignedBigInteger('entity_id')->nullable()->index();
            $table->string('storage_disk')->nullable();
            $table->string('storage_path')->nullable();
            $table->string('filename')->nullable()->index();
            $table->string('mime_type')->nullable()->index();
            $table->json('classification')->nullable();
            $table->json('attachment_meta')->nullable();
            $table->boolean('is_pipeline_attached')->default(false);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_ai_file_records');
        Schema::dropIfExists('tz_core_ai_tool_registry');
        Schema::dropIfExists('tz_core_ai_prompt_tests');
        Schema::dropIfExists('tz_core_ai_exports');
        Schema::dropIfExists('tz_core_ai_assistants');
        Schema::dropIfExists('tz_core_ai_embeddings');
        Schema::dropIfExists('tz_core_ai_memories');
    }
};
