<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_decision_envelopes', function (Blueprint $table) {
            $table->id();
            $table->string('envelope_id')->unique();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedBigInteger('assistant_id')->nullable()->index();
            $table->string('lifecycle_id')->nullable()->index();
            $table->string('entity_type')->nullable()->index();
            $table->string('entity_id')->nullable()->index();
            $table->string('schema_version')->default('coreai.decision-envelope.v1');
            $table->decimal('confidence', 5, 4)->default(0);
            $table->string('validation_status')->default('pending')->index();
            $table->json('retrieval_sources')->nullable();
            $table->json('telemetry')->nullable();
            $table->json('payload')->nullable();
            $table->json('meta')->nullable();
            $table->string('hash', 64)->nullable()->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_decision_envelopes');
    }
};
