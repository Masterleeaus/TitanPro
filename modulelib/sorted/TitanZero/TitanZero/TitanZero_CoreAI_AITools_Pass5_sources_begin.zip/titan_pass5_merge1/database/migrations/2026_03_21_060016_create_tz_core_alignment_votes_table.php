<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tz_core_alignment_votes', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('process_id')->nullable()->index();
            $table->string('lifecycle_event')->nullable()->index();
            $table->string('persona')->nullable()->index();
            $table->string('stance')->nullable()->index();
            $table->decimal('confidence', 8, 4)->default(0);
            $table->json('vote_payload')->nullable();
            $table->timestamps();

            $table->index(['process_id', 'persona'], 'tz_core_alignment_process_persona_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_alignment_votes');
    }
};
