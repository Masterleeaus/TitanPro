<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tz_core_ai_personas', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('name');
            $table->string('slug')->index();
            $table->text('role')->nullable();
            $table->text('authority_boundary')->nullable();
            $table->string('model_preference')->nullable();
            $table->decimal('temperature', 4, 2)->default(0.20);
            $table->integer('max_tokens')->default(1200);
            $table->json('allowed_lifecycle_stages')->nullable();
            $table->json('training_pack')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_ai_persona_prompts', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedBigInteger('persona_id')->nullable()->index();
            $table->string('stage')->default('default');
            $table->string('title');
            $table->longText('prompt');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('tz_core_ai_prompt_templates', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('name');
            $table->string('category')->nullable();
            $table->string('persona')->nullable()->index();
            $table->longText('template');
            $table->json('meta')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_ai_usage_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('provider')->nullable();
            $table->string('model')->nullable();
            $table->string('persona')->nullable();
            $table->integer('prompt_tokens')->default(0);
            $table->integer('completion_tokens')->default(0);
            $table->integer('total_tokens')->default(0);
            $table->decimal('estimated_cost', 12, 4)->default(0);
            $table->json('meta')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_ai_audits', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('persona')->nullable()->index();
            $table->string('event_type')->nullable()->index();
            $table->string('entity_type')->nullable()->index();
            $table->unsignedBigInteger('entity_id')->nullable()->index();
            $table->text('decision_summary')->nullable();
            $table->json('request_payload')->nullable();
            $table->json('response_payload')->nullable();
            $table->decimal('confidence_score', 5, 2)->default(0);
            $table->timestamps();
        });

        Schema::create('tz_core_ai_tenant_settings', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('provider')->default('openai');
            $table->string('key_scope')->default('company');
            $table->text('api_key_encrypted')->nullable();
            $table->json('settings')->nullable();
            $table->boolean('is_verified')->default(false);
            $table->timestamp('verified_at')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_ai_entity_threads', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('entity_type')->index();
            $table->unsignedBigInteger('entity_id')->nullable()->index();
            $table->string('thread_type')->default('entity');
            $table->string('title')->nullable();
            $table->json('context_snapshot')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_ai_thread_messages', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('thread_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('role')->index();
            $table->longText('content')->nullable();
            $table->json('meta')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_ai_confidence_scores', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('persona')->nullable()->index();
            $table->string('event_type')->nullable()->index();
            $table->decimal('score', 5, 2)->default(0);
            $table->json('factors')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_lifecycle_events', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('event_key')->unique();
            $table->string('title');
            $table->json('pipeline')->nullable();
            $table->json('meta')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_pipeline_defs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedBigInteger('lifecycle_event_id')->nullable()->index();
            $table->string('name');
            $table->string('event_key')->index();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('tz_core_pipeline_steps', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedBigInteger('pipeline_def_id')->index();
            $table->integer('step_order')->default(1);
            $table->string('persona');
            $table->string('stage_key')->nullable();
            $table->integer('max_tokens')->default(1200);
            $table->decimal('temperature', 4, 2)->default(0.20);
            $table->json('output_schema')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_pipeline_runs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('pipeline_def_id')->nullable()->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('event_key')->index();
            $table->string('status')->default('initiated');
            $table->string('entity_type')->nullable()->index();
            $table->unsignedBigInteger('entity_id')->nullable()->index();
            $table->json('input_context')->nullable();
            $table->json('final_output')->nullable();
            $table->timestamps();
        });

        Schema::create('tz_core_pipeline_step_runs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('pipeline_run_id')->index();
            $table->unsignedBigInteger('pipeline_step_id')->nullable()->index();
            $table->string('persona')->nullable()->index();
            $table->integer('step_order')->default(1);
            $table->string('status')->default('initiated');
            $table->json('input_payload')->nullable();
            $table->json('output_payload')->nullable();
            $table->decimal('confidence_score', 5, 2)->default(0);
            $table->timestamps();
        });

        Schema::create('tz_core_zero_profiles', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('name')->default('Default Zero');
            $table->longText('system_prompt')->nullable();
            $table->json('profile_meta')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_zero_profiles');
        Schema::dropIfExists('tz_core_pipeline_step_runs');
        Schema::dropIfExists('tz_core_pipeline_runs');
        Schema::dropIfExists('tz_core_pipeline_steps');
        Schema::dropIfExists('tz_core_pipeline_defs');
        Schema::dropIfExists('tz_core_lifecycle_events');
        Schema::dropIfExists('tz_core_ai_confidence_scores');
        Schema::dropIfExists('tz_core_ai_thread_messages');
        Schema::dropIfExists('tz_core_ai_entity_threads');
        Schema::dropIfExists('tz_core_ai_tenant_settings');
        Schema::dropIfExists('tz_core_ai_audits');
        Schema::dropIfExists('tz_core_ai_usage_logs');
        Schema::dropIfExists('tz_core_ai_prompt_templates');
        Schema::dropIfExists('tz_core_ai_persona_prompts');
        Schema::dropIfExists('tz_core_ai_personas');
    }
};
