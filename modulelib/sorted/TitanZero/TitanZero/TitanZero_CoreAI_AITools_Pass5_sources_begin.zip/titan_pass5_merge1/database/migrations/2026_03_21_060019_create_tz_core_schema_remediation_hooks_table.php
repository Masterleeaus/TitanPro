<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        
Schema::create('tz_core_schema_remediation_hooks', function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('company_id')->nullable()->index();
    $table->string('lifecycle_event')->index();
    $table->string('violation_key')->index();
    $table->json('hook_payload')->nullable();
    $table->unsignedInteger('priority')->default(100);
    $table->boolean('is_active')->default(true)->index();
    $table->timestamps();
});
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_schema_remediation_hooks');
    }
};
