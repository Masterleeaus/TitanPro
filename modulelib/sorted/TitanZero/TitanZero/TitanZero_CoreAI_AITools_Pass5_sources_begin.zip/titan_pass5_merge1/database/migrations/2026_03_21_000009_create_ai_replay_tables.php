<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_pipeline_runs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('lifecycle_type')->index();
            $table->string('run_key')->unique();
            $table->string('status')->default('captured')->index();
            $table->json('meta')->nullable();
            $table->timestamps();
        });
        Schema::create('ai_pipeline_steps', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('pipeline_run_id')->index();
            $table->string('stage_key')->index();
            $table->string('persona_key')->nullable()->index();
            $table->unsignedInteger('step_order')->default(0);
            $table->string('status')->default('captured')->index();
            $table->json('input_payload')->nullable();
            $table->json('output_payload')->nullable();
            $table->timestamps();
        });
        Schema::create('ai_pipeline_snapshots', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('pipeline_run_id')->index();
            $table->string('snapshot_key')->unique();
            $table->string('snapshot_type')->index();
            $table->json('payload')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('ai_pipeline_snapshots');
        Schema::dropIfExists('ai_pipeline_steps');
        Schema::dropIfExists('ai_pipeline_runs');
    }
};
