<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_feature_eligibility', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('feature')->index();
            $table->string('tier')->nullable()->index();
            $table->boolean('eligible')->default(true);
            $table->json('metadata')->nullable();
            $table->timestamps();
        });
        Schema::create('ai_persona_eligibility', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('persona')->index();
            $table->string('tier')->nullable()->index();
            $table->boolean('eligible')->default(true);
            $table->json('metadata')->nullable();
            $table->timestamps();
        });
        Schema::create('ai_pipeline_eligibility', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('pipeline')->index();
            $table->string('tier')->nullable()->index();
            $table->boolean('eligible')->default(true);
            $table->json('metadata')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('ai_pipeline_eligibility');
        Schema::dropIfExists('ai_persona_eligibility');
        Schema::dropIfExists('ai_feature_eligibility');
    }
};
