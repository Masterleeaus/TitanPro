<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('tz_core_ai_memories', function (Blueprint $table) {
            if (!Schema::hasColumn('tz_core_ai_memories', 'assistant_id')) {
                $table->string('assistant_id')->nullable()->after('entity_id');
            }
            if (!Schema::hasColumn('tz_core_ai_memories', 'lifecycle_stage')) {
                $table->string('lifecycle_stage')->nullable()->after('assistant_id');
            }
            if (!Schema::hasColumn('tz_core_ai_memories', 'retention_flag')) {
                $table->string('retention_flag')->default('standard')->after('memory_value');
            }
            if (!Schema::hasColumn('tz_core_ai_memories', 'is_pinned')) {
                $table->boolean('is_pinned')->default(false)->after('retention_flag');
            }
            if (!Schema::hasColumn('tz_core_ai_memories', 'expires_at')) {
                $table->timestamp('expires_at')->nullable()->after('is_pinned');
            }
        });

        Schema::table('tz_core_ai_embeddings', function (Blueprint $table) {
            if (!Schema::hasColumn('tz_core_ai_embeddings', 'training_pack')) {
                $table->string('training_pack')->nullable()->after('lifecycle_stage');
            }
            if (!Schema::hasColumn('tz_core_ai_embeddings', 'metadata')) {
                $table->json('metadata')->nullable()->after('chunk_text');
            }
        });

        if (!Schema::hasTable('tz_core_ai_file_records')) {
            Schema::create('tz_core_ai_file_records', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id');
                $table->string('source_type')->nullable();
                $table->string('source_key')->nullable();
                $table->string('filename')->nullable();
                $table->string('mime_type')->nullable();
                $table->string('classification')->default('general_context');
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->index(['company_id', 'classification']);
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('tz_core_ai_file_records')) {
            Schema::dropIfExists('tz_core_ai_file_records');
        }
    }
};
