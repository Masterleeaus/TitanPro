<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_confidence_metrics', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('pipeline_key')->index();
            $table->string('stage_key')->nullable()->index();
            $table->string('persona_key')->nullable()->index();
            $table->decimal('schema_completeness', 5, 2)->default(0);
            $table->decimal('signal_alignment', 5, 2)->default(0);
            $table->decimal('lifecycle_consistency', 5, 2)->default(0);
            $table->decimal('aggregate_confidence', 5, 2)->default(0)->index();
            $table->json('meta')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('ai_confidence_metrics');
    }
};
