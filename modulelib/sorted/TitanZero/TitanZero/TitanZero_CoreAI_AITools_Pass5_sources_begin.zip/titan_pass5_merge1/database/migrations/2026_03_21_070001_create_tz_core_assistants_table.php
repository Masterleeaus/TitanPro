<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('tz_core_assistants', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('assistant_uid')->unique();
            $table->string('name');
            $table->string('slug')->index();
            $table->string('status')->default('draft')->index();
            $table->boolean('is_active')->default(false)->index();
            $table->json('capabilities')->nullable();
            $table->json('policy_overrides')->nullable();
            $table->json('settings')->nullable();
            $table->timestamps();
            $table->index(['company_id', 'slug']);
        });
    }
    public function down(): void { Schema::dropIfExists('tz_core_assistants'); }
};