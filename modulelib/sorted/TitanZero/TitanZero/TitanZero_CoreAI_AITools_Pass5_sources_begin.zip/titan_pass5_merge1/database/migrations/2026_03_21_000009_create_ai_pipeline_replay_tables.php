<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_pipeline_runs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('lifecycle_event')->nullable()->index();
            $table->string('entity_type')->nullable()->index();
            $table->string('entity_id')->nullable()->index();
            $table->string('status')->default('captured')->index();
            $table->string('schema_version')->nullable();
            $table->string('source_envelope_hash', 128)->nullable()->index();
            $table->json('meta_json')->nullable();
            $table->timestamps();
        });

        Schema::create('ai_pipeline_steps', function (Blueprint $table) {
            $table->id();
            $table->foreignId('pipeline_run_id')->constrained('ai_pipeline_runs')->cascadeOnDelete();
            $table->string('step_key')->index();
            $table->string('persona_key')->nullable()->index();
            $table->string('prompt_version')->nullable();
            $table->json('input_json')->nullable();
            $table->json('output_json')->nullable();
            $table->string('status')->default('captured')->index();
            $table->unsignedInteger('latency_ms')->nullable();
            $table->timestamps();
        });

        Schema::create('ai_pipeline_snapshots', function (Blueprint $table) {
            $table->id();
            $table->foreignId('pipeline_run_id')->constrained('ai_pipeline_runs')->cascadeOnDelete();
            $table->string('stage_key')->index();
            $table->json('snapshot_json');
            $table->string('snapshot_hash', 128)->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_pipeline_snapshots');
        Schema::dropIfExists('ai_pipeline_steps');
        Schema::dropIfExists('ai_pipeline_runs');
    }
};
