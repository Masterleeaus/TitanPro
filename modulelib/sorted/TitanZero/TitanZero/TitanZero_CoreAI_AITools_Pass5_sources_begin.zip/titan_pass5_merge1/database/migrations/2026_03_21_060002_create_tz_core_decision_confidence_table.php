<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        
Schema::create('tz_core_decision_confidence', function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('company_id')->nullable()->index();
    $table->string('process_id')->nullable()->index();
    $table->string('lifecycle_event')->nullable()->index();
    $table->decimal('confidence_score', 8, 4)->default(0)->index();
    $table->json('confidence_components')->nullable();
    $table->boolean('requires_escalation')->default(false)->index();
    $table->boolean('automation_eligible')->default(false)->index();
    $table->timestamps();
    $table->unique(['company_id', 'process_id', 'lifecycle_event'], 'tz_core_confidence_company_process_event_unique');
});
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_decision_confidence');
    }
};
