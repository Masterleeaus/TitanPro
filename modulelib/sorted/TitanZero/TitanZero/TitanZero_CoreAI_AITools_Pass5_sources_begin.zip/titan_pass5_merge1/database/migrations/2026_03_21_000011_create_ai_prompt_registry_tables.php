<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_prompt_categories', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('category_key')->unique();
            $table->string('name');
            $table->string('parent_key')->nullable()->index();
            $table->json('meta')->nullable();
            $table->timestamps();
        });
        Schema::create('ai_prompt_persona_map', function (Blueprint $table) {
            $table->id();
            $table->string('persona_key')->index();
            $table->string('category_key')->index();
            $table->json('meta')->nullable();
            $table->timestamps();
        });
        Schema::create('ai_prompt_stage_map', function (Blueprint $table) {
            $table->id();
            $table->string('lifecycle_stage')->index();
            $table->string('category_key')->index();
            $table->json('meta')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('ai_prompt_stage_map');
        Schema::dropIfExists('ai_prompt_persona_map');
        Schema::dropIfExists('ai_prompt_categories');
    }
};
