<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('coreai_prompt_tests', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('test_name')->index();
            $table->string('persona')->nullable()->index();
            $table->string('lifecycle_stage')->nullable()->index();
            $table->string('prompt_version')->nullable()->index();
            $table->json('input_payload')->nullable();
            $table->json('output_payload')->nullable();
            $table->json('metrics_json')->nullable();
            $table->timestamp('executed_at')->nullable()->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('coreai_prompt_tests');
    }
};

