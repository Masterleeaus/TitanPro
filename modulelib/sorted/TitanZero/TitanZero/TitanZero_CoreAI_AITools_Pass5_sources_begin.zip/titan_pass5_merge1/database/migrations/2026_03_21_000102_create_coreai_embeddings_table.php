<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('coreai_embeddings', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('source_type')->nullable()->index();
            $table->string('source_reference')->nullable();
            $table->string('lifecycle_stage')->nullable()->index();
            $table->string('training_pack_key')->nullable()->index();
            $table->unsignedInteger('chunk_index')->default(0);
            $table->longText('chunk_text');
            $table->json('source_meta')->nullable();
            $table->json('chunk_meta')->nullable();
            $table->json('embedding_meta')->nullable();
            $table->timestamp('indexed_at')->nullable()->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('coreai_embeddings');
    }
};

