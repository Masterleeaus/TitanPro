<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_training_packs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('slug')->unique();
            $table->string('name');
            $table->string('persona', 64)->default('Zero')->index();
            $table->json('stage_filters')->nullable();
            $table->json('meta_json')->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
        });

        Schema::create('ai_training_pack_sources', function (Blueprint $table) {
            $table->id();
            $table->foreignId('training_pack_id')->constrained('ai_training_packs')->cascadeOnDelete();
            $table->unsignedBigInteger('embedding_source_id')->nullable()->index();
            $table->string('lifecycle_stage', 64)->default('general')->index();
            $table->string('source_role', 64)->default('reference')->index();
            $table->json('meta_json')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_training_pack_sources');
        Schema::dropIfExists('ai_training_packs');
    }
};
