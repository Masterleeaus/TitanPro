<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tz_core_lifecycle_matrix', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('lifecycle_event')->index();
            $table->json('required_personas')->nullable();
            $table->decimal('minimum_confidence', 8, 4)->default(0);
            $table->string('approval_policy')->nullable()->index();
            $table->json('automation_eligibility')->nullable();
            $table->json('token_budget_defaults')->nullable();
            $table->json('escalation_defaults')->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();

            $table->unique(['company_id', 'lifecycle_event'], 'tz_core_matrix_company_event_unique');
            $table->index(['lifecycle_event', 'is_active'], 'tz_core_matrix_event_active_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_lifecycle_matrix');
    }
};
