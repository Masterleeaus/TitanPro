<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        
Schema::create('tz_core_persona_alignment', function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('company_id')->nullable()->index();
    $table->string('process_id')->nullable()->index();
    $table->string('lifecycle_event')->nullable()->index();
    $table->decimal('alignment_score', 8, 4)->default(0)->index();
    $table->json('alignment_payload')->nullable();
    $table->timestamps();
});
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_persona_alignment');
    }
};
