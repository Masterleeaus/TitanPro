<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('tz_core_assistant_personas', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('assistant_id')->index();
            $table->string('persona_key')->index();
            $table->json('persona_config')->nullable();
            $table->json('authority_scope')->nullable();
            $table->timestamps();
            $table->unique(['company_id', 'assistant_id', 'persona_key'], 'tz_core_assistant_personas_unique');
        });
    }
    public function down(): void { Schema::dropIfExists('tz_core_assistant_personas'); }
};