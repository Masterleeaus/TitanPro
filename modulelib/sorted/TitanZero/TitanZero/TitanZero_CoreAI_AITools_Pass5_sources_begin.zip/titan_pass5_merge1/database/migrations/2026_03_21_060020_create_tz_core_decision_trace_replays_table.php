<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        
Schema::create('tz_core_decision_trace_replays', function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('company_id')->index();
    $table->string('process_id')->nullable()->index();
    $table->string('lifecycle_event')->nullable()->index();
    $table->json('trace_payload');
    $table->json('replay_payload')->nullable();
    $table->string('trace_hash', 64)->nullable()->index();
    $table->timestamps();
});
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_decision_trace_replays');
    }
};
