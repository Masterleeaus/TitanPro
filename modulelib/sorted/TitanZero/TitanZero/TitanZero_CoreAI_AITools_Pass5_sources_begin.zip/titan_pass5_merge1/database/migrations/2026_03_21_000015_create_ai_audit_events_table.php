<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_audit_events', function (Blueprint $table) {
            $table->id();
            $table->uuid('event_uuid')->unique();
            $table->string('event_key');
            $table->unsignedBigInteger('pipeline_run_id')->nullable();
            $table->string('step_key')->nullable();
            $table->unsignedBigInteger('company_id')->nullable();
            $table->string('persona_key')->nullable();
            $table->string('provider_key')->nullable();
            $table->string('status')->default('recorded');
            $table->longText('payload_json')->nullable();
            $table->longText('meta_json')->nullable();
            $table->timestamp('recorded_at')->nullable();
            $table->timestamps();

            $table->index(['pipeline_run_id', 'event_key']);
            $table->index(['company_id', 'recorded_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_audit_events');
    }
};
