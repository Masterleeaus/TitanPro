<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('tz_core_assistant_channels', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('assistant_id')->index();
            $table->string('channel_key')->index();
            $table->boolean('is_active')->default(true)->index();
            $table->json('channel_config')->nullable();
            $table->json('deployment_state')->nullable();
            $table->timestamp('last_dispatched_at')->nullable();
            $table->timestamps();
            $table->unique(['company_id', 'assistant_id', 'channel_key'], 'tz_core_assistant_channels_unique');
        });
    }
    public function down(): void { Schema::dropIfExists('tz_core_assistant_channels'); }
};