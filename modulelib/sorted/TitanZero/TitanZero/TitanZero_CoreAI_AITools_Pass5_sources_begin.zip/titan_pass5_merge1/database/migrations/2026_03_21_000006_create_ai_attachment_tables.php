<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('ai_attachment_index', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('entity_type')->nullable()->index();
            $table->unsignedBigInteger('entity_id')->nullable()->index();
            $table->string('filename')->nullable();
            $table->string('mime_type')->nullable()->index();
            $table->string('source')->nullable();
            $table->json('metadata')->nullable();
            $table->json('extracted_text')->nullable();
            $table->timestamps();
        });
        Schema::create('ai_attachment_classes', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('attachment_index_id')->index();
            $table->string('class')->index();
            $table->decimal('confidence',5,2)->default(0);
            $table->json('scores')->nullable();
            $table->timestamps();
        });
        Schema::create('ai_attachment_links', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('attachment_index_id')->index();
            $table->string('linked_type')->index();
            $table->unsignedBigInteger('linked_id')->index();
            $table->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('ai_attachment_links');
        Schema::dropIfExists('ai_attachment_classes');
        Schema::dropIfExists('ai_attachment_index');
    }
};
