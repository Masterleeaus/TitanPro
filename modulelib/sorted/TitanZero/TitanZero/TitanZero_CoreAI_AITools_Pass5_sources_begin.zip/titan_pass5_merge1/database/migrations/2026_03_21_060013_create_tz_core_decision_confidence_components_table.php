<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        
Schema::create('tz_core_decision_confidence_components', function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('company_id')->nullable()->index();
    $table->string('process_id')->nullable()->index();
    $table->string('lifecycle_event')->nullable()->index();
    $table->string('component_name')->nullable()->index();
    $table->decimal('component_score', 8, 4)->default(0);
    $table->json('component_payload')->nullable();
    $table->timestamps();
});
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_decision_confidence_components');
    }
};
