<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        
Schema::create('tz_core_tenant_confidence_profiles', function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('company_id')->index();
    $table->string('profile_key')->index();
    $table->json('weight_overrides')->nullable();
    $table->json('threshold_overrides')->nullable();
    $table->json('lifecycle_overrides')->nullable();
    $table->boolean('is_active')->default(true)->index();
    $table->timestamps();
    $table->unique(['company_id', 'profile_key'], 'tz_core_conf_profile_company_key_unique');
});
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_tenant_confidence_profiles');
    }
};
