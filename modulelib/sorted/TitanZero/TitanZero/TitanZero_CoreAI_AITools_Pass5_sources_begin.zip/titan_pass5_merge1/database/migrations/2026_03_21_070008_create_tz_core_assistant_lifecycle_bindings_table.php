<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('tz_core_assistant_lifecycle_bindings', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('assistant_id')->index();
            $table->string('lifecycle_event')->index();
            $table->boolean('is_active')->default(true)->index();
            $table->json('binding_rules')->nullable();
            $table->json('binding_meta')->nullable();
            $table->timestamps();
            $table->unique(['company_id', 'assistant_id', 'lifecycle_event'], 'tz_core_assistant_bindings_unique');
        });
    }
    public function down(): void { Schema::dropIfExists('tz_core_assistant_lifecycle_bindings'); }
};