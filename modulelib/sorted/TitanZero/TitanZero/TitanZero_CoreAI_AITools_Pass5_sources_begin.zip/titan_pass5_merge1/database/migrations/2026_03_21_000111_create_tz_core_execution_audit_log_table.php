<?php

use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    public function up(): void
    {
        // No-op repair migration retained to preserve chronological compatibility
        // with earlier cumulative deltas. The canonical table definitions live in
        // the 060012/060016 migrations included in this cumulative pass.
    }

    public function down(): void
    {
        // Intentionally empty.
    }
};
