<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('modules', function (Blueprint $table) {
            if (!Schema::hasColumn('modules', 'source')) {
                $table->string('source')->nullable()->after('description');
            }

            if (!Schema::hasColumn('modules', 'module_path')) {
                $table->string('module_path')->nullable()->after('source');
            }

            if (!Schema::hasColumn('modules', 'provider')) {
                $table->string('provider')->nullable()->after('module_path');
            }

            if (!Schema::hasColumn('modules', 'version')) {
                $table->string('version')->nullable()->after('provider');
            }

            if (!Schema::hasColumn('modules', 'is_enabled')) {
                $table->boolean('is_enabled')->default(false)->after('version');
            }

            if (!Schema::hasColumn('modules', 'visible_in_packages')) {
                $table->boolean('visible_in_packages')->default(true)->after('is_enabled');
            }

            if (!Schema::hasColumn('modules', 'visible_in_superadmin')) {
                $table->boolean('visible_in_superadmin')->default(true)->after('visible_in_packages');
            }

            if (!Schema::hasColumn('modules', 'visible_in_user_menu')) {
                $table->boolean('visible_in_user_menu')->default(true)->after('visible_in_superadmin');
            }

            if (!Schema::hasColumn('modules', 'sort_order')) {
                $table->integer('sort_order')->default(999)->after('visible_in_user_menu');
            }

            if (!Schema::hasColumn('modules', 'meta_json')) {
                $table->longText('meta_json')->nullable()->after('sort_order');
            }
        });
    }

    public function down(): void
    {
        Schema::table('modules', function (Blueprint $table) {
            $columns = [
                'source',
                'module_path',
                'provider',
                'version',
                'is_enabled',
                'visible_in_packages',
                'visible_in_superadmin',
                'visible_in_user_menu',
                'sort_order',
                'meta_json',
            ];

            foreach ($columns as $column) {
                if (Schema::hasColumn('modules', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
