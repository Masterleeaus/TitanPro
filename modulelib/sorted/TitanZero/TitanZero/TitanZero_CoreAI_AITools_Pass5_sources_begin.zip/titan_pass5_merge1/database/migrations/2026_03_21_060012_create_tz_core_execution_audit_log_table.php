<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tz_core_execution_audit_log', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('process_id')->nullable()->index();
            $table->string('lifecycle_event')->nullable()->index();
            $table->string('outcome')->nullable()->index();
            $table->json('reason_codes')->nullable();
            $table->json('context_payload')->nullable();
            $table->json('trace_payload')->nullable();
            $table->string('event_source')->nullable()->index();
            $table->string('reason_hash', 64)->nullable()->index();
            $table->timestamp('decision_recorded_at')->nullable()->index();
            $table->timestamps();

            $table->index(['company_id', 'lifecycle_event', 'created_at'], 'tz_core_audit_company_event_created_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tz_core_execution_audit_log');
    }
};
