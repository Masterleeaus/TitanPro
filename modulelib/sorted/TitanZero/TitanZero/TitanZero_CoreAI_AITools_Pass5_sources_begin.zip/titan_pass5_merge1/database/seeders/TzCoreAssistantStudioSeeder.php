<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TzCoreAssistantStudioSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('tz_core_assistants')->updateOrInsert([
            'company_id' => 1,
            'assistant_uid' => 'ast-demo-zero',
        ], [
            'name' => 'Zero Demo Assistant',
            'slug' => 'zero-demo-assistant',
            'status' => 'active',
            'is_active' => 1,
            'capabilities' => json_encode(['chatbot_surface', 'lifecycle_binding']),
            'policy_overrides' => json_encode(['auto_execute_cap' => 500]),
            'settings' => json_encode(['voice_enabled' => true]),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
