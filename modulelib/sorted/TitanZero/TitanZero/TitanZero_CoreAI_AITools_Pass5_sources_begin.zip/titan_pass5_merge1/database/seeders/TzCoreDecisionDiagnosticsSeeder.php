<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TzCoreDecisionDiagnosticsSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('tz_core_tenant_confidence_profiles')->insert([
            'company_id' => 1,
            'profile_name' => 'default-sensitive-finance',
            'weight_overrides' => json_encode(['financial_exposure' => 0.18, 'persona_agreement' => 0.14]),
            'threshold_overrides' => json_encode(['automation' => 0.94, 'zero_review' => 0.80]),
            'lifecycle_overrides' => json_encode(['invoice_payment_confirmation' => ['minimum_confidence' => 0.95]]),
            'is_active' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        DB::table('tz_core_policy_overrides')->insert([
            'company_id' => 1,
            'lifecycle_event' => 'negative_feedback_remediation',
            'priority' => 10,
            'override_payload' => json_encode(['approval_mode' => 'MANAGER_APPROVAL', 'automation_allowed' => false]),
            'is_active' => 1,
            'expires_at' => null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        DB::table('tz_core_schema_remediation_hooks')->insert([
            'lifecycle_event' => 'booking_to_job',
            'trigger_code' => 'missing_staff_assignment',
            'hook_type' => 'fill_default',
            'target_field' => 'staff_assignment_mode',
            'source_field' => null,
            'hook_payload' => json_encode(['default' => 'manual_dispatch']),
            'priority' => 10,
            'is_active' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
