<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TzCoreEscalationTargetsSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();

        DB::table('tz_core_escalation_targets')->upsert([
            ['target_key' => 'Logic', 'label' => 'Logic Persona', 'human_review' => false, 'created_at' => $now, 'updated_at' => $now],
            ['target_key' => 'Finance', 'label' => 'Finance Persona', 'human_review' => false, 'created_at' => $now, 'updated_at' => $now],
            ['target_key' => 'Macro', 'label' => 'Macro Persona', 'human_review' => false, 'created_at' => $now, 'updated_at' => $now],
            ['target_key' => 'Zero', 'label' => 'Zero Consolidation', 'human_review' => false, 'created_at' => $now, 'updated_at' => $now],
            ['target_key' => 'Human', 'label' => 'Human Reviewer', 'human_review' => true, 'created_at' => $now, 'updated_at' => $now],
        ], ['target_key'], ['label', 'human_review', 'updated_at']);
    }
}
