<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TzCorePolicyReasonCodesSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();

        DB::table('tz_core_policy_reason_codes')->upsert([
            ['reason_code' => 'schema_block', 'severity' => 'high', 'label' => 'Schema block', 'created_at' => $now, 'updated_at' => $now],
            ['reason_code' => 'persona_conflict', 'severity' => 'medium', 'label' => 'Persona conflict', 'created_at' => $now, 'updated_at' => $now],
            ['reason_code' => 'low_confidence', 'severity' => 'high', 'label' => 'Low confidence', 'created_at' => $now, 'updated_at' => $now],
            ['reason_code' => 'financial_risk', 'severity' => 'high', 'label' => 'Financial risk', 'created_at' => $now, 'updated_at' => $now],
            ['reason_code' => 'policy_blocked', 'severity' => 'high', 'label' => 'Policy blocked', 'created_at' => $now, 'updated_at' => $now],
            ['reason_code' => 'zero_review_required', 'severity' => 'medium', 'label' => 'Zero review required', 'created_at' => $now, 'updated_at' => $now],
        ], ['reason_code'], ['severity', 'label', 'updated_at']);
    }
}
