<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TzCoreLifecycleMatrixSeeder extends Seeder
{
    public function run(): void
    {
        $rows = [];
        $now = now();

        foreach ((array) config('tz_core_decision.lifecycle_matrix', []) as $event => $settings) {
            $rows[] = [
                'lifecycle_event' => $event,
                'minimum_confidence' => $settings['minimum_confidence'],
                'required_personas' => json_encode($settings['required_personas']),
                'approval_mode' => $settings['approval_mode'],
                'automation_allowed' => $settings['automation_allowed'],
                'created_at' => $now,
                'updated_at' => $now,
            ];
        }

        DB::table('tz_core_lifecycle_matrix')->upsert(
            $rows,
            ['lifecycle_event'],
            ['minimum_confidence', 'required_personas', 'approval_mode', 'automation_allowed', 'updated_at']
        );
    }
}
