<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TzCoreDecisionPass6Seeder extends Seeder
{
    public function run(): void
    {
        DB::table('tz_core_lifecycle_matrix')->insertOrIgnore([
            [
                'company_id' => 1,
                'lifecycle_event' => 'booking_to_job',
                'required_personas' => json_encode(['Micro','Finance','Logic','Macro','Zero']),
                'minimum_confidence' => 0.82,
                'approval_policy' => 'ZERO_REVIEW',
                'automation_eligibility' => 'conditional',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}
