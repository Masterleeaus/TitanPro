# Install notes

1. Copy `app`, `config`, `database`, `routes`, and `Modules/AITools` into the target codebase.
2. Register `App\Providers\TitanCoreAiAggregateServiceProvider::class`.
3. Register `App\Providers\TzCoreDecisionServiceProvider::class` if not already loaded.
4. Ensure `routes/core-ai.php` is present; the included `RouteServiceProvider` already maps it.
5. Run the included migrations after reviewing table names against the target tenant doctrine.
6. Optionally register `App\Console\Commands\CoreAiBootstrapCommand::class` if your host app does not auto-discover commands.
7. Keep AITools as a module surface only; do not move runtime execution into the module.
