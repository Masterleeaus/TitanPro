<?php

use App\Http\Controllers\CoreAI\Api\CoreAiRuntimeController;
use App\Http\Controllers\CoreAI\CoreAiController;
use Illuminate\Support\Facades\Route;

Route::prefix('account/core-ai')
    ->name('account.core-ai.')
    ->group(function () {
        Route::get('/', [CoreAiController::class, 'index'])->name('index');
        Route::post('/zero', [CoreAiController::class, 'zero'])->name('zero');
        Route::post('/pipelines/bootstrap', [CoreAiController::class, 'pipelineBootstrap'])->name('pipelines.bootstrap');
        Route::post('/pipelines/run', [CoreAiController::class, 'pipeline'])->name('pipelines.run');
    });

Route::prefix('api/core-ai')
    ->middleware('api')
    ->name('api.core-ai.')
    ->group(function () {
        Route::post('/runtime', CoreAiRuntimeController::class)->name('runtime');
    });
