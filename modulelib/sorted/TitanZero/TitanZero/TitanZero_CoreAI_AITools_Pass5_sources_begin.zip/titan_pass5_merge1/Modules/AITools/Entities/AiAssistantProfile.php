<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;

class AiAssistantProfile extends BaseModel
{
    protected $table = 'ai_tools_assistant_profiles';

    protected $guarded = ['id'];

    protected $casts = [
        'allowed_lifecycle_events' => 'array',
        'attached_entities' => 'array',
        'requires_zero_merge' => 'boolean',
        'is_active' => 'boolean',
    ];
}
