<?php

namespace Modules\Aitools\Http\Controllers;

use App\Helper\Reply;
use App\Models\Company;
use Modules\Aitools\Entities\AiToolsSetting;
use Modules\Aitools\Entities\AiToolsUsageHistory;
use Modules\Aitools\Traits\ChecksTokenAvailability;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\StreamedResponse;
use App\Http\Controllers\AccountBaseController;

class AiToolsSettingController extends AccountBaseController
{
    use ChecksTokenAvailability;

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'aitools::app.aiTools';
        $this->activeSettingMenu = 'ai_tools_settings';
        $this->middleware(function ($request, $next) {
            
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('edit_aitools') == 'all')));
    
        $this->aiToolsSetting = AiToolsSetting::forCurrentContext();
        $this->platformAiSetting = AiToolsSetting::platformSetting();
        $this->activeTab = $request->get('tab', 'settings');
        
        $settingsRowToPersist = user()->is_superadmin ? $this->platformAiSetting : $this->aiToolsSetting;
        $apiKey = $settingsRowToPersist->chatgpt_api_key ?? null;

        if (empty($settingsRowToPersist->model_name)) {
            $settingsRowToPersist->model_name = $this->resolveSuggestedModel($apiKey, 'gpt-4o-mini');
            $settingsRowToPersist->save();
        }

        $this->resolvedSuggestedModel = $this->resolveSuggestedModel($apiKey, $settingsRowToPersist->model_name ?: 'gpt-4o-mini');
        $this->usageDateTimeFormat = $this->usageDateTimeFormat();
        $this->resolvedCredentialStatus = $this->aiToolsSetting->resolvedCredentialStatus();
        $usageFilters = $this->usageFilterValues($request);
        $this->usageFilters = $usageFilters;

        // Get resolved usage statistics from all matching history rows
        $statsCompanyId = user()->is_superadmin ? null : company()?->id;
        $usageTotals = $this->fetchResolvedUsageTotals($statsCompanyId, $usageFilters);
        $this->totalTokens = $usageTotals['total_tokens'];
        $this->totalRequests = $usageTotals['total_requests'];
        $this->totalPromptTokens = $usageTotals['total_prompt_tokens'];
        $this->totalCompletionTokens = $usageTotals['total_completion_tokens'];
        $this->platformKeyStatus = $this->formatKeyStatus($this->platformAiSetting->platform_api_key_last4 ?? null, $this->platformAiSetting->platform_key_validated_at ?? null);
        $this->tenantKeyStatus = $this->formatKeyStatus($this->aiToolsSetting->custom_api_key_last4 ?? null, $this->aiToolsSetting->custom_key_validated_at ?? null);

        // Get usage history records for simple table
        if ($this->activeTab == 'usage') {
            if (user()->is_superadmin && module_enabled('Aitools')) {
                $usageQuery = $this->buildUsageHistoryQuery(null, $usageFilters, true);
                $this->usageHistory = $usageQuery
                    ->with(['user', 'company'])
                    ->orderBy('created_at', 'desc')
                    ->paginate(companyOrGlobalSetting()->datatable_row_limit ?? 10)
                    ->appends(array_merge(['tab' => 'usage'], $usageFilters));

                $companyFilter = $request->get('company_id', 'all');
                $this->companyTokenStats = $this->getCompanyTokenStatistics($companyFilter, $usageFilters);
                $this->usageBreakdown = $this->getUsageBreakdown(null, $usageFilters, true);
                $this->companies = Company::withoutGlobalScope(\App\Scopes\CompanyScope::class)
                    ->orderBy('company_name', 'asc')
                    ->get();
            } else {
                $companyId = company()->id;
                $this->usageBreakdown = $this->getUsageBreakdown($companyId, $usageFilters);
                $this->usageHistory = $this->buildUsageHistoryQuery($companyId, $usageFilters)
                    ->with(['user', 'company'])
                    ->orderBy('created_at', 'desc')
                    ->paginate(companyOrGlobalSetting()->datatable_row_limit ?? 10)
                    ->appends(array_merge(['tab' => 'usage'], $usageFilters));
            }
        }


        return view('aitools::ai-tools-settings.index', $this->data);
    }


    /**
     * Fetch latest model ID from OpenAI API
     *
     * @param string $apiKey
     * @return string|null
     * @throws \Exception
     */
    private static function fetchModelsFromAPI($apiKey)
    {
        if (empty($apiKey)) {
            return [];
        }

        return Cache::remember('aitools:models:' . md5($apiKey), now()->addHours(6), function () use ($apiKey) {
            $client = new Client();
            $response = $client->request('GET', 'https://api.openai.com/v1/models', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $apiKey,
                    'Content-Type'  => 'application/json',
                ],
                'timeout' => 10,
            ]);

            $responseBody = json_decode($response->getBody(), true);
            $models = [];

            foreach (($responseBody['data'] ?? []) as $model) {
                $modelId = $model['id'] ?? '';

                if (strpos($modelId, 'gpt-') !== 0) {
                    continue;
                }

                if (preg_match('/(audio|vision|whisper|embedding|moderation|realtime|search|transcribe|tts)/i', $modelId)) {
                    continue;
                }

                $models[] = [
                    'id' => $modelId,
                    'created' => (int) ($model['created'] ?? 0),
                ];
            }

            usort($models, static function (array $a, array $b) {
                return $b['created'] <=> $a['created'];
            });

            return $models;
        });
    }

    private function resolveSuggestedModel(?string $apiKey, string $fallback = 'gpt-4o-mini'): string
    {
        if (empty($apiKey)) {
            return $fallback;
        }

        try {
            $models = self::fetchModelsFromAPI($apiKey);
            $available = array_column($models, 'id');
            $preferred = ['gpt-4.1-mini', 'gpt-4o-mini', 'gpt-4.1', 'gpt-4o'];

            foreach ($preferred as $candidate) {
                if (in_array($candidate, $available, true)) {
                    return $candidate;
                }
            }

            return $available[0] ?? $fallback;
        } catch (\Exception $e) {
            logger()->warning('Failed to resolve suggested AI model', ['error' => $e->getMessage()]);

            return $fallback;
        }
    }

    private function usageDateTimeFormat(): string
    {
        $settings = companyOrGlobalSetting();

        return trim(($settings->date_format ?? 'Y-m-d') . ' ' . ($settings->time_format ?? 'H:i'));
    }

    private function validateApiKey(string $apiKey): void
    {
        $client = new Client();

        try {
            Cache::forget('aitools:models:' . md5($apiKey));
            $client->request('GET', 'https://api.openai.com/v1/models', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $apiKey,
                    'Content-Type' => 'application/json',
                ],
                'timeout' => 10,
            ]);
        } catch (RequestException $e) {
            $message = 'The API key could not be validated.';
            if ($e->hasResponse()) {
                $errorResponse = json_decode($e->getResponse()->getBody(), true);
                $message = $errorResponse['error']['message'] ?? $message;
            }
            throw new \RuntimeException($message);
        } catch (GuzzleException $e) {
            throw new \RuntimeException('Network error while validating the API key.');
        }
    }

    private function estimateRequestCost(string $model, int $inputTokens, int $outputTokens): float
    {
        $pricing = [
            'gpt-4o' => ['input' => 2.50, 'output' => 10.00],
            'gpt-4o-mini' => ['input' => 0.15, 'output' => 0.60],
            'gpt-4.1' => ['input' => 2.00, 'output' => 8.00],
            'gpt-4.1-mini' => ['input' => 0.40, 'output' => 1.60],
        ];

        $rates = $pricing[$model] ?? $pricing['gpt-4o-mini'];

        return round((($inputTokens / 1000000) * $rates['input']) + (($outputTokens / 1000000) * $rates['output']), 6);
    }



    private function getUsageBreakdown($companyId, array $filters = [], bool $withoutCompanyScope = false): array
    {
        $query = $this->buildUsageHistoryQuery($companyId, $filters, $withoutCompanyScope);

        $byKeySource = (clone $query)
            ->select('key_source', DB::raw('COUNT(*) as request_count'), DB::raw('COALESCE(SUM(total_tokens), 0) as token_count'), DB::raw('COALESCE(SUM(estimated_cost), 0) as total_cost'))
            ->groupBy('key_source')
            ->get()
            ->map(function ($row) {
                return [
                    'label' => ucfirst($row->key_source ?: 'unknown'),
                    'request_count' => (int) $row->request_count,
                    'token_count' => (int) $row->token_count,
                    'total_cost' => round((float) $row->total_cost, 6),
                ];
            })
            ->values()
            ->all();

        $byRequestType = (clone $query)
            ->select('request_type', DB::raw('COUNT(*) as request_count'), DB::raw('COALESCE(SUM(total_tokens), 0) as token_count'))
            ->groupBy('request_type')
            ->orderByDesc('request_count')
            ->get()
            ->map(function ($row) {
                return [
                    'label' => str_replace('_', ' ', $row->request_type ?: 'request'),
                    'request_count' => (int) $row->request_count,
                    'token_count' => (int) $row->token_count,
                ];
            })
            ->values()
            ->all();

        return [
            'by_key_source' => $byKeySource,
            'by_request_type' => $byRequestType,
        ];
    }

    private function usageFilterValues(Request $request): array
    {
        return [
            'key_source' => $request->get('key_source', 'all'),
            'request_type' => $request->get('request_type', 'all'),
            'start_date' => $request->get('start_date'),
            'end_date' => $request->get('end_date'),
        ];
    }

    private function buildUsageHistoryQuery($companyId, array $filters = [], bool $withoutCompanyScope = false)
    {
        $query = $withoutCompanyScope
            ? AiToolsUsageHistory::withoutGlobalScope(\App\Scopes\CompanyScope::class)
            : AiToolsUsageHistory::query();

        if (is_null($companyId)) {
            $query->whereNull('company_id');
        } else {
            $query->forCompany($companyId);
        }

        return $query
            ->forKeySource($filters['key_source'] ?? 'all')
            ->forRequestType($filters['request_type'] ?? 'all')
            ->betweenDates($filters['start_date'] ?? null, $filters['end_date'] ?? null);
    }


    private function formatKeyStatus(?string $last4, $validatedAt): string
    {
        if (empty($last4)) {
            return 'Not configured';
        }

        $label = 'Saved key ending in ' . $last4;

        if ($validatedAt) {
            return $label . ' • validated ' . \Carbon\Carbon::parse($validatedAt)->diffForHumans();
        }

        return $label . ' • not validated yet';
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id-
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'provider_mode' => 'nullable|in:platform,custom,hybrid',
            'model_name' => 'nullable|string|max:191',
            'custom_model_name' => 'nullable|string|max:191',
            'chatgpt_api_key' => 'nullable|string|max:500',
            'custom_api_key' => 'nullable|string|max:500',
        ]);

        $setting = AiToolsSetting::forCurrentContext();

        try {
            if (user()->is_superadmin) {
                if ($request->boolean('clear_platform_api_key')) {
                    $setting->chatgpt_api_key = null;
                    $setting->platform_api_key_last4 = null;
                    $setting->platform_key_validated_at = null;
                } elseif ($request->filled('chatgpt_api_key')) {
                    $setting->chatgpt_api_key = $request->chatgpt_api_key;
                    $setting->setPlatformApiKeyMetadata();
                    $setting->platform_key_validated_at = null;
                    $this->validateApiKey($setting->chatgpt_api_key);
                    $setting->platform_key_validated_at = now();
                }

                if ($request->has('model_name')) {
                    $setting->model_name = $request->model_name ?: 'gpt-4o-mini';
                }

                $setting->allow_user_bring_own_key = $request->boolean('allow_user_bring_own_key', true);
            } else {
                $platform = AiToolsSetting::platformSetting();
                if (!$platform->allow_user_bring_own_key && $request->boolean('use_custom_key')) {
                    return Reply::error('Bring your own key is disabled by the platform administrator.');
                }

                $providerMode = $request->input('provider_mode', 'hybrid');
                $setting->provider_mode = in_array($providerMode, ['platform', 'custom', 'hybrid'], true) ? $providerMode : 'hybrid';
                $setting->use_custom_key = $request->boolean('use_custom_key');
                $setting->platform_fallback_enabled = $request->boolean('platform_fallback_enabled', true);

                if (!$platform->chatgpt_api_key && $setting->provider_mode === 'platform') {
                    return Reply::error('Platform key mode is not available because the platform API key has not been configured yet.');
                }

                if ($request->boolean('clear_custom_api_key')) {
                    $setting->custom_api_key = null;
                    $setting->custom_api_key_last4 = null;
                    $setting->custom_key_validated_at = null;
                    $setting->use_custom_key = false;
                } elseif ($request->filled('custom_api_key')) {
                    $setting->custom_api_key = $request->custom_api_key;
                    $setting->setCustomApiKeyMetadata();
                    $setting->custom_key_validated_at = null;

                    if ($setting->use_custom_key) {
                        $this->validateApiKey($setting->custom_api_key);
                        $setting->custom_key_validated_at = now();
                    }
                }

                if ($request->has('custom_model_name')) {
                    $setting->custom_model_name = $request->custom_model_name ?: null;
                }
                if ($request->has('model_name') && empty($setting->custom_model_name)) {
                    $setting->model_name = $request->model_name ?: 'gpt-4o-mini';
                }

                if ($setting->provider_mode === 'custom' && (!$setting->use_custom_key || empty($setting->custom_api_key))) {
                    return Reply::error('Custom key mode requires an active saved tenant API key.');
                }

                if ($setting->provider_mode === 'hybrid' && !$setting->use_custom_key && !$platform->chatgpt_api_key) {
                    return Reply::error('Hybrid mode requires either your own key or a configured platform fallback key.');
                }
            }

            $setting->save();

            return Reply::success(__('messages.updateSuccess'));
        } catch (\RuntimeException $e) {
            return Reply::error($e->getMessage());
        }
    }

    /**
     * Test ChatGPT API with a prompt
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function testChat(Request $request)
    {
        $request->validate([
            'prompt' => 'required|string|max:12000',
        ]);

        // Check token availability before processing (skip for superadmin)
        if (!user()->is_superadmin) {
            $tokenCheck = $this->checkTokenAvailability();
            if ($tokenCheck !== true) {
                return $tokenCheck;
            }
        }
        
        $setting = AiToolsSetting::forCurrentContext();
        $credentials = $setting->resolveCredentials(user());

        if (empty($credentials['api_key'])) {
            return Reply::error('No active AI API key is configured.');
        }

        $prompt = trim((string) $request->input('prompt'));

        try {
            $client = new Client();
            
            // Get the selected model or use default
            $model = $credentials['model'] ?: 'gpt-4o-mini';
            
            $response = $client->request('POST', 'https://api.openai.com/v1/responses', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $credentials['api_key'],
                    'Content-Type'  => 'application/json',
                ],
                'json' => [
                    'model' => $model,
                    'input' => [
                        [
                            'role' => 'user',
                            'content' => [
                                [
                                    'type' => 'input_text',
                                    'text' => $prompt
                                ]
                            ]
                        ]
                    ],
                ],
                'timeout' => 30,
            ]);
            

            $responseBody = json_decode($response->getBody(), true);

            $reply = $responseBody['output'][0]['content'][0]['text'] ?? null;

            if (!$reply) {
                logger()->error('OpenAI unexpected response', $responseBody);
                return Reply::error(__('aitools::messages.unexpectedResponse'));
            }

            // Track usage - try multiple possible response formats
            $usage = $responseBody['usage'] ?? $responseBody['data']['usage'] ?? [];
           
            // Try different possible locations for usage data
            $promptTokens = $usage['prompt_tokens'] ?? $usage['input_tokens'] ?? $usage['n_context_tokens_total'] ?? 0;
            $completionTokens = $usage['completion_tokens'] ?? $usage['output_tokens'] ?? $usage['n_generated_tokens_total'] ?? 0;
            $totalTokens = $usage['total_tokens'] ?? ($promptTokens + $completionTokens);
            
            // If still no tokens, estimate based on prompt and response length
            if ($totalTokens == 0) {
                // Rough estimation: ~4 characters per token for English text
                $promptTokens = max(1, (int) ceil(mb_strlen($prompt) / 4));
                $completionTokens = max(1, (int) ceil(mb_strlen($reply) / 4));
                $totalTokens = $promptTokens + $completionTokens;
            }

            // Track usage per request for accurate history and totals
            try {
                $companyId = user()->is_superadmin && module_enabled('Aitools') ? null : company()->id;

                AiToolsUsageHistory::create([
                    'company_id' => $companyId,
                    'user_id' => user()->id,
                    'model' => $model,
                    'key_source' => $credentials['key_source'] ?? null,
                    'request_type' => 'test_chat',
                    'prompt' => $prompt,
                    'response' => mb_substr($reply, 0, 1000),
                    'prompt_tokens' => $promptTokens,
                    'completion_tokens' => $completionTokens,
                    'total_tokens' => $totalTokens,
                    'total_requests' => 1,
                    'estimated_cost' => $this->estimateRequestCost($model, $promptTokens, $completionTokens),
                ]);
            } catch (\Exception $e) {
                // Log error but don't fail the request
                logger()->error('Failed to save usage history', [
                    'error' => $e->getMessage(),
                    'prompt_tokens' => $promptTokens,
                    'completion_tokens' => $completionTokens,
                ]);
            }

            return Reply::dataOnly([
                'status' => 'success',
                'response' => $reply
            ]);
            

        } catch (RequestException $e) {
            $errorMessage = 'An error occurred while connecting to OpenAI API.';
            
            // Try to parse error response
            try {
                if ($e->hasResponse()) {
                    $errorResponse = json_decode($e->getResponse()->getBody(), true);
                    if (isset($errorResponse['error']['message'])) {
                        $errorMessage = $errorResponse['error']['message'];
                    } elseif (isset($errorResponse['error'])) {
                        $errorMessage = is_string($errorResponse['error']) ? $errorResponse['error'] : 'API Error: ' . json_encode($errorResponse['error']);
                    }
                } else {
                    // Network or connection error
                    $errorMessage = 'Unable to connect to OpenAI API. Please check your internet connection and API key.';
                }
            } catch (\Exception $parseException) {
                // If parsing fails, use default message
                $errorMessage = 'Unable to connect to OpenAI API. Please check your internet connection and API key.';
            }
            
            return Reply::error($errorMessage);
        } catch (GuzzleException $e) {
            return Reply::error('Network error: Unable to connect to OpenAI API. Please check your internet connection.');
        } catch (\Exception $e) {
            return Reply::error('An unexpected error occurred: ' . $e->getMessage());
        }
    }

    public function exportUsage(Request $request): StreamedResponse
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('edit_aitools') == 'all')));

        $filters = $this->usageFilterValues($request);
        $isSuperadminUsage = user()->is_superadmin && module_enabled('Aitools');
        $companyId = $isSuperadminUsage ? null : company()?->id;

        $query = $this->buildUsageHistoryQuery($companyId, $filters, $isSuperadminUsage)
            ->with(['user', 'company'])
            ->orderBy('created_at', 'desc');

        $filename = 'ai-tools-usage-' . now()->format('Ymd-His') . '.csv';

        return response()->streamDownload(function () use ($query) {
            $handle = fopen('php://output', 'w');
            fputcsv($handle, ['when', 'company', 'user', 'type', 'model', 'key_source', 'prompt_tokens', 'completion_tokens', 'total_tokens', 'estimated_cost']);

            $query->chunk(500, function ($rows) use ($handle) {
                foreach ($rows as $item) {
                    fputcsv($handle, [
                        optional($item->created_at)->format('Y-m-d H:i:s'),
                        $item->company->company_name ?? '',
                        $item->user->name ?? 'System',
                        $item->request_type ?? 'request',
                        $item->model ?? '',
                        $item->key_source ?? 'unknown',
                        (int) ($item->prompt_tokens ?? 0),
                        (int) ($item->completion_tokens ?? 0),
                        (int) ($item->total_tokens ?? 0),
                        number_format((float) ($item->estimated_cost ?? 0), 6, '.', ''),
                    ]);
                }
            });

            fclose($handle);
        }, $filename, ['Content-Type' => 'text/csv']);
    }

    /**
     * Refresh usage data - recalculates statistics from database
     *
     * @return \Illuminate\Http\Response
     */
    public function refreshUsage()
    {
        try {

            $companyId = user()->is_superadmin && module_enabled('Aitools') ? null : company()->id;
            $totals = $this->fetchResolvedUsageTotals($companyId);

            $totalTokens = $totals['total_tokens'];
            $totalRequests = $totals['total_requests'];
            $totalPromptTokens = $totals['total_prompt_tokens'];
            $totalCompletionTokens = $totals['total_completion_tokens'];

            $message = __('aitools::app.usageDataRefreshedSuccessfully');

            return Reply::successWithData($message, [
                'total_tokens' => $totalTokens,
                'total_requests' => $totalRequests,
                'total_prompt_tokens' => $totalPromptTokens,
                'total_completion_tokens' => $totalCompletionTokens,
            ]);

        } catch (\Exception $e) {
            return Reply::error(__('aitools::app.errorRefreshingUsageData') . ': ' . $e->getMessage());
        }
    }

    /**
     * Reset usage data - deletes the usage history record to start fresh
     *
     * @return \Illuminate\Http\Response
     */
    public function resetUsage()
    {
        try {

            $companyId = user()->is_superadmin && module_enabled('Aitools') ? null : company()->id;
            $companyId === null
                ? AiToolsUsageHistory::whereNull('company_id')->delete()
                : AiToolsUsageHistory::where('company_id', $companyId)->delete();

            $message = __('aitools::app.usageDataResetSuccessfully');

            return Reply::successWithData($message, [
                'total_tokens' => 0,
                'total_requests' => 0,
                'total_prompt_tokens' => 0,
                'total_completion_tokens' => 0,
            ]);

        } catch (\Exception $e) {
            return Reply::error(__('aitools::app.errorResettingUsageData') . ': ' . $e->getMessage());
        }
    }

    /**
     * Display company-level usage and history page
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function companyUsage(Request $request)
    {
        abort_403(
            !(module_enabled('Aitools') && in_array('aitools', user_modules()) && user()->permission('edit_aitools') == 'all')
        );

        $this->pageTitle = 'aitools::app.usageHistory';
        $this->activeSettingMenu = 'ai_tools_usage';

        $companyId = company()->id;
        $usageFilters = $this->usageFilterValues($request);
        $this->usageFilters = $usageFilters;

        $usageHistoryQuery = $this->buildUsageHistoryQuery($companyId, $usageFilters);
        $usageHistoryRecords = (clone $usageHistoryQuery)->get();

        $this->totalTokens = $usageHistoryRecords->sum('total_tokens');
        $this->totalRequests = $usageHistoryRecords->sum('total_requests');
        $this->totalPromptTokens = $usageHistoryRecords->sum('prompt_tokens');
        $this->totalCompletionTokens = $usageHistoryRecords->sum('completion_tokens');

        $company = company();
        $package = $company->package;
        $this->totalAssignedTokens = $package ? ($package->ai_chatgpt_tokens ?? 0) : 0;
        $platformTokenUsage = (clone $usageHistoryQuery)
            ->where(function ($query) {
                $query->whereNull('key_source')->orWhere('key_source', 'platform');
            })
            ->sum('total_tokens');
        $this->remainingTokens = max(0, $this->totalAssignedTokens - $platformTokenUsage);
        $this->usageDateTimeFormat = $this->usageDateTimeFormat();

        $this->usageHistory = $usageHistoryQuery
            ->with(['user'])
            ->orderBy('created_at', 'desc')
            ->paginate(companyOrGlobalSetting()->datatable_row_limit ?? 10)
            ->appends($usageFilters);

        return view('aitools::ai-tools-usage.index', $this->data);
    }

    /**
     * Get company-wise token statistics
     *
     * @param string $companyFilter
     * @return \Illuminate\Support\Collection
     */
    private function getCompanyTokenStatistics($companyFilter = 'all', array $filters = [])
    {
        $query = Company::withoutGlobalScope(\App\Scopes\CompanyScope::class)
            ->with('package')
            ->select('companies.id', 'companies.company_name', 'companies.package_id')
            ->whereNotNull('companies.package_id');

        // Apply company filter
        if ($companyFilter !== 'all' && $companyFilter) {
            $query->where('companies.id', $companyFilter);
        }

        $companies = $query->get();

        $stats = $companies->map(function ($company) {
            // Get total assigned tokens from package
            $totalAssignedTokens = $company->package ? ($company->package->ai_chatgpt_tokens ?? 0) : 0;

            // Get total platform-billed tokens used by company
            $totalTokensUsed = $this->buildUsageHistoryQuery($company->id, $filters)
                ->where(function ($query) {
                    $query->whereNull('key_source')->orWhere('key_source', 'platform');
                })
                ->sum('total_tokens');

            // Calculate remaining tokens
            $remainingTokens = max(0, $totalAssignedTokens - $totalTokensUsed);

            return [
                'company_id' => $company->id,
                'company_name' => $company->company_name,
                'total_tokens' => $totalAssignedTokens,
                'used_tokens' => $totalTokensUsed,
                'remaining_tokens' => $remainingTokens,
            ];
        });

        return $stats;
    }

    /**
     * Update company used tokens
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function updateCompanyUsedTokens(Request $request)
    {
        abort_403(!(user()->is_superadmin && module_enabled('Aitools')));

        $request->validate([
            'company_id' => 'required|exists:companies,id',
            'used_tokens' => 'required|integer|min:0',
        ]);

        try {
            $companyId = $request->company_id;
            $newUsedTokens = (int) $request->used_tokens;

            // Get all usage history records for the company
            $usageHistoryRecords = AiToolsUsageHistory::where('company_id', $companyId)->get();
            $currentTotalUsed = $usageHistoryRecords->sum('total_tokens');

            // Calculate the difference
            $difference = $newUsedTokens - $currentTotalUsed;

            if ($difference != 0) {
                AiToolsUsageHistory::create([
                    'company_id' => $companyId,
                    'user_id' => user()->id,
                    'model' => 'manual-adjustment',
                    'key_source' => 'platform',
                    'request_type' => 'manual_adjustment',
                    'prompt' => 'Manual token adjustment by superadmin',
                    'response' => 'Adjusted package-billed usage to ' . $newUsedTokens . ' total tokens.',
                    'prompt_tokens' => 0,
                    'completion_tokens' => 0,
                    'total_tokens' => $difference,
                    'total_requests' => 0,
                    'estimated_cost' => 0,
                ]);
            }

            // Get updated statistics
            $company = Company::with('package')->find($companyId);
            $totalAssignedTokens = $company->package ? ($company->package->ai_chatgpt_tokens ?? 0) : 0;
            $updatedUsageRecords = AiToolsUsageHistory::where('company_id', $companyId)->get();
            $totalTokensUsed = $updatedUsageRecords->sum('total_tokens');
            $remainingTokens = max(0, $totalAssignedTokens - $totalTokensUsed);

            return Reply::successWithData(__('messages.updateSuccess'), [
                'used_tokens' => $totalTokensUsed,
                'remaining_tokens' => $remainingTokens,
                'total_assigned_tokens' => $totalAssignedTokens,
            ]);

        } catch (\Exception $e) {
            return Reply::error(__('messages.somethingWentWrong') . ': ' . $e->getMessage());
        }
    }
}

