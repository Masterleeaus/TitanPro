<?php

namespace Modules\Aitools\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\Aitools\Entities\AiPromptTemplate;
use Modules\Aitools\Services\OpenAiTemplateService;

class AiTemplateController extends AccountBaseController
{
    public function __construct(private OpenAiTemplateService $service)
    {
        parent::__construct();
        $this->pageTitle = 'aitools::app.promptLibrary';
        $this->activeSettingMenu = 'ai_prompt_templates';
    }

    public function index()
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('edit_aitools') == 'all')));
        $this->templates = AiPromptTemplate::visibleToCurrentUser()->orderBy('name')->get();
        $this->personas = AiPromptTemplate::PERSONAS;
        $this->lifecycleStages = AiPromptTemplate::LIFECYCLE_STAGES;

        return view('aitools::templates.index', $this->data);
    }

    public function store(Request $request)
    {
        $payload = $this->validatedPayload($request);
        $template = new AiPromptTemplate();
        $this->fillTemplate($template, $payload);
        $template->slug = AiPromptTemplate::makeSlug($request->name . '-' . now()->timestamp);
        $template->created_by = user()->id;
        $template->save();

        return Reply::success(__('messages.createSuccess'));
    }

    public function generate(Request $request)
    {
        $request->validate([
            'brief' => 'required|string|max:12000',
            'category' => 'nullable|string|max:100',
            'persona_key' => 'nullable|string|max:50',
            'lifecycle_stage' => 'nullable|string|max:50',
            'action_key' => 'nullable|string|max:100',
        ]);

        $generated = $this->service->generatePromptTemplate($request->brief, $request->category ?: 'general');
        $json = $generated['json'];

        $template = new AiPromptTemplate();
        $template->company_id = user()->is_superadmin ? null : company()?->id;
        $template->created_by = user()->id;
        $template->name = $json['name'] ?? 'Generated Template';
        $template->slug = AiPromptTemplate::makeSlug(($json['name'] ?? 'generated-template') . '-' . now()->timestamp);
        $template->category = $request->category ?: 'general';
        $template->persona_key = $request->persona_key;
        $template->lifecycle_stage = $request->lifecycle_stage;
        $template->action_key = $request->action_key;
        $template->description = $json['description'] ?? null;
        $template->system_prompt = $json['system_prompt'] ?? null;
        $template->user_prompt_template = $json['user_prompt_template'] ?? '';
        $template->variables_json = $json['variables'] ?? [];
        $template->output_format = $json['output_format'] ?? 'text';
        $template->generated_from_brief = $request->brief;
        $template->visibility = user()->is_superadmin ? 'global' : 'company';
        $template->status = 'draft';
        $template->version_label = 'v1';
        $template->save();

        return Reply::successWithData('Template generated and saved.', ['redirect' => route('ai-tools.templates.show', $template->id)]);
    }

    public function show(AiPromptTemplate $template)
    {
        abort_unless($this->canAccess($template), 403);
        $this->template = $template;
        $this->personas = AiPromptTemplate::PERSONAS;
        $this->lifecycleStages = AiPromptTemplate::LIFECYCLE_STAGES;
        $this->activeSettingMenu = 'ai_prompt_templates';
        return view('aitools::templates.show', $this->data);
    }

    public function update(Request $request, AiPromptTemplate $template)
    {
        abort_unless($this->canAccess($template), 403);
        $payload = $this->validatedPayload($request);
        $this->fillTemplate($template, $payload);
        $template->save();

        return Reply::success(__('messages.updateSuccess'));
    }

    public function duplicate(AiPromptTemplate $template)
    {
        abort_unless($this->canAccess($template), 403);
        $copy = $template->replicate();
        $copy->name = $template->name . ' Copy';
        $copy->slug = AiPromptTemplate::makeSlug($template->name . '-copy-' . now()->timestamp);
        $copy->status = 'draft';
        $copy->version_label = 'v1';
        $copy->created_by = user()->id;
        $copy->company_id = user()->is_superadmin ? null : company()?->id;
        $copy->visibility = user()->is_superadmin ? 'global' : 'company';
        $copy->save();

        return redirect()->route('ai-tools.templates.show', $copy->id);
    }

    public function preview(Request $request, AiPromptTemplate $template)
    {
        abort_unless($this->canAccess($template), 403);
        $variables = [];
        foreach ($template->resolvedVariables() as $variable) {
            $variables[$variable['key']] = $request->input('variables.' . $variable['key'], $variable['placeholder'] ?? '');
        }

        return Reply::successWithData('Preview generated.', $this->service->previewPromptTemplate(
            $template->system_prompt ?: '',
            $template->user_prompt_template,
            $variables,
            $template->output_format ?: 'text'
        ));
    }

    public function run(Request $request, AiPromptTemplate $template)
    {
        abort_unless($this->canAccess($template), 403);
        $variables = [];
        foreach ($template->resolvedVariables() as $variable) {
            $value = $request->input('variables.' . $variable['key']);
            if ($variable['required'] && blank($value)) {
                return Reply::error($variable['label'] . ' is required.');
            }
            $variables[$variable['key']] = $value;
        }

        $result = $this->service->runPromptTemplate(
            $template->system_prompt ?: '',
            $template->user_prompt_template,
            $variables,
            'template_run',
            $template->output_format ?: 'text'
        );

        return Reply::successWithData('Template executed successfully.', ['content' => $result['content']]);
    }

    private function validatedPayload(Request $request): array
    {
        $request->validate([
            'name' => 'required|string|max:191',
            'category' => 'nullable|string|max:100',
            'persona_key' => 'nullable|string|max:50',
            'lifecycle_stage' => 'nullable|string|max:50',
            'action_key' => 'nullable|string|max:100',
            'description' => 'nullable|string|max:5000',
            'system_prompt' => 'nullable|string|max:12000',
            'user_prompt_template' => 'required|string|max:20000',
            'output_format' => 'nullable|in:text,json,markdown,html',
            'variables_json' => 'nullable|string',
            'status' => 'nullable|in:draft,published,archived',
            'version_label' => 'nullable|string|max:30',
        ]);

        return $request->all();
    }

    private function fillTemplate(AiPromptTemplate $template, array $payload): void
    {
        $template->company_id = user()->is_superadmin ? null : company()?->id;
        $template->name = $payload['name'];
        $template->category = $payload['category'] ?? null;
        $template->persona_key = $payload['persona_key'] ?? null;
        $template->lifecycle_stage = $payload['lifecycle_stage'] ?? null;
        $template->action_key = $payload['action_key'] ?? null;
        $template->description = $payload['description'] ?? null;
        $template->system_prompt = $payload['system_prompt'] ?? null;
        $template->user_prompt_template = $payload['user_prompt_template'];
        $template->output_format = $payload['output_format'] ?? 'text';
        $template->variables_json = $this->decodeJsonField($payload['variables_json'] ?? null, 'variables_json');
        $template->visibility = user()->is_superadmin ? 'global' : 'company';
        $template->status = $payload['status'] ?? 'draft';
        $template->version_label = $payload['version_label'] ?? 'v1';
    }

    private function decodeJsonField(?string $value, string $field): array
    {
        if (blank($value)) {
            return [];
        }

        $decoded = json_decode($value, true);
        if (!is_array($decoded)) {
            throw \Illuminate\Validation\ValidationException::withMessages([$field => 'This field must contain valid JSON.']);
        }

        return $decoded;
    }

    private function canAccess(AiPromptTemplate $template): bool
    {
        return user()->is_superadmin || is_null($template->company_id) || $template->company_id === company()?->id;
    }
}
