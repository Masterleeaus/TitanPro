@extends('layouts.app')
@section('content')
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Record Provider Health</h3></div>
                <div class="card-body">
                    <form method="POST" action="{{ route('ai-tools.control-plane.health-logs.store') }}">
                        @csrf
                        <div class="form-group"><label>Provider</label><input name="provider" class="form-control" placeholder="openai"></div>
                        <div class="form-group"><label>Model</label><input name="model" class="form-control" placeholder="gpt-4o-mini"></div>
                        <div class="form-row">
                            <div class="form-group col-md-6"><label>Latency ms</label><input name="avg_latency_ms" type="number" class="form-control"></div>
                            <div class="form-group col-md-6"><label>Failure Rate %</label><input name="failure_rate" type="number" step="0.01" class="form-control"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6"><label>Quota Remaining</label><input name="quota_remaining" class="form-control"></div>
                            <div class="form-group col-md-6"><label>Fallback Uses</label><input name="fallback_uses" type="number" class="form-control" value="0"></div>
                        </div>
                        <div class="form-group"><label>Last Success At</label><input name="last_success_at" type="datetime-local" class="form-control"></div>
                        <button class="btn btn-primary">Save Health Snapshot</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Health Timeline</h3></div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead><tr><th>Provider</th><th>Model</th><th>Latency</th><th>Failure</th><th>Quota</th><th>Fallback</th><th>Recorded</th></tr></thead>
                        <tbody>
                        @forelse($healthLogs as $log)
                            <tr>
                                <td>{{ $log->provider }}</td><td>{{ $log->model ?: '—' }}</td><td>{{ $log->avg_latency_ms ?: '—' }}</td><td>{{ $log->failure_rate ?: '—' }}</td><td>{{ $log->quota_remaining ?: '—' }}</td><td>{{ $log->fallback_uses }}</td><td>{{ optional($log->last_success_at)->format('Y-m-d H:i') ?: optional($log->created_at)->format('Y-m-d H:i') }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="7" class="text-center text-muted">No provider health snapshots yet.</td></tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
