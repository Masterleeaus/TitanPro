<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;

class AiKnowledgeSource extends BaseModel
{
    protected $table = 'ai_tools_knowledge_sources';

    protected $guarded = ['id'];

    protected $casts = [
        'meta_json' => 'array',
    ];
}
