<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ai_chat_profiles', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('profile_key')->index();
            $table->string('name');
            $table->string('default_persona')->default('Zero');
            $table->string('thread_mode')->default('entity');
            $table->string('response_style')->default('concise');
            $table->string('tone')->default('professional');
            $table->unsignedInteger('memory_window')->default(20);
            $table->unsignedInteger('export_retention_days')->default(90);
            $table->boolean('exports_enabled')->default(true);
            $table->boolean('entity_linking_enabled')->default(true);
            $table->boolean('citations_enabled')->default(false);
            $table->boolean('voice_friendly')->default(true);
            $table->json('allowed_assistants')->nullable();
            $table->json('feature_flags')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->unique(['company_id', 'profile_key'], 'ai_chat_profiles_company_profile_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_chat_profiles');
    }
};
