<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;

class AiPromptLabScenario extends BaseModel
{
    protected $table = 'ai_prompt_lab_scenarios';

    protected $guarded = ['id'];

    protected $casts = [
        'variables_json' => 'array',
        'is_default' => 'boolean',
    ];

    public function scopeVisibleToCurrentUser($query)
    {
        if (user()?->is_superadmin) {
            return $query;
        }

        $companyId = company()?->id;

        return $query->where(function ($builder) use ($companyId) {
            $builder->whereNull('company_id')->orWhere('company_id', $companyId);
        });
    }
}
