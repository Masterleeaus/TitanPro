<?php

namespace Modules\Aitools\Services;

use Modules\Aitools\Entities\AiPersona;

class PersonaConfigResolver
{
    public function getPersonaConfig(string $personaKey, array $context = [], ?int $companyId = null): array
    {
        $persona = AiPersona::query()
            ->whereRaw('LOWER(persona_key) = ?', [strtolower($personaKey)])
            ->when(!is_null($companyId), fn ($query) => $query->where(function ($builder) use ($companyId) {
                $builder->where('company_id', $companyId)->orWhereNull('company_id');
            }))
            ->orderByRaw('CASE WHEN company_id IS NULL THEN 1 ELSE 0 END')
            ->first();

        if (!$persona) {
            return ['found' => false, 'message' => 'Persona config not found.', 'persona_key' => $personaKey];
        }

        $allowed = $this->isLifecycleEventAllowed($persona, $context['lifecycle_event'] ?? null);

        return [
            'found' => true,
            'persona_key' => $persona->persona_key,
            'name' => $persona->name,
            'description' => $persona->description,
            'authority_scope' => $persona->authority_scope,
            'model_preference' => $persona->model_preference,
            'temperature' => (float) ($persona->temperature ?? 0.20),
            'token_budget' => (int) ($persona->token_budget ?? 0),
            'escalation_threshold' => (int) ($persona->escalation_threshold ?? 0),
            'is_enabled' => (bool) $persona->is_enabled,
            'event_permissions' => $persona->event_permissions_json ?: [],
            'lifecycle_allowed' => $allowed,
            'company_scope' => is_null($persona->company_id) ? 'global' : 'company',
        ];
    }

    protected function isLifecycleEventAllowed(AiPersona $persona, ?string $event): bool
    {
        if (!$event) {
            return true;
        }

        $permissions = $persona->event_permissions_json ?: [];
        if (empty($permissions)) {
            return true;
        }

        if (in_array('*', $permissions, true) || in_array($event, $permissions, true)) {
            return true;
        }

        $stage = str_contains($event, '.') ? explode('.', $event)[0] . '.*' : null;

        return $stage ? in_array($stage, $permissions, true) : false;
    }
}
