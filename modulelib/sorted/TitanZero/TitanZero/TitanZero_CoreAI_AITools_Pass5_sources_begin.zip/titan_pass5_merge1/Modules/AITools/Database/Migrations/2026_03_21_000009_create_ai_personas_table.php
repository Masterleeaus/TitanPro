<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ai_tools_personas')) {
            return;
        }

        Schema::create('ai_tools_personas', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->string('persona_key', 50)->index();
            $table->string('name');
            $table->string('provider_model', 100)->nullable();
            $table->string('authority_scope', 191)->nullable();
            $table->string('lifecycle_stage', 50)->nullable()->index();
            $table->integer('token_budget')->default(0);
            $table->decimal('temperature', 4, 2)->default(0.20);
            $table->decimal('escalation_threshold', 5, 2)->default(0.00);
            $table->boolean('is_enabled')->default(true);
            $table->text('description')->nullable();
            $table->json('event_permissions_json')->nullable();
            $table->timestamps();
            $table->unique(['company_id', 'persona_key', 'lifecycle_stage'], 'ai_tools_persona_scope_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_tools_personas');
    }
};
