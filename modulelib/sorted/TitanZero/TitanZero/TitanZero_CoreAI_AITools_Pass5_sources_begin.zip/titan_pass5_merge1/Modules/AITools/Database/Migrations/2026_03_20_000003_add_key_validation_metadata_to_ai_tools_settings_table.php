<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ai_tools_settings', function (Blueprint $table) {
            if (!Schema::hasColumn('ai_tools_settings', 'platform_api_key_last4')) {
                $table->string('platform_api_key_last4', 4)->nullable()->after('chatgpt_api_key');
            }
            if (!Schema::hasColumn('ai_tools_settings', 'custom_api_key_last4')) {
                $table->string('custom_api_key_last4', 4)->nullable()->after('custom_api_key');
            }
            if (!Schema::hasColumn('ai_tools_settings', 'platform_key_validated_at')) {
                $table->timestamp('platform_key_validated_at')->nullable()->after('platform_api_key_last4');
            }
            if (!Schema::hasColumn('ai_tools_settings', 'custom_key_validated_at')) {
                $table->timestamp('custom_key_validated_at')->nullable()->after('custom_api_key_last4');
            }
        });
    }

    public function down(): void
    {
        Schema::table('ai_tools_settings', function (Blueprint $table) {
            foreach (['platform_api_key_last4', 'custom_api_key_last4', 'platform_key_validated_at', 'custom_key_validated_at'] as $column) {
                if (Schema::hasColumn('ai_tools_settings', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
