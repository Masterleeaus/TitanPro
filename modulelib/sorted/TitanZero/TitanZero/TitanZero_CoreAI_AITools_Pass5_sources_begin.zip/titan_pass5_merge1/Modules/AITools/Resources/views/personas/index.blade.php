@extends('layouts.app')
@section('content')
<div class="row">
    <div class="col-sm-12">
        <x-setting-card>
            <x-slot name="header">Persona Controls</x-slot>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>Persona</th>
                        <th>Stage</th>
                        <th>Model</th>
                        <th>Budget</th>
                        <th>Threshold</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse($personas as $persona)
                        <tr>
                            <td>{{ $persona->name }}</td>
                            <td>{{ $persona->lifecycle_stage ?: 'all' }}</td>
                            <td>{{ $persona->provider_model ?: 'default' }}</td>
                            <td>{{ $persona->token_budget }}</td>
                            <td>{{ $persona->escalation_threshold }}</td>
                            <td>{{ $persona->is_enabled ? 'enabled' : 'disabled' }}</td>
                        </tr>
                    @empty
                        <tr><td colspan="6">No personas configured yet.</td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
        </x-setting-card>
    </div>
</div>
@endsection
