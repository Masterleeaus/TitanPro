<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ai_tools_prompt_test_runs')) {
            return;
        }

        Schema::create('ai_tools_prompt_test_runs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->unsignedBigInteger('prompt_template_id')->nullable()->index();
            $table->string('persona_key', 50)->nullable()->index();
            $table->string('lifecycle_stage', 50)->nullable()->index();
            $table->string('provider_model', 100)->nullable();
            $table->json('input_variables_json')->nullable();
            $table->longText('preview_prompt')->nullable();
            $table->longText('output_preview')->nullable();
            $table->integer('estimated_tokens')->default(0);
            $table->decimal('confidence_score', 5, 2)->default(0.00);
            $table->string('status', 30)->default('previewed')->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_tools_prompt_test_runs');
    }
};
