@php
    $steps = $wizard->resolvedSteps();
@endphp

<style>
    .lifecycle-shell { background: linear-gradient(180deg, #111827 0%, #182133 100%); color: #f8fafc; border-radius: 20px; overflow: hidden; }
    .lifecycle-shell .hero { padding: 1.5rem; border-bottom: 1px solid rgba(255,255,255,.08); }
    .lifecycle-shell .hero small { color: rgba(248,250,252,.72); }
    .lifecycle-shell .hero .badge { background: rgba(255,255,255,.12); color: #fff; }
    .lifecycle-stepper { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px,1fr)); gap: 12px; padding: 1.25rem 1.5rem; background: rgba(255,255,255,.03); }
    .lifecycle-step-card { border: 1px solid rgba(255,255,255,.08); border-radius: 16px; padding: .9rem; min-height: 110px; background: rgba(255,255,255,.02); cursor: pointer; transition: .2s ease; }
    .lifecycle-step-card.active { background: rgba(59,130,246,.18); border-color: rgba(96,165,250,.6); transform: translateY(-1px); }
    .lifecycle-step-card.done { border-color: rgba(52,211,153,.5); }
    .lifecycle-step-card .index { width: 28px; height: 28px; border-radius: 999px; display: inline-flex; align-items: center; justify-content: center; background: rgba(255,255,255,.14); margin-bottom: .75rem; font-weight: 600; }
    .lifecycle-body { padding: 1.5rem; background: #fff; color: #0f172a; }
    .lifecycle-pane { display: none; }
    .lifecycle-pane.active { display: block; }
    .lifecycle-shell .footer-actions { padding: 1rem 1.5rem 1.5rem; display: flex; gap: .75rem; justify-content: space-between; background: #fff; border-top: 1px solid #e5e7eb; }
    .lifecycle-meta-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px,1fr)); gap: .75rem; margin-top: 1rem; }
    .lifecycle-meta-box { padding: .85rem 1rem; border-radius: 14px; background: rgba(255,255,255,.05); }
</style>

<div class="lifecycle-shell mb-4">
    <div class="hero">
        <div class="d-flex flex-wrap justify-content-between gap-3 align-items-start">
            <div>
                <div class="d-flex align-items-center gap-2 mb-2">
                    <span class="badge">Lifecycle Engine</span>
                    @if($wizard->lifecycle_stage)
                        <span class="badge">{{ ucfirst($wizard->lifecycle_stage) }}</span>
                    @endif
                    @if($wizard->action_key)
                        <span class="badge">{{ $wizard->action_key }}</span>
                    @endif
                </div>
                <h3 class="mb-1">{{ $wizard->name }}</h3>
                <small>{{ $wizard->description ?: 'Adaptive wizard surface for lifecycle entry, multimodal inputs, and staged execution.' }}</small>
            </div>
            <div class="text-end">
                <div class="small">{{ count($steps) }} stages</div>
                <div class="small">{{ strtoupper($wizard->output_format ?: 'text') }} output</div>
            </div>
        </div>
        <div class="lifecycle-meta-grid">
            <div class="lifecycle-meta-box">
                <div class="small text-uppercase">Purpose</div>
                <div>{{ $wizard->category ?: 'general' }}</div>
            </div>
            <div class="lifecycle-meta-box">
                <div class="small text-uppercase">Entry</div>
                <div>Start anywhere in the customer lifecycle.</div>
            </div>
            <div class="lifecycle-meta-box">
                <div class="small text-uppercase">Mode</div>
                <div>Wizard UI + prompt pipeline preview</div>
            </div>
        </div>
    </div>

    <div class="lifecycle-stepper" id="lifecycle-stepper">
        @foreach($steps as $index => $step)
            <div class="lifecycle-step-card {{ $index === 0 ? 'active' : '' }}" data-step-index="{{ $index }}">
                <div class="index">{{ $index + 1 }}</div>
                <div class="fw-bold mb-1">{{ $step['label'] }}</div>
                <div class="small opacity-75">{{ $step['help'] ?: ($step['required'] ? 'Required input' : 'Optional context') }}</div>
            </div>
        @endforeach
    </div>

    <div class="lifecycle-body">
        @foreach($steps as $index => $step)
            <div class="lifecycle-pane {{ $index === 0 ? 'active' : '' }}" data-pane-index="{{ $index }}">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <div class="small text-muted text-uppercase">Step {{ $index + 1 }}</div>
                        <h5 class="mb-1">{{ $step['label'] }}</h5>
                        @if($step['help'])
                            <p class="text-muted mb-0">{{ $step['help'] }}</p>
                        @endif
                    </div>
                    <span class="badge bg-light text-dark">{{ $step['type'] }}</span>
                </div>
                <div class="form-group mb-0">
                    @if($step['type'] === 'textarea')
                        <textarea class="form-control lifecycle-input" name="answers[{{ $step['key'] }}]" rows="5" placeholder="{{ $step['placeholder'] }}"></textarea>
                    @else
                        <input type="text" class="form-control lifecycle-input" name="answers[{{ $step['key'] }}]" placeholder="{{ $step['placeholder'] }}">
                    @endif
                </div>
            </div>
        @endforeach
    </div>

    <div class="footer-actions">
        <button type="button" class="btn btn-outline-secondary" id="lifecycle-prev">Previous</button>
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-primary" id="lifecycle-preview">Preview Prompt</button>
            <button type="button" class="btn btn-primary" id="lifecycle-next">Next</button>
        </div>
    </div>
</div>
