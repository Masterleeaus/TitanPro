<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;

class AiLifecycleSupport extends BaseModel
{
    protected $table = 'ai_tools_lifecycle_supports';

    protected $guarded = ['id'];

    protected $casts = [
        'voice_friendly' => 'boolean',
        'requires_review' => 'boolean',
        'is_active' => 'boolean',
        'flags' => 'array',
    ];
}
