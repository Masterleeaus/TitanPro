<?php

namespace Modules\Aitools\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\Aitools\Entities\AiPersona;
use Modules\Aitools\Entities\AiPromptTemplate;
use Modules\Aitools\Entities\AiPromptTestRun;
use Modules\Aitools\Entities\AiPromptLabScenario;
use Modules\Aitools\Services\OpenAiTemplateService;
use Modules\Aitools\Services\PromptComparisonService;

class AiPromptLabController extends AccountBaseController
{
    public function __construct(private OpenAiTemplateService $service, private PromptComparisonService $comparisonService)
    {
        parent::__construct();
        $this->pageTitle = 'Prompt Testing Lab';
        $this->activeSettingMenu = 'ai_prompt_lab';
    }

    public function index()
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('edit_aitools') == 'all')));
        $this->templates = AiPromptTemplate::visibleToCurrentUser()->orderBy('name')->get();
        $this->personas = AiPersona::visibleToCurrentUser()->orderBy('persona_key')->get();
        $this->recentRuns = AiPromptTestRun::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where('company_id', company()?->id))
            ->latest()->limit(12)->get();
        $this->scenarios = AiPromptLabScenario::visibleToCurrentUser()->latest()->limit(12)->get();

        return view('aitools::prompt-lab.index', $this->data);
    }

    public function preview(Request $request)
    {
        $data = $request->validate([
            'prompt_template_id' => 'required|integer|exists:ai_tools_prompt_templates,id',
            'variables_json' => 'nullable|string',
            'persona_key' => 'nullable|string|max:50',
            'provider_model' => 'nullable|string|max:100',
            'confidence_score' => 'nullable|numeric|min:0|max:100',
        ]);

        $template = AiPromptTemplate::findOrFail($data['prompt_template_id']);
        abort_unless(user()->is_superadmin || is_null($template->company_id) || $template->company_id === company()?->id, 403);

        $variables = $this->decodeVariables($data['variables_json'] ?? null);
        $preview = $this->service->previewPromptTemplate(
            $template->system_prompt ?: '',
            $template->user_prompt_template,
            $variables,
            $template->output_format ?: 'text'
        );

        $run = AiPromptTestRun::create([
            'company_id' => user()->is_superadmin ? null : company()?->id,
            'user_id' => user()->id,
            'prompt_template_id' => $template->id,
            'persona_key' => $data['persona_key'] ?? $template->persona_key,
            'lifecycle_stage' => $template->lifecycle_stage,
            'provider_model' => $data['provider_model'] ?? null,
            'input_variables_json' => $variables,
            'preview_prompt' => ($preview['system_prompt'] ?? '') . "\n\n" . ($preview['user_prompt'] ?? ''),
            'output_preview' => null,
            'estimated_tokens' => (int) ($preview['estimated_prompt_tokens'] ?? 0),
            'confidence_score' => $data['confidence_score'] ?? 0,
            'status' => 'previewed',
        ]);

        return Reply::successWithData('Preview generated.', ['preview' => $preview, 'run_id' => $run->id]);
    }


    public function compare(Request $request)
    {
        $data = $request->validate([
            'left_prompt_template_id' => 'required|integer|exists:ai_tools_prompt_templates,id',
            'right_prompt_template_id' => 'required|integer|exists:ai_tools_prompt_templates,id',
            'variables_json' => 'nullable|string',
        ]);

        $variables = $this->decodeVariables($data['variables_json'] ?? null);
        $left = AiPromptTemplate::findOrFail($data['left_prompt_template_id']);
        $right = AiPromptTemplate::findOrFail($data['right_prompt_template_id']);

        foreach ([$left, $right] as $template) {
            abort_unless(user()->is_superadmin || is_null($template->company_id) || $template->company_id === company()?->id, 403);
        }

        $leftPreview = $this->service->previewPromptTemplate($left->system_prompt ?: '', $left->user_prompt_template, $variables, $left->output_format ?: 'text');
        $rightPreview = $this->service->previewPromptTemplate($right->system_prompt ?: '', $right->user_prompt_template, $variables, $right->output_format ?: 'text');

        return Reply::successWithData('Comparison generated.', [
            'left' => $leftPreview,
            'right' => $rightPreview,
            'comparison' => $this->comparisonService->compare($leftPreview, $rightPreview),
        ]);
    }

    public function saveScenario(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'persona_key' => 'nullable|string|max:50',
            'lifecycle_stage' => 'nullable|string|max:50',
            'variables_json' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);

        $scenario = AiPromptLabScenario::create([
            'company_id' => user()->is_superadmin ? null : company()?->id,
            'user_id' => user()->id,
            'name' => $data['name'],
            'persona_key' => $data['persona_key'] ?? null,
            'lifecycle_stage' => $data['lifecycle_stage'] ?? null,
            'variables_json' => $this->decodeVariables($data['variables_json'] ?? null),
            'notes' => $data['notes'] ?? null,
            'is_default' => false,
        ]);

        return Reply::successWithData('Scenario saved.', ['scenario' => $scenario]);
    }

    protected function decodeVariables(?string $json): array
    {
        if (blank($json)) {
            return [];
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            throw \Illuminate\Validation\ValidationException::withMessages(['variables_json' => 'This field must contain valid JSON.']);
        }

        return $decoded;
    }
}
