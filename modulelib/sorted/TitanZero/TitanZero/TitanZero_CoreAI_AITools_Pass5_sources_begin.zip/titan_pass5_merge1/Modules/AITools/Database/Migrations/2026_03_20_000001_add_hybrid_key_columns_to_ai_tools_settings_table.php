<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ai_tools_settings', function (Blueprint $table) {
            if (!Schema::hasColumn('ai_tools_settings', 'provider_mode')) {
                $table->string('provider_mode', 20)->default('platform')->after('chatgpt_api_key');
            }
            if (!Schema::hasColumn('ai_tools_settings', 'use_custom_key')) {
                $table->boolean('use_custom_key')->default(false)->after('provider_mode');
            }
            if (!Schema::hasColumn('ai_tools_settings', 'custom_api_key')) {
                $table->text('custom_api_key')->nullable()->after('use_custom_key');
            }
            if (!Schema::hasColumn('ai_tools_settings', 'custom_model_name')) {
                $table->string('custom_model_name')->nullable()->after('model_name');
            }
            if (!Schema::hasColumn('ai_tools_settings', 'allow_user_bring_own_key')) {
                $table->boolean('allow_user_bring_own_key')->default(true)->after('custom_model_name');
            }
            if (!Schema::hasColumn('ai_tools_settings', 'platform_fallback_enabled')) {
                $table->boolean('platform_fallback_enabled')->default(true)->after('allow_user_bring_own_key');
            }
        });
    }

    public function down(): void
    {
        Schema::table('ai_tools_settings', function (Blueprint $table) {
            $columns = ['provider_mode', 'use_custom_key', 'custom_api_key', 'custom_model_name', 'allow_user_bring_own_key', 'platform_fallback_enabled'];
            foreach ($columns as $column) {
                if (Schema::hasColumn('ai_tools_settings', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
