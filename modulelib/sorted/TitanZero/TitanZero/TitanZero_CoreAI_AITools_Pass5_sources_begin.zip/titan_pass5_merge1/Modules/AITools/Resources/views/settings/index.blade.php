@extends('layouts.app')

@section('title', 'AI Settings')

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="grid grid-cols-12 gap-6">
        <!-- Sidebar -->
        <div class="col-span-3">
            <div class="sticky top-8">
                <h2 class="text-lg font-bold text-gray-900 mb-4">Settings</h2>
                <nav class="space-y-2">
                    <a href="#chat" onclick="showSettings('chat')" class="block px-4 py-2 rounded-lg bg-blue-50 text-blue-600 font-medium">Chat Settings</a>
                    <a href="#model" onclick="showSettings('model')" class="block px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-100">Model Selection</a>
                    <a href="#provider" onclick="showSettings('provider')" class="block px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-100">Provider Config</a>
                    <a href="#quota" onclick="showSettings('quota')" class="block px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-100">Quotas & Limits</a>
                    <a href="#privacy" onclick="showSettings('privacy')" class="block px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-100">Privacy</a>
                    <a href="#notifications" onclick="showSettings('notifications')" class="block px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-100">Notifications</a>
                </nav>
            </div>
        </div>

        <!-- Content -->
        <div class="col-span-9">
            <!-- Chat Settings -->
            <div id="chat-settings" class="settings-panel">
                <h3 class="text-2xl font-bold text-gray-900 mb-6">Chat Settings</h3>

                <div class="bg-white p-6 rounded-lg border border-gray-200 space-y-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Chat Tone</label>
                        <select id="chat-tone" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                            <option value="professional">Professional</option>
                            <option value="casual">Casual</option>
                            <option value="friendly">Friendly</option>
                            <option value="formal">Formal</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Memory Limit</label>
                        <input type="range" id="memory-limit" min="1" max="20" value="10" class="w-full">
                        <p class="text-xs text-gray-600 mt-1">Messages to keep in context: <span id="memory-display">10</span></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Response Length</label>
                        <select id="response-length" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                            <option value="short">Short (1-2 sentences)</option>
                            <option value="medium" selected>Medium (2-4 sentences)</option>
                            <option value="long">Long (4+ sentences)</option>
                        </select>
                    </div>

                    <div class="flex items-center">
                        <input type="checkbox" id="chat-history" checked class="h-4 w-4 text-blue-600">
                        <label for="chat-history" class="ml-2 text-sm text-gray-700">Save chat history</label>
                    </div>

                    <div class="flex items-center">
                        <input type="checkbox" id="chat-export" checked class="h-4 w-4 text-blue-600">
                        <label for="chat-export" class="ml-2 text-sm text-gray-700">Allow conversation export</label>
                    </div>

                    <div class="pt-4 border-t border-gray-200">
                        <button onclick="saveSettings('chat')" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Save Chat Settings</button>
                    </div>
                </div>
            </div>

            <!-- Model Selection -->
            <div id="model-settings" class="settings-panel hidden">
                <h3 class="text-2xl font-bold text-gray-900 mb-6">Model Selection</h3>

                <div class="bg-white p-6 rounded-lg border border-gray-200 space-y-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Default Reasoning Model</label>
                        <select id="model-reasoning" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                            <option value="claude-opus">Claude Opus</option>
                            <option value="o1">OpenAI o1</option>
                            <option value="o3">OpenAI o3</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Default Generation Model</label>
                        <select id="model-generation" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                            <option value="claude-sonnet" selected>Claude Sonnet</option>
                            <option value="gpt-4">GPT-4</option>
                            <option value="gpt-4-turbo">GPT-4 Turbo</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Fast Model (Quick responses)</label>
                        <select id="model-fast" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                            <option value="claude-haiku" selected>Claude Haiku</option>
                            <option value="gpt-4-mini">GPT-4 Mini</option>
                        </select>
                    </div>

                    <div class="pt-4 border-t border-gray-200">
                        <button onclick="saveSettings('model')" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Save Model Preferences</button>
                    </div>
                </div>
            </div>

            <!-- Provider Configuration -->
            <div id="provider-settings" class="settings-panel hidden">
                <h3 class="text-2xl font-bold text-gray-900 mb-6">Provider Configuration</h3>

                <div class="bg-white p-6 rounded-lg border border-gray-200 space-y-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Primary Provider</label>
                        <select id="provider-primary" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                            <option value="anthropic" selected>Anthropic (Claude)</option>
                            <option value="openai">OpenAI</option>
                            <option value="google">Google</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">API Key (your key, not stored)</label>
                        <input type="password" id="provider-key" placeholder="sk-..." class="w-full px-3 py-2 border border-gray-300 rounded-lg font-mono">
                        <p class="text-xs text-gray-600 mt-1">✅ Your key stays on your device and is never sent to our servers</p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Fallback Provider</label>
                        <select id="provider-fallback" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                            <option value="">-- None (disable if primary fails) --</option>
                            <option value="openai">OpenAI</option>
                            <option value="google">Google</option>
                        </select>
                    </div>

                    <div class="pt-4 border-t border-gray-200">
                        <button onclick="testProvider()" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium mr-2">Test Connection</button>
                        <button onclick="saveSettings('provider')" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Save Provider Config</button>
                    </div>
                </div>
            </div>

            <!-- Quotas & Limits -->
            <div id="quota-settings" class="settings-panel hidden">
                <h3 class="text-2xl font-bold text-gray-900 mb-6">Quotas & Limits</h3>

                <div class="bg-white p-6 rounded-lg border border-gray-200 space-y-6">
                    <div class="bg-blue-50 p-4 rounded-lg mb-4">
                        <p class="text-sm text-blue-900">Current Usage: <strong>2.4M / 10M tokens</strong> this month</p>
                        <div class="w-full bg-blue-200 rounded-full h-2 mt-2">
                            <div class="bg-blue-600 h-2 rounded-full" style="width: 24%"></div>
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Monthly Token Limit</label>
                        <input type="number" id="quota-limit" value="10000000" class="w-full px-3 py-2 border border-gray-300 rounded-lg">
                        <p class="text-xs text-gray-600 mt-1">Maximum tokens allowed per month</p>
                    </div>

                    <div class="flex items-center">
                        <input type="checkbox" id="quota-alert" checked class="h-4 w-4 text-blue-600">
                        <label for="quota-alert" class="ml-2 text-sm text-gray-700">Alert at 80% usage</label>
                    </div>

                    <div class="pt-4 border-t border-gray-200">
                        <button onclick="saveSettings('quota')" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Save Quota Settings</button>
                    </div>
                </div>
            </div>

            <!-- Privacy -->
            <div id="privacy-settings" class="settings-panel hidden">
                <h3 class="text-2xl font-bold text-gray-900 mb-6">Privacy Settings</h3>

                <div class="bg-white p-6 rounded-lg border border-gray-200 space-y-6">
                    <div class="flex items-center">
                        <input type="checkbox" id="privacy-analytics" checked class="h-4 w-4 text-blue-600">
                        <label for="privacy-analytics" class="ml-2 text-sm text-gray-700">Allow anonymous usage analytics</label>
                    </div>

                    <div class="flex items-center">
                        <input type="checkbox" id="privacy-training" class="h-4 w-4 text-blue-600">
                        <label for="privacy-training" class="ml-2 text-sm text-gray-700">Allow conversations for model training improvement</label>
                    </div>

                    <div class="flex items-center">
                        <input type="checkbox" id="privacy-retention" checked class="h-4 w-4 text-blue-600">
                        <label for="privacy-retention" class="ml-2 text-sm text-gray-700">Retain conversation history</label>
                    </div>

                    <div class="pt-4 border-t border-gray-200">
                        <p class="text-sm text-gray-700 mb-4">Privacy Policy: <a href="/privacy" class="text-blue-600 hover:underline">Read Full Policy</a></p>
                        <button onclick="saveSettings('privacy')" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Save Privacy Settings</button>
                    </div>
                </div>
            </div>

            <!-- Notifications -->
            <div id="notifications-settings" class="settings-panel hidden">
                <h3 class="text-2xl font-bold text-gray-900 mb-6">Notification Settings</h3>

                <div class="bg-white p-6 rounded-lg border border-gray-200 space-y-6">
                    <div class="flex items-center">
                        <input type="checkbox" id="notify-quota" checked class="h-4 w-4 text-blue-600">
                        <label for="notify-quota" class="ml-2 text-sm text-gray-700">Notify when quota reaches 80%</label>
                    </div>

                    <div class="flex items-center">
                        <input type="checkbox" id="notify-errors" checked class="h-4 w-4 text-blue-600">
                        <label for="notify-errors" class="ml-2 text-sm text-gray-700">Notify on API errors</label>
                    </div>

                    <div class="flex items-center">
                        <input type="checkbox" id="notify-updates" class="h-4 w-4 text-blue-600">
                        <label for="notify-updates" class="ml-2 text-sm text-gray-700">Notify on AITools updates</label>
                    </div>

                    <div class="pt-4 border-t border-gray-200">
                        <button onclick="saveSettings('notifications')" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Save Notification Settings</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function showSettings(section) {
    // Hide all settings panels
    document.querySelectorAll('.settings-panel').forEach(panel => panel.classList.add('hidden'));
    document.querySelectorAll('.sticky a').forEach(link => link.classList.remove('bg-blue-50', 'text-blue-600'));

    // Show selected section
    document.getElementById(section + '-settings').classList.remove('hidden');
    event.target.classList.add('bg-blue-50', 'text-blue-600');
}

function saveSettings(section) {
    const data = {};

    if (section === 'chat') {
        data.tone = document.getElementById('chat-tone').value;
        data.memory_limit = document.getElementById('memory-limit').value;
        data.response_length = document.getElementById('response-length').value;
        data.save_history = document.getElementById('chat-history').checked;
        data.allow_export = document.getElementById('chat-export').checked;
    }

    fetch('/account/aitools/settings/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content },
        body: JSON.stringify({ section, ...data })
    }).then(r => r.json()).then(data => {
        if (data.success) alert('Settings saved!');
    }).catch(e => console.error(e));
}

function testProvider() {
    const key = document.getElementById('provider-key').value;
    if (!key) {
        alert('Enter API key first');
        return;
    }

    fetch('/account/aitools/settings/test-provider', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content },
        body: JSON.stringify({ key })
    }).then(r => r.json()).then(data => {
        if (data.success) alert('✅ Connection successful!');
        else alert('❌ Connection failed');
    }).catch(e => console.error(e));
}

// Memory limit display
document.getElementById('memory-limit')?.addEventListener('input', e => {
    document.getElementById('memory-display').textContent = e.target.value;
});
</script>
@endsection
