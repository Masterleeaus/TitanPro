<?php

namespace Modules\Aitools\Services;

class LifecycleWizardPresetService
{
    public function all(): array
    {
        return [
            $this->clientIntake(),
            $this->quoteBuilder(),
            $this->bookingEngine(),
            $this->jobCreation(),
            $this->invoiceDraft(),
        ];
    }

    public function find(string $key): ?array
    {
        foreach ($this->all() as $preset) {
            if (($preset['key'] ?? null) === $key) {
                return $preset;
            }
        }

        return null;
    }

    private function clientIntake(): array
    {
        return [
            'key' => 'client_intake',
            'name' => 'Client Intake Engine',
            'category' => 'lifecycle',
            'lifecycle_stage' => 'client',
            'action_key' => 'create_client',
            'description' => 'Starts the lifecycle from enquiry or phone-call context and creates a client-ready intake summary.',
            'output_format' => 'markdown',
            'steps' => [
                $this->step('entry_modality', 'Entry modality', 'text', 'phone, email, chat, voice, upload', true, 'How did this request enter the system?'),
                $this->step('client_name', 'Client or contact name', 'text', 'Jane Smith / Acme Pty Ltd', true),
                $this->step('service_type', 'Requested service', 'text', 'General clean, end of lease, mowing', true),
                $this->step('site_address', 'Service address', 'textarea', 'Include suburb and any access notes', false),
                $this->step('request_summary', 'Customer request summary', 'textarea', 'Paste the request, transcript, or notes', true),
                $this->step('urgency', 'Urgency or timing', 'text', 'today, this week, flexible', false),
                $this->step('attachments', 'Documents, photos, or evidence', 'textarea', 'List uploaded docs, PDFs, images, or emails', false),
            ],
            'final_prompt_template' => <<<'PROMPT'
You are the AITools lifecycle engine for a service business.

Goal: convert the intake data into a clean client-intake packet that can enter the lifecycle engine.

Entry modality: {{entry_modality}}
Client: {{client_name}}
Service type: {{service_type}}
Site address: {{site_address}}
Request summary: {{request_summary}}
Urgency: {{urgency}}
Attachments/evidence: {{attachments}}

Return markdown with these sections:
1. Client Profile
2. Site Snapshot
3. Requested Outcome
4. Missing Information
5. Suggested Next Lifecycle Step
6. Recommended Prompt Variables
PROMPT,
        ];
    }

    private function quoteBuilder(): array
    {
        return [
            'key' => 'quote_builder',
            'name' => 'Quote Builder Engine',
            'category' => 'lifecycle',
            'lifecycle_stage' => 'quote',
            'action_key' => 'create_quote',
            'description' => 'Collects quote context and turns it into a structured proposal brief.',
            'output_format' => 'markdown',
            'steps' => [
                $this->step('client_name', 'Client name', 'text', 'Acme Pty Ltd', true),
                $this->step('site_details', 'Site details', 'textarea', 'Property type, size, suburb, access', true),
                $this->step('scope_of_work', 'Scope of work', 'textarea', 'Rooms, exclusions, special tasks', true),
                $this->step('frequency', 'Frequency', 'text', 'One-off, weekly, fortnightly', false),
                $this->step('materials', 'Materials or equipment notes', 'textarea', 'Consumables, machines, safety gear', false),
                $this->step('pricing_notes', 'Pricing notes', 'textarea', 'Budget, target margin, floor price', false),
                $this->step('supporting_inputs', 'Supporting docs or images', 'textarea', 'Photos, PDF specs, emails, links', false),
            ],
            'final_prompt_template' => <<<'PROMPT'
You are preparing a quote-engine output for a service business lifecycle pipeline.

Client: {{client_name}}
Site details: {{site_details}}
Scope of work: {{scope_of_work}}
Frequency: {{frequency}}
Materials/equipment: {{materials}}
Pricing notes: {{pricing_notes}}
Supporting inputs: {{supporting_inputs}}

Return markdown with:
1. Quote Summary
2. Scope Table
3. Assumptions
4. Risk Flags
5. Missing Pricing Inputs
6. Suggested Booking Conversion Trigger
PROMPT,
        ];
    }

    private function bookingEngine(): array
    {
        return [
            'key' => 'booking_engine',
            'name' => 'Booking Engine',
            'category' => 'lifecycle',
            'lifecycle_stage' => 'booking',
            'action_key' => 'create_booking',
            'description' => 'Builds a booking-ready payload from accepted quote or direct request context.',
            'output_format' => 'markdown',
            'steps' => [
                $this->step('client_name', 'Client name', 'text', 'Client or account name', true),
                $this->step('service_summary', 'Service summary', 'textarea', 'What is being booked?', true),
                $this->step('preferred_date', 'Preferred date', 'text', 'Tomorrow / 2026-03-24', true),
                $this->step('preferred_window', 'Preferred time window', 'text', '8am-12pm', false),
                $this->step('site_access', 'Site access notes', 'textarea', 'Keys, codes, contact, parking', false),
                $this->step('staff_requirements', 'Staff or equipment needs', 'textarea', 'Crew size, ladders, special tools', false),
                $this->step('dependencies', 'Dependencies or blockers', 'textarea', 'Approvals, payments, prerequisites', false),
            ],
            'final_prompt_template' => <<<'PROMPT'
Create a lifecycle booking pack.

Client: {{client_name}}
Service summary: {{service_summary}}
Preferred date: {{preferred_date}}
Preferred window: {{preferred_window}}
Site access: {{site_access}}
Staff/equipment: {{staff_requirements}}
Dependencies: {{dependencies}}

Return markdown with:
1. Booking Snapshot
2. Dispatch Notes
3. Customer Confirmation Text
4. Internal Checklist
5. Missing Inputs
PROMPT,
        ];
    }

    private function jobCreation(): array
    {
        return [
            'key' => 'job_creation',
            'name' => 'Job Creation Engine',
            'category' => 'lifecycle',
            'lifecycle_stage' => 'job',
            'action_key' => 'create_job',
            'description' => 'Creates an execution-ready job pack from booking, call, or field update context.',
            'output_format' => 'markdown',
            'steps' => [
                $this->step('client_name', 'Client name', 'text', 'Client name', true),
                $this->step('job_summary', 'Job summary', 'textarea', 'Tasks, deliverables, standards', true),
                $this->step('location', 'Location', 'textarea', 'Address, unit, parking, access route', true),
                $this->step('crew', 'Crew or owner', 'text', 'Assigned staff or team', false),
                $this->step('start_time', 'Scheduled start', 'text', 'Date and time', false),
                $this->step('evidence_inputs', 'Evidence or multimodal inputs', 'textarea', 'Photos, checklists, docs, voice notes', false),
                $this->step('job_risks', 'Risks or special instructions', 'textarea', 'Hazards, client sensitivities, constraints', false),
            ],
            'final_prompt_template' => <<<'PROMPT'
You are compiling a job-engine execution pack.

Client: {{client_name}}
Job summary: {{job_summary}}
Location: {{location}}
Crew: {{crew}}
Scheduled start: {{start_time}}
Evidence inputs: {{evidence_inputs}}
Job risks: {{job_risks}}

Return markdown with:
1. Job Brief
2. Arrival Checklist
3. Evidence Capture Plan
4. Risk Controls
5. Completion Trigger
PROMPT,
        ];
    }

    private function invoiceDraft(): array
    {
        return [
            'key' => 'invoice_draft',
            'name' => 'Invoice Draft Engine',
            'category' => 'lifecycle',
            'lifecycle_stage' => 'invoice',
            'action_key' => 'create_invoice',
            'description' => 'Builds an invoice-ready summary from completed work and evidence.',
            'output_format' => 'markdown',
            'steps' => [
                $this->step('client_name', 'Client name', 'text', 'Client name', true),
                $this->step('completed_work', 'Completed work summary', 'textarea', 'What was done and delivered?', true),
                $this->step('pricing_basis', 'Pricing basis', 'textarea', 'Quote amount, hourly, extras, callout', true),
                $this->step('evidence', 'Evidence and notes', 'textarea', 'Photos, signoff, checklist, messages', false),
                $this->step('extra_charges', 'Extra charges or variations', 'textarea', 'Add-ons, consumables, penalties', false),
                $this->step('billing_notes', 'Billing notes', 'textarea', 'PO, due date, accounts contact', false),
            ],
            'final_prompt_template' => <<<'PROMPT'
Prepare an invoice-draft pack from completed lifecycle work.

Client: {{client_name}}
Completed work: {{completed_work}}
Pricing basis: {{pricing_basis}}
Evidence: {{evidence}}
Extra charges: {{extra_charges}}
Billing notes: {{billing_notes}}

Return markdown with:
1. Invoice Summary
2. Charge Breakdown
3. Evidence Summary
4. Clarifications Needed
5. Suggested Customer Message
PROMPT,
        ];
    }

    private function step(string $key, string $label, string $type, string $placeholder, bool $required = false, ?string $help = null): array
    {
        return compact('key', 'label', 'type', 'placeholder', 'required', 'help');
    }
}
