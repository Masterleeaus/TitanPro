<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;

class AiLifecycleBundle extends BaseModel
{
    protected $table = 'ai_tools_lifecycle_bundles';

    protected $guarded = ['id'];

    protected $casts = [
        'prompt_keys' => 'array',
        'template_keys' => 'array',
        'wizard_keys' => 'array',
        'context_schema' => 'array',
        'is_active' => 'boolean',
    ];
}
