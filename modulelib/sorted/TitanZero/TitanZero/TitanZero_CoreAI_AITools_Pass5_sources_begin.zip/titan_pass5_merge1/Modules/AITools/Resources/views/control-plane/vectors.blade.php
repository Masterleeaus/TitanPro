@extends('layouts.app')
@section('content')
<div class="row">
  <div class="col-md-4">
    <div class="card"><div class="card-body">
      <h3 class="mb-3">Vector Indexes</h3>
      <form method="POST" action="{{ route('ai-tools.control-plane.vectors.store') }}">@csrf
        <div class="mb-2"><label>Index Key</label><input name="index_key" class="form-control" required></div>
        <div class="mb-2"><label>Knowledge Pack</label><select name="knowledge_pack_id" class="form-control"><option value="">-- none --</option>@foreach($knowledgePacks as $pack)<option value="{{ $pack->id }}">{{ $pack->name ?? $pack->title ?? ('Pack #'.$pack->id) }}</option>@endforeach</select></div>
        <div class="mb-2"><label>Embedding Provider</label><input name="embedding_provider" class="form-control" value="openai"></div>
        <div class="mb-2"><label>Embedding Model</label><input name="embedding_model" class="form-control" placeholder="text-embedding-3-small"></div>
        <div class="mb-2"><label>Chunk Strategy</label><input name="chunk_strategy" class="form-control" placeholder="semantic-800"></div>
        <div class="mb-2"><label>Lifecycle Scope</label><input name="lifecycle_scope" class="form-control" placeholder="job.completed"></div>
        <div class="mb-2"><label>Chunk Count</label><input name="chunk_count" type="number" class="form-control" value="0"></div>
        <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="is_ready" value="1" id="vector_ready"><label class="form-check-label" for="vector_ready">Ready</label></div>
        <button class="btn btn-primary w-100">Save Vector Index</button>
      </form>
    </div></div>
  </div>
  <div class="col-md-8">
    <div class="row mb-3">
      <div class="col-md-12"><div class="card"><div class="card-body"><h3 class="mb-3">Provider Capability Matrix</h3><div class="table-responsive"><table class="table table-bordered"><thead><tr><th>Profile</th><th>Provider</th><th>Model</th><th>Fallback</th><th>R</th><th>T</th><th>I</th><th>M</th><th>E</th><th>JSON</th></tr></thead><tbody>@forelse($providers as $profile)<tr><td>{{ $profile->profile_key }}</td><td>{{ $profile->provider }}</td><td>{{ $profile->default_model }}</td><td>{{ $profile->fallback_model }}</td><td>{{ $profile->supports_reasoning ? '✓' : '—' }}</td><td>{{ $profile->supports_text ? '✓' : '—' }}</td><td>{{ $profile->supports_image ? '✓' : '—' }}</td><td>{{ $profile->supports_multimodal ? '✓' : '—' }}</td><td>{{ $profile->supports_embeddings ? '✓' : '—' }}</td><td>{{ $profile->supports_structured_output ? '✓' : '—' }}</td></tr>@empty<tr><td colspan="10">No provider profiles yet.</td></tr>@endforelse</tbody></table></div></div></div></div>
    </div>
    <div class="card"><div class="card-body">
      <h3 class="mb-3">Current Vector Indexes</h3>
      <div class="table-responsive"><table class="table table-bordered align-middle"><thead><tr><th>Index</th><th>Pack</th><th>Provider</th><th>Model</th><th>Scope</th><th>Chunks</th><th>Ready</th></tr></thead><tbody>
      @forelse($vectors as $vector)
        <tr>
          <td>{{ $vector->index_key }}</td><td>{{ $vector->knowledgePack->name ?? $vector->knowledgePack->title ?? '—' }}</td><td>{{ $vector->embedding_provider }}</td><td>{{ $vector->embedding_model }}</td><td>{{ $vector->lifecycle_scope }}</td><td>{{ $vector->chunk_count }}</td><td>{{ $vector->is_ready ? 'yes' : 'no' }}</td>
        </tr>
      @empty
        <tr><td colspan="7">No vector indexes yet.</td></tr>
      @endforelse
      </tbody></table></div>
    </div></div>
  </div>
</div>
@endsection
