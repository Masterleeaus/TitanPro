AITools cleanup applied

- Removed duplicate early migrations for conversations, messages, and plural usage_histories.
- Kept canonical migrations with richer schema and indexes.
- Removed pass-specific scratch notes/readmes from module root.
- Left runtime, control-plane, chat, prompt, wizard, tool, and knowledge code intact.

- Removed unused legacy PagesController and corresponding Resources/views/pages/* legacy view set.
- Removed unused legacy RephraseController duplicate; routed controller remains AiRephraseController.
- Normalized translations by merging Resources/lang/eng into Resources/lang/en and removing duplicate locale folder.
