<?php

namespace Modules\Aitools\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Http\Request;
use Modules\Aitools\Entities\AiToolsSetting;
use Modules\Aitools\Entities\AiToolsUsageHistory;
use Modules\Aitools\Traits\ChecksTokenAvailability;

class AiRephraseController extends AccountBaseController
{
    use ChecksTokenAvailability;

    private function estimateRequestCost(string $model, int $inputTokens, int $outputTokens): float
    {
        $pricing = [
            'gpt-4o' => ['input' => 2.50, 'output' => 10.00],
            'gpt-4o-mini' => ['input' => 0.15, 'output' => 0.60],
            'gpt-4.1' => ['input' => 2.00, 'output' => 8.00],
            'gpt-4.1-mini' => ['input' => 0.40, 'output' => 1.60],
        ];

        $rates = $pricing[$model] ?? $pricing['gpt-4o-mini'];

        return round((($inputTokens / 1000000) * $rates['input']) + (($outputTokens / 1000000) * $rates['output']), 6);
    }


    public function rephraseText(Request $request)
    {
        $request->validate([
            'text' => 'required|string|max:12000',
        ]);

        abort_403(!(module_enabled('Aitools') && user()->permission('view_aitools') == 'all'));

        $tokenCheck = $this->checkTokenAvailability();
        if ($tokenCheck !== true) {
            return $tokenCheck;
        }

        $text = trim((string) $request->input('text'));

        try {
            $setting = AiToolsSetting::forCurrentContext();
            $credentials = $setting->resolveCredentials(user());

            if (empty($credentials['api_key'])) {
                return Reply::error('No active AI API key is configured. Add your own key or enable platform fallback.');
            }

            $client = new Client();
            $model = $credentials['model'] ?: 'gpt-4o-mini';

            $response = $client->request('POST', 'https://api.openai.com/v1/responses', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $credentials['api_key'],
                    'Content-Type'  => 'application/json',
                ],
                'json' => [
                    'model' => $model,
                    'input' => [[
                        'role' => 'system',
                        'content' => [['type' => 'input_text', 'text' => 'Rewrite the user text clearly and naturally. Return only the rewritten text.']],
                    ], [
                        'role' => 'user',
                        'content' => [['type' => 'input_text', 'text' => $text]],
                    ]],
                ],
                'timeout' => 30,
            ]);

            $data = json_decode($response->getBody(), true);
            $rephrasedText = $data['output'][0]['content'][0]['text'] ?? '';

            if (!$rephrasedText && !empty($data['output']) && is_array($data['output'])) {
                foreach ($data['output'] as $outputItem) {
                    $rephrasedText = $outputItem['content'][0]['text'] ?? '';
                    if (!empty($rephrasedText)) {
                        break;
                    }
                }
            }

            if (!$rephrasedText) {
                return Reply::error(__('aitools::messages.unexpectedResponse'));
            }

            $usage = $data['usage'] ?? $data['data']['usage'] ?? [];
            $promptTokens = $usage['prompt_tokens'] ?? $usage['input_tokens'] ?? $usage['n_context_tokens_total'] ?? 0;
            $completionTokens = $usage['completion_tokens'] ?? $usage['output_tokens'] ?? $usage['n_generated_tokens_total'] ?? 0;
            $totalTokens = $usage['total_tokens'] ?? ($promptTokens + $completionTokens);

            if ($totalTokens == 0) {
                $promptTokens = max(1, (int) ceil(mb_strlen($text) / 4));
                $completionTokens = max(1, (int) ceil(mb_strlen($rephrasedText) / 4));
                $totalTokens = $promptTokens + $completionTokens;
            }

            try {
                $companyId = user()->is_superadmin ? null : company()?->id;

                AiToolsUsageHistory::create([
                    'company_id' => $companyId,
                    'user_id' => user()->id,
                    'model' => $model,
                    'key_source' => $credentials['key_source'] ?? null,
                    'request_type' => 'rephrase_text',
                    'prompt' => $text,
                    'response' => mb_substr($rephrasedText, 0, 1000),
                    'prompt_tokens' => $promptTokens,
                    'completion_tokens' => $completionTokens,
                    'total_tokens' => $totalTokens,
                    'total_requests' => 1,
                    'estimated_cost' => $this->estimateRequestCost($model, $promptTokens, $completionTokens),
                ]);
            } catch (\Exception $e) {
                logger()->error('Failed to save usage history', ['error' => $e->getMessage()]);
            }

            return Reply::dataOnly([
                'status' => 'success',
                'rephrased_text' => trim($rephrasedText)
            ]);
        } catch (RequestException $e) {
            $errorMessage = __('aitools::messages.aiRequestFailed');

            if ($e->hasResponse()) {
                try {
                    $errorResponse = json_decode($e->getResponse()->getBody(), true);
                    if (isset($errorResponse['error']['message'])) {
                        $errorMessage = $errorResponse['error']['message'];
                    }
                } catch (\Exception $parseException) {
                }
            }

            return Reply::error($errorMessage);
        } catch (GuzzleException $e) {
            return Reply::error(__('aitools::messages.networkError'));
        } catch (\Exception $e) {
            logger()->error('Rephrase text error', ['error' => $e->getMessage()]);
            return Reply::error(__('aitools::messages.somethingWentWrong'));
        }
    }
}
