@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="d-flex flex-wrap justify-content-between gap-3 align-items-center mb-3">
        <div>
            <div class="text-muted small mb-1">AITools / Lifecycle Wizard</div>
            <h3 class="mb-0">{{ $wizard->name }}</h3>
        </div>
        <div class="d-flex gap-2">
            <form method="POST" action="{{ route('ai-tools.wizards.duplicate', $wizard->id) }}">@csrf<button class="btn btn-outline-primary">Duplicate</button></form>
            <a href="{{ route('ai-tools.wizards.index') }}" class="btn btn-outline-secondary">Back</a>
        </div>
    </div>

    @include('aitools::wizards.partials.lifecycle-engine-shell', ['wizard' => $wizard])

    <div class="row g-4">
        <div class="col-xl-6">
            <div class="card border-0 shadow-sm" style="border-radius: 18px;">
                <div class="card-header bg-white border-0 pt-4 px-4"><h5 class="mb-0">Wizard definition</h5></div>
                <div class="card-body px-4 pb-4">
                    <form id="update-wizard-form">
                        @csrf
                        @method('PUT')
                        <div class="form-group mb-3"><label>Name</label><input type="text" class="form-control" name="name" value="{{ $wizard->name }}"></div>
                        <div class="row">
                            <div class="col-md-6 form-group mb-3"><label>Category</label><input type="text" class="form-control" name="category" value="{{ $wizard->category }}"></div>
                            <div class="col-md-6 form-group mb-3"><label>Lifecycle stage</label><select name="lifecycle_stage" class="form-control"><option value="">None</option>@foreach($lifecycleStages as $stage)<option value="{{ $stage }}" @selected($wizard->lifecycle_stage === $stage)>{{ ucfirst($stage) }}</option>@endforeach</select></div>
                        </div>
                        <div class="form-group mb-3"><label>Action key</label><input type="text" class="form-control" name="action_key" value="{{ $wizard->action_key }}"></div>
                        <div class="form-group mb-3"><label>Description</label><textarea class="form-control" name="description" rows="3">{{ $wizard->description }}</textarea></div>
                        <div class="form-group mb-3"><label>Steps JSON</label><textarea class="form-control" name="steps_json" rows="10">{{ json_encode($wizard->steps_json ?: [], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</textarea></div>
                        <div class="form-group mb-3"><label>Final prompt template</label><textarea class="form-control" name="final_prompt_template" rows="8">{{ $wizard->final_prompt_template }}</textarea></div>
                        <div class="row">
                            <div class="col-md-4 form-group mb-3"><label>Output format</label><select class="form-control" name="output_format"><option value="text" @selected($wizard->output_format==='text')>text</option><option value="markdown" @selected($wizard->output_format==='markdown')>markdown</option><option value="json" @selected($wizard->output_format==='json')>json</option><option value="html" @selected($wizard->output_format==='html')>html</option></select></div>
                            <div class="col-md-4 form-group mb-3"><label>Status</label><select class="form-control" name="status"><option value="draft" @selected($wizard->status==='draft')>draft</option><option value="published" @selected($wizard->status==='published')>published</option><option value="archived" @selected($wizard->status==='archived')>archived</option></select></div>
                            <div class="col-md-4 form-group mb-3"><label>Version</label><input type="text" class="form-control" name="version_label" value="{{ $wizard->version_label ?: 'v1' }}"></div>
                        </div>
                        <button class="btn btn-primary">Save definition</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="card border-0 shadow-sm" style="border-radius: 18px;">
                <div class="card-header bg-white border-0 pt-4 px-4"><h5 class="mb-0">Prompt preview and output</h5></div>
                <div class="card-body px-4 pb-4">
                    <form id="run-wizard-form">@csrf</form>
                    <div class="mb-3">
                        <h6>Preview</h6>
                        <pre id="wizard-preview" class="bg-light border rounded-4 p-3" style="min-height: 180px; white-space: pre-wrap;"></pre>
                    </div>
                    <div class="mb-0">
                        <h6>Output</h6>
                        <pre id="wizard-output" class="bg-light border rounded-4 p-3" style="min-height: 280px; white-space: pre-wrap;"></pre>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
(function () {
    const cards = Array.from(document.querySelectorAll('.lifecycle-step-card'));
    const panes = Array.from(document.querySelectorAll('.lifecycle-pane'));
    const inputs = Array.from(document.querySelectorAll('.lifecycle-input'));
    let activeIndex = 0;

    function syncRunForm() {
        const runForm = document.getElementById('run-wizard-form');
        runForm.innerHTML = '@csrf';
        inputs.forEach(function (input) {
            const hidden = document.createElement(input.tagName === 'TEXTAREA' ? 'textarea' : 'input');
            if (hidden.tagName === 'INPUT') hidden.type = 'hidden';
            hidden.name = input.name;
            hidden.value = input.value;
            runForm.appendChild(hidden);
        });
    }

    function setActive(index) {
        activeIndex = Math.max(0, Math.min(index, cards.length - 1));
        cards.forEach((card, i) => {
            card.classList.toggle('active', i === activeIndex);
            card.classList.toggle('done', i < activeIndex);
        });
        panes.forEach((pane, i) => pane.classList.toggle('active', i === activeIndex));
        document.getElementById('lifecycle-prev').disabled = activeIndex === 0;
        document.getElementById('lifecycle-next').textContent = activeIndex === cards.length - 1 ? 'Run wizard' : 'Next';
        syncRunForm();
    }

    cards.forEach(card => card.addEventListener('click', () => setActive(Number(card.dataset.stepIndex))));
    inputs.forEach(input => input.addEventListener('input', syncRunForm));

    document.getElementById('lifecycle-prev').addEventListener('click', () => setActive(activeIndex - 1));
    document.getElementById('lifecycle-next').addEventListener('click', function () {
        if (activeIndex < cards.length - 1) {
            setActive(activeIndex + 1);
            return;
        }
        $('#run-wizard-form').trigger('submit');
    });

    document.getElementById('lifecycle-preview').addEventListener('click', function () {
        syncRunForm();
        $.ajax({
            url: '{{ route('ai-tools.wizards.preview', $wizard->id) }}',
            method: 'POST',
            data: $('#run-wizard-form').serialize(),
            success: function (response) {
                $('#wizard-preview').text(JSON.stringify(response.data || {}, null, 2));
            },
            error: function (xhr) {
                alert(xhr.responseJSON?.message || xhr.responseJSON?.error || 'Request failed');
            }
        });
    });

    $('#update-wizard-form').on('submit', function (e) {
        e.preventDefault();
        $.ajax({
            url: '{{ route('ai-tools.wizards.update', $wizard->id) }}',
            method: 'POST',
            data: $(this).serialize(),
            success: function () { window.location.reload(); },
            error: function (xhr) { alert(xhr.responseJSON?.message || xhr.responseJSON?.error || 'Request failed'); }
        });
    });

    $('#run-wizard-form').on('submit', function (e) {
        e.preventDefault();
        syncRunForm();
        $.ajax({
            url: '{{ route('ai-tools.wizards.run', $wizard->id) }}',
            method: 'POST',
            data: $(this).serialize(),
            success: function (response) {
                $('#wizard-output').text(response.data?.content || '');
            },
            error: function (xhr) {
                alert(xhr.responseJSON?.message || xhr.responseJSON?.error || 'Request failed');
            }
        });
    });

    setActive(0);
})();
</script>
@endpush
