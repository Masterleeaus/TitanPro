<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;

class AiVectorIndex extends BaseModel
{
    protected $table = 'ai_tools_vector_indexes';

    protected $guarded = ['id'];

    protected $casts = [
        'is_ready' => 'boolean',
        'last_indexed_at' => 'datetime',
    ];

    public function knowledgePack()
    {
        return $this->belongsTo(AiKnowledgePack::class, 'knowledge_pack_id');
    }
}
