<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ai_tools_knowledge_packs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('name');
            $table->string('slug')->index();
            $table->string('pack_type', 50)->default('policy')->index();
            $table->string('persona_key', 50)->nullable()->index();
            $table->string('lifecycle_stage', 50)->nullable()->index();
            $table->text('description')->nullable();
            $table->string('status', 30)->default('draft')->index();
            $table->boolean('is_active')->default(false)->index();
            $table->timestamps();
        });

        Schema::create('ai_tools_knowledge_sources', function (Blueprint $table) {
            $table->id();
            $table->foreignId('knowledge_pack_id')->constrained('ai_tools_knowledge_packs')->cascadeOnDelete();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('source_type', 30)->default('text')->index();
            $table->string('title');
            $table->string('source_ref')->nullable();
            $table->longText('source_content')->nullable();
            $table->json('meta_json')->nullable();
            $table->timestamps();
        });

        Schema::create('ai_tools_provider_health_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('provider', 50)->index();
            $table->string('model', 100)->nullable()->index();
            $table->decimal('avg_latency_ms', 10, 2)->nullable();
            $table->decimal('failure_rate', 8, 2)->nullable();
            $table->integer('quota_remaining')->nullable();
            $table->integer('fallback_uses')->default(0);
            $table->timestamp('last_success_at')->nullable();
            $table->timestamp('last_failure_at')->nullable();
            $table->timestamps();
        });

        Schema::create('ai_tools_audit_replays', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('replay_type', 50)->default('pipeline')->index();
            $table->string('subject_key', 150)->nullable()->index();
            $table->json('persona_sequence_json')->nullable();
            $table->json('provider_chain_json')->nullable();
            $table->json('confidence_metrics_json')->nullable();
            $table->longText('zero_output')->nullable();
            $table->json('trace_json')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_tools_audit_replays');
        Schema::dropIfExists('ai_tools_provider_health_logs');
        Schema::dropIfExists('ai_tools_knowledge_sources');
        Schema::dropIfExists('ai_tools_knowledge_packs');
    }
};
