<?php

namespace Modules\Aitools\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\Aitools\Entities\AiPersona;
use Modules\Aitools\Entities\AiPromptTemplate;

class AiPersonaController extends AccountBaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'Persona Controls';
        $this->activeSettingMenu = 'ai_personas';
    }

    public function index()
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('edit_aitools') == 'all')));
        $this->personas = AiPersona::visibleToCurrentUser()->orderBy('persona_key')->orderBy('lifecycle_stage')->get();
        $this->personaKeys = AiPersona::PERSONAS;
        $this->lifecycleStages = AiPromptTemplate::LIFECYCLE_STAGES;

        return view('aitools::personas.index', $this->data);
    }

    public function store(Request $request)
    {
        $data = $this->validatePayload($request);
        $persona = new AiPersona();
        $this->fill($persona, $data);
        $persona->created_by = user()->id;
        $persona->save();

        return Reply::success(__('messages.createSuccess'));
    }

    public function update(Request $request, AiPersona $persona)
    {
        abort_unless($this->canAccess($persona), 403);
        $data = $this->validatePayload($request);
        $this->fill($persona, $data);
        $persona->save();

        return Reply::success(__('messages.updateSuccess'));
    }

    protected function validatePayload(Request $request): array
    {
        return $request->validate([
            'persona_key' => 'required|in:zero,logic,finance,creative,macro,micro,entropy',
            'name' => 'required|string|max:191',
            'provider_model' => 'nullable|string|max:100',
            'authority_scope' => 'nullable|string|max:191',
            'lifecycle_stage' => 'nullable|string|max:50',
            'token_budget' => 'nullable|integer|min:0',
            'temperature' => 'nullable|numeric|min:0|max:2',
            'escalation_threshold' => 'nullable|numeric|min:0|max:100',
            'description' => 'nullable|string|max:5000',
            'event_permissions_json' => 'nullable|string',
            'is_enabled' => 'nullable|boolean',
        ]);
    }

    protected function fill(AiPersona $persona, array $data): void
    {
        $persona->company_id = user()->is_superadmin ? null : company()?->id;
        $persona->persona_key = $data['persona_key'];
        $persona->name = $data['name'];
        $persona->provider_model = $data['provider_model'] ?? null;
        $persona->authority_scope = $data['authority_scope'] ?? null;
        $persona->lifecycle_stage = $data['lifecycle_stage'] ?? null;
        $persona->token_budget = (int) ($data['token_budget'] ?? 0);
        $persona->temperature = $data['temperature'] ?? 0.20;
        $persona->escalation_threshold = $data['escalation_threshold'] ?? 0.00;
        $persona->description = $data['description'] ?? null;
        $persona->event_permissions_json = $this->decodeJson($data['event_permissions_json'] ?? null);
        $persona->is_enabled = (bool) ($data['is_enabled'] ?? true);
    }

    protected function decodeJson(?string $json): array
    {
        if (blank($json)) {
            return [];
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            throw \Illuminate\Validation\ValidationException::withMessages(['event_permissions_json' => 'This field must contain valid JSON.']);
        }

        return $decoded;
    }

    protected function canAccess(AiPersona $persona): bool
    {
        return user()->is_superadmin || is_null($persona->company_id) || $persona->company_id === company()?->id;
    }
}
