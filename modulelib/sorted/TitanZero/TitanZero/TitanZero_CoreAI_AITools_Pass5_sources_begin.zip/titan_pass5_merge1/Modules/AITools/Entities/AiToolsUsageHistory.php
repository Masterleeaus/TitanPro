<?php

namespace Modules\Aitools\Entities;

use App\Models\User;
use App\Traits\HasCompany;
use Illuminate\Database\Eloquent\Model;

class AiToolsUsageHistory extends Model
{
    use HasCompany;

    protected $table = 'ai_tools_usage_history';

    protected $guarded = ['id'];

    protected $casts = [
        'prompt_tokens' => 'integer',
        'completion_tokens' => 'integer',
        'total_tokens' => 'integer',
        'total_requests' => 'integer',
        'estimated_cost' => 'float',
    ];

    protected $fillable = [
        'company_id', 'user_id', 'model', 'key_source', 'request_type', 'prompt', 'response',
        'prompt_tokens', 'completion_tokens', 'total_tokens', 'total_requests', 'estimated_cost',
    ];


    public function scopeForCompany($query, $companyId)
    {
        return is_null($companyId)
            ? $query->whereNull('company_id')
            : $query->where('company_id', $companyId);
    }

    public function scopeForKeySource($query, ?string $keySource)
    {
        if (empty($keySource) || $keySource === 'all') {
            return $query;
        }

        return $query->where('key_source', $keySource);
    }

    public function scopeForRequestType($query, ?string $requestType)
    {
        if (empty($requestType) || $requestType === 'all') {
            return $query;
        }

        return $query->where('request_type', $requestType);
    }

    public function scopeBetweenDates($query, ?string $startDate, ?string $endDate)
    {
        if (!empty($startDate)) {
            $query->whereDate('created_at', '>=', $startDate);
        }

        if (!empty($endDate)) {
            $query->whereDate('created_at', '<=', $endDate);
        }

        return $query;
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}

