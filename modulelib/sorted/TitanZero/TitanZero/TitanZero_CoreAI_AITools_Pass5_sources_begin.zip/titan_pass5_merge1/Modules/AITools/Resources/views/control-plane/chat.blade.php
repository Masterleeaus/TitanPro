@extends('layouts.app')
@section('content')
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Chat Controls</h3></div>
                <div class="card-body">
                    <form method="POST" action="{{ route('ai-tools.control-plane.chat.store') }}">
                        @csrf
                        <div class="form-group"><label>Profile Key</label><input name="profile_key" class="form-control" placeholder="zero_default"></div>
                        <div class="form-group"><label>Name</label><input name="name" class="form-control" placeholder="Zero Default"></div>
                        <div class="form-row">
                            <div class="form-group col-md-6"><label>Default Persona</label><input name="default_persona" class="form-control" value="Zero"></div>
                            <div class="form-group col-md-6"><label>Thread Mode</label><select name="thread_mode" class="form-control"><option value="entity">Entity linked</option><option value="global">Global</option><option value="process">Process linked</option></select></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6"><label>Response Style</label><select name="response_style" class="form-control"><option>concise</option><option>balanced</option><option>detailed</option></select></div>
                            <div class="form-group col-md-6"><label>Tone</label><select name="tone" class="form-control"><option>professional</option><option>friendly</option><option>operator</option><option>client-safe</option></select></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6"><label>Memory Window</label><input name="memory_window" type="number" class="form-control" value="20"></div>
                            <div class="form-group col-md-6"><label>Export Retention Days</label><input name="export_retention_days" type="number" class="form-control" value="90"></div>
                        </div>
                        <div class="form-group"><label>Allowed Assistants</label><input name="allowed_assistants" class="form-control" placeholder="job_assistant, booking_assistant"></div>
                        <div class="form-check"><input class="form-check-input" type="checkbox" name="exports_enabled" checked id="exports_enabled"><label class="form-check-label" for="exports_enabled">Exports Enabled</label></div>
                        <div class="form-check"><input class="form-check-input" type="checkbox" name="entity_linking_enabled" checked id="entity_linking_enabled"><label class="form-check-label" for="entity_linking_enabled">Entity Linking Enabled</label></div>
                        <div class="form-check"><input class="form-check-input" type="checkbox" name="citations_enabled" id="citations_enabled"><label class="form-check-label" for="citations_enabled">Citations Enabled</label></div>
                        <div class="form-check"><input class="form-check-input" type="checkbox" name="voice_friendly" checked id="voice_friendly"><label class="form-check-label" for="voice_friendly">Voice Friendly</label></div>
                        <hr>
                        <div class="form-check"><input class="form-check-input" type="checkbox" name="feature_export_controls" checked id="feature_export_controls"><label class="form-check-label" for="feature_export_controls">Export Controls</label></div>
                        <div class="form-check"><input class="form-check-input" type="checkbox" name="feature_thread_pinning" id="feature_thread_pinning"><label class="form-check-label" for="feature_thread_pinning">Thread Pinning</label></div>
                        <div class="form-check"><input class="form-check-input" type="checkbox" name="feature_memory_trim" checked id="feature_memory_trim"><label class="form-check-label" for="feature_memory_trim">Memory Trim</label></div>
                        <div class="form-check"><input class="form-check-input" type="checkbox" name="feature_voice_confirmations" checked id="feature_voice_confirmations"><label class="form-check-label" for="feature_voice_confirmations">Voice Confirmations</label></div>
                        <div class="form-check mt-2"><input class="form-check-input" type="checkbox" name="is_active" checked id="is_active"><label class="form-check-label" for="is_active">Active</label></div>
                        <button class="btn btn-primary mt-3">Save Chat Profile</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Saved Chat Profiles</h3></div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead><tr><th>Profile</th><th>Persona</th><th>Thread</th><th>Style</th><th>Memory</th><th>Voice</th><th>Assistants</th></tr></thead>
                        <tbody>
                        @forelse($chatProfiles as $profile)
                            <tr>
                                <td><strong>{{ $profile->name }}</strong><br><small>{{ $profile->profile_key }}</small></td>
                                <td>{{ $profile->default_persona }}</td>
                                <td>{{ $profile->thread_mode }}</td>
                                <td>{{ $profile->response_style }} / {{ $profile->tone }}</td>
                                <td>{{ $profile->memory_window }}</td>
                                <td>{{ $profile->voice_friendly ? 'yes' : 'no' }}</td>
                                <td>{{ implode(', ', $profile->allowed_assistants ?? []) ?: '—' }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="7" class="text-center text-muted">No chat profiles yet.</td></tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
