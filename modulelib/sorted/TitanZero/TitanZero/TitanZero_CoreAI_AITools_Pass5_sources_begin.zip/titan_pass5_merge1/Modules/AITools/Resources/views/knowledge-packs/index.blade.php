@extends('layouts.app')
@section('content')
<div class="content-wrapper">
    <div class="card">
        <div class="card-header"><h3 class="card-title">Knowledge Packs</h3></div>
        <div class="card-body">
            <p class="text-muted">Persona training packs, SOP bundles, pricing packs, and lifecycle guidance.</p>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead><tr><th>Name</th><th>Type</th><th>Persona</th><th>Lifecycle</th><th>Status</th></tr></thead>
                    <tbody>
                    @forelse($packs as $pack)
                        <tr>
                            <td>{{ $pack->name }}</td>
                            <td>{{ $pack->pack_type }}</td>
                            <td>{{ $pack->persona_key ?: '—' }}</td>
                            <td>{{ $pack->lifecycle_stage ?: '—' }}</td>
                            <td>{{ $pack->status }}</td>
                        </tr>
                    @empty
                        <tr><td colspan="5" class="text-center text-muted">No knowledge packs yet.</td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
