<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;
use Illuminate\Support\Str;

class AiPromptTemplate extends BaseModel
{
    protected $table = 'ai_tools_prompt_templates';

    protected $guarded = ['id'];

    protected $casts = [
        'variables_json' => 'array',
        'is_active' => 'boolean',
    ];

    public const PERSONAS = ['zero', 'logic', 'finance', 'creative', 'macro', 'micro', 'entropy'];
    public const LIFECYCLE_STAGES = ['client', 'quote', 'booking', 'job', 'completion', 'invoice', 'payment', 'followup'];

    public static function visibleToCurrentUser()
    {
        $query = static::query()->where('is_active', true);

        if (user()?->is_superadmin) {
            return $query;
        }

        $companyId = company()?->id;

        return $query->where(function ($builder) use ($companyId) {
            $builder->whereNull('company_id')->orWhere('company_id', $companyId);
        });
    }

    public static function makeSlug(string $name): string
    {
        return Str::slug(Str::limit($name, 120, '')) ?: 'template';
    }

    public function scopeOwnedByCurrentTenant($query)
    {
        if (user()?->is_superadmin) {
            return $query->whereNull('company_id');
        }

        return $query->where('company_id', company()?->id);
    }

    public function metadataLabel(): string
    {
        $parts = array_filter([$this->persona_key, $this->lifecycle_stage, $this->action_key, $this->status]);

        return implode(' · ', $parts);
    }

    public function resolvedVariables(): array
    {
        return collect($this->variables_json ?: [])
            ->map(function ($variable) {
                return [
                    'key' => $variable['key'] ?? null,
                    'label' => $variable['label'] ?? ucfirst(str_replace('_', ' ', $variable['key'] ?? 'value')),
                    'placeholder' => $variable['placeholder'] ?? '',
                    'required' => (bool) ($variable['required'] ?? false),
                ];
            })
            ->filter(fn ($item) => !empty($item['key']))
            ->values()
            ->all();
    }
}
