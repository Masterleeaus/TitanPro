<?php

namespace Modules\Aitools\Http\Controllers;

use App\Http\Controllers\AccountBaseController;
use Modules\Aitools\Entities\AiAuditReplay;
use Modules\Aitools\Entities\AiProviderHealthLog;
use Modules\Aitools\Entities\AiToolsUsageHistory;

class AiOpsDashboardController extends AccountBaseController
{
    public function quota()
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('view_aitools') == 'all' || user()->permission('edit_aitools') == 'all')));
        $companyId = user()->is_superadmin ? null : company()?->id;

        $usageQuery = AiToolsUsageHistory::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where('company_id', $companyId))
            ->when(request('from_date'), fn ($q) => $q->whereDate('created_at', '>=', request('from_date')))
            ->when(request('to_date'), fn ($q) => $q->whereDate('created_at', '<=', request('to_date')));

        $usage = (clone $usageQuery)
            ->selectRaw('COALESCE(SUM(total_tokens),0) as total_tokens, COALESCE(SUM(total_requests),0) as total_requests, COALESCE(SUM(estimated_cost),0) as total_cost')
            ->first();

        $this->usage = $usage;
        $this->byType = (clone $usageQuery)
            ->selectRaw('COALESCE(request_type, "unknown") as request_type, COUNT(*) as rows_count, COALESCE(SUM(total_tokens),0) as total_tokens, COALESCE(SUM(estimated_cost),0) as total_cost')
            ->groupBy('request_type')->orderByDesc('total_tokens')->get();
        $this->byModel = (clone $usageQuery)
            ->selectRaw('COALESCE(model, "unknown") as model_name, COUNT(*) as rows_count, COALESCE(SUM(total_tokens),0) as total_tokens, COALESCE(SUM(estimated_cost),0) as total_cost')
            ->groupBy('model')->orderByDesc('total_tokens')->get();
        $this->byKeySource = (clone $usageQuery)
            ->selectRaw('COALESCE(key_source, "unknown") as key_source_name, COUNT(*) as rows_count, COALESCE(SUM(total_tokens),0) as total_tokens, COALESCE(SUM(estimated_cost),0) as total_cost')
            ->groupBy('key_source')->orderByDesc('total_tokens')->get();

        return view('aitools::ops.quota', $this->data);
    }

    public function health()
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('view_aitools') == 'all' || user()->permission('edit_aitools') == 'all')));
        $this->healthLogs = AiProviderHealthLog::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where('company_id', company()?->id))
            ->latest()->get();

        return view('aitools::ops.health', $this->data);
    }

    public function replay()
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('view_aitools') == 'all' || user()->permission('edit_aitools') == 'all')));
        $this->replays = AiAuditReplay::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where('company_id', company()?->id))
            ->latest()->limit(50)->get();

        return view('aitools::ops.replay', $this->data);
    }
}
