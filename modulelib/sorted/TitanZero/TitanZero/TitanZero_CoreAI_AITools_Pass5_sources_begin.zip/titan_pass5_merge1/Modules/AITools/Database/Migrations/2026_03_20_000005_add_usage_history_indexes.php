<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('ai_tools_usage_history', function (Blueprint $table) {
            $table->index(['company_id', 'created_at'], 'ai_tools_usage_company_created_idx');
            $table->index(['company_id', 'key_source'], 'ai_tools_usage_company_key_source_idx');
            $table->index(['company_id', 'request_type'], 'ai_tools_usage_company_request_type_idx');
        });
    }

    public function down(): void
    {
        Schema::table('ai_tools_usage_history', function (Blueprint $table) {
            $table->dropIndex('ai_tools_usage_company_created_idx');
            $table->dropIndex('ai_tools_usage_company_key_source_idx');
            $table->dropIndex('ai_tools_usage_company_request_type_idx');
        });
    }
};
