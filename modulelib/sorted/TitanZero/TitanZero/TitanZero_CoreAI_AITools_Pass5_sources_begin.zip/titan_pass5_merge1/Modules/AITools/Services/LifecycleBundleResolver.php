<?php

namespace Modules\Aitools\Services;

use Modules\Aitools\Entities\AiAssistantProfile;
use Modules\Aitools\Entities\AiLifecycleBundle;
use Modules\Aitools\Entities\AiLifecycleSupport;

class LifecycleBundleResolver
{
    public function getLifecycleBundle(string $event, array $options = [], ?int $companyId = null): array
    {
        $assistantSlug = $options['assistant_slug'] ?? null;
        $entityType = $options['entity_type'] ?? null;

        $bundle = AiLifecycleBundle::query()
            ->where('is_active', true)
            ->where('lifecycle_event', $event)
            ->when($entityType, fn ($query) => $query->where(function ($builder) use ($entityType) {
                $builder->where('entity_type', $entityType)->orWhereNull('entity_type');
            }))
            ->when($assistantSlug, fn ($query) => $query->where(function ($builder) use ($assistantSlug) {
                $builder->where('assistant_slug', $assistantSlug)->orWhereNull('assistant_slug');
            }))
            ->when(!is_null($companyId), fn ($query) => $query->where(function ($builder) use ($companyId) {
                $builder->where('company_id', $companyId)->orWhereNull('company_id');
            }))
            ->orderByRaw('CASE WHEN company_id IS NULL THEN 1 ELSE 0 END')
            ->orderByRaw('CASE WHEN assistant_slug IS NULL THEN 1 ELSE 0 END')
            ->orderBy('priority')
            ->first();

        if (!$bundle) {
            return ['found' => false, 'message' => 'Lifecycle bundle not found.', 'event' => $event];
        }

        $support = AiLifecycleSupport::query()
            ->where('is_active', true)
            ->where('lifecycle_stage', $this->inferLifecycleStage($event))
            ->when($entityType, fn ($query) => $query->where(function ($builder) use ($entityType) {
                $builder->where('entity_type', $entityType)->orWhereNull('entity_type');
            }))
            ->when(!is_null($companyId), fn ($query) => $query->where(function ($builder) use ($companyId) {
                $builder->where('company_id', $companyId)->orWhereNull('company_id');
            }))
            ->orderByRaw('CASE WHEN company_id IS NULL THEN 1 ELSE 0 END')
            ->orderBy('priority')
            ->first();

        $assistant = $assistantSlug
            ? AiAssistantProfile::query()
                ->where('assistant_slug', $assistantSlug)
                ->when(!is_null($companyId), fn ($query) => $query->where(function ($builder) use ($companyId) {
                    $builder->where('company_id', $companyId)->orWhereNull('company_id');
                }))
                ->orderByRaw('CASE WHEN company_id IS NULL THEN 1 ELSE 0 END')
                ->first()
            : null;

        return [
            'found' => true,
            'bundle_key' => $bundle->bundle_key,
            'lifecycle_event' => $bundle->lifecycle_event,
            'entity_type' => $bundle->entity_type,
            'default_persona' => $assistant->default_persona ?: $bundle->default_persona ?: ($support->default_persona ?? 'Zero'),
            'assistant_slug' => $assistant?->assistant_slug ?: $bundle->assistant_slug,
            'prompt_keys' => $bundle->prompt_keys ?: [],
            'template_keys' => $bundle->template_keys ?: [],
            'wizard_keys' => $bundle->wizard_keys ?: [],
            'context_schema' => $bundle->context_schema ?: [],
            'support' => $support ? [
                'support_key' => $support->support_key,
                'stage_instruction' => $support->stage_instruction,
                'missing_data_prompt' => $support->missing_data_prompt,
                'clarification_prompt' => $support->clarification_prompt,
                'review_prompt' => $support->review_prompt,
                'helper_template_key' => $support->helper_template_key,
                'summary_template_key' => $support->summary_template_key,
                'final_template_key' => $support->final_template_key,
                'voice_friendly' => (bool) $support->voice_friendly,
                'requires_review' => (bool) $support->requires_review,
                'flags' => $support->flags ?: [],
            ] : null,
            'assistant' => $assistant ? [
                'name' => $assistant->name,
                'entity_scope' => $assistant->entity_scope,
                'allowed_lifecycle_events' => $assistant->allowed_lifecycle_events ?: [],
                'token_budget' => (int) $assistant->token_budget,
                'temperature' => (float) $assistant->temperature,
                'requires_zero_merge' => (bool) $assistant->requires_zero_merge,
            ] : null,
            'company_id' => $bundle->company_id,
        ];
    }

    protected function inferLifecycleStage(string $event): string
    {
        return str_contains($event, '.') ? explode('.', $event)[0] : $event;
    }
}
