<?php

namespace Modules\Aitools\Http\Controllers;

use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\Aitools\Entities\AiAssistantProfile;
use Modules\Aitools\Entities\AiAuditReplay;
use Modules\Aitools\Entities\AiChatProfile;
use Modules\Aitools\Entities\AiProviderHealthLog;
use Modules\Aitools\Entities\AiKnowledgePack;
use Modules\Aitools\Entities\AiLifecycleBundle;
use Modules\Aitools\Entities\AiLifecycleSupport;
use Modules\Aitools\Entities\AiProviderProfile;
use Modules\Aitools\Entities\AiVectorIndex;
use Modules\Aitools\Services\Bootstrap\CoreAiBlueprintRegistry;

class AiControlPlaneController extends AccountBaseController
{
    protected function authorizeAitools(): void
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('view_aitools') == 'all' || user()->permission('edit_aitools') == 'all')));
    }

    protected function currentCompanyId(): ?int
    {
        return user()->is_superadmin ? null : company()?->id;
    }


    public function coreIntegration(CoreAiBlueprintRegistry $registry)
    {
        $this->authorizeAitools();
        $companyId = $this->currentCompanyId();
        $this->integrationSummary = $registry->summary(base_path());
        $this->personaBlueprints = $registry->personaBlueprints();
        $this->providerBlueprints = $registry->providerBlueprints();
        $this->assistantBlueprints = $registry->assistantBlueprints();
        $this->bundleBlueprints = $registry->lifecycleBundleBlueprints();
        $this->currentCounts = [
            'personas' => AiPersona::query()->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) { $query->whereNull('company_id')->orWhere('company_id', $companyId); }))->count(),
            'providers' => AiProviderProfile::query()->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) { $query->whereNull('company_id')->orWhere('company_id', $companyId); }))->count(),
            'assistants' => AiAssistantProfile::query()->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) { $query->whereNull('company_id')->orWhere('company_id', $companyId); }))->count(),
            'bundles' => AiLifecycleBundle::query()->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) { $query->whereNull('company_id')->orWhere('company_id', $companyId); }))->count(),
        ];

        return view('aitools::control-plane.core-integration', $this->data);
    }

    public function syncCoreIntegration(CoreAiBlueprintRegistry $registry)
    {
        $this->authorizeAitools();
        $companyId = $this->currentCompanyId();

        foreach ($registry->personaBlueprints() as $row) {
            AiPersona::updateOrCreate([
                'company_id' => $companyId,
                'persona_key' => $row['persona_key'],
                'lifecycle_stage' => $row['lifecycle_stage'],
            ], array_merge($row, ['company_id' => $companyId]));
        }

        foreach ($registry->providerBlueprints() as $row) {
            AiProviderProfile::updateOrCreate([
                'company_id' => $companyId,
                'profile_key' => $row['profile_key'],
            ], array_merge($row, ['company_id' => $companyId]));
        }

        foreach ($registry->assistantBlueprints() as $row) {
            AiAssistantProfile::updateOrCreate([
                'company_id' => $companyId,
                'assistant_slug' => $row['assistant_slug'],
            ], array_merge($row, ['company_id' => $companyId]));
        }

        foreach ($registry->lifecycleBundleBlueprints() as $row) {
            AiLifecycleBundle::updateOrCreate([
                'company_id' => $companyId,
                'bundle_key' => $row['bundle_key'],
            ], array_merge($row, ['company_id' => $companyId]));
        }

        return back()->with('status', 'CoreAI blueprints synced into AITools.');
    }

    public function chat()
    {
        $this->authorizeAitools();
        $companyId = $this->currentCompanyId();
        $this->assistants = AiAssistantProfile::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) {
                $query->whereNull('company_id')->orWhere('company_id', $companyId);
            }))
            ->orderBy('assistant_slug')->get();
        $this->chatProfiles = AiChatProfile::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) {
                $query->whereNull('company_id')->orWhere('company_id', $companyId);
            }))
            ->latest()->get();

        return view('aitools::control-plane.chat', $this->data);
    }

    public function storeChat(Request $request)
    {
        $this->authorizeAitools();
        AiChatProfile::updateOrCreate(
            ['company_id' => $this->currentCompanyId(), 'profile_key' => $request->profile_key],
            [
                'name' => $request->name,
                'default_persona' => $request->default_persona ?: 'Zero',
                'thread_mode' => $request->thread_mode ?: 'entity',
                'response_style' => $request->response_style ?: 'concise',
                'tone' => $request->tone ?: 'professional',
                'memory_window' => (int) ($request->memory_window ?? 20),
                'export_retention_days' => (int) ($request->export_retention_days ?? 90),
                'exports_enabled' => $request->boolean('exports_enabled', true),
                'entity_linking_enabled' => $request->boolean('entity_linking_enabled', true),
                'citations_enabled' => $request->boolean('citations_enabled', false),
                'voice_friendly' => $request->boolean('voice_friendly', true),
                'allowed_assistants' => array_values(array_filter(array_map('trim', explode(',', (string) $request->allowed_assistants)))),
                'feature_flags' => [
                    'export_controls' => $request->boolean('feature_export_controls', true),
                    'thread_pinning' => $request->boolean('feature_thread_pinning', false),
                    'memory_trim' => $request->boolean('feature_memory_trim', true),
                    'voice_confirmations' => $request->boolean('feature_voice_confirmations', true),
                ],
                'is_active' => $request->boolean('is_active', true),
            ]
        );

        return back()->with('status', 'Chat profile saved');
    }

    public function healthLogs()
    {
        $this->authorizeAitools();
        $companyId = $this->currentCompanyId();
        $this->providers = AiProviderProfile::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) {
                $query->whereNull('company_id')->orWhere('company_id', $companyId);
            }))
            ->orderBy('priority')->get();
        $this->healthLogs = AiProviderHealthLog::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where('company_id', $companyId))
            ->latest()->limit(100)->get();

        return view('aitools::control-plane.health-logs', $this->data);
    }

    public function storeHealthLog(Request $request)
    {
        $this->authorizeAitools();
        AiProviderHealthLog::create([
            'company_id' => $this->currentCompanyId(),
            'provider' => $request->provider,
            'model' => $request->model,
            'avg_latency_ms' => $request->avg_latency_ms ?: null,
            'failure_rate' => $request->failure_rate ?: null,
            'quota_remaining' => $request->quota_remaining ?: null,
            'fallback_uses' => (int) ($request->fallback_uses ?? 0),
            'last_success_at' => $request->filled('last_success_at') ? $request->last_success_at : now(),
        ]);

        return back()->with('status', 'Health snapshot recorded');
    }

    public function replayShow(AiAuditReplay $replay)
    {
        $this->authorizeAitools();

        return view('aitools::control-plane.replay-show', ['replay' => $replay] + $this->data);
    }


    public function lifecycleSupport()
    {
        $this->authorizeAitools();
        $companyId = $this->currentCompanyId();
        $this->supports = AiLifecycleSupport::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) {
                $query->whereNull('company_id')->orWhere('company_id', $companyId);
            }))
            ->orderBy('lifecycle_stage')->orderBy('priority')->get();

        return view('aitools::control-plane.lifecycle-support', $this->data);
    }

    public function storeLifecycleSupport(Request $request)
    {
        $this->authorizeAitools();
        AiLifecycleSupport::updateOrCreate(
            ['company_id' => $this->currentCompanyId(), 'support_key' => $request->support_key],
            [
                'lifecycle_stage' => $request->lifecycle_stage,
                'action_context' => $request->action_context,
                'entity_type' => $request->entity_type,
                'default_persona' => $request->default_persona ?: 'Zero',
                'helper_template_key' => $request->helper_template_key,
                'summary_template_key' => $request->summary_template_key,
                'final_template_key' => $request->final_template_key,
                'stage_instruction' => $request->stage_instruction,
                'missing_data_prompt' => $request->missing_data_prompt,
                'clarification_prompt' => $request->clarification_prompt,
                'review_prompt' => $request->review_prompt,
                'voice_friendly' => $request->boolean('voice_friendly', true),
                'requires_review' => $request->boolean('requires_review', true),
                'is_active' => $request->boolean('is_active', true),
                'priority' => (int) ($request->priority ?? 100),
                'flags' => [
                    'customer_facing' => $request->boolean('flag_customer_facing', false),
                    'approval_gate' => $request->boolean('flag_approval_gate', false),
                    'missing_data_blocking' => $request->boolean('flag_missing_data_blocking', true),
                ],
            ]
        );

        return back()->with('status', 'Lifecycle support saved');
    }

    public function bundles()
    {
        $this->authorizeAitools();
        $companyId = $this->currentCompanyId();
        $this->bundles = AiLifecycleBundle::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) {
                $query->whereNull('company_id')->orWhere('company_id', $companyId);
            }))
            ->latest()->get();

        return view('aitools::control-plane.bundles', $this->data);
    }

    public function storeBundle(Request $request)
    {
        $this->authorizeAitools();
        AiLifecycleBundle::updateOrCreate(
            ['company_id' => $this->currentCompanyId(), 'bundle_key' => $request->bundle_key],
            [
                'lifecycle_event' => $request->lifecycle_event,
                'entity_type' => $request->entity_type,
                'default_persona' => $request->default_persona,
                'assistant_slug' => $request->assistant_slug,
                'prompt_keys' => array_values(array_filter(array_map('trim', explode(',', (string) $request->prompt_keys)))),
                'template_keys' => array_values(array_filter(array_map('trim', explode(',', (string) $request->template_keys)))),
                'wizard_keys' => array_values(array_filter(array_map('trim', explode(',', (string) $request->wizard_keys)))),
                'context_schema' => ['raw' => $request->context_schema],
                'priority' => (int) ($request->priority ?? 100),
                'is_active' => $request->boolean('is_active', true),
            ]
        );

        return back()->with('status', 'Bundle saved');
    }

    public function assistants()
    {
        $this->authorizeAitools();
        $companyId = $this->currentCompanyId();
        $this->assistants = AiAssistantProfile::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) {
                $query->whereNull('company_id')->orWhere('company_id', $companyId);
            }))
            ->latest()->get();

        return view('aitools::control-plane.assistants', $this->data);
    }

    public function storeAssistant(Request $request)
    {
        $this->authorizeAitools();
        AiAssistantProfile::updateOrCreate(
            ['company_id' => $this->currentCompanyId(), 'assistant_slug' => $request->assistant_slug],
            [
                'name' => $request->name,
                'default_persona' => $request->default_persona,
                'entity_scope' => $request->entity_scope,
                'allowed_lifecycle_events' => array_values(array_filter(array_map('trim', explode(',', (string) $request->allowed_lifecycle_events)))),
                'attached_entities' => array_values(array_filter(array_map('trim', explode(',', (string) $request->attached_entities)))),
                'token_budget' => (int) ($request->token_budget ?? 0),
                'temperature' => (float) ($request->temperature ?? 0.20),
                'requires_zero_merge' => $request->boolean('requires_zero_merge', true),
                'is_active' => $request->boolean('is_active', true),
            ]
        );

        return back()->with('status', 'Assistant saved');
    }

    public function vectors()
    {
        $this->authorizeAitools();
        $companyId = $this->currentCompanyId();
        $this->knowledgePacks = AiKnowledgePack::query()->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) {
            $query->whereNull('company_id')->orWhere('company_id', $companyId);
        }))->get();
        $this->vectors = AiVectorIndex::query()
            ->with('knowledgePack')
            ->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) {
                $query->whereNull('company_id')->orWhere('company_id', $companyId);
            }))
            ->latest()->get();
        $this->providers = AiProviderProfile::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) {
                $query->whereNull('company_id')->orWhere('company_id', $companyId);
            }))
            ->orderBy('priority')->get();

        return view('aitools::control-plane.vectors', $this->data);
    }

    public function storeVector(Request $request)
    {
        $this->authorizeAitools();
        AiVectorIndex::updateOrCreate(
            ['company_id' => $this->currentCompanyId(), 'index_key' => $request->index_key],
            [
                'knowledge_pack_id' => $request->knowledge_pack_id ?: null,
                'embedding_provider' => $request->embedding_provider ?: 'openai',
                'embedding_model' => $request->embedding_model,
                'chunk_strategy' => $request->chunk_strategy,
                'lifecycle_scope' => $request->lifecycle_scope,
                'chunk_count' => (int) ($request->chunk_count ?? 0),
                'is_ready' => $request->boolean('is_ready', false),
                'last_indexed_at' => $request->boolean('is_ready', false) ? now() : null,
            ]
        );

        return back()->with('status', 'Vector index saved');
    }

    public function providers()
    {
        $this->authorizeAitools();
        $companyId = $this->currentCompanyId();
        $this->providers = AiProviderProfile::query()
            ->when(!user()->is_superadmin, fn ($q) => $q->where(function ($query) use ($companyId) {
                $query->whereNull('company_id')->orWhere('company_id', $companyId);
            }))
            ->orderBy('priority')->get();

        return view('aitools::control-plane.providers', $this->data);
    }

    public function storeProvider(Request $request)
    {
        $this->authorizeAitools();
        AiProviderProfile::updateOrCreate(
            ['company_id' => $this->currentCompanyId(), 'profile_key' => $request->profile_key],
            [
                'provider' => $request->provider ?: 'openai',
                'default_model' => $request->default_model,
                'fallback_model' => $request->fallback_model,
                'offline_model' => $request->offline_model,
                'supports_reasoning' => $request->boolean('supports_reasoning', true),
                'supports_text' => $request->boolean('supports_text', true),
                'supports_image' => $request->boolean('supports_image', false),
                'supports_multimodal' => $request->boolean('supports_multimodal', false),
                'supports_embeddings' => $request->boolean('supports_embeddings', false),
                'supports_structured_output' => $request->boolean('supports_structured_output', false),
                'priority' => (int) ($request->priority ?? 100),
                'is_active' => $request->boolean('is_active', true),
            ]
        );

        return back()->with('status', 'Provider profile saved');
    }
}
