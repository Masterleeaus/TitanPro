<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('ai_tools_wizard_templates')) {
            Schema::create('ai_tools_wizard_templates', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->nullable()->index();
                $table->unsignedBigInteger('created_by')->nullable()->index();
                $table->string('name');
                $table->string('slug');
                $table->string('category')->nullable()->index();
                $table->string('output_format')->default('text');
                $table->string('visibility')->default('company');
                $table->boolean('is_active')->default(true);
                $table->text('description')->nullable();
                $table->json('steps_json')->nullable();
                $table->longText('final_prompt_template')->nullable();
                $table->text('generated_from_brief')->nullable();
                $table->timestamps();

                $table->unique(['company_id', 'slug'], 'aitools_wizard_templates_company_slug_unique');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_tools_wizard_templates');
    }
};
