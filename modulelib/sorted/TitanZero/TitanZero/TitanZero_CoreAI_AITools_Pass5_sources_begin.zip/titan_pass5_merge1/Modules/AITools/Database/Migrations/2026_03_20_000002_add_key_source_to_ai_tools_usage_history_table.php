<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ai_tools_usage_history', function (Blueprint $table) {
            if (!Schema::hasColumn('ai_tools_usage_history', 'key_source')) {
                $table->string('key_source', 20)->nullable()->after('model');
            }
        });
    }

    public function down(): void
    {
        Schema::table('ai_tools_usage_history', function (Blueprint $table) {
            if (Schema::hasColumn('ai_tools_usage_history', 'key_source')) {
                $table->dropColumn('key_source');
            }
        });
    }
};
