@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="card mb-3">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div>
                <h4 class="mb-0">{{ $template->name }}</h4>
                <div class="text-muted small">{{ $template->category ?: 'general' }} · {{ $template->output_format }} · {{ $template->version_label ?: 'v1' }}</div>
                @if($template->metadataLabel())
                    <div class="mt-1"><span class="badge bg-light text-dark">{{ $template->metadataLabel() }}</span></div>
                @endif
            </div>
            <div class="d-flex gap-2">
                <form method="POST" action="{{ route('ai-tools.templates.duplicate', $template->id) }}">@csrf<button class="btn btn-outline-primary">{{ __('app.copy') }}</button></form>
                <a href="{{ route('ai-tools.templates.index') }}" class="btn btn-outline-secondary">{{ __('app.back') }}</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-header"><h5 class="mb-0">{{ __('app.edit') }}</h5></div>
                <div class="card-body">
                    <form id="update-template-form">
                        @csrf
                        @method('PUT')
                        <div class="form-group mb-3"><label>{{ __('app.name') }}</label><input type="text" class="form-control" name="name" value="{{ $template->name }}"></div>
                        <div class="row">
                            <div class="col-md-6 form-group mb-3"><label>{{ __('aitools::app.category') }}</label><input type="text" class="form-control" name="category" value="{{ $template->category }}"></div>
                            <div class="col-md-6 form-group mb-3"><label>{{ __('aitools::app.persona') }}</label><select name="persona_key" class="form-control"><option value="">None</option>@foreach($personas as $persona)<option value="{{ $persona }}" @selected($template->persona_key === $persona)>{{ ucfirst($persona) }}</option>@endforeach</select></div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 form-group mb-3"><label>{{ __('aitools::app.lifecycleStage') }}</label><select name="lifecycle_stage" class="form-control"><option value="">None</option>@foreach($lifecycleStages as $stage)<option value="{{ $stage }}" @selected($template->lifecycle_stage === $stage)>{{ ucfirst($stage) }}</option>@endforeach</select></div>
                            <div class="col-md-6 form-group mb-3"><label>{{ __('aitools::app.actionKey') }}</label><input type="text" class="form-control" name="action_key" value="{{ $template->action_key }}"></div>
                        </div>
                        <div class="form-group mb-3"><label>{{ __('app.description') }}</label><textarea class="form-control" name="description" rows="3">{{ $template->description }}</textarea></div>
                        <div class="form-group mb-3"><label>{{ __('aitools::app.systemPrompt') }}</label><textarea class="form-control" name="system_prompt" rows="4">{{ $template->system_prompt }}</textarea></div>
                        <div class="form-group mb-3"><label>{{ __('aitools::app.userPromptTemplate') }}</label><textarea class="form-control" name="user_prompt_template" rows="6">{{ $template->user_prompt_template }}</textarea></div>
                        <div class="form-group mb-3"><label>{{ __('aitools::app.variablesJson') }}</label><textarea class="form-control" name="variables_json" rows="5">{{ json_encode($template->variables_json ?: [], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</textarea></div>
                        <div class="row">
                            <div class="col-md-4 form-group mb-3"><label>{{ __('aitools::app.outputFormat') }}</label><select class="form-control" name="output_format"><option value="text" @selected($template->output_format==='text')>text</option><option value="markdown" @selected($template->output_format==='markdown')>markdown</option><option value="json" @selected($template->output_format==='json')>json</option><option value="html" @selected($template->output_format==='html')>html</option></select></div>
                            <div class="col-md-4 form-group mb-3"><label>{{ __('aitools::app.status') }}</label><select class="form-control" name="status"><option value="draft" @selected($template->status==='draft')>draft</option><option value="published" @selected($template->status==='published')>published</option><option value="archived" @selected($template->status==='archived')>archived</option></select></div>
                            <div class="col-md-4 form-group mb-3"><label>{{ __('aitools::app.version') }}</label><input type="text" class="form-control" name="version_label" value="{{ $template->version_label ?: 'v1' }}"></div>
                        </div>
                        <button class="btn btn-primary">{{ __('app.save') }}</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-header"><h5 class="mb-0">{{ __('aitools::app.runTemplate') }}</h5></div>
                <div class="card-body">
                    <form id="run-template-form">
                        @csrf
                        @foreach($template->resolvedVariables() as $variable)
                            <div class="form-group mb-3">
                                <label>{{ $variable['label'] }}</label>
                                <input type="text" class="form-control" name="variables[{{ $variable['key'] }}]" placeholder="{{ $variable['placeholder'] }}">
                            </div>
                        @endforeach
                        <div class="d-flex gap-2">
                            <button class="btn btn-outline-secondary" type="button" id="preview-template-button">{{ __('aitools::app.preview') }}</button>
                            <button class="btn btn-primary">{{ __('aitools::app.runTemplate') }}</button>
                        </div>
                    </form>
                    <hr>
                    <h6>{{ __('aitools::app.preview') }}</h6>
                    <pre id="template-preview" class="bg-light border rounded p-3 mb-3" style="min-height: 140px; white-space: pre-wrap;"></pre>
                    <h6>{{ __('aitools::app.output') }}</h6>
                    <pre id="template-output" class="bg-light border rounded p-3" style="min-height: 240px; white-space: pre-wrap;"></pre>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
$('#update-template-form').on('submit', function (e) {
    e.preventDefault();
    $.ajax({
        url: '{{ route('ai-tools.templates.update', $template->id) }}',
        method: 'POST',
        data: $(this).serialize(),
        success: function () { window.location.reload(); },
        error: function (xhr) { alert(xhr.responseJSON?.message || xhr.responseJSON?.error || 'Request failed'); }
    });
});

$('#preview-template-button').on('click', function () {
    $.ajax({
        url: '{{ route('ai-tools.templates.preview', $template->id) }}',
        method: 'POST',
        data: $('#run-template-form').serialize(),
        success: function (response) {
            $('#template-preview').text(JSON.stringify(response.data || {}, null, 2));
        },
        error: function (xhr) { alert(xhr.responseJSON?.message || xhr.responseJSON?.error || 'Request failed'); }
    });
});

$('#run-template-form').on('submit', function (e) {
    e.preventDefault();
    $.ajax({
        url: '{{ route('ai-tools.templates.run', $template->id) }}',
        method: 'POST',
        data: $(this).serialize(),
        success: function (response) {
            $('#template-output').text(response.data?.content || '');
        },
        error: function (xhr) {
            alert(xhr.responseJSON?.message || xhr.responseJSON?.error || 'Request failed');
        }
    });
});
</script>
@endpush
