@extends('layouts.app')
@section('content')
<div class="row">
  <div class="col-md-4">
    <div class="card"><div class="card-body">
      <h3 class="mb-3">Assistant Profiles</h3>
      <form method="POST" action="{{ route('ai-tools.control-plane.assistants.store') }}">@csrf
        <div class="mb-2"><label>Slug</label><input name="assistant_slug" class="form-control" required></div>
        <div class="mb-2"><label>Name</label><input name="name" class="form-control" required></div>
        <div class="mb-2"><label>Default Persona</label><input name="default_persona" class="form-control" value="Zero"></div>
        <div class="mb-2"><label>Entity Scope</label><input name="entity_scope" class="form-control" placeholder="job|invoice|booking"></div>
        <div class="mb-2"><label>Lifecycle Events</label><input name="allowed_lifecycle_events" class="form-control" placeholder="booking.processed,job.completed"></div>
        <div class="mb-2"><label>Attached Entities</label><input name="attached_entities" class="form-control" placeholder="job,customer"></div>
        <div class="mb-2"><label>Token Budget</label><input name="token_budget" type="number" class="form-control" value="0"></div>
        <div class="mb-2"><label>Temperature</label><input name="temperature" type="number" step="0.01" class="form-control" value="0.20"></div>
        <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="requires_zero_merge" value="1" checked id="requires_zero_merge"><label class="form-check-label" for="requires_zero_merge">Requires Zero merge</label></div>
        <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="is_active" value="1" checked id="assistant_active"><label class="form-check-label" for="assistant_active">Active</label></div>
        <button class="btn btn-primary w-100">Save Assistant</button>
      </form>
    </div></div>
  </div>
  <div class="col-md-8">
    <div class="card"><div class="card-body">
      <h3 class="mb-3">Current Assistants</h3>
      <div class="table-responsive"><table class="table table-bordered align-middle"><thead><tr><th>Slug</th><th>Name</th><th>Persona</th><th>Scope</th><th>Budget</th><th>Status</th></tr></thead><tbody>
      @forelse($assistants as $assistant)
        <tr>
          <td>{{ $assistant->assistant_slug }}</td><td>{{ $assistant->name }}</td><td>{{ $assistant->default_persona }}</td><td>{{ $assistant->entity_scope }}</td><td>{{ $assistant->token_budget }}</td><td>{{ $assistant->is_active ? 'active' : 'off' }}</td>
        </tr>
      @empty
        <tr><td colspan="6">No assistants yet.</td></tr>
      @endforelse
      </tbody></table></div>
    </div></div>
  </div>
</div>
@endsection
