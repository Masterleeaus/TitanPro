<?php

namespace Modules\Aitools\Services;

class PromptPreviewService
{
    public function renderTemplateText(string $template, array $variables = []): array
    {
        preg_match_all('/{{\s*([a-zA-Z0-9_\.\-]+)\s*}}/', $template, $matches);
        $placeholders = collect($matches[1] ?? [])->unique()->values()->all();
        $missing = [];
        $replacements = [];

        foreach ($placeholders as $key) {
            $value = data_get($variables, $key);
            if (is_null($value) || $value === '') {
                $missing[] = $key;
                $value = '{{' . $key . '}}';
            }

            $replacements['{{' . $key . '}}'] = is_scalar($value) ? (string) $value : json_encode($value);
            $replacements['{{ ' . $key . ' }}'] = $replacements['{{' . $key . '}}'];
        }

        $resolved = strtr($template, $replacements);

        return [
            'raw' => $template,
            'resolved' => $resolved,
            'missing_variables' => array_values(array_unique($missing)),
            'estimated_tokens' => max(1, (int) ceil(mb_strlen($resolved) / 4)),
        ];
    }
}
