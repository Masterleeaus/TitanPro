<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;

class AiAuditReplay extends BaseModel
{
    protected $table = 'ai_tools_audit_replays';

    protected $guarded = ['id'];

    protected $casts = [
        'persona_sequence_json' => 'array',
        'provider_chain_json' => 'array',
        'confidence_metrics_json' => 'array',
        'trace_json' => 'array',
    ];
}
