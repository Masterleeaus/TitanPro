<?php

namespace Modules\Aitools\Services;

class PromptComparisonService
{
    public function compare(array $leftPreview, array $rightPreview): array
    {
        $leftPrompt = trim((string) (($leftPreview['system_prompt'] ?? '') . "

" . ($leftPreview['user_prompt'] ?? '')));
        $rightPrompt = trim((string) (($rightPreview['system_prompt'] ?? '') . "

" . ($rightPreview['user_prompt'] ?? '')));

        return [
            'left_tokens' => (int) ($leftPreview['estimated_prompt_tokens'] ?? 0),
            'right_tokens' => (int) ($rightPreview['estimated_prompt_tokens'] ?? 0),
            'token_delta' => ((int) ($rightPreview['estimated_prompt_tokens'] ?? 0)) - ((int) ($leftPreview['estimated_prompt_tokens'] ?? 0)),
            'schema_completeness_left' => $this->schemaCompleteness($leftPrompt),
            'schema_completeness_right' => $this->schemaCompleteness($rightPrompt),
            'lifecycle_readiness_left' => $this->lifecycleReadiness($leftPrompt),
            'lifecycle_readiness_right' => $this->lifecycleReadiness($rightPrompt),
            'diff' => $this->lineDiff($leftPrompt, $rightPrompt),
        ];
    }

    protected function schemaCompleteness(string $prompt): int
    {
        $score = 0;
        foreach (['json', 'schema', 'required', 'format'] as $needle) {
            if (stripos($prompt, $needle) !== false) {
                $score += 25;
            }
        }
        return min(100, $score);
    }

    protected function lifecycleReadiness(string $prompt): int
    {
        $score = 0;
        foreach (['customer', 'action', 'stage', 'output', 'context'] as $needle) {
            if (stripos($prompt, $needle) !== false) {
                $score += 20;
            }
        }
        return min(100, $score);
    }

    protected function lineDiff(string $left, string $right): array
    {
        $leftLines = preg_split('/
||
/', $left) ?: [];
        $rightLines = preg_split('/
||
/', $right) ?: [];
        $max = max(count($leftLines), count($rightLines));
        $diff = [];

        for ($i = 0; $i < $max; $i++) {
            $l = $leftLines[$i] ?? null;
            $r = $rightLines[$i] ?? null;
            if ($l === $r) {
                continue;
            }
            $diff[] = [
                'line' => $i + 1,
                'left' => $l,
                'right' => $r,
            ];
        }

        return array_slice($diff, 0, 40);
    }
}
