@if (in_array('aitools', user_modules()) && module_enabled('Aitools') && user()->permission('edit_aitools') == 'all')
    <x-setting-menu-item :active="$activeMenu" menu="ai_tools_settings" :href="route('ai-tools-settings.index')"
                         text="AI Tools"/>
    <x-setting-menu-item :active="$activeMenu" menu="ai_tools_usage" :href="route('ai-tools-usage.index')"
                         :text="__('aitools::app.usageHistory')"/>
    <x-setting-menu-item :active="$activeMenu" menu="ai_prompt_templates" :href="route('ai-tools.templates.index')"
                         :text="__('aitools::app.promptLibrary')"/>
    <x-setting-menu-item :active="$activeMenu" menu="ai_wizard_templates" :href="route('ai-tools.wizards.index')"
                         :text="__('aitools::app.wizardLibrary')"/>
@endif
