<?php

use Illuminate\Support\Facades\Route;
use Modules\Aitools\Http\Controllers\AiToolsSettingController;
use Modules\Aitools\Http\Controllers\AiRephraseController;
use Modules\Aitools\Http\Controllers\AiTemplateController;
use Modules\Aitools\Http\Controllers\AiWizardController;
use Modules\Aitools\Http\Controllers\AiPersonaController;
use Modules\Aitools\Http\Controllers\AiPromptLabController;
use Modules\Aitools\Http\Controllers\AiKnowledgePackController;
use Modules\Aitools\Http\Controllers\AiOpsDashboardController;
use Modules\Aitools\Http\Controllers\AiControlPlaneController;
use Modules\Aitools\Http\Controllers\AiRuntimeContractController;

Route::group(['middleware' => 'auth', 'prefix' => 'account'], function () {
    Route::resource('settings/ai-tools-settings', AiToolsSettingController::class)->only(['index', 'update']);
    Route::post('ai-tools-settings/test-chat', [AiToolsSettingController::class, 'testChat'])->name('ai-tools-settings.test-chat');
    Route::post('ai-tools-settings/refresh-usage', [AiToolsSettingController::class, 'refreshUsage'])->name('ai-tools-settings.refresh-usage');
    Route::post('ai-tools-settings/reset-usage', [AiToolsSettingController::class, 'resetUsage'])->name('ai-tools-settings.reset-usage');
    Route::post('ai-tools-settings/update-company-used-tokens', [AiToolsSettingController::class, 'updateCompanyUsedTokens'])->name('ai-tools-settings.update-company-used-tokens');
    Route::get('ai-tools-settings/export-usage', [AiToolsSettingController::class, 'exportUsage'])->name('ai-tools-settings.export-usage');
    Route::get('settings/ai-tools-usage', [AiToolsSettingController::class, 'companyUsage'])->name('ai-tools-usage.index');
    Route::post('ai-tools/rephrase-text', [AiRephraseController::class, 'rephraseText'])->name('ai-tools.rephrase-text');

    Route::get('ai-tools/templates', [AiTemplateController::class, 'index'])->name('ai-tools.templates.index');
    Route::post('ai-tools/templates', [AiTemplateController::class, 'store'])->name('ai-tools.templates.store');
    Route::post('ai-tools/templates/generate', [AiTemplateController::class, 'generate'])->name('ai-tools.templates.generate');
    Route::get('ai-tools/templates/{template}', [AiTemplateController::class, 'show'])->name('ai-tools.templates.show');
    Route::put('ai-tools/templates/{template}', [AiTemplateController::class, 'update'])->name('ai-tools.templates.update');
    Route::post('ai-tools/templates/{template}/duplicate', [AiTemplateController::class, 'duplicate'])->name('ai-tools.templates.duplicate');
    Route::post('ai-tools/templates/{template}/preview', [AiTemplateController::class, 'preview'])->name('ai-tools.templates.preview');
    Route::post('ai-tools/templates/{template}/run', [AiTemplateController::class, 'run'])->name('ai-tools.templates.run');


    Route::get('ai-tools/personas', [AiPersonaController::class, 'index'])->name('ai-tools.personas.index');
    Route::post('ai-tools/personas', [AiPersonaController::class, 'store'])->name('ai-tools.personas.store');
    Route::put('ai-tools/personas/{persona}', [AiPersonaController::class, 'update'])->name('ai-tools.personas.update');

    Route::get('ai-tools/prompt-lab', [AiPromptLabController::class, 'index'])->name('ai-tools.prompt-lab.index');

    Route::get('ai-tools/knowledge-packs', [AiKnowledgePackController::class, 'index'])->name('ai-tools.knowledge-packs.index');
    Route::post('ai-tools/knowledge-packs', [AiKnowledgePackController::class, 'store'])->name('ai-tools.knowledge-packs.store');
    Route::get('ai-tools/ops/quota', [AiOpsDashboardController::class, 'quota'])->name('ai-tools.ops.quota');
    Route::get('ai-tools/ops/health', [AiOpsDashboardController::class, 'health'])->name('ai-tools.ops.health');
    Route::get('ai-tools/ops/replay', [AiOpsDashboardController::class, 'replay'])->name('ai-tools.ops.replay');

    Route::get('ai-tools/control-plane/providers', [AiControlPlaneController::class, 'providers'])->name('ai-tools.control-plane.providers');
    Route::get('ai-tools/control-plane/core-integration', [AiControlPlaneController::class, 'coreIntegration'])->name('ai-tools.control-plane.core-integration');
    Route::post('ai-tools/control-plane/core-integration/sync', [AiControlPlaneController::class, 'syncCoreIntegration'])->name('ai-tools.control-plane.core-integration.sync');
    Route::get('ai-tools/control-plane/chat', [AiControlPlaneController::class, 'chat'])->name('ai-tools.control-plane.chat');
    Route::post('ai-tools/control-plane/chat', [AiControlPlaneController::class, 'storeChat'])->name('ai-tools.control-plane.chat.store');
    Route::get('ai-tools/control-plane/health-logs', [AiControlPlaneController::class, 'healthLogs'])->name('ai-tools.control-plane.health-logs');
    Route::post('ai-tools/control-plane/health-logs', [AiControlPlaneController::class, 'storeHealthLog'])->name('ai-tools.control-plane.health-logs.store');
    Route::get('ai-tools/control-plane/replays/{replay}', [AiControlPlaneController::class, 'replayShow'])->name('ai-tools.control-plane.replays.show');
    Route::post('ai-tools/control-plane/providers', [AiControlPlaneController::class, 'storeProvider'])->name('ai-tools.control-plane.providers.store');
    Route::get('ai-tools/control-plane/lifecycle-support', [AiControlPlaneController::class, 'lifecycleSupport'])->name('ai-tools.control-plane.lifecycle-support');
    Route::post('ai-tools/control-plane/lifecycle-support', [AiControlPlaneController::class, 'storeLifecycleSupport'])->name('ai-tools.control-plane.lifecycle-support.store');
    Route::get('ai-tools/control-plane/bundles', [AiControlPlaneController::class, 'bundles'])->name('ai-tools.control-plane.bundles');
    Route::post('ai-tools/control-plane/bundles', [AiControlPlaneController::class, 'storeBundle'])->name('ai-tools.control-plane.bundles.store');
    Route::get('ai-tools/control-plane/assistants', [AiControlPlaneController::class, 'assistants'])->name('ai-tools.control-plane.assistants');
    Route::post('ai-tools/control-plane/assistants', [AiControlPlaneController::class, 'storeAssistant'])->name('ai-tools.control-plane.assistants.store');
    Route::get('ai-tools/control-plane/vectors', [AiControlPlaneController::class, 'vectors'])->name('ai-tools.control-plane.vectors');
    Route::post('ai-tools/control-plane/vectors', [AiControlPlaneController::class, 'storeVector'])->name('ai-tools.control-plane.vectors.store');
    Route::post('ai-tools/prompt-lab/preview', [AiPromptLabController::class, 'preview'])->name('ai-tools.prompt-lab.preview');
    Route::post('ai-tools/prompt-lab/compare', [AiPromptLabController::class, 'compare'])->name('ai-tools.prompt-lab.compare');
    Route::post('ai-tools/prompt-lab/scenarios', [AiPromptLabController::class, 'saveScenario'])->name('ai-tools.prompt-lab.scenarios.store');

    Route::post('ai-tools/runtime/prompt', [AiRuntimeContractController::class, 'prompt'])->name('ai-tools.runtime.prompt');
    Route::post('ai-tools/runtime/lifecycle-bundle', [AiRuntimeContractController::class, 'lifecycleBundle'])->name('ai-tools.runtime.lifecycle-bundle');
    Route::post('ai-tools/runtime/persona', [AiRuntimeContractController::class, 'persona'])->name('ai-tools.runtime.persona');
    Route::post('ai-tools/runtime/provider', [AiRuntimeContractController::class, 'provider'])->name('ai-tools.runtime.provider');
    Route::post('ai-tools/runtime/chat', [AiRuntimeContractController::class, 'chat'])->name('ai-tools.runtime.chat');

    Route::get('ai-tools/wizards', [AiWizardController::class, 'index'])->name('ai-tools.wizards.index');

    Route::get('ai-tools/wizards/lifecycle/create', [AiWizardController::class, 'createLifecycle'])->name('ai-tools.wizards.lifecycle.create');
    Route::post('ai-tools/wizards/presets', [AiWizardController::class, 'storePreset'])->name('ai-tools.wizards.presets.store');
    Route::post('ai-tools/wizards', [AiWizardController::class, 'store'])->name('ai-tools.wizards.store');
    Route::post('ai-tools/wizards/generate', [AiWizardController::class, 'generate'])->name('ai-tools.wizards.generate');
    Route::get('ai-tools/wizards/{wizard}', [AiWizardController::class, 'show'])->name('ai-tools.wizards.show');
    Route::put('ai-tools/wizards/{wizard}', [AiWizardController::class, 'update'])->name('ai-tools.wizards.update');
    Route::post('ai-tools/wizards/{wizard}/duplicate', [AiWizardController::class, 'duplicate'])->name('ai-tools.wizards.duplicate');
    Route::post('ai-tools/wizards/{wizard}/preview', [AiWizardController::class, 'preview'])->name('ai-tools.wizards.preview');
    Route::post('ai-tools/wizards/{wizard}/run', [AiWizardController::class, 'run'])->name('ai-tools.wizards.run');

    Route::group(['prefix' => 'projects'], function () {
        Route::post('rephrase-text', [AiRephraseController::class, 'rephraseText'])->name('projects.rephrase-text');
    });
});
