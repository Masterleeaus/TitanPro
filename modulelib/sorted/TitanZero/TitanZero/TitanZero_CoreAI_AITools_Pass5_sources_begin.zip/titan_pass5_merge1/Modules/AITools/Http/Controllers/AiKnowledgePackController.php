<?php

namespace Modules\Aitools\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\Aitools\Entities\AiKnowledgePack;

class AiKnowledgePackController extends AccountBaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'Knowledge Packs';
        $this->activeSettingMenu = 'ai_knowledge_packs';
    }

    public function index()
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('edit_aitools') == 'all')));
        $this->packs = AiKnowledgePack::query()->visibleToCurrentUser()->latest()->get();

        return view('aitools::knowledge-packs.index', $this->data);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255',
            'pack_type' => 'required|string|max:50',
            'persona_key' => 'nullable|string|max:50',
            'lifecycle_stage' => 'nullable|string|max:50',
            'description' => 'nullable|string',
            'status' => 'nullable|string|max:30',
            'is_active' => 'nullable|boolean',
        ]);

        $data['company_id'] = user()->is_superadmin ? null : company()?->id;
        $pack = AiKnowledgePack::create($data);

        return Reply::successWithData('Knowledge pack saved.', ['id' => $pack->id]);
    }
}
