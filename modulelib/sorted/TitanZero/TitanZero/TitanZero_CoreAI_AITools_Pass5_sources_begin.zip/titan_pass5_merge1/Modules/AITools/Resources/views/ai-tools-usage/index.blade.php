@extends('layouts.app')

@push('styles')
    <style>
        .ai-tool-card {
            background: #fff;
            border: 1px solid #e0e6ed;
            border-radius: 8px;
            padding: 24px;
            margin-bottom: 24px;
            transition: all 0.3s ease;
        }

        .ai-tool-card:hover {
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .usage-stat-card {
            padding: 20px;
        }

        .usage-stat-card h3 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .usage-stat-card p {
            font-size: 14px;
            color: #6c757d;
        }
    </style>
@endpush

@section('content')

    <!-- SETTINGS START -->
    <div class="w-100 d-flex ">

        <x-setting-sidebar :activeMenu="$activeSettingMenu" />

        <x-setting-card>
            <x-slot name="header">
                {{-- <div class="s-b-n-header">
                    <h4 class="mb-0 f-18 font-weight-normal">@lang('aitools::app.usageHistory')</h4>
                </div> --}}
            </x-slot>

            <div class="col-lg-12 col-md-12 ntfcn-tab-content-left w-100 p-20">
                {{-- Usage Statistics --}}
                <div class="row">
                    <div class="col-lg-12 mb-4">
                        <h5 class="mb-4">@lang('aitools::app.usageStatistics')</h5>
                        
                        <div class="row mb-4">
                            <div class="col-md-3">
                                <div class="ai-tool-card usage-stat-card text-center">
                                    <h3 class="mb-2 text-info" id="stat-prompt-tokens">{{ number_format($totalPromptTokens ?? 0) }}</h3>
                                    <p class="mb-0 text-muted">@lang('aitools::app.promptTokens')</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="ai-tool-card usage-stat-card text-center">
                                    <h3 class="mb-2 text-warning" id="stat-completion-tokens">{{ number_format($totalCompletionTokens ?? 0) }}</h3>
                                    <p class="mb-0 text-muted">@lang('aitools::app.completionTokens')</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="ai-tool-card usage-stat-card text-center">
                                    <h3 class="mb-2 text-success" id="stat-total-requests">{{ number_format($totalRequests ?? 0) }}</h3>
                                    <p class="mb-0 text-muted">@lang('aitools::app.totalRequests')</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="ai-tool-card usage-stat-card text-center">
                                    <h3 class="mb-2 text-primary" id="stat-total-tokens">{{ number_format($totalTokens ?? 0) }}</h3>
                                    <p class="mb-0 text-muted">@lang('aitools::app.totalTokens')</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="ai-tool-card usage-stat-card text-center">
                                    <h3 class="mb-2 text-dark" id="stat-total-assigned-tokens">{{ number_format($totalAssignedTokens ?? 0) }}</h3>
                                    <p class="mb-0 text-muted">@lang('aitools::app.totalAssignedTokens')</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="ai-tool-card usage-stat-card text-center">
                                    <h3 class="mb-2 {{ ($remainingTokens ?? 0) > 0 ? 'text-success' : 'text-danger' }}" id="stat-remaining-tokens">{{ number_format($remainingTokens ?? 0) }}</h3>
                                    <p class="mb-0 text-muted">@lang('aitools::app.remainingTokens')</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                

                @php($usageStartDate = $usageFilters['start_date'] ?? request('start_date'))
                @php($usageEndDate = $usageFilters['end_date'] ?? request('end_date'))

                <div class="row mt-4">
                    <div class="col-12">
                        <div class="ai-tool-card">
                            <div class="d-flex justify-content-between align-items-end flex-wrap mb-3" style="gap: 12px;">
                                <div>
                                    <h5 class="mb-1">Usage filters</h5>
                                    <p class="text-muted mb-0">Filter your company history by date, then export the same slice.</p>
                                </div>
                                <form method="GET" action="{{ route('ai-tools-usage.index') }}" class="d-flex flex-wrap" style="gap: 12px;">
                                    <div>
                                        <label class="f-12 text-muted d-block mb-1">Start date</label>
                                        <input type="date" class="form-control" name="start_date" value="{{ $usageStartDate }}">
                                    </div>
                                    <div>
                                        <label class="f-12 text-muted d-block mb-1">End date</label>
                                        <input type="date" class="form-control" name="end_date" value="{{ $usageEndDate }}">
                                    </div>
                                    <div class="align-self-end d-flex" style="gap: 8px;">
                                        <button type="submit" class="btn btn-primary">Apply</button>
                                        <a href="{{ route('ai-tools-settings.export-usage', array_filter(['start_date' => $usageStartDate, 'end_date' => $usageEndDate])) }}" class="btn btn-outline-secondary">Export CSV</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                @if(isset($usageHistory) && $usageHistory->count())
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="ai-tool-card">
                                <h5 class="mb-3">Recent AI requests</h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th>When</th>
                                                <th>User</th>
                                                <th>Type</th>
                                                <th>Model</th>
                                                <th>Key Source</th>
                                                <th>Tokens</th>
                                                <th>Cost</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($usageHistory as $item)
                                                <tr>
                                                    <td>{{ optional($item->created_at)->format($usageDateTimeFormat ?? 'Y-m-d H:i') }}</td>
                                                    <td>{{ $item->user->name ?? 'System' }}</td>
                                                    <td>{{ $item->request_type ?? 'request' }}</td>
                                                    <td>{{ $item->model ?? '-' }}</td>
                                                    <td>{{ ucfirst($item->key_source ?? 'unknown') }}</td>
                                                    <td>{{ number_format($item->total_tokens ?? 0) }}</td>
                                                    <td>${{ number_format((float) ($item->estimated_cost ?? 0), 6) }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <div class="mt-3">{{ $usageHistory->links() }}</div>
                            </div>
                        </div>
                    </div>
                @endif

            </div>
        </x-setting-card>
    </div>
    <!-- SETTINGS END -->

@endsection

@push('scripts')
    <script>
        function number_format(number) {
            return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
    </script>
@endpush
