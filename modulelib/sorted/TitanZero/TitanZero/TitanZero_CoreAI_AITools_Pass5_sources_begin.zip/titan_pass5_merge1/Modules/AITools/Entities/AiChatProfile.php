<?php

namespace Modules\Aitools\Entities;

use Illuminate\Database\Eloquent\Model;

class AiChatProfile extends Model
{
    protected $table = 'ai_chat_profiles';

    protected $guarded = ['id'];

    protected $casts = [
        'allowed_assistants' => 'array',
        'feature_flags' => 'array',
        'exports_enabled' => 'boolean',
        'entity_linking_enabled' => 'boolean',
        'citations_enabled' => 'boolean',
        'voice_friendly' => 'boolean',
        'is_active' => 'boolean',
    ];
}
