<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('ai_tools_prompt_templates', function (Blueprint $table) {
            if (!Schema::hasColumn('ai_tools_prompt_templates', 'persona_key')) {
                $table->string('persona_key', 50)->nullable()->after('category');
            }
            if (!Schema::hasColumn('ai_tools_prompt_templates', 'lifecycle_stage')) {
                $table->string('lifecycle_stage', 50)->nullable()->after('persona_key');
            }
            if (!Schema::hasColumn('ai_tools_prompt_templates', 'action_key')) {
                $table->string('action_key', 100)->nullable()->after('lifecycle_stage');
            }
            if (!Schema::hasColumn('ai_tools_prompt_templates', 'status')) {
                $table->string('status', 20)->default('draft')->after('visibility');
            }
            if (!Schema::hasColumn('ai_tools_prompt_templates', 'version_label')) {
                $table->string('version_label', 30)->default('v1')->after('status');
            }
        });

        Schema::table('ai_tools_wizard_templates', function (Blueprint $table) {
            if (!Schema::hasColumn('ai_tools_wizard_templates', 'lifecycle_stage')) {
                $table->string('lifecycle_stage', 50)->nullable()->after('category');
            }
            if (!Schema::hasColumn('ai_tools_wizard_templates', 'action_key')) {
                $table->string('action_key', 100)->nullable()->after('lifecycle_stage');
            }
            if (!Schema::hasColumn('ai_tools_wizard_templates', 'status')) {
                $table->string('status', 20)->default('draft')->after('visibility');
            }
            if (!Schema::hasColumn('ai_tools_wizard_templates', 'version_label')) {
                $table->string('version_label', 30)->default('v1')->after('status');
            }
        });
    }

    public function down(): void
    {
        Schema::table('ai_tools_prompt_templates', function (Blueprint $table) {
            foreach (['persona_key', 'lifecycle_stage', 'action_key', 'status', 'version_label'] as $column) {
                if (Schema::hasColumn('ai_tools_prompt_templates', $column)) {
                    $table->dropColumn($column);
                }
            }
        });

        Schema::table('ai_tools_wizard_templates', function (Blueprint $table) {
            foreach (['lifecycle_stage', 'action_key', 'status', 'version_label'] as $column) {
                if (Schema::hasColumn('ai_tools_wizard_templates', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
