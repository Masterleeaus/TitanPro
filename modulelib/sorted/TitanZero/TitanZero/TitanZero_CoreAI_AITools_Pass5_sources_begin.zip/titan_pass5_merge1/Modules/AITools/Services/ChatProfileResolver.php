<?php

namespace Modules\Aitools\Services;

use Modules\Aitools\Entities\AiChatProfile;

class ChatProfileResolver
{
    public function getChatProfile(?string $profileKey = null, ?int $companyId = null): array
    {
        $profile = AiChatProfile::query()
            ->where('is_active', true)
            ->when($profileKey, fn ($query) => $query->where('profile_key', $profileKey))
            ->when(!is_null($companyId), fn ($query) => $query->where(function ($builder) use ($companyId) {
                $builder->where('company_id', $companyId)->orWhereNull('company_id');
            }))
            ->orderByRaw('CASE WHEN company_id IS NULL THEN 1 ELSE 0 END')
            ->latest()
            ->first();

        if (!$profile) {
            return ['found' => false, 'message' => 'Chat profile not found.'];
        }

        return [
            'found' => true,
            'profile_key' => $profile->profile_key,
            'name' => $profile->name,
            'default_persona' => $profile->default_persona,
            'thread_mode' => $profile->thread_mode,
            'response_style' => $profile->response_style,
            'tone' => $profile->tone,
            'memory_window' => (int) $profile->memory_window,
            'export_retention_days' => (int) $profile->export_retention_days,
            'exports_enabled' => (bool) $profile->exports_enabled,
            'entity_linking_enabled' => (bool) $profile->entity_linking_enabled,
            'citations_enabled' => (bool) $profile->citations_enabled,
            'voice_friendly' => (bool) $profile->voice_friendly,
            'allowed_assistants' => $profile->allowed_assistants ?: [],
            'feature_flags' => $profile->feature_flags ?: [],
            'company_scope' => is_null($profile->company_id) ? 'global' : 'company',
        ];
    }
}
