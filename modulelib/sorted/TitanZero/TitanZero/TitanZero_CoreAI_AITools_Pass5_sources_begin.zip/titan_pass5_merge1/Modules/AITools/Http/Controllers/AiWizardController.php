<?php

namespace Modules\Aitools\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\Aitools\Entities\AiWizardTemplate;
use Modules\Aitools\Services\LifecycleWizardPresetService;
use Modules\Aitools\Services\OpenAiTemplateService;

class AiWizardController extends AccountBaseController
{
    public function __construct(
        private OpenAiTemplateService $service,
        private LifecycleWizardPresetService $presets,
    ) {
        parent::__construct();
        $this->pageTitle = 'aitools::app.wizardLibrary';
        $this->activeSettingMenu = 'ai_wizard_templates';
    }

    public function index()
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('edit_aitools') == 'all')));
        $this->wizards = AiWizardTemplate::visibleToCurrentUser()->orderBy('name')->get();
        $this->lifecycleStages = AiWizardTemplate::LIFECYCLE_STAGES;
        $this->presetCards = $this->presets->all();

        return view('aitools::wizards.index', $this->data);
    }

    public function createLifecycle(Request $request)
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('edit_aitools') == 'all')));

        $presetKey = $request->query('preset');
        $selectedPreset = $presetKey ? $this->presets->find($presetKey) : null;
        $this->selectedPreset = $selectedPreset;
        $this->presetCards = $this->presets->all();
        $this->lifecycleStages = AiWizardTemplate::LIFECYCLE_STAGES;

        return view('aitools::wizards.create-lifecycle', $this->data);
    }

    public function store(Request $request)
    {
        $payload = $this->validatedPayload($request);
        $wizard = new AiWizardTemplate();
        $this->fillWizard($wizard, $payload);
        $wizard->slug = AiWizardTemplate::makeSlug($request->name . '-' . now()->timestamp);
        $wizard->created_by = user()->id;
        $wizard->save();

        return Reply::successWithData(__('messages.createSuccess'), [
            'redirect' => route('ai-tools.wizards.show', $wizard->id),
        ]);
    }

    public function storePreset(Request $request)
    {
        $request->validate([
            'preset_key' => 'required|string|max:100',
            'name' => 'nullable|string|max:191',
            'description' => 'nullable|string|max:5000',
        ]);

        $preset = $this->presets->find($request->preset_key);
        abort_unless($preset, 404);

        $wizard = new AiWizardTemplate();
        $wizard->company_id = user()->is_superadmin ? null : company()?->id;
        $wizard->created_by = user()->id;
        $wizard->name = $request->filled('name') ? $request->name : $preset['name'];
        $wizard->slug = AiWizardTemplate::makeSlug(($request->name ?: $preset['name']) . '-' . now()->timestamp);
        $wizard->category = $preset['category'] ?? 'lifecycle';
        $wizard->lifecycle_stage = $preset['lifecycle_stage'] ?? null;
        $wizard->action_key = $preset['action_key'] ?? null;
        $wizard->description = $request->filled('description') ? $request->description : ($preset['description'] ?? null);
        $wizard->steps_json = $preset['steps'] ?? [];
        $wizard->final_prompt_template = $preset['final_prompt_template'] ?? '';
        $wizard->output_format = $preset['output_format'] ?? 'markdown';
        $wizard->generated_from_brief = 'Preset: ' . $request->preset_key;
        $wizard->visibility = user()->is_superadmin ? 'global' : 'company';
        $wizard->status = 'draft';
        $wizard->version_label = 'v1';
        $wizard->is_active = true;
        $wizard->save();

        return Reply::successWithData('Lifecycle wizard created.', [
            'redirect' => route('ai-tools.wizards.show', $wizard->id),
        ]);
    }

    public function generate(Request $request)
    {
        $request->validate([
            'brief' => 'required|string|max:12000',
            'category' => 'nullable|string|max:100',
            'lifecycle_stage' => 'nullable|string|max:50',
            'action_key' => 'nullable|string|max:100',
        ]);

        $generated = $this->service->generateWizardTemplate($request->brief, $request->category ?: 'general');
        $json = $generated['json'];

        $wizard = new AiWizardTemplate();
        $wizard->company_id = user()->is_superadmin ? null : company()?->id;
        $wizard->created_by = user()->id;
        $wizard->name = $json['name'] ?? 'Generated Wizard';
        $wizard->slug = AiWizardTemplate::makeSlug(($json['name'] ?? 'generated-wizard') . '-' . now()->timestamp);
        $wizard->category = $request->category ?: 'general';
        $wizard->lifecycle_stage = $request->lifecycle_stage;
        $wizard->action_key = $request->action_key;
        $wizard->description = $json['description'] ?? null;
        $wizard->steps_json = $json['steps'] ?? [];
        $wizard->final_prompt_template = $json['final_prompt_template'] ?? '';
        $wizard->output_format = $json['output_format'] ?? 'text';
        $wizard->generated_from_brief = $request->brief;
        $wizard->visibility = user()->is_superadmin ? 'global' : 'company';
        $wizard->status = 'draft';
        $wizard->version_label = 'v1';
        $wizard->save();

        return Reply::successWithData('Wizard generated and saved.', ['redirect' => route('ai-tools.wizards.show', $wizard->id)]);
    }

    public function show(AiWizardTemplate $wizard)
    {
        abort_unless($this->canAccess($wizard), 403);
        $this->wizard = $wizard;
        $this->lifecycleStages = AiWizardTemplate::LIFECYCLE_STAGES;
        $this->presetCards = $this->presets->all();
        $this->activeSettingMenu = 'ai_wizard_templates';
        return view('aitools::wizards.show', $this->data);
    }

    public function update(Request $request, AiWizardTemplate $wizard)
    {
        abort_unless($this->canAccess($wizard), 403);
        $payload = $this->validatedPayload($request);
        $this->fillWizard($wizard, $payload);
        $wizard->save();

        return Reply::success(__('messages.updateSuccess'));
    }

    public function duplicate(AiWizardTemplate $wizard)
    {
        abort_unless($this->canAccess($wizard), 403);
        $copy = $wizard->replicate();
        $copy->name = $wizard->name . ' Copy';
        $copy->slug = AiWizardTemplate::makeSlug($wizard->name . '-copy-' . now()->timestamp);
        $copy->status = 'draft';
        $copy->version_label = 'v1';
        $copy->created_by = user()->id;
        $copy->company_id = user()->is_superadmin ? null : company()?->id;
        $copy->visibility = user()->is_superadmin ? 'global' : 'company';
        $copy->save();

        return redirect()->route('ai-tools.wizards.show', $copy->id);
    }

    public function preview(Request $request, AiWizardTemplate $wizard)
    {
        abort_unless($this->canAccess($wizard), 403);
        $answers = [];
        foreach ($wizard->resolvedSteps() as $step) {
            $answers[$step['key']] = $request->input('answers.' . $step['key'], $step['placeholder'] ?? '');
        }

        return Reply::successWithData('Preview generated.', $this->service->previewWizard(
            $wizard->final_prompt_template ?: '',
            $answers,
            $wizard->output_format ?: 'text'
        ));
    }

    public function run(Request $request, AiWizardTemplate $wizard)
    {
        abort_unless($this->canAccess($wizard), 403);
        $answers = [];
        foreach ($wizard->resolvedSteps() as $step) {
            $value = $request->input('answers.' . $step['key']);
            if ($step['required'] && blank($value)) {
                return Reply::error($step['label'] . ' is required.');
            }
            $answers[$step['key']] = $value;
        }

        $result = $this->service->runWizard($wizard->final_prompt_template ?: '', $answers, 'wizard_run', $wizard->output_format ?: 'text');

        return Reply::successWithData('Wizard completed successfully.', ['content' => $result['content']]);
    }

    private function validatedPayload(Request $request): array
    {
        $request->validate([
            'name' => 'required|string|max:191',
            'category' => 'nullable|string|max:100',
            'lifecycle_stage' => 'nullable|string|max:50',
            'action_key' => 'nullable|string|max:100',
            'description' => 'nullable|string|max:5000',
            'steps_json' => 'required|string',
            'final_prompt_template' => 'required|string|max:20000',
            'output_format' => 'nullable|in:text,json,markdown,html',
            'status' => 'nullable|in:draft,published,archived',
            'version_label' => 'nullable|string|max:30',
        ]);

        return $request->all();
    }

    private function fillWizard(AiWizardTemplate $wizard, array $payload): void
    {
        $wizard->company_id = user()->is_superadmin ? null : company()?->id;
        $wizard->name = $payload['name'];
        $wizard->category = $payload['category'] ?? null;
        $wizard->lifecycle_stage = $payload['lifecycle_stage'] ?? null;
        $wizard->action_key = $payload['action_key'] ?? null;
        $wizard->description = $payload['description'] ?? null;
        $wizard->steps_json = $this->decodeJsonField($payload['steps_json'] ?? null, 'steps_json');
        $wizard->final_prompt_template = $payload['final_prompt_template'];
        $wizard->output_format = $payload['output_format'] ?? 'text';
        $wizard->visibility = user()->is_superadmin ? 'global' : 'company';
        $wizard->status = $payload['status'] ?? 'draft';
        $wizard->version_label = $payload['version_label'] ?? 'v1';
    }

    private function decodeJsonField(?string $value, string $field): array
    {
        $decoded = json_decode((string) $value, true);
        if (!is_array($decoded)) {
            throw \Illuminate\Validation\ValidationException::withMessages([$field => 'This field must contain valid JSON.']);
        }

        return $decoded;
    }

    private function canAccess(AiWizardTemplate $wizard): bool
    {
        return user()->is_superadmin || is_null($wizard->company_id) || $wizard->company_id === company()?->id;
    }
}
