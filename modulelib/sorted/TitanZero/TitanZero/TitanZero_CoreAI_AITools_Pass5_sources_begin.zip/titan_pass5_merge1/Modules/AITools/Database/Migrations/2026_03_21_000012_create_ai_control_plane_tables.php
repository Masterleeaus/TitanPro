<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ai_tools_provider_profiles', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('provider', 50)->default('openai')->index();
            $table->string('profile_key')->index();
            $table->string('default_model')->nullable();
            $table->string('fallback_model')->nullable();
            $table->string('offline_model')->nullable();
            $table->boolean('supports_reasoning')->default(true);
            $table->boolean('supports_text')->default(true);
            $table->boolean('supports_image')->default(false);
            $table->boolean('supports_multimodal')->default(false);
            $table->boolean('supports_embeddings')->default(false);
            $table->boolean('supports_structured_output')->default(false);
            $table->unsignedInteger('priority')->default(100);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->unique(['company_id', 'profile_key'], 'ai_tools_provider_profiles_unique');
        });

        Schema::create('ai_tools_lifecycle_bundles', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('bundle_key')->index();
            $table->string('lifecycle_event')->index();
            $table->string('entity_type')->nullable()->index();
            $table->string('default_persona')->nullable();
            $table->string('assistant_slug')->nullable();
            $table->json('prompt_keys')->nullable();
            $table->json('template_keys')->nullable();
            $table->json('wizard_keys')->nullable();
            $table->json('context_schema')->nullable();
            $table->unsignedInteger('priority')->default(100);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->unique(['company_id', 'bundle_key'], 'ai_tools_lifecycle_bundles_unique');
        });

        Schema::create('ai_tools_assistant_profiles', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('assistant_slug')->index();
            $table->string('name');
            $table->string('default_persona')->nullable();
            $table->string('entity_scope')->nullable()->index();
            $table->json('allowed_lifecycle_events')->nullable();
            $table->json('attached_entities')->nullable();
            $table->unsignedInteger('token_budget')->default(0);
            $table->decimal('temperature', 4, 2)->default(0.20);
            $table->boolean('requires_zero_merge')->default(true);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->unique(['company_id', 'assistant_slug'], 'ai_tools_assistant_profiles_unique');
        });

        Schema::create('ai_tools_vector_indexes', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedBigInteger('knowledge_pack_id')->nullable()->index();
            $table->string('index_key')->index();
            $table->string('embedding_provider', 50)->default('openai');
            $table->string('embedding_model')->nullable();
            $table->string('chunk_strategy')->nullable();
            $table->string('lifecycle_scope')->nullable()->index();
            $table->unsignedInteger('chunk_count')->default(0);
            $table->boolean('is_ready')->default(false);
            $table->timestamp('last_indexed_at')->nullable();
            $table->timestamps();
            $table->unique(['company_id', 'index_key'], 'ai_tools_vector_indexes_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_tools_vector_indexes');
        Schema::dropIfExists('ai_tools_assistant_profiles');
        Schema::dropIfExists('ai_tools_lifecycle_bundles');
        Schema::dropIfExists('ai_tools_provider_profiles');
    }
};
