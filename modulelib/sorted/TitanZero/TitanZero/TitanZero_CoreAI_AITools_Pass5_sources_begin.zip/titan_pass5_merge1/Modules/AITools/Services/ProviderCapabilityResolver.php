<?php

namespace Modules\Aitools\Services;

use Modules\Aitools\Entities\AiProviderHealthLog;
use Modules\Aitools\Entities\AiProviderProfile;
use Modules\Aitools\Entities\AiToolsSetting;

class ProviderCapabilityResolver
{
    public function getProviderConfig(array $requirements = [], ?int $companyId = null): array
    {
        $profiles = AiProviderProfile::query()
            ->where('is_active', true)
            ->when(!is_null($companyId), fn ($query) => $query->where(function ($builder) use ($companyId) {
                $builder->where('company_id', $companyId)->orWhereNull('company_id');
            }))
            ->orderByRaw('CASE WHEN company_id IS NULL THEN 1 ELSE 0 END')
            ->orderBy('priority')
            ->get();

        $requiredFeatureMap = [
            'reasoning' => 'supports_reasoning',
            'text' => 'supports_text',
            'image' => 'supports_image',
            'multimodal' => 'supports_multimodal',
            'embeddings' => 'supports_embeddings',
            'structured_output' => 'supports_structured_output',
        ];

        $filtered = $profiles->filter(function ($profile) use ($requirements, $requiredFeatureMap) {
            foreach ($requiredFeatureMap as $key => $column) {
                if (($requirements[$key] ?? false) && !$profile->{$column}) {
                    return false;
                }
            }
            return true;
        })->values();

        $selected = $filtered->first() ?: $profiles->first();

        if (!$selected) {
            return ['found' => false, 'message' => 'No active provider profiles are configured.'];
        }

        $health = AiProviderHealthLog::query()
            ->where('provider', $selected->provider)
            ->where(function ($builder) use ($selected) {
                $builder->where('model', $selected->default_model)->orWhereNull('model');
            })
            ->when(!is_null($companyId), fn ($query) => $query->where('company_id', $companyId))
            ->latest('last_success_at')
            ->latest()
            ->first();

        $settings = !is_null($companyId)
            ? AiToolsSetting::firstOrCreate(['company_id' => $companyId], ['provider_mode' => 'hybrid', 'platform_fallback_enabled' => true])
            : AiToolsSetting::platformSetting();

        $credentials = $settings->resolveCredentials(user());

        return [
            'found' => true,
            'profile_key' => $selected->profile_key,
            'provider' => $selected->provider,
            'default_model' => $selected->default_model,
            'fallback_model' => $selected->fallback_model,
            'offline_model' => $selected->offline_model,
            'priority' => (int) $selected->priority,
            'supports' => [
                'reasoning' => (bool) $selected->supports_reasoning,
                'text' => (bool) $selected->supports_text,
                'image' => (bool) $selected->supports_image,
                'multimodal' => (bool) $selected->supports_multimodal,
                'embeddings' => (bool) $selected->supports_embeddings,
                'structured_output' => (bool) $selected->supports_structured_output,
            ],
            'health' => $health ? [
                'avg_latency_ms' => $health->avg_latency_ms,
                'failure_rate' => $health->failure_rate,
                'quota_remaining' => $health->quota_remaining,
                'fallback_uses' => $health->fallback_uses,
                'last_success_at' => optional($health->last_success_at)->toDateTimeString(),
            ] : null,
            'credential_source' => $credentials['key_source'] ?? 'none',
            'effective_model' => $credentials['model'] ?: $selected->default_model,
        ];
    }
}
