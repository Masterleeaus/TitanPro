@extends('layouts.app')
@section('content')
<div class="content-wrapper">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="card-title">Replay Trace Detail</h3>
            <a href="{{ route('ai-tools.ops.replay') }}" class="btn btn-sm btn-secondary">Back</a>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-4"><strong>Replay Type</strong><div>{{ $replay->replay_type }}</div></div>
                <div class="col-md-4"><strong>Subject Key</strong><div>{{ $replay->subject_key ?: '—' }}</div></div>
                <div class="col-md-4"><strong>Created</strong><div>{{ optional($replay->created_at)->format('Y-m-d H:i') }}</div></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-6"><strong>Persona Sequence</strong><pre class="bg-light p-3">{{ json_encode($replay->persona_sequence_json ?? [], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div>
                <div class="col-md-6"><strong>Provider Chain</strong><pre class="bg-light p-3">{{ json_encode($replay->provider_chain_json ?? [], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div>
            </div>
            <div class="row">
                <div class="col-md-6"><strong>Confidence Metrics</strong><pre class="bg-light p-3">{{ json_encode($replay->confidence_metrics_json ?? [], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div>
                <div class="col-md-6"><strong>Zero Output</strong><pre class="bg-light p-3">{{ json_encode($replay->zero_output_json ?? [], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div>
            </div>
        </div>
    </div>
</div>
@endsection
