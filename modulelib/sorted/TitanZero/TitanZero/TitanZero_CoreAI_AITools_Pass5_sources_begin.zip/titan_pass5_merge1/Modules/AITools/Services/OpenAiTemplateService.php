<?php

namespace Modules\Aitools\Services;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\RequestException;
use Modules\Aitools\Entities\AiToolsSetting;
use Modules\Aitools\Entities\AiToolsUsageHistory;

class OpenAiTemplateService
{
    public function generatePromptTemplate(string $brief, string $category = 'general'): array
    {
        $schema = [
            'name' => 'Short template name',
            'description' => 'What the template does',
            'system_prompt' => 'System instructions',
            'user_prompt_template' => 'Prompt with variables like {{customer_name}}',
            'variables' => [
                ['key' => 'customer_name', 'label' => 'Customer name', 'placeholder' => 'Acme Pty Ltd', 'required' => true],
            ],
            'output_format' => 'text',
        ];

        return $this->runJsonTask(
            "Create a reusable business prompt template in category '{$category}'. Return compact valid JSON with this exact shape: " . json_encode($schema),
            $brief,
            'template_generate'
        );
    }

    public function generateWizardTemplate(string $brief, string $category = 'general'): array
    {
        $schema = [
            'name' => 'Wizard name',
            'description' => 'What the wizard helps produce',
            'steps' => [
                ['key' => 'client_name', 'label' => 'Client name', 'type' => 'text', 'placeholder' => 'Acme Pty Ltd', 'required' => true, 'help' => 'Who is this for?'],
            ],
            'final_prompt_template' => 'Use {{client_name}} and other variables to produce the final result.',
            'output_format' => 'text',
        ];

        return $this->runJsonTask(
            "Create a multi-step business wizard. Return compact valid JSON with this exact shape: " . json_encode($schema),
            $brief,
            'wizard_generate'
        );
    }

    public function runPromptTemplate(string $systemPrompt, string $userPromptTemplate, array $variables, string $requestType = 'template_run', string $outputFormat = 'text'): array
    {
        $userPrompt = $this->interpolate($userPromptTemplate, $variables);
        $finalSystemPrompt = trim($systemPrompt ?: 'You are a helpful business writing assistant.');

        if ($outputFormat === 'json') {
            $finalSystemPrompt .= ' Return valid compact JSON only.';
        }

        return $this->callOpenAi($finalSystemPrompt, $userPrompt, $requestType);
    }

    public function previewPromptTemplate(string $systemPrompt, string $userPromptTemplate, array $variables, string $outputFormat = 'text'): array
    {
        $resolvedUserPrompt = $this->interpolate($userPromptTemplate, $variables);
        $finalSystemPrompt = trim($systemPrompt ?: 'You are a helpful business writing assistant.');

        if ($outputFormat === 'json') {
            $finalSystemPrompt .= ' Return valid compact JSON only.';
        }

        return [
            'system_prompt' => $finalSystemPrompt,
            'user_prompt' => $resolvedUserPrompt,
            'variables' => $variables,
            'output_format' => $outputFormat,
            'estimated_prompt_tokens' => max(1, (int) ceil(mb_strlen($finalSystemPrompt . $resolvedUserPrompt) / 4)),
        ];
    }

    public function runWizard(string $finalPromptTemplate, array $answers, string $requestType = 'wizard_run', string $outputFormat = 'text'): array
    {
        $systemPrompt = 'You are a business workflow assistant. Produce a complete result using the user provided wizard answers.';
        if ($outputFormat === 'json') {
            $systemPrompt .= ' Return valid compact JSON only.';
        }

        return $this->callOpenAi($systemPrompt, $this->interpolate($finalPromptTemplate, $answers), $requestType);
    }

    public function previewWizard(string $finalPromptTemplate, array $answers, string $outputFormat = 'text'): array
    {
        $systemPrompt = 'You are a business workflow assistant. Produce a complete result using the user provided wizard answers.';
        if ($outputFormat === 'json') {
            $systemPrompt .= ' Return valid compact JSON only.';
        }

        return [
            'system_prompt' => $systemPrompt,
            'final_prompt' => $this->interpolate($finalPromptTemplate, $answers),
            'answers' => $answers,
            'output_format' => $outputFormat,
            'estimated_prompt_tokens' => max(1, (int) ceil(mb_strlen($systemPrompt . $finalPromptTemplate) / 4)),
        ];
    }

    public function interpolate(string $template, array $variables): string
    {
        $replacements = [];
        foreach ($variables as $key => $value) {
            $replacements['{{' . $key . '}}'] = is_scalar($value) ? (string) $value : json_encode($value);
        }

        return strtr($template, $replacements);
    }

    private function runJsonTask(string $systemPrompt, string $brief, string $requestType): array
    {
        $response = $this->callOpenAi($systemPrompt, "Brief:\n" . $brief, $requestType, true);
        $decoded = json_decode($response['content'], true);

        if (!is_array($decoded)) {
            throw new \RuntimeException('The AI did not return valid JSON. Please try again with a clearer brief.');
        }

        $response['json'] = $decoded;

        return $response;
    }

    private function callOpenAi(string $systemPrompt, string $userPrompt, string $requestType, bool $preferJson = false): array
    {
        $setting = AiToolsSetting::forCurrentContext();
        $credentials = $setting->resolveCredentials(user());

        if (empty($credentials['api_key'])) {
            throw new \RuntimeException('No active AI API key is configured.');
        }

        $model = $credentials['model'] ?: 'gpt-4o-mini';
        $client = new Client();

        try {
            $response = $client->request('POST', 'https://api.openai.com/v1/responses', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $credentials['api_key'],
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'model' => $model,
                    'input' => [[
                        'role' => 'system',
                        'content' => [[
                            'type' => 'input_text',
                            'text' => $systemPrompt,
                        ]],
                    ], [
                        'role' => 'user',
                        'content' => [[
                            'type' => 'input_text',
                            'text' => $userPrompt,
                        ]],
                    ]],
                ],
                'timeout' => 45,
            ]);

            $data = json_decode($response->getBody(), true);
            $content = $data['output'][0]['content'][0]['text'] ?? '';
            if (!$content && !empty($data['output']) && is_array($data['output'])) {
                foreach ($data['output'] as $outputItem) {
                    $content = $outputItem['content'][0]['text'] ?? '';
                    if ($content) {
                        break;
                    }
                }
            }

            if (!$content) {
                throw new \RuntimeException('Unexpected AI response.');
            }

            $usage = $data['usage'] ?? [];
            $promptTokens = (int) ($usage['prompt_tokens'] ?? $usage['input_tokens'] ?? max(1, ceil(mb_strlen($systemPrompt . $userPrompt) / 4)));
            $completionTokens = (int) ($usage['completion_tokens'] ?? $usage['output_tokens'] ?? max(1, ceil(mb_strlen($content) / 4)));
            $totalTokens = (int) ($usage['total_tokens'] ?? ($promptTokens + $completionTokens));

            AiToolsUsageHistory::create([
                'company_id' => user()?->is_superadmin ? null : company()?->id,
                'user_id' => user()?->id,
                'model' => $model,
                'key_source' => $credentials['key_source'] ?? null,
                'request_type' => $requestType,
                'prompt' => mb_substr($userPrompt, 0, 4000),
                'response' => mb_substr($content, 0, 4000),
                'prompt_tokens' => $promptTokens,
                'completion_tokens' => $completionTokens,
                'total_tokens' => $totalTokens,
                'total_requests' => 1,
                'estimated_cost' => $this->estimateRequestCost($model, $promptTokens, $completionTokens),
            ]);

            return [
                'content' => trim($content),
                'model' => $model,
                'key_source' => $credentials['key_source'] ?? null,
            ];
        } catch (RequestException $e) {
            $message = 'The AI request failed.';
            if ($e->hasResponse()) {
                $errorResponse = json_decode($e->getResponse()->getBody(), true);
                $message = $errorResponse['error']['message'] ?? $message;
            }
            throw new \RuntimeException($message);
        } catch (GuzzleException $e) {
            throw new \RuntimeException('Network error while contacting OpenAI.');
        }
    }

    private function estimateRequestCost(string $model, int $inputTokens, int $outputTokens): float
    {
        $pricing = [
            'gpt-4o' => ['input' => 2.50, 'output' => 10.00],
            'gpt-4o-mini' => ['input' => 0.15, 'output' => 0.60],
            'gpt-4.1' => ['input' => 2.00, 'output' => 8.00],
            'gpt-4.1-mini' => ['input' => 0.40, 'output' => 1.60],
        ];
        $rates = $pricing[$model] ?? $pricing['gpt-4o-mini'];

        return round((($inputTokens / 1000000) * $rates['input']) + (($outputTokens / 1000000) * $rates['output']), 6);
    }
}
