<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ai_tools_usage_history', function (Blueprint $table) {
            if (!Schema::hasColumn('ai_tools_usage_history', 'request_type')) {
                $table->string('request_type', 50)->nullable()->after('key_source');
            }
            if (!Schema::hasColumn('ai_tools_usage_history', 'estimated_cost')) {
                $table->decimal('estimated_cost', 10, 6)->default(0)->after('total_requests');
            }
        });
    }

    public function down(): void
    {
        Schema::table('ai_tools_usage_history', function (Blueprint $table) {
            foreach (['request_type', 'estimated_cost'] as $column) {
                if (Schema::hasColumn('ai_tools_usage_history', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
