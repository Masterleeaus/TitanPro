<?php

namespace Modules\Aitools\Services;

use Modules\Aitools\Entities\AiPromptTemplate;

class PromptRegistryService
{
    public function getPrompt(string $templateKey, array $context = [], ?int $companyId = null): array
    {
        $template = $this->resolveTemplate($templateKey, $companyId);

        if (!$template) {
            return [
                'found' => false,
                'template_key' => $templateKey,
                'message' => 'Prompt template not found.',
            ];
        }

        $previewService = app(PromptPreviewService::class);
        $rendered = $previewService->renderTemplateText((string) $template->user_prompt_template, $context);
        $systemPrompt = $previewService->renderTemplateText((string) ($template->system_prompt ?: ''), $context);

        return [
            'found' => true,
            'id' => $template->id,
            'template_key' => $template->template_key,
            'name' => $template->name,
            'persona_key' => $template->persona_key,
            'lifecycle_stage' => $template->lifecycle_stage,
            'action_key' => $template->action_key,
            'status' => $template->status,
            'version' => $template->version,
            'output_format' => $template->output_format ?: 'text',
            'variables' => $template->resolvedVariables(),
            'system_prompt' => $systemPrompt,
            'user_prompt' => $rendered['resolved'],
            'missing_variables' => $rendered['missing_variables'],
            'company_scope' => is_null($template->company_id) ? 'global' : 'company',
            'company_id' => $template->company_id,
        ];
    }

    public function getLifecycleTemplate(string $stage, string $action, ?int $companyId = null): array
    {
        $query = AiPromptTemplate::query()
            ->where('is_active', true)
            ->where('lifecycle_stage', $stage)
            ->where('action_key', $action)
            ->orderByRaw('CASE WHEN company_id IS NULL THEN 1 ELSE 0 END')
            ->orderByDesc('version');

        if (!is_null($companyId)) {
            $query->where(function ($builder) use ($companyId) {
                $builder->where('company_id', $companyId)->orWhereNull('company_id');
            });
        }

        $template = $query->first();

        return $template
            ? $this->getPrompt((string) $template->template_key, [], $companyId)
            : ['found' => false, 'message' => 'Lifecycle template not found.', 'stage' => $stage, 'action' => $action];
    }

    protected function resolveTemplate(string $templateKey, ?int $companyId = null): ?AiPromptTemplate
    {
        $query = AiPromptTemplate::query()
            ->where('is_active', true)
            ->where('template_key', $templateKey)
            ->orderByRaw('CASE WHEN company_id IS NULL THEN 1 ELSE 0 END')
            ->orderByDesc('version');

        if (!is_null($companyId)) {
            $query->where(function ($builder) use ($companyId) {
                $builder->where('company_id', $companyId)->orWhereNull('company_id');
            });
        }

        return $query->first();
    }
}
