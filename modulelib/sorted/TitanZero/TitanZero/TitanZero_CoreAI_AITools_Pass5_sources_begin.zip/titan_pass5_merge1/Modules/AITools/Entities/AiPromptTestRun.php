<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;

class AiPromptTestRun extends BaseModel
{
    protected $table = 'ai_tools_prompt_test_runs';

    protected $guarded = ['id'];

    protected $casts = [
        'input_variables_json' => 'array',
    ];
}
