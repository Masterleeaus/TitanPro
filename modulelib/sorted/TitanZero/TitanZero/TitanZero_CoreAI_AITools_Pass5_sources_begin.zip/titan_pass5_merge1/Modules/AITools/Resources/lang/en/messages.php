<?php

return [
    'aiRequestFailed' => 'Failed to rephrase text. Please try again later.',
    'aiToolsNotConfigured' => 'AI tools are not configured. Please configure your AI settings first.',
    'apiKeyRequired' => 'API key is required. Please enter your ChatGPT API key first.',
    'companyNotFound' => 'Company not found.',
    'invalidTokenValue' => 'Invalid token value. Please enter a number greater than or equal to 0.',
    'networkError' => 'Network error. Please check your internet connection.',
    'packageNotFound' => 'Package not found.',
    'pleaseEnterSomeText' => 'Please enter some text to rephrase.',
    'promptRequired' => 'Please enter a message to test.',
    'rephraseText' => 'Click to rephrase the text using AI',
    'somethingWentWrong' => 'Something went wrong. Please try again later.',
    'textRephrasedSuccessfully' => 'Text rephrased successfully.',
    'tokenLimitExceeded' => 'Token limit exceeded. You have used :used tokens out of :assigned tokens assigned to your package. Please contact your administrator to upgrade your package.',
    'unexpectedResponse' => 'Received an unexpected response from the API.',
];
