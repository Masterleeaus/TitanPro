@extends('layouts.app')
@section('content')
<div class="row">
  <div class="col-md-4">
    <div class="card"><div class="card-body">
      <h3 class="mb-3">Provider Profiles</h3>
      <form method="POST" action="{{ route('ai-tools.control-plane.providers.store') }}">@csrf
        <div class="mb-2"><label>Profile Key</label><input name="profile_key" class="form-control" required></div>
        <div class="mb-2"><label>Provider</label><input name="provider" class="form-control" value="openai"></div>
        <div class="mb-2"><label>Default Model</label><input name="default_model" class="form-control" placeholder="gpt-4o-mini"></div>
        <div class="mb-2"><label>Fallback Model</label><input name="fallback_model" class="form-control" placeholder="gpt-4.1-mini"></div>
        <div class="mb-2"><label>Offline Model</label><input name="offline_model" class="form-control" placeholder="tinyllama"></div>
        <div class="mb-2"><label>Priority</label><input name="priority" type="number" class="form-control" value="100"></div>
        <div class="row g-1 mb-3">
          <div class="col-6 form-check"><input class="form-check-input" type="checkbox" name="supports_reasoning" value="1" checked id="pr"><label class="form-check-label" for="pr">Reasoning</label></div>
          <div class="col-6 form-check"><input class="form-check-input" type="checkbox" name="supports_text" value="1" checked id="pt"><label class="form-check-label" for="pt">Text</label></div>
          <div class="col-6 form-check"><input class="form-check-input" type="checkbox" name="supports_image" value="1" id="pi"><label class="form-check-label" for="pi">Image</label></div>
          <div class="col-6 form-check"><input class="form-check-input" type="checkbox" name="supports_multimodal" value="1" id="pm"><label class="form-check-label" for="pm">Multimodal</label></div>
          <div class="col-6 form-check"><input class="form-check-input" type="checkbox" name="supports_embeddings" value="1" id="pe"><label class="form-check-label" for="pe">Embeddings</label></div>
          <div class="col-6 form-check"><input class="form-check-input" type="checkbox" name="supports_structured_output" value="1" id="ps"><label class="form-check-label" for="ps">Structured Output</label></div>
          <div class="col-6 form-check"><input class="form-check-input" type="checkbox" name="is_active" value="1" checked id="pa"><label class="form-check-label" for="pa">Active</label></div>
        </div>
        <button class="btn btn-primary w-100">Save Provider</button>
      </form>
    </div></div>
  </div>
  <div class="col-md-8">
    <div class="card"><div class="card-body"><h3 class="mb-3">Current Provider Profiles</h3><div class="table-responsive"><table class="table table-bordered"><thead><tr><th>Profile</th><th>Provider</th><th>Default</th><th>Fallback</th><th>Offline</th><th>Priority</th><th>Status</th></tr></thead><tbody>@forelse($providers as $profile)<tr><td>{{ $profile->profile_key }}</td><td>{{ $profile->provider }}</td><td>{{ $profile->default_model }}</td><td>{{ $profile->fallback_model }}</td><td>{{ $profile->offline_model }}</td><td>{{ $profile->priority }}</td><td>{{ $profile->is_active ? 'active' : 'off' }}</td></tr>@empty<tr><td colspan="7">No provider profiles yet.</td></tr>@endforelse</tbody></table></div></div></div>
  </div>
</div>
@endsection
