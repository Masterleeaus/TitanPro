<?php

namespace Modules\Aitools\Http\Controllers;

use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\Aitools\Services\ChatProfileResolver;
use Modules\Aitools\Services\LifecycleBundleResolver;
use Modules\Aitools\Services\PersonaConfigResolver;
use Modules\Aitools\Services\PromptRegistryService;
use Modules\Aitools\Services\ProviderCapabilityResolver;

class AiRuntimeContractController extends AccountBaseController
{
    public function __construct(
        private PromptRegistryService $prompts,
        private LifecycleBundleResolver $bundles,
        private ProviderCapabilityResolver $providers,
        private PersonaConfigResolver $personas,
        private ChatProfileResolver $chatProfiles,
    ) {
        parent::__construct();
    }

    protected function authorizeAitools(): void
    {
        abort_403(!(module_enabled('Aitools') && (user()->is_superadmin || user()->permission('view_aitools') == 'all' || user()->permission('edit_aitools') == 'all')));
    }

    protected function currentCompanyId(): ?int
    {
        return user()->is_superadmin ? null : company()?->id;
    }

    public function prompt(Request $request)
    {
        $this->authorizeAitools();
        $data = $request->validate([
            'template_key' => 'required|string|max:191',
            'context' => 'nullable|array',
        ]);

        return response()->json($this->prompts->getPrompt($data['template_key'], $data['context'] ?? [], $this->currentCompanyId()));
    }

    public function lifecycleBundle(Request $request)
    {
        $this->authorizeAitools();
        $data = $request->validate([
            'lifecycle_event' => 'required|string|max:191',
            'assistant_slug' => 'nullable|string|max:191',
            'entity_type' => 'nullable|string|max:191',
        ]);

        return response()->json($this->bundles->getLifecycleBundle($data['lifecycle_event'], $data, $this->currentCompanyId()));
    }

    public function persona(Request $request)
    {
        $this->authorizeAitools();
        $data = $request->validate([
            'persona_key' => 'required|string|max:191',
            'lifecycle_event' => 'nullable|string|max:191',
        ]);

        return response()->json($this->personas->getPersonaConfig($data['persona_key'], $data, $this->currentCompanyId()));
    }

    public function provider(Request $request)
    {
        $this->authorizeAitools();
        $data = $request->validate([
            'reasoning' => 'nullable|boolean',
            'text' => 'nullable|boolean',
            'image' => 'nullable|boolean',
            'multimodal' => 'nullable|boolean',
            'embeddings' => 'nullable|boolean',
            'structured_output' => 'nullable|boolean',
        ]);

        return response()->json($this->providers->getProviderConfig($data, $this->currentCompanyId()));
    }

    public function chat(Request $request)
    {
        $this->authorizeAitools();
        $data = $request->validate([
            'profile_key' => 'nullable|string|max:191',
        ]);

        return response()->json($this->chatProfiles->getChatProfile($data['profile_key'] ?? null, $this->currentCompanyId()));
    }
}
