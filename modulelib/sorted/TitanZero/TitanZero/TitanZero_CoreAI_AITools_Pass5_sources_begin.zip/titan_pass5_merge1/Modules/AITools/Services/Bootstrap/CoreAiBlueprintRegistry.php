<?php

namespace Modules\Aitools\Services\Bootstrap;

class CoreAiBlueprintRegistry
{
    public function personaBlueprints(): array
    {
        return [
            [
                'persona_key' => 'zero',
                'name' => 'Zero',
                'provider_model' => 'primary.reasoning',
                'authority_scope' => 'final_consolidation',
                'lifecycle_stage' => null,
                'token_budget' => 6000,
                'temperature' => 0.20,
                'escalation_threshold' => 0.75,
                'description' => 'Final consolidator. Resolves contradictions, normalises tone, and enforces tenant-safe final output.',
                'event_permissions_json' => ['*'],
            ],
            [
                'persona_key' => 'logic',
                'name' => 'Logic',
                'provider_model' => 'primary.reasoning',
                'authority_scope' => 'ops_governance',
                'lifecycle_stage' => null,
                'token_budget' => 3500,
                'temperature' => 0.10,
                'escalation_threshold' => 0.65,
                'description' => 'Operational reasoning persona for workflows, constraints, validation, and approval-safe action design.',
                'event_permissions_json' => ['booking.*', 'job.*', 'invoice.*', 'feedback.*', 'staff.*'],
            ],
            [
                'persona_key' => 'finance',
                'name' => 'Finance',
                'provider_model' => 'finance.reasoning',
                'authority_scope' => 'financial_analysis',
                'lifecycle_stage' => null,
                'token_budget' => 3000,
                'temperature' => 0.10,
                'escalation_threshold' => 0.70,
                'description' => 'Financial persona for invoice, payment, margin, exposure, and cost-sensitive recommendations.',
                'event_permissions_json' => ['invoice.*', 'payment.*'],
            ],
            [
                'persona_key' => 'creative',
                'name' => 'Creative',
                'provider_model' => 'creative.generation',
                'authority_scope' => 'content_generation',
                'lifecycle_stage' => null,
                'token_budget' => 2500,
                'temperature' => 0.45,
                'escalation_threshold' => 0.60,
                'description' => 'Creative persona for customer-facing language, design prompts, and visual or messaging output.',
                'event_permissions_json' => ['feedback.*', 'quote.*', 'customer.*'],
            ],
            [
                'persona_key' => 'macro',
                'name' => 'Macro',
                'provider_model' => 'primary.reasoning',
                'authority_scope' => 'strategic_context',
                'lifecycle_stage' => null,
                'token_budget' => 2500,
                'temperature' => 0.15,
                'escalation_threshold' => 0.70,
                'description' => 'Macro persona for long-range business context, trend framing, and portfolio-level guidance.',
                'event_permissions_json' => ['*'],
            ],
            [
                'persona_key' => 'micro',
                'name' => 'Micro',
                'provider_model' => 'fast.classifier',
                'authority_scope' => 'fast_local_decisions',
                'lifecycle_stage' => null,
                'token_budget' => 1200,
                'temperature' => 0.05,
                'escalation_threshold' => 0.55,
                'description' => 'Low-cost micro persona for quick extraction, local checks, and pre-routing helpers.',
                'event_permissions_json' => ['booking.*', 'job.*', 'invoice.*'],
            ],
            [
                'persona_key' => 'entropy',
                'name' => 'Entropy',
                'provider_model' => 'primary.reasoning',
                'authority_scope' => 'risk_challenge',
                'lifecycle_stage' => null,
                'token_budget' => 2200,
                'temperature' => 0.30,
                'escalation_threshold' => 0.80,
                'description' => 'Challenge persona that stress-tests fragile assumptions and highlights failure paths.',
                'event_permissions_json' => ['*'],
            ],
            [
                'persona_key' => 'alien',
                'name' => 'Alien',
                'provider_model' => 'primary.reasoning',
                'authority_scope' => 'inversion_novelty',
                'lifecycle_stage' => null,
                'token_budget' => 2200,
                'temperature' => 0.35,
                'escalation_threshold' => 0.82,
                'description' => 'Assumption-breaking persona for inversion, novelty search, and reframing entrenched patterns.',
                'event_permissions_json' => ['*'],
            ],
        ];
    }

    public function providerBlueprints(): array
    {
        return [
            [
                'provider' => 'openai',
                'profile_key' => 'primary.reasoning',
                'default_model' => 'gpt-4.1',
                'fallback_model' => 'gpt-4.1-mini',
                'offline_model' => 'tinyllama',
                'supports_reasoning' => true,
                'supports_text' => true,
                'supports_image' => true,
                'supports_multimodal' => true,
                'supports_embeddings' => true,
                'supports_structured_output' => true,
                'priority' => 10,
                'is_active' => true,
            ],
            [
                'provider' => 'openai',
                'profile_key' => 'creative.generation',
                'default_model' => 'gpt-image-1',
                'fallback_model' => 'gpt-4.1-mini',
                'offline_model' => null,
                'supports_reasoning' => false,
                'supports_text' => true,
                'supports_image' => true,
                'supports_multimodal' => true,
                'supports_embeddings' => false,
                'supports_structured_output' => true,
                'priority' => 20,
                'is_active' => true,
            ],
            [
                'provider' => 'anthropic',
                'profile_key' => 'fallback.reasoning',
                'default_model' => 'claude-sonnet-4-5',
                'fallback_model' => 'claude-haiku-4-5',
                'offline_model' => null,
                'supports_reasoning' => true,
                'supports_text' => true,
                'supports_image' => true,
                'supports_multimodal' => true,
                'supports_embeddings' => false,
                'supports_structured_output' => true,
                'priority' => 30,
                'is_active' => true,
            ],
            [
                'provider' => 'google',
                'profile_key' => 'multimodal.analysis',
                'default_model' => 'gemini-2.0-flash',
                'fallback_model' => 'gemini-1.5-flash',
                'offline_model' => null,
                'supports_reasoning' => true,
                'supports_text' => true,
                'supports_image' => true,
                'supports_multimodal' => true,
                'supports_embeddings' => true,
                'supports_structured_output' => true,
                'priority' => 40,
                'is_active' => true,
            ],
            [
                'provider' => 'local',
                'profile_key' => 'fast.classifier',
                'default_model' => 'tinyllama',
                'fallback_model' => null,
                'offline_model' => 'tinyllama',
                'supports_reasoning' => true,
                'supports_text' => true,
                'supports_image' => false,
                'supports_multimodal' => false,
                'supports_embeddings' => false,
                'supports_structured_output' => false,
                'priority' => 50,
                'is_active' => true,
            ],
            [
                'provider' => 'openai',
                'profile_key' => 'finance.reasoning',
                'default_model' => 'o3',
                'fallback_model' => 'gpt-4.1',
                'offline_model' => null,
                'supports_reasoning' => true,
                'supports_text' => true,
                'supports_image' => false,
                'supports_multimodal' => false,
                'supports_embeddings' => false,
                'supports_structured_output' => true,
                'priority' => 60,
                'is_active' => true,
            ],
        ];
    }

    public function assistantBlueprints(): array
    {
        return [
            [
                'assistant_slug' => 'booking-assistant',
                'name' => 'Booking Assistant',
                'default_persona' => 'logic',
                'entity_scope' => 'booking',
                'allowed_lifecycle_events' => ['booking.processed', 'booking.reviewed'],
                'attached_entities' => ['booking'],
                'token_budget' => 2500,
                'temperature' => 0.15,
                'requires_zero_merge' => true,
                'is_active' => true,
            ],
            [
                'assistant_slug' => 'job-assistant',
                'name' => 'Job Assistant',
                'default_persona' => 'logic',
                'entity_scope' => 'job',
                'allowed_lifecycle_events' => ['job.completed', 'job.delayed', 'job.exception'],
                'attached_entities' => ['job', 'site'],
                'token_budget' => 2500,
                'temperature' => 0.15,
                'requires_zero_merge' => true,
                'is_active' => true,
            ],
            [
                'assistant_slug' => 'invoice-assistant',
                'name' => 'Invoice Assistant',
                'default_persona' => 'finance',
                'entity_scope' => 'invoice',
                'allowed_lifecycle_events' => ['invoice.paid', 'invoice.overdue'],
                'attached_entities' => ['invoice', 'customer'],
                'token_budget' => 2200,
                'temperature' => 0.10,
                'requires_zero_merge' => true,
                'is_active' => true,
            ],
            [
                'assistant_slug' => 'complaint-resolution-assistant',
                'name' => 'Complaint Resolution Assistant',
                'default_persona' => 'zero',
                'entity_scope' => 'feedback',
                'allowed_lifecycle_events' => ['feedback.negative_received'],
                'attached_entities' => ['feedback', 'job', 'customer'],
                'token_budget' => 3000,
                'temperature' => 0.18,
                'requires_zero_merge' => true,
                'is_active' => true,
            ],
        ];
    }

    public function lifecycleBundleBlueprints(): array
    {
        return [
            [
                'bundle_key' => 'booking_processed_bundle',
                'lifecycle_event' => 'booking.processed',
                'entity_type' => 'booking',
                'default_persona' => 'logic',
                'assistant_slug' => 'booking-assistant',
                'prompt_keys' => ['booking.summary', 'booking.validation', 'booking.next_step'],
                'template_keys' => ['booking_confirmation', 'booking_internal_summary'],
                'wizard_keys' => ['booking_intake_wizard'],
                'context_schema' => ['required' => ['booking', 'customer', 'site'], 'optional' => ['pricing', 'history']],
                'priority' => 10,
                'is_active' => true,
            ],
            [
                'bundle_key' => 'job_completed_bundle',
                'lifecycle_event' => 'job.completed',
                'entity_type' => 'job',
                'default_persona' => 'logic',
                'assistant_slug' => 'job-assistant',
                'prompt_keys' => ['job.completion_summary', 'job.followup', 'job.invoice_readiness'],
                'template_keys' => ['job_completion_customer_message'],
                'wizard_keys' => ['job_completion_wizard'],
                'context_schema' => ['required' => ['job', 'customer'], 'optional' => ['photos', 'materials', 'notes']],
                'priority' => 20,
                'is_active' => true,
            ],
            [
                'bundle_key' => 'invoice_paid_bundle',
                'lifecycle_event' => 'invoice.paid',
                'entity_type' => 'invoice',
                'default_persona' => 'finance',
                'assistant_slug' => 'invoice-assistant',
                'prompt_keys' => ['invoice.receipt_summary', 'invoice.margin_check'],
                'template_keys' => ['invoice_receipt_message'],
                'wizard_keys' => ['payment_followup_wizard'],
                'context_schema' => ['required' => ['invoice', 'payment', 'customer'], 'optional' => ['job']],
                'priority' => 30,
                'is_active' => true,
            ],
            [
                'bundle_key' => 'negative_feedback_bundle',
                'lifecycle_event' => 'feedback.negative_received',
                'entity_type' => 'feedback',
                'default_persona' => 'zero',
                'assistant_slug' => 'complaint-resolution-assistant',
                'prompt_keys' => ['feedback.triage', 'feedback.remediation', 'feedback.customer_reply'],
                'template_keys' => ['complaint_response', 'team_followup_notice'],
                'wizard_keys' => ['complaint_resolution_wizard'],
                'context_schema' => ['required' => ['feedback', 'customer'], 'optional' => ['job', 'photos', 'policy']],
                'priority' => 40,
                'is_active' => true,
            ],
            [
                'bundle_key' => 'staff_absence_bundle',
                'lifecycle_event' => 'staff.absence_reported',
                'entity_type' => 'staff',
                'default_persona' => 'logic',
                'assistant_slug' => 'job-assistant',
                'prompt_keys' => ['staff.absence_impact', 'staff.coverage_plan'],
                'template_keys' => ['staff_absence_internal_notice'],
                'wizard_keys' => ['staff_absence_wizard'],
                'context_schema' => ['required' => ['staff', 'schedule'], 'optional' => ['jobs', 'availability']],
                'priority' => 50,
                'is_active' => true,
            ],
        ];
    }

    public function summary(string $rootPath): array
    {
        $corePath = rtrim($rootPath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'Services' . DIRECTORY_SEPARATOR . 'CoreAI';
        $decisionPath = rtrim($rootPath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'Services' . DIRECTORY_SEPARATOR . 'TitanCoreAI' . DIRECTORY_SEPARATOR . 'DecisionLayer';
        $aitoolsPath = rtrim($rootPath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'Modules' . DIRECTORY_SEPARATOR . 'AITools';

        return [
            'core_services' => $this->countPhpFiles($corePath),
            'decision_services' => $this->countPhpFiles($decisionPath),
            'aitools_files' => $this->countPhpFiles($aitoolsPath),
            'persona_blueprints' => count($this->personaBlueprints()),
            'provider_blueprints' => count($this->providerBlueprints()),
            'assistant_blueprints' => count($this->assistantBlueprints()),
            'lifecycle_bundle_blueprints' => count($this->lifecycleBundleBlueprints()),
        ];
    }

    protected function countPhpFiles(string $path): int
    {
        if (!is_dir($path)) {
            return 0;
        }

        $count = 0;
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path));
        foreach ($iterator as $file) {
            if ($file->isFile() && strtolower($file->getExtension()) === 'php') {
                $count++;
            }
        }

        return $count;
    }
}
