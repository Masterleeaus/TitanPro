@extends('layouts.app')
@section('content')
<div class="content-wrapper">
    <div class="card mb-3"><div class="card-header"><h3 class="card-title">Token Usage Dashboard</h3></div>
    <div class="card-body">
        <form method="GET" class="form-row align-items-end">
            <div class="form-group col-md-3"><label>From</label><input type="date" name="from_date" value="{{ request('from_date') }}" class="form-control"></div>
            <div class="form-group col-md-3"><label>To</label><input type="date" name="to_date" value="{{ request('to_date') }}" class="form-control"></div>
            <div class="form-group col-md-3"><button class="btn btn-primary">Apply</button></div>
        </form>
        <div class="row mb-4 mt-2">
            <div class="col-md-4"><strong>Total Tokens:</strong> {{ number_format($usage->total_tokens ?? 0) }}</div>
            <div class="col-md-4"><strong>Total Requests:</strong> {{ number_format($usage->total_requests ?? 0) }}</div>
            <div class="col-md-4"><strong>Estimated Cost:</strong> {{ number_format((float) ($usage->total_cost ?? 0), 4) }}</div>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <h5>By Request Type</h5>
                <table class="table table-bordered table-sm"><thead><tr><th>Type</th><th>Tokens</th></tr></thead><tbody>@forelse($byType as $row)<tr><td>{{ $row->request_type }}</td><td>{{ number_format($row->total_tokens) }}</td></tr>@empty<tr><td colspan="2" class="text-muted text-center">No data</td></tr>@endforelse</tbody></table>
            </div>
            <div class="col-lg-4">
                <h5>By Model</h5>
                <table class="table table-bordered table-sm"><thead><tr><th>Model</th><th>Tokens</th></tr></thead><tbody>@forelse($byModel as $row)<tr><td>{{ $row->model_name }}</td><td>{{ number_format($row->total_tokens) }}</td></tr>@empty<tr><td colspan="2" class="text-muted text-center">No data</td></tr>@endforelse</tbody></table>
            </div>
            <div class="col-lg-4">
                <h5>By Key Source</h5>
                <table class="table table-bordered table-sm"><thead><tr><th>Key Source</th><th>Tokens</th></tr></thead><tbody>@forelse($byKeySource as $row)<tr><td>{{ $row->key_source_name }}</td><td>{{ number_format($row->total_tokens) }}</td></tr>@empty<tr><td colspan="2" class="text-muted text-center">No data</td></tr>@endforelse</tbody></table>
            </div>
        </div>
    </div></div>
</div>
@endsection
