@extends('layouts.app')
@section('content')
<div class="row">
  <div class="col-md-4">
    <div class="card"><div class="card-body">
      <h3 class="mb-3">Lifecycle Bundles</h3>
      <form method="POST" action="{{ route('ai-tools.control-plane.bundles.store') }}">@csrf
        <div class="mb-2"><label>Bundle Key</label><input name="bundle_key" class="form-control" required></div>
        <div class="mb-2"><label>Lifecycle Event</label><input name="lifecycle_event" class="form-control" placeholder="booking.processed"></div>
        <div class="mb-2"><label>Entity Type</label><input name="entity_type" class="form-control" placeholder="booking"></div>
        <div class="mb-2"><label>Default Persona</label><input name="default_persona" class="form-control" placeholder="Zero"></div>
        <div class="mb-2"><label>Assistant Slug</label><input name="assistant_slug" class="form-control"></div>
        <div class="mb-2"><label>Prompt Keys</label><input name="prompt_keys" class="form-control" placeholder="prompt.a,prompt.b"></div>
        <div class="mb-2"><label>Template Keys</label><input name="template_keys" class="form-control" placeholder="template.a,template.b"></div>
        <div class="mb-2"><label>Wizard Keys</label><input name="wizard_keys" class="form-control" placeholder="wizard.a,wizard.b"></div>
        <div class="mb-2"><label>Context Schema</label><textarea name="context_schema" class="form-control" rows="3"></textarea></div>
        <div class="mb-2"><label>Priority</label><input name="priority" type="number" class="form-control" value="100"></div>
        <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="is_active" value="1" checked id="bundle_active"><label class="form-check-label" for="bundle_active">Active</label></div>
        <button class="btn btn-primary w-100">Save Bundle</button>
      </form>
    </div></div>
  </div>
  <div class="col-md-8">
    <div class="card"><div class="card-body">
      <h3 class="mb-3">Current Bundles</h3>
      <div class="table-responsive"><table class="table table-bordered align-middle"><thead><tr><th>Key</th><th>Event</th><th>Persona</th><th>Assistant</th><th>Priority</th><th>Status</th></tr></thead><tbody>
      @forelse($bundles as $bundle)
        <tr>
          <td>{{ $bundle->bundle_key }}</td><td>{{ $bundle->lifecycle_event }}</td><td>{{ $bundle->default_persona }}</td><td>{{ $bundle->assistant_slug }}</td><td>{{ $bundle->priority }}</td><td>{{ $bundle->is_active ? 'active' : 'off' }}</td>
        </tr>
      @empty
        <tr><td colspan="6">No bundles yet.</td></tr>
      @endforelse
      </tbody></table></div>
    </div></div>
  </div>
</div>
@endsection
