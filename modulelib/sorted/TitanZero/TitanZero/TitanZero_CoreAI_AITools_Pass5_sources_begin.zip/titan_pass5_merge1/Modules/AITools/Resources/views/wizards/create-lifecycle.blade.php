@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="row g-4">
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm" style="border-radius: 18px;">
                <div class="card-header bg-white border-0 pt-4 px-4"><h5 class="mb-0">Lifecycle presets</h5></div>
                <div class="card-body px-4 pb-4">
                    @foreach($presetCards as $preset)
                        <a href="{{ route('ai-tools.wizards.lifecycle.create', ['preset' => $preset['key']]) }}" class="text-decoration-none">
                            <div class="border rounded-4 p-3 mb-3 {{ optional($selectedPreset)['key'] === $preset['key'] ? 'border-primary' : '' }}">
                                <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
                                    <div>
                                        <div class="badge bg-primary-subtle text-primary mb-2">{{ ucfirst($preset['lifecycle_stage']) }}</div>
                                        <h6 class="text-dark mb-1">{{ $preset['name'] }}</h6>
                                    </div>
                                    <span class="badge bg-light text-dark">{{ count($preset['steps']) }}</span>
                                </div>
                                <div class="text-muted small">{{ $preset['description'] }}</div>
                            </div>
                        </a>
                    @endforeach
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm" style="border-radius: 18px; overflow: hidden;">
                <div class="card-header border-0 bg-white pt-4 px-4 d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-1">Lifecycle wizard bootstrap</h5>
                        <div class="text-muted small">Create a reusable AITools lifecycle engine draft from a preset.</div>
                    </div>
                    <a href="{{ route('ai-tools.wizards.index') }}" class="btn btn-outline-secondary btn-sm">Back</a>
                </div>
                <div class="card-body px-4 pb-4">
                    @php $preset = $selectedPreset ?: $presetCards[0]; @endphp
                    <div class="p-4 rounded-4 mb-4" style="background: linear-gradient(135deg, #0f172a 0%, #1d4ed8 100%); color: #fff;">
                        <div class="d-flex justify-content-between flex-wrap gap-3 align-items-start">
                            <div>
                                <div class="badge bg-light text-dark mb-2">{{ ucfirst($preset['lifecycle_stage']) }}</div>
                                <h3 class="mb-2">{{ $preset['name'] }}</h3>
                                <p class="mb-0" style="opacity:.9;">{{ $preset['description'] }}</p>
                            </div>
                            <div class="small text-end" style="opacity:.85;">
                                <div>{{ count($preset['steps']) }} steps</div>
                                <div>{{ strtoupper($preset['output_format']) }} output</div>
                            </div>
                        </div>
                    </div>
                    <form id="create-lifecycle-preset-form" method="POST" action="{{ route('ai-tools.wizards.presets.store') }}">
                        @csrf
                        <input type="hidden" name="preset_key" value="{{ $preset['key'] }}">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Draft name</label>
                                <input type="text" name="name" class="form-control" value="{{ $preset['name'] }}">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Action key</label>
                                <input type="text" class="form-control" value="{{ $preset['action_key'] }}" disabled>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Description override</label>
                                <textarea name="description" class="form-control" rows="3">{{ $preset['description'] }}</textarea>
                            </div>
                        </div>
                        <hr class="my-4">
                        <h6 class="mb-3">Step flow preview</h6>
                        <div class="row g-3 mb-4">
                            @foreach($preset['steps'] as $index => $step)
                                <div class="col-md-6">
                                    <div class="border rounded-4 p-3 h-100">
                                        <div class="small text-muted mb-2">Step {{ $index + 1 }}</div>
                                        <div class="fw-semibold mb-1">{{ $step['label'] }}</div>
                                        <div class="small text-muted mb-2">{{ $step['help'] ?: $step['placeholder'] }}</div>
                                        <span class="badge bg-light text-dark">{{ $step['type'] }}</span>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        <button class="btn btn-primary">Create lifecycle wizard</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
$('#create-lifecycle-preset-form').on('submit', function (e) {
    e.preventDefault();
    $.ajax({
        url: '{{ route('ai-tools.wizards.presets.store') }}',
        method: 'POST',
        data: $(this).serialize(),
        success: function (response) {
            if (response.status === 'success' && response.data?.redirect) {
                window.location.href = response.data.redirect;
            }
        },
        error: function (xhr) {
            alert(xhr.responseJSON?.message || xhr.responseJSON?.error || 'Request failed');
        }
    });
});
</script>
@endpush
