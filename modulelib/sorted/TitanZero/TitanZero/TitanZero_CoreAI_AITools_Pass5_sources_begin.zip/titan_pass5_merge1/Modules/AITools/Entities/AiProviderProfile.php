<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;

class AiProviderProfile extends BaseModel
{
    protected $table = 'ai_tools_provider_profiles';

    protected $guarded = ['id'];

    protected $casts = [
        'supports_reasoning' => 'boolean',
        'supports_text' => 'boolean',
        'supports_image' => 'boolean',
        'supports_multimodal' => 'boolean',
        'supports_embeddings' => 'boolean',
        'supports_structured_output' => 'boolean',
        'is_active' => 'boolean',
    ];
}
