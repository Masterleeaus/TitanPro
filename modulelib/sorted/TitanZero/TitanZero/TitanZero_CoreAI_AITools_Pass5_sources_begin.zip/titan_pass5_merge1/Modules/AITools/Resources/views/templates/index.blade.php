@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="row">
        <div class="col-md-5">
            <div class="card mb-4">
                <div class="card-header"><h5 class="mb-0">{{ __('aitools::app.generateTemplateWithAi') }}</h5></div>
                <div class="card-body">
                    <form id="generate-template-form">
                        @csrf
                        <div class="form-group mb-3">
                            <label>{{ __('aitools::app.templateBrief') }}</label>
                            <textarea name="brief" class="form-control" rows="6" placeholder="Create a follow-up email prompt for overdue invoices with variables for customer name, invoice number, amount and due date."></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 form-group mb-3">
                                <label>{{ __('aitools::app.category') }}</label>
                                <input type="text" name="category" class="form-control" value="general">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label>{{ __('aitools::app.persona') }}</label>
                                <select name="persona_key" class="form-control">
                                    <option value="">None</option>
                                    @foreach($personas as $persona)
                                        <option value="{{ $persona }}">{{ ucfirst($persona) }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 form-group mb-3">
                                <label>{{ __('aitools::app.lifecycleStage') }}</label>
                                <select name="lifecycle_stage" class="form-control">
                                    <option value="">None</option>
                                    @foreach($lifecycleStages as $stage)
                                        <option value="{{ $stage }}">{{ ucfirst($stage) }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label>{{ __('aitools::app.actionKey') }}</label>
                                <input type="text" name="action_key" class="form-control" placeholder="follow_up_email">
                            </div>
                        </div>
                        <button class="btn btn-primary">{{ __('aitools::app.generateAndSave') }}</button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header"><h5 class="mb-0">{{ __('aitools::app.addTemplateManually') }}</h5></div>
                <div class="card-body">
                    <form id="create-template-form">
                        @csrf
                        <div class="form-group mb-3"><label>{{ __('app.name') }}</label><input type="text" class="form-control" name="name"></div>
                        <div class="row">
                            <div class="col-md-6 form-group mb-3"><label>{{ __('aitools::app.category') }}</label><input type="text" class="form-control" name="category"></div>
                            <div class="col-md-6 form-group mb-3"><label>{{ __('aitools::app.persona') }}</label><select name="persona_key" class="form-control"><option value="">None</option>@foreach($personas as $persona)<option value="{{ $persona }}">{{ ucfirst($persona) }}</option>@endforeach</select></div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 form-group mb-3"><label>{{ __('aitools::app.lifecycleStage') }}</label><select name="lifecycle_stage" class="form-control"><option value="">None</option>@foreach($lifecycleStages as $stage)<option value="{{ $stage }}">{{ ucfirst($stage) }}</option>@endforeach</select></div>
                            <div class="col-md-6 form-group mb-3"><label>{{ __('aitools::app.actionKey') }}</label><input type="text" class="form-control" name="action_key"></div>
                        </div>
                        <div class="form-group mb-3"><label>{{ __('app.description') }}</label><textarea class="form-control" name="description" rows="3"></textarea></div>
                        <div class="form-group mb-3"><label>{{ __('aitools::app.systemPrompt') }}</label><textarea class="form-control" name="system_prompt" rows="4"></textarea></div>
                        <div class="form-group mb-3"><label>{{ __('aitools::app.userPromptTemplate') }}</label><textarea class="form-control" name="user_prompt_template" rows="6" placeholder="Write a polite email to {{customer_name}} about invoice {{invoice_number}} for {{amount}} due on {{due_date}}."></textarea></div>
                        <div class="form-group mb-3"><label>{{ __('aitools::app.variablesJson') }}</label><textarea class="form-control" name="variables_json" rows="5">[{"key":"customer_name","label":"Customer name","required":true}]</textarea></div>
                        <div class="row">
                            <div class="col-md-6 form-group mb-3"><label>{{ __('aitools::app.outputFormat') }}</label><select class="form-control" name="output_format"><option value="text">text</option><option value="markdown">markdown</option><option value="json">json</option><option value="html">html</option></select></div>
                            <div class="col-md-3 form-group mb-3"><label>{{ __('aitools::app.status') }}</label><select class="form-control" name="status"><option value="draft">draft</option><option value="published">published</option><option value="archived">archived</option></select></div>
                            <div class="col-md-3 form-group mb-3"><label>{{ __('aitools::app.version') }}</label><input type="text" class="form-control" name="version_label" value="v1"></div>
                        </div>
                        <button class="btn btn-success">{{ __('app.save') }}</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-7">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">{{ __('aitools::app.promptLibrary') }}</h5>
                    <span class="badge bg-primary">{{ $templates->count() }}</span>
                </div>
                <div class="card-body">
                    @forelse($templates as $template)
                        <div class="border rounded p-3 mb-3">
                            <div class="d-flex justify-content-between align-items-start gap-3">
                                <div>
                                    <h6 class="mb-1">{{ $template->name }}</h6>
                                    <div class="text-muted small">{{ $template->category ?: 'general' }} · {{ $template->output_format }} · {{ $template->version_label ?: 'v1' }}</div>
                                    @if($template->metadataLabel())
                                        <div class="small mt-1"><span class="badge bg-light text-dark">{{ $template->metadataLabel() }}</span></div>
                                    @endif
                                </div>
                                <a href="{{ route('ai-tools.templates.show', $template->id) }}" class="btn btn-sm btn-outline-primary">{{ __('aitools::app.open') }}</a>
                            </div>
                            @if($template->description)
                                <p class="mb-2 mt-2">{{ $template->description }}</p>
                            @endif
                            <div class="small text-muted">{{ count($template->resolvedVariables()) }} {{ __('aitools::app.variables') }} · {{ ucfirst($template->visibility ?? 'company') }}</div>
                        </div>
                    @empty
                        <p class="text-muted mb-0">{{ __('aitools::app.noTemplatesYet') }}</p>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
(function () {
    function handleAjax(formId, url) {
        $(formId).on('submit', function (e) {
            e.preventDefault();
            $.ajax({
                url: url,
                method: 'POST',
                data: $(this).serialize(),
                success: function (response) {
                    if (response.status === 'success' && response.data && response.data.redirect) {
                        window.location.href = response.data.redirect;
                        return;
                    }
                    window.location.reload();
                },
                error: function (xhr) {
                    alert(xhr.responseJSON?.message || xhr.responseJSON?.error || 'Request failed');
                }
            });
        });
    }
    handleAjax('#generate-template-form', '{{ route('ai-tools.templates.generate') }}');
    handleAjax('#create-template-form', '{{ route('ai-tools.templates.store') }}');
})();
</script>
@endpush
