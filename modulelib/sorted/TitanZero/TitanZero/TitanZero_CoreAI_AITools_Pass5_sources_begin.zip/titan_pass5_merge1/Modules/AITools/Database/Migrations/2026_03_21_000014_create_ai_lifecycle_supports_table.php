<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ai_tools_lifecycle_supports', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('support_key')->index();
            $table->string('lifecycle_stage')->index();
            $table->string('action_context')->nullable()->index();
            $table->string('entity_type')->nullable()->index();
            $table->string('default_persona')->nullable();
            $table->string('helper_template_key')->nullable();
            $table->string('summary_template_key')->nullable();
            $table->string('final_template_key')->nullable();
            $table->text('stage_instruction')->nullable();
            $table->text('missing_data_prompt')->nullable();
            $table->text('clarification_prompt')->nullable();
            $table->text('review_prompt')->nullable();
            $table->boolean('voice_friendly')->default(true);
            $table->boolean('requires_review')->default(true);
            $table->boolean('is_active')->default(true);
            $table->integer('priority')->default(100);
            $table->json('flags')->nullable();
            $table->timestamps();

            $table->unique(['company_id', 'support_key'], 'ai_tools_lifecycle_supports_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_tools_lifecycle_supports');
    }
};
