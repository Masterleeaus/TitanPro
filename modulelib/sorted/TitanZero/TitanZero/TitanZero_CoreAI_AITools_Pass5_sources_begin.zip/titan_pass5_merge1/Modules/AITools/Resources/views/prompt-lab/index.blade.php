@extends('layouts.app')
@section('content')
<div class="row">
    <div class="col-md-4">
        <x-setting-card>
            <x-slot name="header">Prompt Testing Lab</x-slot>
            <form id="prompt-lab-form">
                @csrf
                <div class="form-group">
                    <label>Template A</label>
                    <select name="prompt_template_id" id="prompt_template_id" class="form-control">
                        @foreach($templates as $template)
                            <option value="{{ $template->id }}">{{ $template->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label>Template B</label>
                    <select name="right_prompt_template_id" id="right_prompt_template_id" class="form-control">
                        @foreach($templates as $template)
                            <option value="{{ $template->id }}">{{ $template->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label>Persona</label>
                    <select name="persona_key" class="form-control">
                        <option value="">Auto</option>
                        @foreach($personas as $persona)
                            <option value="{{ $persona->persona_key }}">{{ $persona->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label>Variables JSON</label>
                    <textarea name="variables_json" id="variables_json" rows="8" class="form-control">{"customer_name":"Acme Pty Ltd","service_type":"Deep Clean","action":"follow_up"}</textarea>
                </div>
                <div class="d-flex flex-wrap gap-2">
                    <button type="button" class="btn btn-primary" id="run-prompt-preview">Preview A</button>
                    <button type="button" class="btn btn-secondary" id="run-prompt-compare">Compare A/B</button>
                </div>
                <hr>
                <div class="form-group">
                    <label>Save Scenario Name</label>
                    <input type="text" name="scenario_name" id="scenario_name" class="form-control" placeholder="Booking complaint test">
                </div>
                <div class="form-group">
                    <label>Scenario Notes</label>
                    <textarea name="scenario_notes" id="scenario_notes" rows="3" class="form-control"></textarea>
                </div>
                <button type="button" class="btn btn-outline-primary" id="save-scenario">Save Scenario</button>
            </form>
        </x-setting-card>
    </div>
    <div class="col-md-8">
        <x-setting-card>
            <x-slot name="header">Preview + Comparison</x-slot>
            <div class="row mb-3">
                <div class="col-md-6">
                    <h6>Template A</h6>
                    <pre id="prompt-lab-preview" class="small text-break bg-light p-3">Preview output will appear here.</pre>
                </div>
                <div class="col-md-6">
                    <h6>Template B / Diff</h6>
                    <pre id="prompt-lab-compare" class="small text-break bg-light p-3">Comparison output will appear here.</pre>
                </div>
            </div>
            <div id="prompt-lab-metrics" class="mb-4 small"></div>
            <div class="row">
                <div class="col-md-6">
                    <h6>Recent Runs</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered">
                            <thead><tr><th>ID</th><th>Persona</th><th>Stage</th><th>Tokens</th><th>Status</th></tr></thead>
                            <tbody>
                            @foreach($recentRuns as $run)
                                <tr>
                                    <td>{{ $run->id }}</td>
                                    <td>{{ $run->persona_key ?: 'auto' }}</td>
                                    <td>{{ $run->lifecycle_stage ?: 'general' }}</td>
                                    <td>{{ $run->estimated_tokens }}</td>
                                    <td>{{ $run->status }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-6">
                    <h6>Saved Scenarios</h6>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered">
                            <thead><tr><th>Name</th><th>Persona</th><th>Stage</th></tr></thead>
                            <tbody>
                            @foreach($scenarios as $scenario)
                                <tr>
                                    <td>{{ $scenario->name }}</td>
                                    <td>{{ $scenario->persona_key ?: 'auto' }}</td>
                                    <td>{{ $scenario->lifecycle_stage ?: 'general' }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </x-setting-card>
    </div>
</div>
@endsection
@push('scripts')
<script>
(function () {
    const token = document.querySelector('input[name="_token"]').value;
    const form = document.getElementById('prompt-lab-form');
    const previewButton = document.getElementById('run-prompt-preview');
    const compareButton = document.getElementById('run-prompt-compare');
    const saveButton = document.getElementById('save-scenario');
    const previewBox = document.getElementById('prompt-lab-preview');
    const compareBox = document.getElementById('prompt-lab-compare');
    const metricsBox = document.getElementById('prompt-lab-metrics');

    function post(url, data) {
        return fetch(url, {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-TOKEN': token },
            body: data
        }).then(response => response.json());
    }

    previewButton?.addEventListener('click', function () {
        const data = new FormData(form);
        post("{{ route('ai-tools.prompt-lab.preview') }}", data).then(payload => {
            const preview = payload.data?.preview || payload.preview || {};
            previewBox.innerText = (preview.system_prompt || '') + "

" + (preview.user_prompt || '');
            metricsBox.innerHTML = '<strong>Estimated tokens:</strong> ' + (preview.estimated_prompt_tokens || 0);
        });
    });

    compareButton?.addEventListener('click', function () {
        const data = new FormData();
        data.append('left_prompt_template_id', document.getElementById('prompt_template_id').value);
        data.append('right_prompt_template_id', document.getElementById('right_prompt_template_id').value);
        data.append('variables_json', document.getElementById('variables_json').value);
        post("{{ route('ai-tools.prompt-lab.compare') }}", data).then(payload => {
            const left = payload.data?.left || {};
            const right = payload.data?.right || {};
            const comparison = payload.data?.comparison || {};
            previewBox.innerText = (left.system_prompt || '') + "

" + (left.user_prompt || '');
            compareBox.innerText = (right.system_prompt || '') + "

" + (right.user_prompt || '') + "

DIFF
" + JSON.stringify(comparison.diff || [], null, 2);
            metricsBox.innerHTML = [
                '<div><strong>Token delta:</strong> ' + (comparison.token_delta || 0) + '</div>',
                '<div><strong>Schema completeness:</strong> A ' + (comparison.schema_completeness_left || 0) + ' / B ' + (comparison.schema_completeness_right || 0) + '</div>',
                '<div><strong>Lifecycle readiness:</strong> A ' + (comparison.lifecycle_readiness_left || 0) + ' / B ' + (comparison.lifecycle_readiness_right || 0) + '</div>'
            ].join('');
        });
    });

    saveButton?.addEventListener('click', function () {
        const data = new FormData();
        data.append('name', document.getElementById('scenario_name').value || 'Untitled Scenario');
        data.append('persona_key', form.querySelector('select[name="persona_key"]').value);
        data.append('variables_json', document.getElementById('variables_json').value);
        data.append('notes', document.getElementById('scenario_notes').value);
        post("{{ route('ai-tools.prompt-lab.scenarios.store') }}", data).then(() => window.location.reload());
    });
})();
</script>
@endpush
