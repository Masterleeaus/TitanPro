<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;
use Illuminate\Support\Str;

class AiWizardTemplate extends BaseModel
{
    protected $table = 'ai_tools_wizard_templates';

    protected $guarded = ['id'];

    protected $casts = [
        'steps_json' => 'array',
        'is_active' => 'boolean',
    ];

    public const LIFECYCLE_STAGES = ['client', 'quote', 'booking', 'job', 'completion', 'invoice', 'payment', 'followup'];

    public static function visibleToCurrentUser()
    {
        $query = static::query()->where('is_active', true);

        if (user()?->is_superadmin) {
            return $query;
        }

        $companyId = company()?->id;

        return $query->where(function ($builder) use ($companyId) {
            $builder->whereNull('company_id')->orWhere('company_id', $companyId);
        });
    }

    public static function makeSlug(string $name): string
    {
        return Str::slug(Str::limit($name, 120, '')) ?: 'wizard';
    }

    public function scopeOwnedByCurrentTenant($query)
    {
        if (user()?->is_superadmin) {
            return $query->whereNull('company_id');
        }

        return $query->where('company_id', company()?->id);
    }

    public function metadataLabel(): string
    {
        $parts = array_filter([$this->lifecycle_stage, $this->action_key, $this->status]);

        return implode(' · ', $parts);
    }

    public function resolvedSteps(): array
    {
        return collect($this->steps_json ?: [])
            ->map(function ($step) {
                $key = $step['key'] ?? Str::slug($step['label'] ?? 'step', '_');
                return [
                    'key' => $key,
                    'label' => $step['label'] ?? ucfirst(str_replace('_', ' ', $key)),
                    'type' => $step['type'] ?? 'textarea',
                    'placeholder' => $step['placeholder'] ?? '',
                    'required' => (bool) ($step['required'] ?? false),
                    'help' => $step['help'] ?? null,
                ];
            })
            ->filter(fn ($step) => !empty($step['key']))
            ->values()
            ->all();
    }
}
