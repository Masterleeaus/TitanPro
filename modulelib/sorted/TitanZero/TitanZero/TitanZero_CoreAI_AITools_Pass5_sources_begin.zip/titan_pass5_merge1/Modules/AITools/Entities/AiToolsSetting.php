<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;
use App\Models\ModuleSetting;
use App\Models\User;
use Illuminate\Support\Str;

class AiToolsSetting extends BaseModel
{
    protected $table = 'ai_tools_settings';

    protected $guarded = ['id'];

    protected $casts = [
        'chatgpt_api_key' => 'encrypted',
        'custom_api_key' => 'encrypted',
        'use_custom_key' => 'boolean',
        'allow_user_bring_own_key' => 'boolean',
        'platform_fallback_enabled' => 'boolean',
        'platform_key_validated_at' => 'datetime',
        'custom_key_validated_at' => 'datetime',
    ];

    const MODULE_NAME = 'aitools';

    public static function addModuleSetting($company)
    {
        $roles = ['employee', 'admin', 'client'];
        ModuleSetting::createRoleSettingEntry(self::MODULE_NAME, $roles, $company);
    }

    public static function forCurrentContext(): self
    {
        if (user() && user()->is_superadmin) {
            return static::firstOrCreate(['company_id' => null], [
                'model_name' => 'gpt-4o-mini',
                'provider_mode' => 'platform',
                'platform_fallback_enabled' => true,
                'allow_user_bring_own_key' => true,
            ]);
        }

        $companyId = company()?->id;

        return static::firstOrCreate(['company_id' => $companyId], [
            'model_name' => 'gpt-4o-mini',
            'provider_mode' => 'hybrid',
            'platform_fallback_enabled' => true,
            'allow_user_bring_own_key' => true,
        ]);
    }

    public static function platformSetting(): self
    {
        return static::firstOrCreate(['company_id' => null], [
            'model_name' => 'gpt-4o-mini',
            'provider_mode' => 'platform',
            'platform_fallback_enabled' => true,
            'allow_user_bring_own_key' => true,
        ]);
    }


    public function canUseCustomKey(): bool
    {
        $platform = static::platformSetting();

        return (bool) ($platform->allow_user_bring_own_key ?? true);
    }

    public function normalizedProviderMode(): string
    {
        $mode = (string) ($this->provider_mode ?: 'hybrid');

        return in_array($mode, ['platform', 'custom', 'hybrid'], true) ? $mode : 'hybrid';
    }

    public function maskedCustomKey(): ?string
    {
        if (empty($this->custom_api_key_last4)) {
            return null;
        }

        return '••••••••' . $this->custom_api_key_last4;
    }

    public function setCustomApiKeyMetadata(): void
    {
        $this->custom_api_key_last4 = !empty($this->custom_api_key) ? Str::substr($this->custom_api_key, -4) : null;
    }

    public function setPlatformApiKeyMetadata(): void
    {
        $this->platform_api_key_last4 = !empty($this->chatgpt_api_key) ? Str::substr($this->chatgpt_api_key, -4) : null;
    }

    public function hasCustomKeyConfigured(): bool
    {
        return !empty($this->custom_api_key);
    }

    public function hasPlatformKeyConfigured(): bool
    {
        return !empty(static::platformSetting()->chatgpt_api_key);
    }

    public function resolvedCredentialStatus(): array
    {
        $platform = static::platformSetting();
        $mode = $this->normalizedProviderMode();
        $customEnabled = $this->canUseCustomKey() && (bool) $this->use_custom_key && !empty($this->custom_api_key);
        $platformEnabled = !empty($platform->chatgpt_api_key);

        if ($mode === 'custom') {
            return [
                'mode' => $mode,
                'custom_enabled' => $customEnabled,
                'platform_enabled' => $platformEnabled,
                'resolved_source' => $customEnabled ? 'tenant' : 'none',
                'is_ready' => $customEnabled,
                'message' => $customEnabled
                    ? 'Using your saved API key only.'
                    : 'Custom key mode is selected, but no tenant API key is ready yet.',
            ];
        }

        if ($mode === 'platform') {
            return [
                'mode' => $mode,
                'custom_enabled' => $customEnabled,
                'platform_enabled' => $platformEnabled,
                'resolved_source' => $platformEnabled ? 'platform' : 'none',
                'is_ready' => $platformEnabled,
                'message' => $platformEnabled
                    ? 'Using the platform API key only.'
                    : 'Platform key mode is selected, but the platform API key is not configured.',
            ];
        }

        if ($customEnabled) {
            return [
                'mode' => $mode,
                'custom_enabled' => $customEnabled,
                'platform_enabled' => $platformEnabled,
                'resolved_source' => 'tenant',
                'is_ready' => true,
                'message' => 'Hybrid mode is active and will use your saved API key first.',
            ];
        }

        if ($this->platform_fallback_enabled && $platformEnabled) {
            return [
                'mode' => $mode,
                'custom_enabled' => $customEnabled,
                'platform_enabled' => $platformEnabled,
                'resolved_source' => 'platform',
                'is_ready' => true,
                'message' => 'Hybrid mode is active and will fall back to the platform API key.',
            ];
        }

        return [
            'mode' => $mode,
            'custom_enabled' => $customEnabled,
            'platform_enabled' => $platformEnabled,
            'resolved_source' => 'none',
            'is_ready' => false,
            'message' => 'No active AI credentials are currently available for this configuration.',
        ];
    }

    public function resolveCredentials(?User $user = null): array
    {
        $platform = static::platformSetting();
        $mode = $this->normalizedProviderMode();
        $customEnabled = $this->canUseCustomKey() && (bool) $this->use_custom_key && !empty($this->custom_api_key);
        $platformEnabled = !empty($platform->chatgpt_api_key);

        if ($mode === 'custom') {
            if ($customEnabled) {
                return [
                    'api_key' => $this->custom_api_key,
                    'model' => $this->custom_model_name ?: $this->model_name ?: 'gpt-4o-mini',
                    'key_source' => 'tenant',
                ];
            }

            return [
                'api_key' => null,
                'model' => $this->custom_model_name ?: $this->model_name ?: 'gpt-4o-mini',
                'key_source' => 'tenant',
            ];
        }

        if ($mode === 'platform') {
            return [
                'api_key' => $platform->chatgpt_api_key,
                'model' => $platform->model_name ?: 'gpt-4o-mini',
                'key_source' => 'platform',
            ];
        }

        if ($customEnabled) {
            return [
                'api_key' => $this->custom_api_key,
                'model' => $this->custom_model_name ?: $this->model_name ?: $platform->model_name ?: 'gpt-4o-mini',
                'key_source' => 'tenant',
            ];
        }

        if ($this->platform_fallback_enabled && $platformEnabled) {
            return [
                'api_key' => $platform->chatgpt_api_key,
                'model' => $platform->model_name ?: $this->model_name ?: 'gpt-4o-mini',
                'key_source' => 'platform',
            ];
        }

        return [
            'api_key' => null,
            'model' => $this->custom_model_name ?: $this->model_name ?: $platform->model_name ?: 'gpt-4o-mini',
            'key_source' => $customEnabled ? 'tenant' : 'none',
        ];
    }
}
