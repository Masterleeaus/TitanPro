<?php

namespace Modules\Aitools\Console\Commands;

use Illuminate\Console\Command;
use Modules\Aitools\Entities\AiAssistantProfile;
use Modules\Aitools\Entities\AiLifecycleBundle;
use Modules\Aitools\Entities\AiPersona;
use Modules\Aitools\Entities\AiProviderProfile;
use Modules\Aitools\Services\Bootstrap\CoreAiBlueprintRegistry;

class AitoolsSyncCoreAiBlueprints extends Command
{
    protected $signature = 'aitools:sync-coreai-blueprints {--company_id=}';

    protected $description = 'Seed or refresh AITools provider, persona, assistant, and lifecycle bundle blueprints from the CoreAI runtime.';

    public function handle(CoreAiBlueprintRegistry $registry): int
    {
        $companyId = $this->option('company_id');
        $counts = [
            'personas' => 0,
            'providers' => 0,
            'assistants' => 0,
            'bundles' => 0,
        ];

        foreach ($registry->personaBlueprints() as $row) {
            $attributes = [
                'company_id' => $companyId,
                'persona_key' => $row['persona_key'],
                'lifecycle_stage' => $row['lifecycle_stage'],
            ];
            AiPersona::updateOrCreate($attributes, array_merge($row, ['company_id' => $companyId]));
            $counts['personas']++;
        }

        foreach ($registry->providerBlueprints() as $row) {
            $attributes = [
                'company_id' => $companyId,
                'profile_key' => $row['profile_key'],
            ];
            AiProviderProfile::updateOrCreate($attributes, array_merge($row, ['company_id' => $companyId]));
            $counts['providers']++;
        }

        foreach ($registry->assistantBlueprints() as $row) {
            $attributes = [
                'company_id' => $companyId,
                'assistant_slug' => $row['assistant_slug'],
            ];
            AiAssistantProfile::updateOrCreate($attributes, array_merge($row, ['company_id' => $companyId]));
            $counts['assistants']++;
        }

        foreach ($registry->lifecycleBundleBlueprints() as $row) {
            $attributes = [
                'company_id' => $companyId,
                'bundle_key' => $row['bundle_key'],
            ];
            AiLifecycleBundle::updateOrCreate($attributes, array_merge($row, ['company_id' => $companyId]));
            $counts['bundles']++;
        }

        $this->info('AITools core integration blueprints synced.');
        foreach ($counts as $key => $value) {
            $this->line(sprintf(' - %s: %d', $key, $value));
        }

        return self::SUCCESS;
    }
}
