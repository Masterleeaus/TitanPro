<?php

namespace Modules\Aitools\Traits;

use App\Helper\Reply;
use Modules\Aitools\Entities\AiToolsSetting;
use Modules\Aitools\Entities\AiToolsUsageHistory;

trait ChecksTokenAvailability
{
    protected function checkTokenAvailability()
    {
        if (user()->is_superadmin) {
            return true;
        }

        $company = company();
        if (!$company) {
            return Reply::error(__('aitools::messages.companyNotFound'));
        }

        $setting = AiToolsSetting::forCurrentContext();
        $credentials = $setting->resolveCredentials(user());

        if (($credentials['key_source'] ?? null) === 'tenant') {
            return true;
        }

        $package = $company->package;
        if (!$package) {
            return Reply::error(__('aitools::messages.packageNotFound'));
        }

        $totalAssignedTokens = $package->ai_chatgpt_tokens ?? 0;
        if ($totalAssignedTokens <= 0) {
            return true;
        }

        $totalTokensUsed = AiToolsUsageHistory::where('company_id', $company->id)
            ->where(function ($query) {
                $query->whereNull('key_source')->orWhere('key_source', 'platform');
            })
            ->sum('total_tokens');

        $remainingTokens = $totalAssignedTokens - $totalTokensUsed;

        if ($remainingTokens <= 0) {
            return Reply::error(__('aitools::messages.tokenLimitExceeded', [
                'assigned' => number_format($totalAssignedTokens),
                'used' => number_format($totalTokensUsed)
            ]));
        }

        return true;
    }
}
