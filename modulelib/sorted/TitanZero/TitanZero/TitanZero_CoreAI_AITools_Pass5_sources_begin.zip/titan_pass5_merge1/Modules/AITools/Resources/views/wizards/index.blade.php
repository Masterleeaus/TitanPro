@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="card border-0 shadow-sm mb-4" style="background: linear-gradient(135deg, #0f172a 0%, #1d4ed8 100%); color: #fff; border-radius: 22px; overflow: hidden;">
        <div class="card-body p-4 p-lg-5 d-flex flex-wrap justify-content-between gap-4 align-items-center">
            <div style="max-width: 720px;">
                <div class="text-uppercase small mb-2" style="letter-spacing: .14em; opacity: .72;">AITools · Lifecycle Engine</div>
                <h2 class="mb-2">Design one adaptive wizard for clients, quotes, bookings, jobs, and invoices.</h2>
                <p class="mb-0" style="opacity: .88;">Extracted from the SocialMediaAgent progressive wizard pattern and reshaped into a reusable lifecycle builder surface.</p>
            </div>
            <div class="d-flex flex-wrap gap-2">
                <a href="{{ route('ai-tools.wizards.lifecycle.create') }}" class="btn btn-light">Open lifecycle builder</a>
                <a href="#wizard-library" class="btn btn-outline-light">View library</a>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        @foreach($presetCards as $preset)
            <div class="col-md-6 col-xl-4">
                <div class="card h-100 border-0 shadow-sm" style="border-radius: 18px;">
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <div class="badge bg-primary-subtle text-primary mb-2">{{ ucfirst($preset['lifecycle_stage']) }}</div>
                                <h5 class="mb-1">{{ $preset['name'] }}</h5>
                            </div>
                            <span class="badge bg-light text-dark">{{ count($preset['steps']) }} steps</span>
                        </div>
                        <p class="text-muted flex-grow-1">{{ $preset['description'] }}</p>
                        <div class="small text-muted mb-3">{{ $preset['action_key'] }}</div>
                        <form class="preset-create-form" method="POST" action="{{ route('ai-tools.wizards.presets.store') }}">
                            @csrf
                            <input type="hidden" name="preset_key" value="{{ $preset['key'] }}">
                            <div class="d-flex gap-2">
                                <button class="btn btn-primary flex-grow-1">Create draft</button>
                                <a href="{{ route('ai-tools.wizards.lifecycle.create', ['preset' => $preset['key']]) }}" class="btn btn-outline-secondary">Preview</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        @endforeach
    </div>

    <div class="row g-4">
        <div class="col-lg-5">
            <div class="card h-100 shadow-sm border-0" style="border-radius: 18px;">
                <div class="card-header bg-white border-0 pt-4 px-4"><h5 class="mb-0">Generate a new wizard with AI</h5></div>
                <div class="card-body px-4 pb-4">
                    <form id="generate-wizard-form">
                        @csrf
                        <div class="form-group mb-3">
                            <label>Wizard brief</label>
                            <textarea name="brief" class="form-control" rows="6" placeholder="Create a quote-to-booking lifecycle wizard for a cleaning business that accepts email, PDF quotes, and manual notes."></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 form-group mb-3"><label>Category</label><input type="text" name="category" class="form-control" value="lifecycle"></div>
                            <div class="col-md-6 form-group mb-3"><label>Lifecycle stage</label><select name="lifecycle_stage" class="form-control"><option value="">None</option>@foreach($lifecycleStages as $stage)<option value="{{ $stage }}">{{ ucfirst($stage) }}</option>@endforeach</select></div>
                        </div>
                        <div class="form-group mb-3"><label>Action key</label><input type="text" name="action_key" class="form-control" placeholder="create_quote"></div>
                        <button class="btn btn-primary w-100">Generate and save</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-7" id="wizard-library">
            <div class="card shadow-sm border-0" style="border-radius: 18px;">
                <div class="card-header bg-white border-0 pt-4 px-4 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Wizard library</h5>
                    <a href="{{ route('ai-tools.wizards.lifecycle.create') }}" class="btn btn-sm btn-outline-primary">Lifecycle builder</a>
                </div>
                <div class="card-body px-4 pb-4">
                    @forelse($wizards as $wizard)
                        <div class="border rounded-4 p-3 mb-3">
                            <div class="d-flex justify-content-between gap-3 align-items-start">
                                <div>
                                    <div class="d-flex flex-wrap gap-2 mb-2">
                                        <span class="badge bg-light text-dark">{{ $wizard->category ?: 'general' }}</span>
                                        @if($wizard->lifecycle_stage)<span class="badge bg-primary-subtle text-primary">{{ ucfirst($wizard->lifecycle_stage) }}</span>@endif
                                        @if($wizard->action_key)<span class="badge bg-light text-dark">{{ $wizard->action_key }}</span>@endif
                                    </div>
                                    <h6 class="mb-1">{{ $wizard->name }}</h6>
                                    <p class="text-muted mb-2">{{ $wizard->description }}</p>
                                    <div class="small text-muted">{{ count($wizard->resolvedSteps()) }} steps · {{ strtoupper($wizard->output_format ?: 'text') }} · {{ ucfirst($wizard->visibility ?? 'company') }}</div>
                                </div>
                                <a href="{{ route('ai-tools.wizards.show', $wizard->id) }}" class="btn btn-outline-primary btn-sm">Open</a>
                            </div>
                        </div>
                    @empty
                        <div class="text-muted">No lifecycle wizards created yet.</div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
(function () {
    function handleAjax(formSelector, url) {
        $(document).on('submit', formSelector, function (e) {
            e.preventDefault();
            $.ajax({
                url: url,
                method: 'POST',
                data: $(this).serialize(),
                success: function (response) {
                    if (response.status === 'success' && response.data && response.data.redirect) {
                        window.location.href = response.data.redirect;
                        return;
                    }
                    window.location.reload();
                },
                error: function (xhr) {
                    alert(xhr.responseJSON?.message || xhr.responseJSON?.error || 'Request failed');
                }
            });
        });
    }

    handleAjax('#generate-wizard-form', '{{ route('ai-tools.wizards.generate') }}');
    handleAjax('.preset-create-form', '{{ route('ai-tools.wizards.presets.store') }}');
})();
</script>
@endpush
