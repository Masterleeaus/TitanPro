<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;

class AiPersona extends BaseModel
{
    protected $table = 'ai_tools_personas';

    protected $guarded = ['id'];

    protected $casts = [
        'is_enabled' => 'boolean',
        'event_permissions_json' => 'array',
    ];

    public const PERSONAS = ['zero', 'logic', 'finance', 'creative', 'macro', 'micro', 'entropy', 'alien'];

    public static function visibleToCurrentUser()
    {
        $query = static::query();

        if (user()?->is_superadmin) {
            return $query;
        }

        $companyId = company()?->id;

        return $query->where(function ($builder) use ($companyId) {
            $builder->whereNull('company_id')->orWhere('company_id', $companyId);
        });
    }
}
