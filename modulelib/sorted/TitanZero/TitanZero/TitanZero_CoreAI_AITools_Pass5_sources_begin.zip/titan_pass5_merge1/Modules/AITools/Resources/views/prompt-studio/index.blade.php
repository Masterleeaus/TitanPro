@extends('layouts.app')

@section('title', 'Prompt Studio')

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="grid grid-cols-12 gap-6 h-screen">
        <!-- Left: Prompt Editor -->
        <div class="col-span-6 border-r border-gray-200">
            <div class="flex flex-col h-full">
                <!-- Header -->
                <div class="pb-4 border-b border-gray-200">
                    <h1 class="text-3xl font-bold text-gray-900">Prompt Studio</h1>
                    <p class="text-sm text-gray-600 mt-1">Create, edit, and test prompts</p>
                </div>

                <!-- Persona & Lifecycle Selection -->
                <div class="py-4 space-y-3">
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Persona</label>
                            <select id="persona-select" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-blue-500 focus:border-blue-500">
                                <option value="">-- Select Persona --</option>
                                <option value="Logic">Logic</option>
                                <option value="Finance">Finance</option>
                                <option value="Creative">Creative</option>
                                <option value="Macro">Macro</option>
                                <option value="Micro">Micro</option>
                                <option value="Zero">Zero</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Lifecycle Event</label>
                            <select id="lifecycle-select" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-blue-500 focus:border-blue-500">
                                <option value="">-- Select Event --</option>
                                <option value="job_completed">Job Completed</option>
                                <option value="invoice_paid">Invoice Paid</option>
                                <option value="negative_feedback">Negative Feedback</option>
                                <option value="booking_processed">Booking Processed</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Prompt Editor -->
                <div class="flex-1 flex flex-col overflow-hidden">
                    <div class="flex items-center justify-between mb-2">
                        <label class="block text-sm font-medium text-gray-700">Prompt Content</label>
                        <div class="flex gap-2">
                            <button onclick="formatPrompt()" class="text-xs px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-gray-700">Format</button>
                            <button onclick="toggleWordWrap()" class="text-xs px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-gray-700">Wrap</button>
                        </div>
                    </div>
                    <textarea id="prompt-content" placeholder="Enter your prompt here... Use {variable} for template variables" class="flex-1 w-full p-3 border border-gray-300 rounded-lg font-mono text-sm resize-none focus:ring-blue-500 focus:border-blue-500"></textarea>
                </div>

                <!-- Action Buttons -->
                <div class="mt-4 flex gap-2 pt-4 border-t border-gray-200">
                    <button onclick="savePrompt()" class="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Save Prompt</button>
                    <button onclick="saveAsVersion()" class="flex-1 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 font-medium">Save as Version</button>
                    <button onclick="resetPrompt()" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-medium">Reset</button>
                </div>
            </div>
        </div>

        <!-- Right: Preview & Comparison -->
        <div class="col-span-6 flex flex-col">
            <!-- Tabs -->
            <div class="flex border-b border-gray-200 mb-4">
                <button onclick="showTab('preview')" class="preview-tab px-4 py-2 font-medium text-gray-700 border-b-2 border-blue-600">Preview</button>
                <button onclick="showTab('history')" class="history-tab px-4 py-2 font-medium text-gray-700 border-b-2 border-transparent hover:text-gray-900">History</button>
                <button onclick="showTab('comparison')" class="comparison-tab px-4 py-2 font-medium text-gray-700 border-b-2 border-transparent hover:text-gray-900">Comparison</button>
            </div>

            <!-- Preview Tab -->
            <div id="preview-tab" class="flex-1 overflow-auto">
                <div class="bg-gray-50 p-4 rounded-lg">
                    <h3 class="font-semibold text-gray-900 mb-3">Rendered Prompt</h3>
                    <div id="preview-output" class="bg-white p-3 rounded border border-gray-200 font-mono text-sm min-h-32 max-h-64 overflow-auto">
                        <p class="text-gray-500">Preview will appear here...</p>
                    </div>
                </div>

                <!-- Test Data -->
                <div class="mt-4">
                    <h3 class="font-semibold text-gray-900 mb-2">Test Variables</h3>
                    <div id="test-variables" class="space-y-2">
                        <!-- Test variables added dynamically -->
                    </div>
                </div>

                <!-- Test Output -->
                <div class="mt-4">
                    <h3 class="font-semibold text-gray-900 mb-2">Test Output</h3>
                    <button onclick="runTest()" class="w-full px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium mb-2">Run Test</button>
                    <div id="test-output" class="bg-white p-3 rounded border border-gray-200 font-mono text-sm min-h-20 max-h-32 overflow-auto">
                        <p class="text-gray-500">Test output will appear here...</p>
                    </div>
                </div>
            </div>

            <!-- History Tab -->
            <div id="history-tab" class="flex-1 overflow-auto hidden">
                <div class="space-y-2">
                    <div id="history-list" class="space-y-2">
                        <!-- Versions loaded dynamically -->
                    </div>
                </div>
            </div>

            <!-- Comparison Tab -->
            <div id="comparison-tab" class="flex-1 overflow-auto hidden">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Version 1</label>
                        <select id="compare-v1" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm mb-3">
                            <!-- Versions populated dynamically -->
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Version 2</label>
                        <select id="compare-v2" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm mb-3">
                            <!-- Versions populated dynamically -->
                        </select>
                    </div>
                </div>
                <button onclick="compareVersions()" class="w-full px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-medium mb-4">Compare</button>
                <div id="comparison-output" class="grid grid-cols-2 gap-4 max-h-96 overflow-auto">
                    <div>
                        <h4 class="font-semibold text-gray-900 mb-2">Version 1</h4>
                        <pre id="compare-diff-1" class="bg-white p-3 rounded border border-gray-200 text-xs overflow-auto"></pre>
                    </div>
                    <div>
                        <h4 class="font-semibold text-gray-900 mb-2">Version 2</h4>
                        <pre id="compare-diff-2" class="bg-white p-3 rounded border border-gray-200 text-xs overflow-auto"></pre>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function showTab(tabName) {
    // Hide all tabs
    document.getElementById('preview-tab').classList.add('hidden');
    document.getElementById('history-tab').classList.add('hidden');
    document.getElementById('comparison-tab').classList.add('hidden');

    // Remove active styling from all buttons
    document.querySelectorAll('button[onclick*="showTab"]').forEach(btn => {
        btn.classList.remove('border-blue-600', 'text-gray-900');
        btn.classList.add('border-transparent', 'text-gray-700');
    });

    // Show selected tab and activate button
    document.getElementById(tabName + '-tab').classList.remove('hidden');
    event.target.classList.add('border-blue-600', 'text-gray-900');
}

function savePrompt() {
    const persona = document.getElementById('persona-select').value;
    const lifecycle = document.getElementById('lifecycle-select').value;
    const content = document.getElementById('prompt-content').value;

    if (!persona || !lifecycle || !content) {
        alert('Please fill all fields');
        return;
    }

    // POST to /account/aitools/prompts/save
    fetch('/account/aitools/prompts/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content },
        body: JSON.stringify({ persona, lifecycle, content })
    }).then(r => r.json()).then(data => {
        if (data.success) {
            alert('Prompt saved!');
            loadHistory();
        }
    }).catch(e => console.error(e));
}

function saveAsVersion() {
    const persona = document.getElementById('persona-select').value;
    const lifecycle = document.getElementById('lifecycle-select').value;
    const content = document.getElementById('prompt-content').value;

    if (!persona || !lifecycle || !content) {
        alert('Please fill all fields');
        return;
    }

    fetch('/account/aitools/prompts/version', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content },
        body: JSON.stringify({ persona, lifecycle, content })
    }).then(r => r.json()).then(data => {
        if (data.success) {
            alert('Version saved! Version #' + data.version);
            loadHistory();
        }
    }).catch(e => console.error(e));
}

function resetPrompt() {
    document.getElementById('prompt-content').value = '';
}

function formatPrompt() {
    // Simple formatting: trim lines, remove extra spaces
    let content = document.getElementById('prompt-content').value;
    content = content.split('\n').map(line => line.trim()).filter(line => line).join('\n');
    document.getElementById('prompt-content').value = content;
}

function toggleWordWrap() {
    const textarea = document.getElementById('prompt-content');
    textarea.style.whiteSpace = textarea.style.whiteSpace === 'nowrap' ? 'pre-wrap' : 'nowrap';
}

function runTest() {
    const content = document.getElementById('prompt-content').value;
    // Mock test run
    document.getElementById('test-output').innerHTML = '<p class="text-gray-700">Test completed successfully</p>';
}

function loadHistory() {
    const persona = document.getElementById('persona-select').value;
    const lifecycle = document.getElementById('lifecycle-select').value;

    if (!persona || !lifecycle) return;

    fetch(`/account/aitools/prompts/history?persona=${persona}&lifecycle=${lifecycle}`)
        .then(r => r.json())
        .then(data => {
            const list = document.getElementById('history-list');
            list.innerHTML = data.versions.map(v => `
                <div class="p-3 border border-gray-200 rounded cursor-pointer hover:bg-gray-50" onclick="loadVersion(${v.id})">
                    <div class="font-medium text-gray-900">Version ${v.version}</div>
                    <div class="text-sm text-gray-600">${new Date(v.created_at).toLocaleDateString()}</div>
                </div>
            `).join('');

            // Populate comparison selects
            const v1 = document.getElementById('compare-v1');
            const v2 = document.getElementById('compare-v2');
            v1.innerHTML = v2.innerHTML = data.versions.map(v => `<option value="${v.id}">Version ${v.version}</option>`).join('');
        })
        .catch(e => console.error(e));
}

function loadVersion(versionId) {
    fetch(`/account/aitools/prompts/version/${versionId}`)
        .then(r => r.json())
        .then(data => {
            document.getElementById('prompt-content').value = data.content;
            alert('Version loaded');
        })
        .catch(e => console.error(e));
}

function compareVersions() {
    const v1Id = document.getElementById('compare-v1').value;
    const v2Id = document.getElementById('compare-v2').value;

    if (!v1Id || !v2Id) {
        alert('Select both versions');
        return;
    }

    fetch(`/account/aitools/prompts/compare?v1=${v1Id}&v2=${v2Id}`)
        .then(r => r.json())
        .then(data => {
            document.getElementById('compare-diff-1').innerText = data.content1;
            document.getElementById('compare-diff-2').innerText = data.content2;
        })
        .catch(e => console.error(e));
}

// Load history when persona/lifecycle changes
document.getElementById('persona-select').addEventListener('change', loadHistory);
document.getElementById('lifecycle-select').addEventListener('change', loadHistory);
</script>
@endsection
