<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;

class AiKnowledgePack extends BaseModel
{
    protected $table = 'ai_tools_knowledge_packs';

    protected $guarded = ['id'];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function scopeVisibleToCurrentUser($query)
    {
        if (user()?->is_superadmin) {
            return $query;
        }

        $companyId = company()?->id;

        return $query->where(function ($builder) use ($companyId) {
            $builder->whereNull('company_id')->orWhere('company_id', $companyId);
        });
    }
}
