@extends('layouts.app')

@section('content')
<div class="w-100 px-4 py-3">
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
        <div>
            <h2 class="mb-1">Lifecycle Support Surface</h2>
            <p class="text-muted mb-0">Define stage instructions, clarification prompts, missing-data prompts, and final template mappings without moving lifecycle execution into AITools.</p>
        </div>
    </div>

    @if(session('status'))
        <div class="alert alert-success">{{ session('status') }}</div>
    @endif

    <div class="card mb-4">
        <div class="card-body">
            <form method="POST" action="{{ route('ai-tools.control-plane.lifecycle-support.store') }}" class="row g-3">
                @csrf
                <div class="col-md-3">
                    <label class="form-label">Support Key</label>
                    <input type="text" name="support_key" class="form-control" placeholder="booking.intake.default" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Lifecycle Stage</label>
                    <input type="text" name="lifecycle_stage" class="form-control" placeholder="booking_processed" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Action Context</label>
                    <input type="text" name="action_context" class="form-control" placeholder="intake_review">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Entity Type</label>
                    <input type="text" name="entity_type" class="form-control" placeholder="booking">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Default Persona</label>
                    <input type="text" name="default_persona" class="form-control" placeholder="Zero">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Helper Template Key</label>
                    <input type="text" name="helper_template_key" class="form-control" placeholder="booking.helper.card">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Summary Template Key</label>
                    <input type="text" name="summary_template_key" class="form-control" placeholder="booking.summary.operator">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Final Template Key</label>
                    <input type="text" name="final_template_key" class="form-control" placeholder="booking.customer.final_message">
                </div>
                <div class="col-12">
                    <label class="form-label">Stage Instruction</label>
                    <textarea name="stage_instruction" class="form-control" rows="2" placeholder="Describe what this stage should do."></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Missing Data Prompt</label>
                    <textarea name="missing_data_prompt" class="form-control" rows="3" placeholder="Ask only for missing fields required to continue."></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Clarification Prompt</label>
                    <textarea name="clarification_prompt" class="form-control" rows="3" placeholder="Clarify ambiguous customer intent or operator notes."></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Review Prompt</label>
                    <textarea name="review_prompt" class="form-control" rows="3" placeholder="Explain what should be reviewed before approval."></textarea>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Priority</label>
                    <input type="number" name="priority" value="100" class="form-control">
                </div>
                <div class="col-md-4 d-flex flex-wrap align-items-end gap-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="voice_friendly" value="1" checked>
                        <label class="form-check-label">Voice friendly</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="requires_review" value="1" checked>
                        <label class="form-check-label">Requires review</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" checked>
                        <label class="form-check-label">Active</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="flag_customer_facing" value="1">
                        <label class="form-check-label">Customer facing</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="flag_approval_gate" value="1">
                        <label class="form-check-label">Approval gate</label>
                    </div>
                </div>
                <div class="col-12">
                    <button class="btn btn-primary">Save Lifecycle Support</button>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <h4 class="mb-3">Configured Stage Supports</h4>
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead>
                        <tr>
                            <th>Key</th>
                            <th>Stage</th>
                            <th>Context</th>
                            <th>Persona</th>
                            <th>Templates</th>
                            <th>Flags</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($supports as $support)
                            <tr>
                                <td>
                                    <div class="fw-bold">{{ $support->support_key }}</div>
                                    <small class="text-muted">{{ $support->entity_type ?: 'any entity' }}</small>
                                </td>
                                <td>{{ $support->lifecycle_stage }}</td>
                                <td>{{ $support->action_context ?: 'default' }}</td>
                                <td>{{ $support->default_persona ?: 'Zero' }}</td>
                                <td>
                                    <div><small>Helper:</small> {{ $support->helper_template_key ?: '—' }}</div>
                                    <div><small>Summary:</small> {{ $support->summary_template_key ?: '—' }}</div>
                                    <div><small>Final:</small> {{ $support->final_template_key ?: '—' }}</div>
                                </td>
                                <td>
                                    @if($support->voice_friendly)<span class="badge bg-info me-1">voice</span>@endif
                                    @if($support->requires_review)<span class="badge bg-warning text-dark me-1">review</span>@endif
                                    @if($support->is_active)<span class="badge bg-success me-1">active</span>@endif
                                    @if(data_get($support->flags, 'customer_facing'))<span class="badge bg-primary me-1">customer</span>@endif
                                    @if(data_get($support->flags, 'approval_gate'))<span class="badge bg-secondary me-1">approval</span>@endif
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="6" class="text-center text-muted">No lifecycle support records yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
