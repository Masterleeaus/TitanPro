@extends('layouts.app')
@section('content')
<div class="row g-3">
  <div class="col-12">
    <div class="card border-0 shadow-sm"><div class="card-body">
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
        <div>
          <h2 class="mb-1">CoreAI ↔ AITools Integration</h2>
          <p class="text-muted mb-0">Sync runtime blueprints from CoreAI into the editable AITools control plane without replacing the runtime layer.</p>
        </div>
        <form method="POST" action="{{ route('ai-tools.control-plane.core-integration.sync') }}">
          @csrf
          <button class="btn btn-primary btn-lg">Sync CoreAI Blueprints</button>
        </form>
      </div>
      <div class="row g-3">
        <div class="col-md-3"><div class="border rounded p-3"><div class="text-muted small">CoreAI services</div><div class="fs-3 fw-bold">{{ $integrationSummary['core_services'] ?? 0 }}</div></div></div>
        <div class="col-md-3"><div class="border rounded p-3"><div class="text-muted small">Decision services</div><div class="fs-3 fw-bold">{{ $integrationSummary['decision_services'] ?? 0 }}</div></div></div>
        <div class="col-md-3"><div class="border rounded p-3"><div class="text-muted small">AITools php files</div><div class="fs-3 fw-bold">{{ $integrationSummary['aitools_files'] ?? 0 }}</div></div></div>
        <div class="col-md-3"><div class="border rounded p-3"><div class="text-muted small">Blueprints ready</div><div class="fs-3 fw-bold">{{ ($integrationSummary['persona_blueprints'] ?? 0) + ($integrationSummary['provider_blueprints'] ?? 0) + ($integrationSummary['assistant_blueprints'] ?? 0) + ($integrationSummary['lifecycle_bundle_blueprints'] ?? 0) }}</div></div></div>
      </div>
    </div></div>
  </div>

  <div class="col-lg-6">
    <div class="card border-0 shadow-sm"><div class="card-body">
      <h3 class="h5 mb-3">Current editable counts</h3>
      <table class="table table-sm align-middle mb-0">
        <tr><th>Personas</th><td>{{ $currentCounts['personas'] }}</td><td>{{ $integrationSummary['persona_blueprints'] }} blueprint rows</td></tr>
        <tr><th>Providers</th><td>{{ $currentCounts['providers'] }}</td><td>{{ $integrationSummary['provider_blueprints'] }} blueprint rows</td></tr>
        <tr><th>Assistants</th><td>{{ $currentCounts['assistants'] }}</td><td>{{ $integrationSummary['assistant_blueprints'] }} blueprint rows</td></tr>
        <tr><th>Lifecycle bundles</th><td>{{ $currentCounts['bundles'] }}</td><td>{{ $integrationSummary['lifecycle_bundle_blueprints'] }} blueprint rows</td></tr>
      </table>
    </div></div>
  </div>

  <div class="col-lg-6">
    <div class="card border-0 shadow-sm"><div class="card-body">
      <h3 class="h5 mb-3">What sync writes</h3>
      <ul class="mb-0 ps-3">
        <li>Provider profiles for reasoning, image, multimodal, offline, and finance routing.</li>
        <li>Persona registry rows for Zero, Logic, Finance, Creative, Macro, Micro, Entropy, and Alien.</li>
        <li>Assistant profiles for booking, job, invoice, and complaint-resolution surfaces.</li>
        <li>Lifecycle bundles for booking processed, job completed, invoice paid, negative feedback, and staff absence.</li>
      </ul>
    </div></div>
  </div>

  <div class="col-12 col-xl-6">
    <div class="card border-0 shadow-sm"><div class="card-body">
      <h3 class="h5 mb-3">Persona blueprints</h3>
      <div class="table-responsive"><table class="table table-bordered table-sm align-middle">
        <thead><tr><th>Persona</th><th>Scope</th><th>Budget</th><th>Threshold</th></tr></thead>
        <tbody>@foreach($personaBlueprints as $row)<tr><td>{{ $row['name'] }}</td><td>{{ $row['authority_scope'] }}</td><td>{{ $row['token_budget'] }}</td><td>{{ $row['escalation_threshold'] }}</td></tr>@endforeach</tbody>
      </table></div>
    </div></div>
  </div>

  <div class="col-12 col-xl-6">
    <div class="card border-0 shadow-sm"><div class="card-body">
      <h3 class="h5 mb-3">Provider blueprints</h3>
      <div class="table-responsive"><table class="table table-bordered table-sm align-middle">
        <thead><tr><th>Profile</th><th>Provider</th><th>Default</th><th>Caps</th></tr></thead>
        <tbody>@foreach($providerBlueprints as $row)<tr><td>{{ $row['profile_key'] }}</td><td>{{ $row['provider'] }}</td><td>{{ $row['default_model'] }}</td><td>{{ collect(['reasoning' => $row['supports_reasoning'], 'text' => $row['supports_text'], 'image' => $row['supports_image'], 'multimodal' => $row['supports_multimodal'], 'embeddings' => $row['supports_embeddings']])->filter()->keys()->implode(', ') }}</td></tr>@endforeach</tbody>
      </table></div>
    </div></div>
  </div>

  <div class="col-12 col-xl-6">
    <div class="card border-0 shadow-sm"><div class="card-body">
      <h3 class="h5 mb-3">Assistant blueprints</h3>
      <div class="table-responsive"><table class="table table-bordered table-sm align-middle">
        <thead><tr><th>Assistant</th><th>Scope</th><th>Persona</th><th>Events</th></tr></thead>
        <tbody>@foreach($assistantBlueprints as $row)<tr><td>{{ $row['name'] }}</td><td>{{ $row['entity_scope'] }}</td><td>{{ strtoupper($row['default_persona']) }}</td><td>{{ implode(', ', $row['allowed_lifecycle_events']) }}</td></tr>@endforeach</tbody>
      </table></div>
    </div></div>
  </div>

  <div class="col-12 col-xl-6">
    <div class="card border-0 shadow-sm"><div class="card-body">
      <h3 class="h5 mb-3">Lifecycle bundle blueprints</h3>
      <div class="table-responsive"><table class="table table-bordered table-sm align-middle">
        <thead><tr><th>Bundle</th><th>Event</th><th>Persona</th><th>Assistant</th></tr></thead>
        <tbody>@foreach($bundleBlueprints as $row)<tr><td>{{ $row['bundle_key'] }}</td><td>{{ $row['lifecycle_event'] }}</td><td>{{ strtoupper($row['default_persona']) }}</td><td>{{ $row['assistant_slug'] }}</td></tr>@endforeach</tbody>
      </table></div>
    </div></div>
  </div>
</div>
@endsection
