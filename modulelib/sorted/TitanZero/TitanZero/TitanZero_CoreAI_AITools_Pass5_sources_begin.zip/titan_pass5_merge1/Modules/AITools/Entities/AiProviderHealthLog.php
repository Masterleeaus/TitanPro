<?php

namespace Modules\Aitools\Entities;

use App\Models\BaseModel;

class AiProviderHealthLog extends BaseModel
{
    protected $table = 'ai_tools_provider_health_logs';

    protected $guarded = ['id'];

    protected $casts = [
        'last_success_at' => 'datetime',
        'last_failure_at' => 'datetime',
    ];
}
