# CoreAI Pipeline Pass 2

## What this pass adds
- database-backed pipeline definition sync for the five MVP lifecycle events
- pipeline run persistence in `tz_core_pipeline_runs`
- step run persistence in `tz_core_pipeline_step_runs`
- confidence snapshots in `tz_core_ai_confidence_scores`
- Zero profile bootstrap in `tz_core_zero_profiles`
- bootstrap route to sync config-driven lifecycle pipelines into company-scoped records

## Execution shape
1. WorkSuite action reaches process/signal chain
2. approved lifecycle event calls CoreAI pipeline
3. pipeline run record is created
4. each persona stage stores a step run
5. Zero consolidates final output
6. final output is stored on the pipeline run for later audit / rewind compatibility

## Notes
- this pass still keeps lifecycle execution bounded and config-first
- automation remains outside CoreAI and should consume final structured outputs after approval
- company-scoped sync allows the same default pipelines to be materialized per tenant without hardcoding them into controllers
