# AITools Lifecycle Wizard Integration — Pass 4

## Base
- Started from `TitanZero_CoreAI_AITools_Pass3_integrated.zip`
- Kept CoreAI and AITools boundaries unchanged
- Did **not** merge TitanBuilder/module-scoped code into core

## What was integrated
Extracted the **progressive multi-step wizard pattern** from the `SocialMediaAgent` donor in `Extension Library.zip` and adapted it into **AITools** as a reusable **Lifecycle Engine** surface.

## Main additions
- preset-backed lifecycle wizard bootstrap service
- lifecycle builder route and draft-creation flow
- richer wizard library landing page with preset cards
- progressive stepper runner UI for wizard execution
- lifecycle-specific presets for:
  - client intake
  - quote builder
  - booking engine
  - job creation
  - invoice draft

## Files added
- `Modules/AITools/Services/LifecycleWizardPresetService.php`
- `Modules/AITools/Resources/views/wizards/create-lifecycle.blade.php`
- `Modules/AITools/Resources/views/wizards/partials/lifecycle-engine-shell.blade.php`
- `TitanDocs/AITools/LIFECYCLE_WIZARD_PASS4.md`

## Files updated
- `Modules/AITools/Http/Controllers/AiWizardController.php`
- `Modules/AITools/Routes/web.php`
- `Modules/AITools/Resources/views/wizards/index.blade.php`
- `Modules/AITools/Resources/views/wizards/show.blade.php`

## Next pass ideas
- persist wizard graph/nodes separately from `steps_json`
- add policy thresholds, purpose, personas, and provider selectors directly inside wizard definitions
- connect wizard output to lifecycle bundle runtime contracts
- add import-from-donor conversion for more SocialMediaAgent flows
