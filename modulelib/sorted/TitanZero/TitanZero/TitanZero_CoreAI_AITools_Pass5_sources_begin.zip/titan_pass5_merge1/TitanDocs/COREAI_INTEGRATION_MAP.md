# Titan CoreAI Integration Map — Pass 1

## Base Artifact
- Base system: WorkSuite `script/`
- Build target: native WorkSuite CoreAI foundation
- Tenant rule: `company_id` first, `team_id` legacy-bridge only
- Table rule: `tz_core_*`

## Donor classification

### TitanCore — directly reusable with refactor
- OpenAI adapter/client abstractions
- provider/settings services
- usage logging and cost logging patterns
- prompt entities and CRUD patterns
- KB collections, document, chunk and collection-doc entities
- knowledge search service patterns
- API controller patterns for chat, prompt, kb, tools, metrics

### TitanCore — adaptable with refactor
- admin dashboard/settings console surfaces
- agent contract and agent registry concepts
- knowledge sync flows

### TitanCore — not relevant to MVP CoreAI pass 1
- donor provider wrappers that preserve donor namespaces
- full donor admin UX shells

### TitanZero — directly reusable with refactor
- retrieval engine structure
- document parser / chunker / classifier patterns
- audit logger patterns
- standards/help answer builder ideas
- review queue and admin audit concepts

### TitanZero — adaptable with refactor
- assist actions
- coach registry patterns
- wizard action controller ideas

### TitanZero — not relevant to MVP CoreAI pass 1
- donor marketplace assets
- module-local UX shells not native to WorkSuite

## WorkSuite anchor points confirmed
- existing chat foundation: `app/Models/UserChat.php`
- existing search foundation: `app/Models/UniversalSearch.php`
- package AI token field already exists in migrations
- notification/channel foundations exist for Twilio, Telegram and OneSignal

## Pass 1 implemented
- `config/core_ai.php`
- CoreAI service foundation
- lifecycle pipeline registry + runner
- OpenAI provider abstraction
- CoreAI dashboard/controller/routes
- `tz_core_*` migration foundation
- initial TitanDocs + cumulative delta logging

## Next pass target
- donor extraction into WorkSuite-native namespaces
- prompt registry persistence
- lifecycle seed data
- entity-thread persistence layer
- admin/provider settings screens
