# Diagnostics

This pass adds tenant-scoped diagnostics for:

- confidence tuning profiles
- active policy overrides
- schema auto-remediation suggestions
- indexed audit slices for later search and review

Console commands:

- `php artisan tzcore:decision:diagnose 1 booking_to_job`
- `php artisan tzcore:decision:replay /path/to/trace.json`
