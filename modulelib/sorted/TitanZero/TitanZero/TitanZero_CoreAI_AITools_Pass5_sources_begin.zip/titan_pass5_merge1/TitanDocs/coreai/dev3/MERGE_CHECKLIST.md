# Merge Checklist

- [ ] Copy delta into Worksuite root without extra nesting
- [ ] Register `App\Providers\TzCoreDecisionServiceProvider`
- [ ] Confirm `company_id` is used as the tenant identifier
- [ ] Run tz_core migrations
- [ ] Run seeders
- [ ] Run `php artisan tz:core-decision:install --report`
- [ ] Run `php artisan tz:core-decision:smoke`
- [ ] Wire booking/job/invoice/feedback/staff absence lifecycle events into the bridge
- [ ] Confirm policy blocks still override Zero arbitration
