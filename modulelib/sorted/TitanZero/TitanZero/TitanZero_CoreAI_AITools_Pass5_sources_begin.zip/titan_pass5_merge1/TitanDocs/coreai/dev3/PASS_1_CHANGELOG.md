# Dev 3 Pass 1

## Added
- Decision orchestration service stack for schema, confidence, policy, routing, escalation, eligibility, and Zero refinement.
- Ten `tz_core_*` migrations for audit-safe decision persistence.
- Core AI service provider for container binding.
- Base Eloquent models for new audit tables.

## Notes
- Tenant scope uses `company_id` first.
- All engines accept normalized arrays and persist JSON-safe audit snapshots.
- This pass is delta-only and is designed for later merge into the main WorkSuite artifact.
