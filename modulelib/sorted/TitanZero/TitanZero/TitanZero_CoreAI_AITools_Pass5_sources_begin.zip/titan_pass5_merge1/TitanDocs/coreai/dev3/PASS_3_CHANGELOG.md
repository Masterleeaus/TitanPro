# Pass 3

- Rebuilt the cumulative delta with a clean extractable root structure.
- Added deterministic decision orchestration services.
- Added confidence component calculators and outcome resolvers.
- Added full `tz_core_*` migration pack, models, tests, seeder, docs, provider, and smoke command.
