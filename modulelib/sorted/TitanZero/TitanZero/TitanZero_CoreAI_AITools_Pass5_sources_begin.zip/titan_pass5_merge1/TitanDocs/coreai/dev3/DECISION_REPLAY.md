# Decision Replay

The replay layer re-runs a stored decision trace through the current Dev 3 orchestration stack and stores:

- original input trace
- replayed result payload
- field-by-field diff summary

Use it to detect drift after changing confidence weights, lifecycle matrices, policy overrides, or schema rules.
