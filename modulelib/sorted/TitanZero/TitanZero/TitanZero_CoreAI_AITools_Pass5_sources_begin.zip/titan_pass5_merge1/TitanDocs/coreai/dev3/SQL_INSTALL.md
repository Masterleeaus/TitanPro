# SQL-first note

This cumulative delta includes Laravel migrations because the current base is a Worksuite code delta.
If you install SQL-first, mirror each migration table definition into paste-SQL and keep names identical.
