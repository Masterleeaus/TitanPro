# Dev 3 Integration Map

## Inputs expected from Dev 1 / Dev 2
- normalized persona outputs as JSON-safe arrays
- lifecycle event name
- company_id
- process_id
- financial exposure
- policy requirements
- missing enrichment fields
- schema validity hints

## Outputs emitted by Dev 3
- execution outcome
- approval mode
- reason codes
- persona sequence
- token budget
- escalation targets
- Zero refinement payload
- audit trace payload

## Worksuite merge points
- provider registration
- event/listener bridge or direct service calls at lifecycle transitions
- migration + seeder execution
- config override publication
