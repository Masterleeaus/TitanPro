# Dev 3 Pass 10

## Focus
- Repair `company_id` doctrine
- Remove duplicate migration execution risk
- Stabilize repository contracts
- Add Worksuite inbound lifecycle adapters
- Harden audit payload persistence

## Main Changes
- `tz_core_*` migrations normalized to `unsignedBigInteger company_id`
- duplicate `000111/000112` migrations converted to no-op repair placeholders
- lifecycle matrix migration corrected
- repositories upgraded with insertMany, upsert, process/lifecycle lookup helpers
- adapter registry added for the 5 MVP lifecycle actions
- bridge now routes through adapters before context creation
