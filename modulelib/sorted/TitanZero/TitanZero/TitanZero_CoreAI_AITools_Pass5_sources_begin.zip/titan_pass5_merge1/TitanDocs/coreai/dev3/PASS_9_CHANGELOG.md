# Pass 9 Changelog

## Merge + new build
- merged the uploaded cumulative deltas with pass 7 as the clean root base
- restored missing cumulative docs from older passes where useful
- added tenant confidence tuning profiles and policy override support
- added schema remediation hook registry and diagnostics snapshot flow
- added decision trace replay storage and replay service
- added audit indexing for faster execution-decision analysis
- added replay and diagnostics console commands
- added migrations and seed data for the new diagnostics layer
