# Worksuite Adapter Contract

Every inbound lifecycle adapter must emit:
- `company_id`
- `process_id`
- `lifecycle_event`
- `payload`
- `tenant_settings`
- `policy_requirements`
- `missing_fields`
- `financial_exposure`
- `schema_valid`
- `risk_level`

Adapters added:
- BookingToJobDecisionAdapter
- JobCompletionDecisionAdapter
- InvoicePaymentDecisionAdapter
- NegativeFeedbackDecisionAdapter
- StaffAbsenceDecisionAdapter
