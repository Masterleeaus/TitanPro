# Install Steps

1. Merge this delta into the app root.
2. Register `App\Providers\TzCoreDecisionServiceProvider::class`.
3. Run migrations.
4. Seed matrix, reason codes, and escalation targets.
5. Run `php artisan tzcore:decision-smoke`.
