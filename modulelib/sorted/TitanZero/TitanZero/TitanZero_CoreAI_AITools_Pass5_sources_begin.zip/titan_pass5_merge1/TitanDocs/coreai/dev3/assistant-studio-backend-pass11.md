# Assistant Studio backend pass 11

This pass adds Dev-3 backend ownership for Assistant Studio without touching any Studio UI files.

## Added backend surfaces

- AssistantLifecycleBindingResolver
- AssistantChannelDispatchRouter
- AssistantExecutionPolicyAdapter
- AssistantDeploymentEligibilityService
- AssistantSafetyEnvelopeBuilder
- AssistantDispatchTraceWriter
- AssistantStudioDecisionBridge
- AssistantStudioAdapterRegistry

## Added reserved tables

- tz_core_assistants
- tz_core_assistant_sources
- tz_core_assistant_personas
- tz_core_assistant_channels
- tz_core_assistant_embeds
- tz_core_assistant_styles
- tz_core_assistant_knowledge_links
- tz_core_assistant_lifecycle_bindings
- tz_core_assistant_dispatch_traces

## Boundary kept intact

No wizard, preview shell, builder blade, JS, CSS, routes, menus, or Studio controller/view files were changed in this pass.
