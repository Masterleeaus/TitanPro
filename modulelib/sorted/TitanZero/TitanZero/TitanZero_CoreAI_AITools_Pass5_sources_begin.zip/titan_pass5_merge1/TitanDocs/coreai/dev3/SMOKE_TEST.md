# Smoke Test

Use the smoke command after provider registration and migration. A successful run returns JSON with outcome, approval mode, confidence score, reason codes, and Zero refinement.
