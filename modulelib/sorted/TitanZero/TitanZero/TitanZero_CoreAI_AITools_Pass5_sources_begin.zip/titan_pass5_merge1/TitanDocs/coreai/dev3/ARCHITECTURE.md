# Architecture

Dev 3 is the control layer for lifecycle execution safety.
It validates schema, scores confidence, routes personas, resolves policy, gates execution, and records auditable decisions in `tz_core_*` tables.
