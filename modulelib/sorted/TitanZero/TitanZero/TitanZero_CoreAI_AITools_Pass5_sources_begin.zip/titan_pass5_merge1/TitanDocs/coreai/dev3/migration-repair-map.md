# Migration Repair Map

## Repairs
- `060011` removed invalid `process_id` index and added canonical lifecycle matrix keys.
- `060012` became canonical audit log definition with JSON payload columns.
- `000111` and `000112` converted to no-op compatibility migrations.
- `060001` to `060021` now align on `company_id` integer doctrine.

## Merge Note
This cumulative delta is intended to replace earlier Dev 3 delta files at the same paths.
