# CoreAI Cumulative Delta

## Pass 1
### Added
- `script/config/core_ai.php`
- `script/routes/core-ai.php`
- `script/app/Services/CoreAI/AiOrchestrator.php`
- `script/app/Services/CoreAI/PersonaRegistry.php`
- `script/app/Services/CoreAI/PersonaPromptRegistry.php`
- `script/app/Services/CoreAI/PersonaContextRegistry.php`
- `script/app/Services/CoreAI/ContextBuilder.php`
- `script/app/Services/CoreAI/ConfidenceScorer.php`
- `script/app/Services/CoreAI/AiAuditLogger.php`
- `script/app/Services/CoreAI/UsageMeter.php`
- `script/app/Services/CoreAI/ZeroConsolidator.php`
- `script/app/Services/CoreAI/Lifecycle/LifecycleEventRegistry.php`
- `script/app/Services/CoreAI/Lifecycle/PipelineRunner.php`
- `script/app/Services/CoreAI/Providers/ProviderInterface.php`
- `script/app/Services/CoreAI/Providers/OpenAIProvider.php`
- `script/app/Models/CoreAI/CoreAiPersona.php`
- `script/app/Models/CoreAI/CoreAiTenantSetting.php`
- `script/app/Models/CoreAI/CoreAiEntityThread.php`
- `script/app/Models/CoreAI/CoreAiUsageLog.php`
- `script/app/Models/CoreAI/CoreAiAudit.php`
- `script/app/Models/CoreAI/CoreLifecycleEvent.php`
- `script/app/Http/Controllers/CoreAI/CoreAiController.php`
- `script/resources/views/core-ai/index.blade.php`
- `script/database/migrations/2026_03_21_000001_create_tz_core_ai_foundation_tables.php`
- `TitanDocs/COREAI_INTEGRATION_MAP.md`
- `TitanDocs/COREAI_CUMULATIVE_DELTA.md`

### Changed
- `script/app/Providers/RouteServiceProvider.php`

### Purpose
- establish CoreAI foundation in native WorkSuite core paths
- register Zero-first persona config and lifecycle pipeline definitions
- add first `tz_core_*` schema layer
- add accessible dashboard/API seam for further passes


## Pass 2
### Added
- `script/app/Models/CoreAI/CoreAiPersonaPrompt.php`
- `script/app/Models/CoreAI/CoreAiPromptTemplate.php`
- `script/app/Models/CoreAI/CoreAiThreadMessage.php`
- `script/app/Models/CoreAI/CoreAiConfidenceScore.php`
- `script/app/Models/CoreAI/CorePipelineDef.php`
- `script/app/Models/CoreAI/CorePipelineStep.php`
- `script/app/Models/CoreAI/CorePipelineRun.php`
- `script/app/Models/CoreAI/CorePipelineStepRun.php`
- `script/app/Models/CoreAI/CoreZeroProfile.php`
- `script/app/Services/CoreAI/Lifecycle/PipelineRegistry.php`
- `script/app/Services/CoreAI/Lifecycle/PipelineRunRecorder.php`
- `TitanDocs/COREAI_PIPELINE_PASS2.md`

### Changed
- `script/app/Services/CoreAI/Lifecycle/PipelineRunner.php`
- `script/app/Http/Controllers/CoreAI/CoreAiController.php`
- `script/routes/core-ai.php`
- `script/resources/views/core-ai/index.blade.php`
- `TitanDocs/COREAI_CUMULATIVE_DELTA.md`

### Purpose
- materialize the five MVP lifecycle pipelines into company-scoped records
- persist pipeline runs and step runs for auditability and rewind-safe replay
- add Zero profile bootstrapping and confidence snapshots
- prepare the next pass for real lifecycle event execution against approved WorkSuite process/signal stages
