# CoreAI Begin Pass 01

This pass assembles the three CoreAI developer deliveries into one cumulative delta and places AITools into a module-safe destination.

## Included
- Dev1 foundation layer
- Dev2 integration layer overlaid on Dev1 where files overlap
- Dev3 decision layer added alongside runtime services
- AITools partial completion moved to `Modules/AITools`
- Bridge service provider and runtime bridge added for first integration handoff

## Merge rules used
1. Dev1 copied first as base foundation.
2. Dev2 overlaid when the same relative file existed.
3. Dev3 preserved under `app/Services/TitanCoreAI/*` and `app/Models/TzCore/*`.
4. AITools kept separate from runtime core.

## Immediate next pass
- wire signal/process adapters into `CoreAiRuntimeBridge`
- normalize config keys between `core_ai` and `coreai`
- add install manifest for provider registration and route loading
- map decision lifecycle events to Worksuite entities
- prune duplicate CoreAI models and align table names
