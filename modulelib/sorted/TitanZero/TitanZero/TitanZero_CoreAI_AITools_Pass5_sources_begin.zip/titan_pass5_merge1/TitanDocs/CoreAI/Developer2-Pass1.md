# CoreAI Developer 2 — Runtime Capability Pass 1

## Added Runtime Surfaces
- Conversation memory with lifecycle and entity scopes.
- Embedding registry with chunking and training-pack binding scaffolding.
- Assistant profiles for owner, staff, lifecycle, and entity attachment use.
- Envelope formatting, normalization, and malformed-output repair helpers.
- Provider registry plus capability-aware model routing.
- Token metering summaries by provider, persona, and stage.
- File intelligence classification and attachment indexing.
- Multimodal validation and context packaging.
- Audit export scaffolding and structured archive manifests.
- Credit eligibility metadata surface.
- Prompt testing lab with regression checks.
- Assistant tool registry.

## Database Tables
- coreai_memories
- coreai_embeddings
- coreai_assistants
- coreai_usage_logs
- coreai_exports
- coreai_prompt_tests
- coreai_tool_registry

## Integration Notes
- All new tables are company-scoped.
- Services are registered in `CoreAIServiceProvider`.
- This pass exposes runtime infrastructure only and does not own policy, routing authority, or UI.

