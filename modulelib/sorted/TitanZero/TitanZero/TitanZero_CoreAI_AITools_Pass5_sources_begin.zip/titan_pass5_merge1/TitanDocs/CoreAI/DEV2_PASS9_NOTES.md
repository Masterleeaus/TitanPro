# Dev2 Pass 9

Added training-pack persistence, embedding ingestion pipeline, lifecycle-stage retriever,
assistant/entity memory bridge, export manifest v2, and telemetry aggregation for retrieval packs.
