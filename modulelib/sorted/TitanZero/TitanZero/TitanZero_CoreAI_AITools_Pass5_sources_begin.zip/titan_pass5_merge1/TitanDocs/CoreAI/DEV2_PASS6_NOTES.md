# Dev2 Pass 6

Added notification adapters, speech compatibility, and confidence bridge outputs for Dev3.
