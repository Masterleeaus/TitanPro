# CoreAI Dev2 Pass 3

This pass expands the runtime capability layer in four major areas:

1. **Vector index layer**
   - tenant-safe embedding sources
   - stage-scoped retrieval
   - persona-targeted retrieval wrappers

2. **Schema safety utilities**
   - normalization
   - validation
   - fallback repair
   - lifecycle-stage compatibility checks

3. **Provider capability routing**
   - capability matrix
   - stage-aware model eligibility
   - zero-only cost guard

4. **Token metering**
   - per-call ledger
   - pipeline summaries
   - provider rollups
   - soft quota signal preparation

This remains orchestrator-agnostic and hands clean structured outputs to Dev 3.
