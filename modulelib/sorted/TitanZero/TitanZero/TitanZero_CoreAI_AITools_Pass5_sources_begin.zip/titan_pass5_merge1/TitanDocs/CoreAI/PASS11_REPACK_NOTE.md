Pass 11 repack created from cumulative CoreAI Dev2 runtime artifact.
This archive was rebuilt with a clean root to avoid nesting/path issues.
