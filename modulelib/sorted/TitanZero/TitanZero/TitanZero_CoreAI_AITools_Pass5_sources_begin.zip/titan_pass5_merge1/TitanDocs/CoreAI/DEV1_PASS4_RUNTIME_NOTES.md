# CoreAI Dev1 Pass 4 Runtime Notes

## Added runtime domains
- Memory
- Vector
- Assistants
- Formatting
- Provider Routing
- Metering
- File Intelligence
- Multimodal
- Export
- Credits
- Testing
- Tools

## Migration set
Creates tenant-scoped runtime tables using `company_id` only:
- `tz_core_ai_memories`
- `tz_core_ai_embeddings`
- `tz_core_ai_assistants`
- `tz_core_ai_exports`
- `tz_core_ai_prompt_tests`
- `tz_core_ai_tool_registry`
- `tz_core_ai_file_records`

## Integration updates
- `ContextBuilder` now appends memory + file attachment context.
- `AiOrchestrator` now uses model routing + formatting helpers + usage summaries.
- `CoreAiController` now exposes aggregated usage summary on index and accepts assistant/lifecycle inputs.
- `config/core_ai.php` now includes capability matrix + memory settings.

## Scope boundary retained
This pass does **not** add execution authority, persona policy ownership, approval gating, or UI settings surfaces.
