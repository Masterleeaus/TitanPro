# Dev2 Pass 8
- Added prompt testing lab runtime stubs
- Added regression comparator and lifecycle readiness scorer
- Added envelope hashing v2
- Added retrieval source trace registry
