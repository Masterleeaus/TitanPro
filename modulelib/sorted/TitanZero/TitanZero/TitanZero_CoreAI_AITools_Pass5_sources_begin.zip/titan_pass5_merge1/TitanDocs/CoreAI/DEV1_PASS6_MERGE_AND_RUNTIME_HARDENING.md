# Dev1 Pass 6

Merged pass4 + pass5 into one cumulative CoreAI delta and added runtime hardening.

## Added
- memory scope, payload normalization, and touch services
- vector source typing, chunk metadata, and retrieval formatting
- assistant scoping, inheritance merge, and entity lookup
- routing helpers for stage/model/capability/health
- metering snapshots, breakdowns, and quota warnings
- file intelligence fingerprinting and confidence scoring
- multimodal payload normalization and evidence packaging
- export manifest/storage/trace formatting helpers
- credits tier/persona/pipeline metadata catalogs
- testing recorder, comparison lab, and regression snapshots
- tool scope, helper catalogs, and manifest builder
- repair migration for runtime column consistency
