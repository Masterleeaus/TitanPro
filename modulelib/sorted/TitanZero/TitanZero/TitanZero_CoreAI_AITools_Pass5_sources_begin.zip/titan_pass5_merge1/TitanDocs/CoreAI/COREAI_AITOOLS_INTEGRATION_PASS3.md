# CoreAI ↔ AITools Integration Pass 3

## Purpose
This pass integrates the runtime overlay and the AITools module without moving execution logic out of CoreAI.

## What was added
- **Blueprint registry** in `Modules/AITools/Services/Bootstrap/CoreAiBlueprintRegistry.php`
  - canonical provider profiles
  - canonical persona rows
  - assistant profile defaults
  - lifecycle bundle defaults
- **Control-plane page** in `ai-tools/control-plane/core-integration`
  - shows runtime counts from `/app/Services/CoreAI`
  - previews blueprint rows before sync
  - one-click sync into editable AITools tables
- **CLI sync command**
  - `php artisan aitools:sync-coreai-blueprints`
  - optional `--company_id=` scope
- **Alien persona support** added to AITools persona constant

## Integration rule
- **CoreAI** remains execution runtime and decision engine.
- **AITools** remains editable control plane and authoring surface.
- Sync writes configuration rows only; it does not replace runtime classes.

## Seeded blueprint groups
### Providers
- primary.reasoning
- creative.generation
- fallback.reasoning
- multimodal.analysis
- fast.classifier
- finance.reasoning

### Personas
- Zero
- Logic
- Finance
- Creative
- Macro
- Micro
- Entropy
- Alien

### Assistants
- booking-assistant
- job-assistant
- invoice-assistant
- complaint-resolution-assistant

### Lifecycle bundles
- booking.processed
- job.completed
- invoice.paid
- feedback.negative_received
- staff.absence_reported

## Why this matters
This makes the current merged ZIP safer to install into WorkSuite because the AITools UI can now be populated directly from CoreAI assumptions instead of being manually re-entered or drifting from runtime behavior.
