# CoreAI Dev2 Pass 2

## Included
- Decision envelope core expanded for hashable, serializable, replay-safe records
- Runtime memory layer added with scoped lifecycle persistence and pruning hooks
- Assistant profile layer added with entity attachments and persona bridge context
- Eloquent models added for immediate WorkSuite integration
- Migrations use `company_id` as the canonical tenant key

## Next Recommended Pass
- vector retrieval registry
- chunk stores
- stage-scoped retrieval resolver
- provider capability router
