# CoreAI Pass 2 Runtime Wiring

## What changed

- Added `config/core_ai.php` alias wrapper so existing services using `core_ai.*` resolve correctly.
- Upgraded `AiOrchestrator` to expose `runZero()`, `orchestrate()`, and tenant-setting resolution.
- Added `CoreAiLifecycleRuntimeManager` to combine runtime preparation with decision-layer evaluation.
- Simplified `CoreAiRuntimeBridge` so it now delegates to one runtime manager.
- Added `routes/core-ai.php` with account and API runtime endpoints.
- Added `CoreAiRuntimeController` for JSON runtime orchestration.
- Added `coreai:bootstrap` command stub for tenant pipeline registration.

## Route surface

- `GET /account/core-ai`
- `POST /account/core-ai/zero`
- `POST /account/core-ai/pipelines/bootstrap`
- `POST /account/core-ai/pipelines/run`
- `POST /api/core-ai/runtime`

## Integration notes

- The command file is included, but the host app may need to register it in its console kernel if commands are not auto-discovered.
- `RouteServiceProvider` in this delta already maps `routes/core-ai.php`, so no extra route wiring is required.
- This pass does not move AITools runtime into the module; AITools remains a control surface only.
