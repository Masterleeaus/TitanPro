# Merge Begin Manifest

This pass begins the merge by staging donor code under `Sources/` inside the current CoreAI/AITools base.

Next merge targets:
1. Provider abstraction (MagicSite OpenAI + MultiModel)
2. Lifecycle wizard executor (MagicSite article wizard + SocialMediaAgent create flow)
3. Worksuite installer/package visibility bridge
4. AIChatPro conversation surfaces into AITools
