# Docs Findings

- `MAGICAI WORKSUITE CORE VS MODULES.pdf`: AI orchestration, routing, usage, event bus belong in core.
- `WORKSUITE COMPLETE WITH NATIVE FEATURES.pdf`: prefer device-native voice/on-device AI features.
- `WORKSUITE VOICE FIRST PWA ARCHITECTURE.pdf`: conversation-first execution model across apps.
- `TITANZERO PWA EDGE BUILD PLAN.pdf`: edge-node/device sync and signal ingestion are ready donors for later passes.
- `Developer Tasks.docx`: extract MagicAI provider drivers, persona registry, lifecycle engine, and prompt templates.
