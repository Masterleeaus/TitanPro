# Key Extraction Decisions

## Pull into Worksuite later
- Worksuite custom module install + package/module visibility pipeline.
- MagicSite OpenAI config + article wizard flow.
- SocialMediaAgent multi-step create wizard as lifecycle-engine donor.
- AIChatPro chat/settings controllers as AITools conversation donor.
- MultiModel config/provider as provider-routing donor.

## Keep in core for now
- Existing CoreAI orchestrator, lifecycle, tools, confidence, export, vector, provider routing services.
