<?php

use Illuminate\Support\Facades\Route;
use Modules\TitanZero\Http\Controllers\TitanZeroController;
use Modules\TitanZero\Http\Controllers\TitanZeroActionController;
use Modules\TitanAssist\Http\Controllers\TitanAssistController;

/*
| Titan Zero Web Routes
*/

Route::group([
    'middleware' => ['web', 'auth'],
    'prefix'     => 'titan-zero',
    'as'         => 'titan-zero.',
], function () {
    Route::get('/', [TitanZeroController::class, 'index'])->name('index');
    Route::get('/help', [TitanZeroController::class, 'help'])->name('help');
    Route::get('/chat', [TitanZeroController::class, 'chat'])->name('chat');
    Route::get('/generators', [TitanZeroController::class, 'generators'])->name('generators');
    Route::get('/templates', [TitanZeroController::class, 'templates'])->name('templates');
    Route::get('/ping', [TitanZeroController::class, 'ping'])->name('ping');
    Route::post('/action', [TitanZeroActionController::class, 'action'])->name('action');
});


/*
| Legacy Titan Assist Routes (compatibility)
*/
Route::group([
    'middleware' => ['web', 'auth'],
    'prefix'     => 'titan-assist',
    'as'         => 'titan-assist.',
], function () {
    Route::get('/', [TitanAssistController::class, 'index'])->name('index');
    Route::get('/help', [TitanAssistController::class, 'help'])->name('help');
    Route::get('/chat', [TitanAssistController::class, 'chat'])->name('chat');
    Route::get('/generators', [TitanAssistController::class, 'generators'])->name('generators');
    Route::get('/templates', [TitanAssistController::class, 'templates'])->name('templates');
});


// Titan Zero Standards Search (Pass 6)
use Modules\TitanZero\Http\Controllers\User\StandardsAssistController;

Route::group([
    'prefix' => 'titan-zero',
    'as' => 'titanzero.',
    'middleware' => ['web','auth']
], function () {
    Route::post('/standards/search', [StandardsAssistController::class, 'search'])->name('standards.search');
});


// Titan Zero standards-grounded assist (Pass 7)
use Modules\TitanZero\Http\Controllers\User\StandardsGroundedController;

Route::group([
    'prefix' => 'titan-zero',
    'as' => 'titanzero.',
    'middleware' => ['web','auth']
], function () {
    Route::post('/assist/standards', [StandardsGroundedController::class, 'assist'])->name('assist.standards');
});
