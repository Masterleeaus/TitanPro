<?php

// Titan Zero Standards Library (Pass 4)
use Modules\TitanZero\Http\Controllers\Admin\DocumentLibraryController;

Route::group([
    'prefix' => 'dashboard/admin/settings/titan-zero/library',
    'as' => 'dashboard.admin.titanzero.library.',
    'middleware' => ['web','auth','admin']
], function () {
    Route::get('/', [DocumentLibraryController::class, 'index'])->name('index');
    Route::get('/upload', [DocumentLibraryController::class, 'upload'])->name('upload');
    Route::post('/upload', [DocumentLibraryController::class, 'store'])->name('store');
    Route::get('/documents/{id}', [DocumentLibraryController::class, 'show'])->name('show');
    Route::get('/imports', [DocumentLibraryController::class, 'imports'])->name('imports');
});

