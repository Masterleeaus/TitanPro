<?php

return [
    'generators' => [
        ['name' => 'Quote Follow-up', 'desc' => 'Generate a polite follow-up message for an outstanding quote.'],
        ['name' => 'Job Summary', 'desc' => 'Turn notes into a customer-ready update.'],
        ['name' => 'Scope Gap Check', 'desc' => 'Check scope/exclusions/access/compliance risks.'],
    ],

    'templates' => [
        ['name' => 'Site Visit Notes', 'desc' => 'A structured site visit note template.'],
        ['name' => 'Variation Notice', 'desc' => 'Draft a variation summary for approval.'],
        ['name' => 'Payment Reminder', 'desc' => 'Friendly payment reminder message.'],
    ],


    'name' => 'Titan Zero',

    // Default Titan Core model for Titan Zero.
    // Only Super Admin should change this (via config or Super Admin settings),
    // regular users and company admins cannot select models directly.
    'model' => 'gpt-5-nano',

    // Optional: list of allowed models that Super Admin can choose from.
    'available_models' => [
        'gpt-5-nano',
        'gpt-5-small',
    ],

    // Soft quota configuration for Titan Zero.
    'quota' => [
        'daily_requests_per_user' => 100,
        'daily_tokens_per_user'   => 50000,
    ],

    // Integration toggles so you can enable/disable downstream hooks.
    'integrations' => [
        'docs_enabled'  => true,
        'tasks_enabled' => true,
    ],

    // Global widget settings: include the Blade partial in your main layout to enable.
    'global_widget' => [
        'enabled' => true,
    ],
    'citations_required' => false,
];
