<?php

namespace Modules\TitanZero\System\Services\Retrieval;

use Modules\TitanZero\System\Models\TitanZeroDocumentChunk;

class RetrievalEngine
{
    /**
     * Simple deterministic keyword retrieval (Pass 6).
     * Returns top chunks that contain any query term.
     */
    public function search(string $query, int $limit = 5): array
    {
        $q = trim($query);
        if ($q === '') return [];

        $terms = preg_split('/\s+/', mb_strtolower($q));
        $terms = array_values(array_filter(array_unique($terms), fn($t) => mb_strlen($t) >= 3));
        if (!$terms) return [];

        $builder = TitanZeroDocumentChunk::query();

        // Build OR LIKE clauses
        $builder->where(function($w) use ($terms) {
            foreach ($terms as $t) {
                $w->orWhereRaw('LOWER(content) LIKE ?', ['%'.$t.'%']);
            }
        });

        $chunks = $builder->with('document')
            ->orderByDesc('id')
            ->limit($limit * 2)
            ->get();

        // Score by term hits
        $scored = [];
        foreach ($chunks as $c) {
            $text = mb_strtolower($c->content);
            $score = 0;
            foreach ($terms as $t) {
                $score += substr_count($text, $t) > 0 ? 1 : 0;
            }
            if ($score > 0) {
                $scored[] = [
                    'chunk' => $c,
                    'score' => $score,
                ];
            }
        }

        usort($scored, fn($a,$b) => $b['score'] <=> $a['score']);

        $out = [];
        foreach (array_slice($scored, 0, $limit) as $row) {
            $c = $row['chunk'];
            $out[] = [
                'document_id' => $c->document_id,
                'document_title' => $c->document?->title,
                'chunk_index' => $c->chunk_index,
                'content' => $c->content,
                'content_hash' => $c->content_hash,
                'score' => $row['score'],
            ];
        }
        return $out;
    }
}
