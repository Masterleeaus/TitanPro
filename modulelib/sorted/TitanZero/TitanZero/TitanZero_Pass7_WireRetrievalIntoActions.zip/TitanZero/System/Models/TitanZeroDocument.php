<?php

namespace Modules\TitanZero\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class TitanZeroDocument extends Model
{
    protected $table = 'titanzero_documents';

    protected $fillable = [
        'title','source','storage_path','sha256','meta',
    ];

    protected $casts = [
        'meta' => 'array',
    ];

    public function chunks(): HasMany
    {
        return $this->hasMany(TitanZeroDocumentChunk::class, 'document_id');
    }
}
