<?php

namespace Modules\TitanZero\Http\Controllers\User;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\TitanZero\System\Services\Assist\StandardsAnswerBuilder;

class StandardsGroundedController extends Controller
{
    public function assist(Request $request, StandardsAnswerBuilder $builder)
    {
        $question = (string) $request->input('question', '');
        $pageContext = (array) $request->input('page_context', []);

        return response()->json(
            $builder->build($question, $pageContext)
        );
    }
}
