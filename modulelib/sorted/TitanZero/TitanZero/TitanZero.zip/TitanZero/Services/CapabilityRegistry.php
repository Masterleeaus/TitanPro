<?php

namespace Modules\TitanZero\Services;

use Illuminate\Support\Facades\Log;

class CapabilityRegistry
{
    /**
     * Store capabilities in the container as an array under 'titanzero.capabilities'.
     */
    public static function registerModuleFromConfig(string $moduleName): void
    {
        try {
            if (!function_exists('module_path')) {
                return;
            }

            $path = module_path($moduleName, 'Config/titanzero.php');
            if (!is_string($path) || !file_exists($path)) {
                return;
            }

            $cfg = include $path;
            if (!is_array($cfg)) {
                return;
            }

            $caps = $cfg['capabilities'] ?? [];
            if (!is_array($caps)) {
                $caps = [];
            }

            $store = app()->bound('titanzero.capabilities')
                ? app('titanzero.capabilities')
                : [];

            if (!is_array($store)) {
                $store = [];
            }

            foreach ($caps as $cap) {
                if (!is_array($cap)) {
                    continue;
                }
                $key = $cap['key'] ?? null;
                if (!is_string($key) || $key === '') {
                    continue;
                }
                $store[$key] = $cap;
            }

            app()->instance('titanzero.capabilities', $store);
        } catch (\Throwable $e) {
            // Never break the app/sidebar path
            try {
                Log::debug('TitanZero CapabilityRegistry registerModuleFromConfig failed: ' . $e->getMessage(), [
                    'module' => $moduleName,
                ]);
            } catch (\Throwable $ignore) {}
        }
    }

    public static function all(): array
    {
        $store = app()->bound('titanzero.capabilities') ? app('titanzero.capabilities') : [];
        return is_array($store) ? $store : [];
    }
}
