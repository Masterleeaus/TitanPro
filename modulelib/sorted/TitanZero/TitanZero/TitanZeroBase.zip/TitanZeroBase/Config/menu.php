<?php
return [
    // Parent hub label for nesting (if your menu system supports parent nodes).
    'parent' => env('AIC_MENU_PARENT', 'AI & Automation'),
    'title'  => env('AIC_MENU_TITLE', 'AI Copilot'),
    'route'  => env('AIC_MENU_ROUTE', 'aicopilot.index'),
    'permission' => env('AIC_MENU_PERMISSION', 'aicopilot.use'),
    'icon' => env('AIC_MENU_ICON', 'ti ti-robot'),
    'position' => (int) env('AIC_MENU_POSITION', 80),
];
