<?php
return [
    // Slug used by your plan/feature system to represent this module.
    // Keep in sync with your PlanModuleCheck middleware, if used.
    'slug' => env('AIC_PLAN_SLUG', config('aicopilot.plan_slug', 'AICopilot')),

    // Optional: feature key name if your schema uses a string 'feature' column
    'feature_key' => env('AIC_PLAN_FEATURE', 'AICopilot'),
];
