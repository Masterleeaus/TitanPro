<?php

namespace Modules\AICopilot\Console;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;

class DoctorCommand extends Command
{
    protected $signature = 'aicopilot:doctor';
    protected $description = 'Diagnose AICopilot integration with Worksuite: routes, DB, plans, permissions, menu.';

    public function handle(): int
    {
        $ok = true;

        // 1) Routes
        $this->line('\n<info>Routes</info>');
        try {
            $hasIndex = collect(Route::getRoutes())->contains(function ($r) {
                return $r->getName() === 'aicopilot.index';
            });
            $this->line('  aicopilot.index: ' . ($hasIndex ? '<info>OK</info>' : '<error>MISSING</error>'));
            if (!$hasIndex) $ok = false;
        } catch (\Throwable $e) {
            $this->line('  route scan error: <error>'.$e->getMessage().'</error>');
            $ok = false;
        }

        // 2) Permissions
        $this->line('\n<info>Permissions</info>');
        try {
            if (Schema::hasTable('permissions')) {
                $names = DB::table('permissions')->pluck('name')->toArray();
                foreach (['aicopilot.use','view_aicopilot'] as $p) {
                    $this->line("  {$p}: " . (in_array($p, $names, true) ? '<info>OK</info>' : '<comment>not found</comment>'));
                }
            } else {
                $this->line('  table permissions: <comment>not present</comment>');
            }
        } catch (\Throwable $e) {
            $this->line('  permissions check error: <error>'.$e->getMessage().'</error>');
            $ok = false;
        }

        // 3) Module registration
        $this->line('\n<info>Module registry</info>');
        try {
            if (Schema::hasTable('modules') && Schema::hasColumn('modules','module_name')) {
                $exists = DB::table('modules')->where('module_name','AICopilot')->first();
                $this->line('  modules.module_name=AICopilot: ' . ($exists ? '<info>OK</info>' : '<comment>not found</comment>'));
            } else {
                $this->line('  modules table: <comment>not present</comment>');
            }
        } catch (\Throwable $e) {
            $this->line('  modules check error: <error>'.$e->getMessage().'</error>');
            $ok = false;
        }

        // 4) Plans/packages
        $this->line('\n<info>Plans & packages</info>');
        try {
            if (Schema::hasTable('packages')) {
                if (Schema::hasColumn('packages','module_in_package')) {
                    $count = DB::table('packages')->whereNotNull('module_in_package')->count();
                    $this->line('  packages.module_in_package: <info>present</info> (rows: '.$count.')');
                } elseif (Schema::hasColumn('packages','modules')) {
                    $count = DB::table('packages')->whereNotNull('modules')->count();
                    $this->line('  packages.modules: <info>present</info> (rows: '.$count.')');
                } else {
                    $this->line('  packages.*: <comment>no module JSON columns found</comment>');
                }
            } elseif (Schema::hasTable('plan_features')) {
                $this->line('  plan_features: <info>present</info>');
            } else {
                $this->line('  plans/packages tables: <comment>not present</comment>');
            }
        } catch (\Throwable $e) {
            $this->line('  plan check error: <error>'.$e->getMessage().'</error>');
            $ok = false;
        }

        // 5) Menu presence (best-effort)
        $this->line('\n<info>Menu</info>');
        try {
            $tables = ['menu_items','menus','navigation_menus'];
            $found = false;
            foreach ($tables as $t) {
                if (Schema::hasTable($t)) {
                    $found = true;
                    $count = DB::table($t)->count();
                    $this->line("  {$t}: <info>present</info> (rows: {$count})");
                }
            }
            if (!$found) $this->line('  none of known menu tables found (this is OK on some builds)');
        } catch (\Throwable $e) {
            $this->line('  menu check error: <error>'.$e->getMessage().'</error>');
        }

        $this->line('\n<info>Doctor verdict:</info> ' . ($ok ? '<info>Looks healthy</info>' : '<error>Issues detected</error>'));
        return $ok ? self::SUCCESS : self::FAILURE;
    }
}
