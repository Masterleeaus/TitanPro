<?php
namespace Modules\AICopilot\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PromptCategory extends Model
{
    protected $table = 'ai_prompt_categories';
    protected $fillable = ['name','slug','description','sort'];
    public function prompts(): HasMany { return $this->hasMany(Prompt::class, 'category_id'); }
}
