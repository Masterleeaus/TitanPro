<?php

// Titan Zero Standards Library (Pass 4)
use Modules\TitanZero\Http\Controllers\Admin\DocumentLibraryController;

Route::group([
    'prefix' => 'dashboard/admin/settings/titan-zero/library',
    'as' => 'dashboard.admin.titanzero.library.',
    'middleware' => ['web','auth','admin']
], function () {
    Route::get('/', [DocumentLibraryController::class, 'index'])->name('index');
    Route::get('/upload', [DocumentLibraryController::class, 'upload'])->name('upload');
    Route::post('/upload', [DocumentLibraryController::class, 'store'])->name('store');
    Route::get('/documents/{id}', [DocumentLibraryController::class, 'show'])->name('show');
    Route::get('/imports', [DocumentLibraryController::class, 'imports'])->name('imports');
});



// Titan Zero Doctor (Pass 8)
use Modules\TitanZero\Http\Controllers\Admin\DoctorController;

Route::group([
    'prefix' => 'dashboard/admin/settings/titan-zero',
    'as' => 'dashboard.admin.titanzero.',
    'middleware' => ['web','auth','admin']
], function () {
    Route::get('/doctor', [DoctorController::class, 'index'])->name('doctor');
});


// Titan Zero Audit Logs (Pass 8)
use Modules\TitanZero\Http\Controllers\Admin\AuditLogController;

Route::group([
    'prefix' => 'dashboard/admin/settings/titan-zero',
    'as' => 'dashboard.admin.titanzero.',
    'middleware' => ['web','auth','admin']
], function () {
    Route::get('/audit', [AuditLogController::class, 'index'])->name('audit');
});


use Modules\TitanZero\Http\Controllers\Admin\CoachAdminController;
use Modules\TitanZero\Http\Controllers\Admin\DocumentMetaController;
use Modules\TitanZero\Http\Controllers\Admin\DocumentBulkController;
use Modules\TitanZero\Http\Controllers\Admin\ReviewQueueController;

Route::group([
    'prefix' => 'dashboard/admin/settings/titan-zero',
    'as' => 'dashboard.admin.titanzero.',
    'middleware' => ['web','auth','admin']
], function () {
    Route::get('/coaches', [CoachAdminController::class, 'index'])->name('coaches.index');
    Route::get('/coaches/{id}/edit', [CoachAdminController::class, 'edit'])->name('coaches.edit');
    Route::post('/coaches/{id}', [CoachAdminController::class, 'update'])->name('coaches.update');

    Route::get('/library/documents/{id}/meta', [DocumentMetaController::class, 'edit'])->name('library.meta.edit');
    Route::post('/library/documents/{id}/meta', [DocumentMetaController::class, 'update'])->name('library.meta.update');

    // Bulk tagging
    Route::get('/library/bulk', [DocumentBulkController::class, 'index'])->name('library.bulk');
    Route::post('/library/bulk/apply', [DocumentBulkController::class, 'apply'])->name('library.bulk.apply');

    // Review queue
    Route::get('/library/review-queue', [ReviewQueueController::class, 'index'])->name('library.review');
    Route::post('/library/review-queue/{id}/approve', [ReviewQueueController::class, 'approve'])->name('review.approve');
    Route::post('/library/review-queue/{id}/needs-work', [ReviewQueueController::class, 'needsWork'])->name('review.needswork');
    Route::post('/library/review-queue/{id}/tags', [ReviewQueueController::class, 'applyTags'])->name('review.applyTags');
});
