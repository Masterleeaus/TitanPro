<?php

use Illuminate\Support\Facades\Route;
use Modules\TitanZero\Http\Controllers\TitanZeroController;
use Modules\TitanZero\Http\Controllers\TitanZeroActionController;
use Modules\TitanZero\Http\Controllers\User\StandardsAssistController;
use Modules\TitanZero\Http\Controllers\User\StandardsGroundedController;

/*
|--------------------------------------------------------------------------
| Titan Zero Web Routes (Worksuite tenant-safe)
|--------------------------------------------------------------------------
| IMPORTANT:
| Worksuite's sidebar + tenant context is established by the /account route
| group middleware stack (auth + multi-company-select + email_verified).
| If Titan Zero routes do not run under the same stack, Worksuite will render
| a reduced sidebar (most modules disappear).
|
| Therefore Titan Zero's UI routes MUST live under:
|   /account/titan/zero/*
| and MUST use the same middleware stack.
|
| Legacy /titan-zero/* routes are kept as redirects.
*/

// ----------------------------------------------------------------------
// Tenant UI (REAL app) — keeps full Worksuite sidebar intact
// ----------------------------------------------------------------------
Route::group([
    'middleware' => ['web', 'auth', 'multi-company-select', 'email_verified'],
    'prefix'     => 'account/titan/zero',
    'as'         => 'titan.zero.',
], function () {
    Route::get('/', [TitanZeroController::class, 'index'])->name('home');
    Route::get('/help', [TitanZeroController::class, 'help'])->name('help');
    Route::get('/chat', [TitanZeroController::class, 'chat'])->name('chat');
    Route::get('/generators', [TitanZeroController::class, 'generators'])->name('generators');
    Route::get('/templates', [TitanZeroController::class, 'templates'])->name('templates');
    Route::get('/ping', [TitanZeroController::class, 'ping'])->name('ping');

    Route::post('/action', [TitanZeroActionController::class, 'action'])->name('action');

    // Standards tools (AJAX)
    Route::post('/standards/search', [StandardsAssistController::class, 'search'])->name('standards.search');
    Route::post('/assist/standards', [StandardsGroundedController::class, 'assist'])->name('assist.standards');
});


// ----------------------------------------------------------------------
// Legacy aliases — redirect into /account so sidebar stays intact
// ----------------------------------------------------------------------
Route::group([
    'middleware' => ['web', 'auth'],
    'prefix'     => 'titan-zero',
    'as'         => 'titan-zero.',
], function () {
    Route::get('/', fn () => redirect()->route('titan.zero.home'))->name('index');
    Route::get('/help', fn () => redirect()->route('titan.zero.help'))->name('help');
    Route::get('/chat', fn () => redirect()->route('titan.zero.chat'))->name('chat');
    Route::get('/generators', fn () => redirect()->route('titan.zero.generators'))->name('generators');
    Route::get('/templates', fn () => redirect()->route('titan.zero.templates'))->name('templates');
    Route::get('/ping', [TitanZeroController::class, 'ping'])->name('ping');

    // Preserve action endpoint for old clients
    Route::post('/action', [TitanZeroActionController::class, 'action'])->name('action');

    // Standards tools (AJAX)
    Route::post('/standards/search', [StandardsAssistController::class, 'search'])->name('standards.search');
    Route::post('/assist/standards', [StandardsGroundedController::class, 'assist'])->name('assist.standards');
});



/*
|--------------------------------------------------------------------------
| Titan Zero Settings (Account)
|--------------------------------------------------------------------------
| Hard-coded settings routes requested by IO.
*/
use Modules\TitanZero\Http\Controllers\SuperAdmin\DashboardController as TitanZeroSettingsDashboardController;
use Modules\TitanZero\Http\Controllers\SuperAdmin\ChannelsController as TitanZeroSettingsChannelsController;
use Modules\TitanZero\Http\Controllers\SuperAdmin\WorkflowsController as TitanZeroSettingsWorkflowsController;
use Modules\TitanZero\Http\Controllers\SuperAdmin\ToolsController as TitanZeroSettingsToolsController;
use Modules\TitanZero\Http\Controllers\SuperAdmin\PersonasController as TitanZeroSettingsPersonasController;
use Modules\TitanZero\Http\Controllers\SuperAdmin\LogsController as TitanZeroSettingsLogsController;
use Modules\TitanZero\Http\Controllers\SuperAdmin\PolicyController as TitanZeroSettingsPolicyController;
use Modules\TitanZero\Http\Controllers\SuperAdmin\DiagnosticsController as TitanZeroSettingsDiagnosticsController;

Route::middleware(['web','auth'])->prefix('account/settings/titanzero')->group(function () {
    Route::get('/dashboard', [TitanZeroSettingsDashboardController::class, 'index'])->name('titanzero.settings.dashboard');
    Route::get('/channels', [TitanZeroSettingsChannelsController::class, 'index'])->name('titanzero.settings.channels');
    Route::post('/channels/save', [TitanZeroSettingsChannelsController::class, 'save'])->name('titanzero.settings.channels.save');
    Route::post('/channels/test/{key}', [TitanZeroSettingsChannelsController::class, 'test'])->name('titanzero.settings.channels.test');
    Route::get('/workflows', [TitanZeroSettingsWorkflowsController::class, 'index'])->name('titanzero.settings.workflows');
    Route::get('/tools', [TitanZeroSettingsToolsController::class, 'index'])->name('titanzero.settings.tools');
    Route::get('/personas', [TitanZeroSettingsPersonasController::class, 'index'])->name('titanzero.settings.personas');
    Route::get('/logs', [TitanZeroSettingsLogsController::class, 'index'])->name('titanzero.settings.logs');
    Route::get('/policy', [TitanZeroSettingsPolicyController::class, 'index'])->name('titanzero.settings.policy');
    Route::get('/diagnostics', [TitanZeroSettingsDiagnosticsController::class, 'index'])->name('titanzero.settings.diagnostics');
});

