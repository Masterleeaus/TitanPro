<?php

namespace Modules\TitanAssist\Listeners;

use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Modules\TitanAssist\Events\TitanAssistContentGenerated;
use Modules\AIDocument\Entities\AiPromptHistory;
use Modules\AIDocument\Entities\AiPromptResponse;

class SendTitanAssistContentToDocs
{
    public function handle(TitanAssistContentGenerated $event): void
    {
        if (! Config::get('aiassistant.integrations.docs_enabled', true)) {
            return;
        }

        $content = trim($event->content ?? '');
        if ($content === '') {
            return;
        }

        try {
            $model      = Config::get('aiassistant.model', 'gpt-5-nano');
            $templateId = $event->templateId;

            $history = AiPromptHistory::create([
                'template_id'   => $templateId,
                'doc_name'      => 'Titan Assist ' . now()->format('Y-m-d H:i'),
                'model'         => $model,
                'creativity'    => 0.5,
                'max_tokens'    => 0,
                'max_results'   => 1,
                'prompt'        => 'Generated via Titan Assist integration.',
                'language'      => 'en',
                'prompt_fields' => null,
                'workspace'     => 'default',
                'created_by'    => $event->userId,
            ]);

            AiPromptResponse::create([
                'template_id'       => $templateId,
                'history_prompt_id' => $history->id,
                'used_words'        => str_word_count($content),
                'content'           => $content,
                'created_by'        => $event->userId,
            ]);
        } catch (\Throwable $e) {
            // Log but do not break user flow.
            Log::warning('Titan Assist: failed to send content to Docs', [
                'error'   => $e->getMessage(),
                'user_id' => $event->userId,
            ]);
        }
    }
}
