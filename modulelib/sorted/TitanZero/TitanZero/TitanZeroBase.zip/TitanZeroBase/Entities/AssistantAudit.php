<?php

namespace Modules\AICopilot\Entities;

use Illuminate\Database\Eloquent\Model;

class AssistantAudit extends Model
{
    protected $table = 'assistant_audits';
    protected $guarded = [];
    protected $casts = ['context'=>'array'];
}
