<?php

namespace Modules\TitanZero\Entities;

use Illuminate\Database\Eloquent\Model;

class TitanZeroAuditLog extends Model
{
    protected $table = 'titanzero_audit_logs';

    protected $fillable = [
        'user_id','action','route','ip','meta'
    ];

    protected $casts = [
        'meta' => 'array',
    ];
}
