<?php

namespace Modules\TitanZero\Entities;

class TitanHero extends TitanZeroCoach
{
    // Alias model for branding: "Titan Heroes"
    protected $table = 'titanzero_coaches';
}
