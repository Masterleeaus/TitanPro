<?php
namespace Modules\AICopilot\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UsageController extends BaseController
{
    public function index()
    {
        if (!Schema::hasTable('ai_assistant_usage')) { return view('aicopilot::usage.index', ['rows'=>[]]); }
        $rows = DB::table('ai_assistant_usage')->orderByDesc('id')->limit(500)->get();
        return view('aicopilot::usage.index', compact('rows'));
    }

    public function exportCsv()
    {
        $response = new StreamedResponse(function(){
            $out = fopen('php://output','w');
            fputcsv(out: $out, fields: ['id','created_at','tenant_id','user_id','provider','model','tokens_prompt','tokens_completion','calls','cost_usd']);
            if (\Illuminate\Support\Facades\Schema::hasTable('ai_assistant_usage')) {
                $q = DB::table('ai_assistant_usage')->orderBy('id');
                $q->chunk(1000, function($chunk) use ($out){
                    foreach ($chunk as $r) {
                        fputcsv($out, [$r->id,$r->created_at,$r->tenant_id,$r->user_id,$r->provider,$r->model,$r->tokens_prompt,$r->tokens_completion,$r->calls,$r->cost_usd]);
                    }
                });
            }
            fclose($out);
        });
        $response->headers->set('Content-Type','text/csv');
        $response->headers->set('Content-Disposition','attachment; filename="aicopilot_usage.csv"');
        return $response;
    }
}
