<?php

namespace Modules\AICopilot\Http\Controllers;

use Illuminate\Routing\Controller;
use Illuminate\Http\Request;
use Modules\AICopilot\Entities\AssistantAudit;
use Illuminate\Support\Facades\Gate;

class AuditWebController extends Controller
{
    public function index(Request $r) {
        Gate::authorize('aicopilot.manage');
        $q = AssistantAudit::query()->orderByDesc('id');
        if ($r->filled('action')) $q->where('action','like','%'.$r->string('action').'%');
        $rows = $q->paginate(25)->withQueryString();
        return view('aicopilot::audit.index', compact('rows'));
    }
    public function show($id) {
        Gate::authorize('aicopilot.manage');
        $row = AssistantAudit::findOrFail($id);
        return view('aicopilot::audit.show', compact('row'));
    }
}
