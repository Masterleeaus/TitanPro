<?php
namespace Modules\AICopilot\Http\Controllers\Api;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;

class ImageApiController extends BaseController
{
    public function generate(Request $request)
    {
        $data = $request->validate(['prompt'=>'required|string|max:1000','size'=>'nullable|string']);
        $key = Config::get('aicopilot.providers.openai.api_key');
        if (!$key) return response()->json(['ok'=>false,'error'=>'OPENAI_API_KEY missing'], 422);
        $size = $data['size'] ?? '1024x1024';
        $resp = Http::withToken($key)->post('https://api.openai.com/v1/images/generations',[
            'prompt'=>$data['prompt'], 'n'=>1, 'size'=>$size
        ]);
        if (!$resp->ok()) return response()->json(['ok'=>false,'error'=>$resp->body()], $resp->status());
        return response()->json(['ok'=>true,'data'=>$resp->json()]);
    }
}
