<?php
namespace Modules\AICopilot\Http\Controllers;
use Illuminate\Routing\Controller;
class AICopilotController extends Controller {
  public function index(){ return view('aicopilot::index',['title'=>'AI Copilot']); }
  public function metrics(){
    abort_unless(auth()->check(), 403);
    return response("# TYPE aicopilot_requests_total counter\naicopilot_requests_total{endpoint=\"index\"} 1")->header('Content-Type','text/plain');
  }
}