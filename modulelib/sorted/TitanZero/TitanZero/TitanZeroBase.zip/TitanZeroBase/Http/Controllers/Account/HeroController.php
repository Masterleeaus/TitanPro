<?php

namespace Modules\TitanZero\Http\Controllers\Account;

use Illuminate\Http\Request;
use Modules\TitanZero\Services\Coach\CoachRegistry;
use Modules\TitanZero\Services\Assist\StandardsAnswerBuilder;

/**
 * Titan Heroes (branding alias for Coaches).
 * Uses the same registry + answer builder but renders hero-branded views.
 */
class HeroController extends CoachController
{
    public function index(CoachRegistry $registry)
    {
        $coaches = $registry->all(); // underlying storage
        return view('titanzero::account.hero.index', compact('coaches'));
    }

    public function show(string $coachKey, CoachRegistry $registry)
    {
        $coach = $registry->get($coachKey);
        abort_if(!$coach, 404);
        return view('titanzero::account.hero.show', compact('coach'));
    }

    // ask() inherited (same endpoint), route points to ask() in this class via inheritance.
}
