<?php

namespace Modules\TitanZero\Http\Controllers\Account;

use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Modules\TitanZero\Entities\TitanZeroIntentRun;
use Modules\TitanZero\Services\Actions\ActionRouter;
use Modules\TitanZero\Services\Context\TitanZeroContextBuilder;
use Modules\TitanZero\Services\Intent\IntentEngine;

class IntentRunController extends AccountBaseController
{
    public function run(Request $request, IntentEngine $engine, ActionRouter $router)
    {
        abort_unless(user()->can('titanzero.use') || in_array('admin', user_roles()), 403);

        $request->validate([
            'text' => 'nullable|string|max:2000',
            'return_url' => 'nullable|string|max:2000',
            'record_type' => 'nullable|string|max:120',
            'record_id' => 'nullable',
            'fields_json' => 'nullable|string',
            'result_mode' => 'nullable|in:ui,session',
        ]);

        $context = TitanZeroContextBuilder::fromRequest($request);

        // Resolve intent deterministically (no provider calls here)
        $intentObj = $engine->resolve($request, $context);

        // Route intent through handlers (creates TitanZeroIntentRun row)
        $result = $router->route($intentObj, $context);

        $runId = (int)($result['run_id'] ?? 0);
        $returnUrl = $context['return_url'] ?? url()->previous();

        // Option B: return to caller with session('titan_zero_result')
        if (($request->input('result_mode') === 'session') && $returnUrl) {
            $payload = [
                'title' => 'Titan Zero',
                'summary' => $result['summary'] ?? ('Intent: ' . ($result['intent']['intent'] ?? 'unknown')),
                'items' => $result['items'] ?? [],
                'citations' => $result['citations'] ?? [],
                'actions' => $result['actions'] ?? [],
                'run_id' => $runId,
                'intent' => $result['intent'] ?? null,
            ];

            return redirect()->to($returnUrl)
                ->with('titan_zero_result', $payload)
                ->with('titan_zero_run_id', $runId);
        }

        // Option A (default): Titan Zero handles result UI
        if ($runId > 0) {
            return redirect()->route('titan.zero.intent.show', ['runId' => $runId, 'return' => $returnUrl]);
        }

        // Fallback
        return redirect()->to($returnUrl ?: route('titan.zero.index'))
            ->with('titan_zero_result', ['title' => 'Titan Zero', 'summary' => 'No run created', 'items' => []]);
    }

    public function show(int $runId, Request $request)
    {
        abort_unless(user()->can('titanzero.use') || in_array('admin', user_roles()), 403);

        $run = TitanZeroIntentRun::query()->findOrFail($runId);
        $returnUrl = $request->query('return');

        $result = [];
        if ($run->result_json) {
            $decoded = json_decode($run->result_json, true);
            if (is_array($decoded)) $result = $decoded;
        }

        return view('titanzero::account.intent.result', compact('run', 'result', 'returnUrl'));
    }
}
