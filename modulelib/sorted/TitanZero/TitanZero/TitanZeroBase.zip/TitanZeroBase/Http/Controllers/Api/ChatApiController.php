<?php

namespace Modules\AICopilot\Http\Controllers\Api;

use Illuminate\Routing\Controller;
use Illuminate\Http\Request;

class ChatApiController extends Controller
{
    public function chat(Request $r)
    {
        $data = $r->validate([
            'message' => 'required|string',
            'context' => 'array'
        ]);
        // Stub response
        return response()->json(['reply' => 'AICopilot is online. Echo: '.$data['message']], 200);
    }
}
