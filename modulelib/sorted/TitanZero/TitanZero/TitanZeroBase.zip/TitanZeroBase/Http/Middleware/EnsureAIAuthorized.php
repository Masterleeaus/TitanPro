<?php
namespace Modules\AICopilot\Http\Middleware;
use Closure;
class EnsureAIAuthorized
{
    public function handle(Request $request, Closure $next, string $ability = 'aicopilot.view')
    {
        if (!$request->user() || !$request->user()->can($ability)) abort(403);
        return $next($request);
    }
}
