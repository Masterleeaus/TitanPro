<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (Schema::hasTable('modules') && Schema::hasColumn('modules','module_name')) {
            $exists = DB::table('modules')->where('module_name','AICopilot')->first();
            if (!$exists) {
                $data = ['module_name'=>'AICopilot'];
                foreach (['module_description','description'] as $c) if (Schema::hasColumn('modules',$c)) $data[$c] = 'AI Copilot module';
                foreach (['module_status','status','active'] as $c) if (Schema::hasColumn('modules',$c)) $data[$c] = 1;
                if (Schema::hasColumn('modules','created_at')) $data['created_at'] = now();
                if (Schema::hasColumn('modules','updated_at')) $data['updated_at'] = now();
                DB::table('modules')->insert($data);
            }
        }
    }
    public function down(): void {
        if (Schema::hasTable('modules') && Schema::hasColumn('modules','module_name')) {
            DB::table('modules')->where('module_name','AICopilot')->delete();
        }
    }
};
