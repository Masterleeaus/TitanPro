<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration{
  public function up(): void {
    Schema::create('assistant_audits', function(Blueprint $table){
      $table->id();
      $table->unsignedBigInteger('user_id')->nullable();
      $table->string('action');
      $table->string('provider')->nullable();
      $table->string('model')->nullable();
      $table->decimal('cost',10,4)->nullable();
      $table->json('meta')->nullable();
      $table->timestamps();
      $table->index(['user_id','action']);
    });
  }
  public function down(): void { Schema::dropIfExists('assistant_audits'); }
};