<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('ai_assistant_usage')) {
            Schema::create('ai_assistant_usage', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('user_id')->nullable();
                $table->string('tenant_id')->nullable();
                $table->string('provider')->default('openai');
                $table->string('model')->nullable();
                $table->unsignedInteger('tokens_prompt')->default(0);
                $table->unsignedInteger('tokens_completion')->default(0);
                $table->unsignedInteger('calls')->default(1);
                $table->decimal('cost_usd', 8, 4)->default(0);
                $table->timestamps();
                $table->index(['user_id','tenant_id','provider']);
            });
        }
    }
    public function down(): void
    {
        Schema::dropIfExists('ai_assistant_usage');
    }
};
