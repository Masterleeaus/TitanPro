<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ai_prompt_categories')) {
            Schema::create('ai_prompt_categories', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('name');
                $table->string('slug')->unique();
                $table->text('description')->nullable();
                $table->unsignedInteger('sort')->default(0);
                $table->timestamps();
            });
        }
        if (!Schema::hasTable('ai_prompts')) {
            Schema::create('ai_prompts', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('category_id')->nullable();
                $table->string('title');
                $table->string('slug')->unique();
                $table->longText('content');
                $table->json('meta')->nullable();
                $table->enum('visibility', ['private','team','public'])->default('private');
                $table->unsignedBigInteger('author_id')->nullable();
                $table->timestamps();
                $table->index(['category_id','visibility']);
            });
        }
    }
    public function down(): void {
        Schema::dropIfExists('ai_prompts');
        Schema::dropIfExists('ai_prompt_categories');
    }
};
