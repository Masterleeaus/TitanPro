<?php

namespace Modules\AICopilot\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class MenuSeeder extends Seeder
{
    public function run(): void
    {
        $cfg = config('aicopilot.menu');

        // Try common menu tables in Worksuite SaaS ecosystems or menu extensions
        $candidates = [
            // table => [columns]
            'menu_items' => ['title','route','permission','icon','position','parent_id','created_at','updated_at'],
            'menus' => ['title','route','permission','icon','order','parent_id','created_at','updated_at'],
            'navigation_menus' => ['label','route','permission','icon','sort','parent_id','created_at','updated_at'],
        ];

        foreach ($candidates as $table => $columns) {
            if (!Schema::hasTable($table)) {
                continue;
            }
            // Basic required pairs
            $title = $cfg['title'] ?? 'AI Copilot';
            $route = $cfg['route'] ?? 'aicopilot.index';
            $perm  = $cfg['permission'] ?? 'aicopilot.use';
            $icon  = $cfg['icon'] ?? 'ti ti-robot';

            // Already exists?
            try {
                $exists = DB::table($table)->where(function($q) use ($title, $route) {
                    $q->where('title', $title)->orWhere('label', $title)->orWhere('route', $route);
                })->first();
            } catch (\Throwable $e) {
                $exists = null;
            }
            if ($exists) {
                continue;
            }

            // Build row compatibly
            $row = [];
            $now = now();

            if (Schema::hasColumn($table, 'title')) $row['title'] = $title;
            if (Schema::hasColumn($table, 'label')) $row['label'] = $title;
            if (Schema::hasColumn($table, 'route')) $row['route'] = $route;
            if (Schema::hasColumn($table, 'permission')) $row['permission'] = $perm;
            if (Schema::hasColumn($table, 'icon')) $row['icon'] = $icon;
            if (Schema::hasColumn($table, 'position')) $row['position'] = (int) ($cfg['position'] ?? 80);
            if (Schema::hasColumn($table, 'order')) $row['order'] = (int) ($cfg['position'] ?? 80);
            if (Schema::hasColumn($table, 'sort')) $row['sort'] = (int) ($cfg['position'] ?? 80);
            if (Schema::hasColumn($table, 'parent_id')) $row['parent_id'] = null;
            if (Schema::hasColumn($table, 'created_at')) $row['created_at'] = $now;
            if (Schema::hasColumn($table, 'updated_at')) $row['updated_at'] = $now;

            try {
                DB::table($table)->insert($row);
                $this->command?->info("Inserted AI Copilot menu item into {$table}");
                return;
            } catch (\Throwable $e) {
                $this->command?->warn("Failed inserting into {$table}: ".$e->getMessage());
                continue;
            }
        }

        // If no compatible table found, emit a hint
        $this->command?->warn('No compatible menu table found. Use the published SQL stub to add the item manually.');
    }
}
