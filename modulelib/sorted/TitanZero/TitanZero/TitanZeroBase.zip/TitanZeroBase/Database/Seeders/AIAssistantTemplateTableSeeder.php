<?php

namespace Modules\TitanAssist\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Nwidart\Modules\Facades\Module;

class TitanAssistTemplateTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        $this_module = Module::find('TitanAssist');
        $this_module->enable();
        $modules = Module::all();
        if(module_is_active('TitanAssist'))
        {
            foreach ($modules as $key => $value) {
                $name = '\Modules\\'.$value->getName();
                $path =   $value->getPath();
                if(file_exists($path.'/Database/Seeders/TitanAssistTemplateListTableSeeder.php'))
                {
                    $this->call($name.'\Database\Seeders\TitanAssistTemplateListTableSeeder');
                }
            }
        }

        // $this->call("OthersTableSeeder");
    }
}
