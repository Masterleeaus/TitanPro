<?php

namespace Modules\AICopilot\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PermissionsSeeder extends Seeder
{
    public function run(): void
    {
        $hasGuard = false;
        try {
            $cols = DB::select('SHOW COLUMNS FROM permissions');
            foreach ($cols as $c) {
                $field = is_object($c) ? ($c->Field ?? $c->field ?? '') : '';
                if ($field == 'guard_name') { $hasGuard = true; break; }
            }
        } catch (\Throwable $e) {}

        foreach (['aicopilot.use','view_aicopilot'] as $perm) {
            $exists = DB::table('permissions')->where('name',$perm)->first();
            if (!$exists) {
                $row = ['name'=>$perm, 'created_at'=>now(), 'updated_at'=>now()];
                if ($hasGuard) $row['guard_name'] = 'web';
                DB::table('permissions')->insert($row);
            }
        }
    }
}
