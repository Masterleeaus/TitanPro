<?php

namespace Modules\AICopilot\Database\Seeders;

use Illuminate\Database\Seeder;

class AICopilotPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        if (!class_exists(\Spatie\Permission\Models\Permission::class)) return;
        $Permission = \Spatie\Permission\Models\Permission::class;
        $Role = \Spatie\Permission\Models\Role::class;
        $guard = config('auth.defaults.guard','web');

        foreach (['aicopilot.view','aicopilot.manage'] as $p) {
            if (!$Permission::where('name',$p)->exists()) {
                $Permission::create(['name'=>$p,'guard_name'=>$guard]);
            }
        }
        if ($Role::where('name','admin')->exists()) {
            $Role::where('name','admin')->first()->givePermissionTo(['aicopilot.view','aicopilot.manage']);
        }
    }
}
