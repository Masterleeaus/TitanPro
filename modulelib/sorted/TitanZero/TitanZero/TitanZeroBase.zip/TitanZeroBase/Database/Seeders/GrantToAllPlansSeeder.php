<?php

namespace Modules\AICopilot\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class GrantToAllPlansSeeder extends Seeder
{
    public function run(): void
    {
        $slug = config('aicopilot.plan.slug', config('aicopilot.plan_slug', 'AICopilot'));
        $alias = 'aicopilot';
        $featureKey = config('aicopilot.plan.feature_key', 'AICopilot');

        if (Schema::hasTable('packages') && Schema::hasColumn('packages','module_in_package')) {
            $pkgs = DB::table('packages')->get();
            foreach ($pkgs as $p) {
                $mods = [];
                try { $mods = json_decode($p->module_in_package ?? '[]', true) ?: []; } catch (\Throwable $e) {}
                $changed = false;
                foreach ([$alias, $slug] as $token) {
                    if (!in_array($token, $mods, true)) { $mods[] = $token; $changed = true; }
                }
                if ($changed) {
                    DB::table('packages')->where('id',$p->id)->update(['module_in_package'=>json_encode(array_values(array_unique($mods)))]);
                }
            }
        }

        if (Schema::hasTable('packages') && Schema::hasColumn('packages','modules')) {
            $pkgs = DB::table('packages')->get();
            foreach ($pkgs as $p) {
                $mods = [];
                try { $mods = json_decode($p->modules ?? '[]', true) ?: []; } catch (\Throwable $e) {}
                $changed = false;
                foreach ([$alias, $slug] as $token) {
                    if (!in_array($token, $mods, true)) { $mods[] = $token; $changed = true; }
                }
                if ($changed) {
                    DB::table('packages')->where('id',$p->id)->update(['modules'=>json_encode(array_values(array_unique($mods)))]);
                }
            }
        }

        if (Schema::hasTable('plan_features')) {
            $featureCol = null;
            foreach (['feature','key','slug','name'] as $c) { if (Schema::hasColumn('plan_features',$c)) { $featureCol = $c; break; } }
            if ($featureCol) {
                $plansTable = Schema::hasTable('subscription_plans') ? 'subscription_plans' : (Schema::hasTable('plans') ? 'plans' : null);
                if ($plansTable) {
                    $plans = DB::table($plansTable)->select('id')->get();
                    foreach ($plans as $pl) {
                        $exists = DB::table('plan_features')->where('plan_id',$pl->id)->where($featureCol,$featureKey)->first();
                        if (!$exists) {
                            $row = ['plan_id'=>$pl->id, $featureCol=>$featureKey];
                            if (Schema::hasColumn('plan_features','value')) $row['value'] = 1;
                            if (Schema::hasColumn('plan_features','created_at')) $row['created_at'] = now();
                            if (Schema::hasColumn('plan_features','updated_at')) $row['updated_at'] = now();
                            DB::table('plan_features')->insert($row);
                        }
                    }
                }
            }
        }

        if (Schema::hasTable('module_settings') && Schema::hasColumn('module_settings','module_name')) {
            $exists = DB::table('module_settings')->where('module_name',$slug)->first();
            if (!$exists) {
                DB::table('module_settings')->insert(['module_name'=>$slug,'status'=>'active','type'=>'admin','created_at'=>now(),'updated_at'=>now()]);
            } else {
                DB::table('module_settings')->where('module_name',$slug)->update(['status'=>'active','updated_at'=>now()]);
            }
        }
    }
}
