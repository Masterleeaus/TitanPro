<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Modules\AICopilot\Http\Controllers\AICopilotController;
Route::group(['middleware' => 'PlanModuleCheck:AICopilot'], function ()
{
    Route::prefix('aicopilot')->group(function() {
		
		Route::get('/generate/{template_module}/{module}', [AICopilotController::class, 'create'])->name('aicopilot.generate')->middleware(['auth']);
		Route::post('/generate/keywords/{id}', [AICopilotController::class, 'GetKeywords'])->name('aicopilot.generate.keywords')->middleware(['auth']);
		Route::any('/generate/response', [AICopilotController::class, 'AiGenerate'])->name('aicopilot.generate.response')->middleware(['auth']);
		Route::any('/generate/{template_module}/{module}/{id}', [AICopilotController::class, 'vcard_create_business'])->name('aicopilot.generate_business')->middleware(['auth']);
		Route::any('/generate_service/{template_module}/{module}/{id}', [AICopilotController::class, 'vcard_create_service'])->name('aicopilot.generate_vcard_service')->middleware(['auth']);
		Route::any('/generate_testimonial/{template_module}/{module}/{id}', [AICopilotController::class, 'vcard_create_testimonial'])->name('aicopilot.generate_vcard_testimonial')->middleware(['auth']);
		Route::any('/cmms-generate/{template_module}/{module}', [AICopilotController::class, 'cmms_create'])->name('cmms_aicopilot.generate')->middleware(['auth']);
	


    });
});
