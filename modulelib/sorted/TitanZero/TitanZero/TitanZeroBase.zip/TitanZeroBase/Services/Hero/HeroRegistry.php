<?php

namespace Modules\TitanZero\Services\Hero;

use Modules\TitanZero\Services\Coach\CoachRegistry;

/**
 * Titan Heroes registry (branding alias).
 * Internally uses the same persistence as coaches.
 */
class HeroRegistry extends CoachRegistry
{
    // Intentionally empty: inherits all() and get()
}
