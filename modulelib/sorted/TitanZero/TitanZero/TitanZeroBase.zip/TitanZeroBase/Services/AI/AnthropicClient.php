<?php
namespace Modules\AICopilot\Services\AI;
class AnthropicClient implements ClientInterface
{
    public function chat(string $prompt): string
    {
        return '[Claude stub] ' . substr($prompt,0,120);
    }
}
