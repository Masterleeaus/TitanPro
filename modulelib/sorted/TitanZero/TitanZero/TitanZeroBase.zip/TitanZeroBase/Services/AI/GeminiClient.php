<?php
namespace Modules\AICopilot\Services\AI;
class GeminiClient implements ClientInterface
{
    public function chat(string $prompt): string
    {
        return '[gemini stub] ' . substr($prompt,0,120);
    }
}
