<?php

namespace Modules\TitanZero\Services\Context;

use Illuminate\Http\Request;

class TitanZeroContextBuilder
{
    public static function fromRequest(Request $request, array $overrides = []): array
    {
        $page = [
            'route_name' => $request->route()?->getName(),
            'url' => url()->current(),
            'method' => $request->method(),
        ];

        $record = [
            'record_type' => $request->input('record_type'),
            'record_id' => $request->input('record_id'),
        ];

        // Optional: pass curated fields as JSON string to avoid huge payloads
        $fieldsJson = $request->input('fields_json');
        $fields = [];
        if (is_string($fieldsJson) && $fieldsJson !== '') {
            $decoded = json_decode($fieldsJson, true);
            if (is_array($decoded)) $fields = $decoded;
        }

        $context = [
            'page' => $page,
            'record' => $record,
            'fields' => $fields,
            'return_url' => $request->input('return_url', url()->previous()),
        ];

        return array_replace_recursive($context, $overrides);
    }
}
