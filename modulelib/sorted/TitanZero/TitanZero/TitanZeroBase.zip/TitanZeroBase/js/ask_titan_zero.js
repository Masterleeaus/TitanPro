(function(){
  function serializeForm(form){
    var obj = {};
    new FormData(form).forEach(function(v,k){
      if(obj[k] !== undefined){
        if(!Array.isArray(obj[k])) obj[k] = [obj[k]];
        obj[k].push(v);
      } else {
        obj[k] = v;
      }
    });
    return obj;
  }

  document.addEventListener('click', function(e){
    var btn = e.target.closest('[data-tz-capture-form]');
    if(!btn) return;
    var sel = btn.getAttribute('data-tz-capture-form');
    var form = document.querySelector(sel);
    if(!form) return;
    var fields = serializeForm(form);
    var input = btn.closest('form')?.querySelector('input[name="fields_json"]');
    if(input) input.value = JSON.stringify(fields);
  });
})();
