<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'These credentials do not match our records.',
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',

    'titan_assist' => 'Titan Assist', // Titan Assist key

    'jobsite_daily_report' => 'Jobsite daily report', // Titan Assist template
    'swms_draft' => 'SWMS / method statement draft', // Titan Assist template
    'quote_scope_works' => 'Quote & scope of works', // Titan Assist template

    'titan_assist_limit_requests' => 'You have reached your daily Titan Assist request limit.', // Titan Assist
    'titan_assist_limit_tokens' => 'You have reached your daily Titan Assist token limit.', // Titan Assist

    'titan_assist_help_title' => 'Titan Assist help & examples', // Titan Assist
    'titan_assist_help_intro' => 'Use these examples to get the best results from Titan Assist for construction and trade workflows.', // Titan Assist

    'titan_assist_send_docs' => 'Send to Docs', // Titan Assist
    'titan_assist_send_tasks' => 'Send to Tasks', // Titan Assist
    'titan_assist_sent_docs' => 'Content sent to Docs.', // Titan Assist
    'titan_assist_sent_tasks' => 'Content sent to Tasks.', // Titan Assist
    'titan_assist_no_content' => 'No content provided.', // Titan Assist

    'titan_assist_widget_title' => 'Titan Assist', // Titan Assist
    'titan_assist_widget_subtitle' => 'Ask anything about this page.', // Titan Assist
    'titan_assist_widget_hint' => 'Titan Assist uses the current page title and URL as context. For best results, mention what you are working on.', // Titan Assist
    'titan_assist_widget_placeholder' => 'How can Titan Assist help on this page?', // Titan Assist
    'titan_assist_widget_button' => 'Ask Titan Assist', // Titan Assist
    'titan_assist_widget_asking' => 'Asking Titan Assist...', // Titan Assist
    'titan_assist_widget_error' => 'Something went wrong. Please try again.', // Titan Assist
    'titan_assist_widget_enter_question' => 'Please enter a question for Titan Assist.', // Titan Assist
    'titan_assist_widget_failed' => 'Titan Assist could not generate a response.', // Titan Assist

];
