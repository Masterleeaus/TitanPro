<?php
return ['title'=>'AI Copilot'];