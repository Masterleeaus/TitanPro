{{-- Titan Assist Pass 2: Template header & layout --}}
@include('titanassist::ai.partials.header')

{{-- Titan Assist Pass 1: architecture & UX baseline --}}
<a  class="btn btn-primary text-white btn-sm" data-size="lg" data-ajax-popup-over="true" data-url="{{ route('titan-assist.generate',[$template_module,$module]) }}" data-bs-toggle="tooltip" data-bs-placement="top" title="{{ __('Generate') }}" data-title="{{ __('Generate Content With AI') }}">
    <i class="fas fa-robot"></i> {{ __('Generate with AI') }}
</a>


{{-- Titan Assist Pass 2: Standard options + result layout --}}
@include('titanassist::ai.partials.options')
@include('titanassist::ai.partials.result_panel')
