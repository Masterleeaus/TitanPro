@php
    $pageTitle = $pageTitle ?? __('Titan Hero');
    $pageIcon  = $pageIcon  ?? 'ti ti-shield-bolt';
@endphp

@include('titanzero::account.coach.show')
