{{-- Titan Assist Pass 2: Result panel --}}
<div class="card mt-3 titan-assist-result">
    <div class="card-header d-flex justify-content-between align-items-center">
        <strong>{{ __('Generated result') }}</strong>
        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="if(window.TitanAssist && TitanAssist.copy){TitanAssist.copy()}">
            {{ __('Copy to clipboard') }}
        </button>
    </div>
    <div class="card-body">
        {{-- Existing textarea / result output will still be used; this wrapper just standardises the layout. --}}

        <div class="mt-3 d-flex flex-wrap gap-2">
            @if(config('aiassistant.integrations.docs_enabled'))
                <button type="button"
                        class="btn btn-sm btn-outline-primary"
                        onclick="window.TitanAssist && TitanAssist.sendTo('docs')">
                    {{ __('Send to Docs') }}
                </button>
            @endif

            @if(config('aiassistant.integrations.tasks_enabled'))
                <button type="button"
                        class="btn btn-sm btn-outline-primary"
                        onclick="window.TitanAssist && TitanAssist.sendTo('tasks')">
                    {{ __('Send to Tasks') }}
                </button>
            @endif
        </div>
    </div>
</div>

@push('scripts')
<script>
    window.TitanAssist = window.TitanAssist || {};
    window.TitanAssist.copy = function () {
        var el = document.querySelector('.titan-assist-result textarea, .titan-assist-result [data-result-text]');
        if (!el) return;
        var text = el.value || el.innerText || '';
        if (!text) return;
        navigator.clipboard && navigator.clipboard.writeText(text).catch(function(){});
    };

    window.TitanAssist.sendTo = function (target) {
        var el = document.querySelector('.titan-assist-result textarea, .titan-assist-result [data-result-text]');
        if (!el) return;
        var text = el.value || el.innerText || '';
        if (!text) return;

        var urlDocs  = '{{ route('titan-assist.send-docs') }}';
        var urlTasks = '{{ route('titan-assist.send-tasks') }}';
        var url      = target === 'docs' ? urlDocs : urlTasks;

        fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ content: text })
        }).then(function (response) {
            return response.json().catch(function () { return {}; });
        }).then(function (json) {
            // You can enhance this with toast notifications later.
        }).catch(function () {});
    };
</script>
@endpush
