{{-- Titan Zero sidebar entries for Worksuite "Custom Modules" include --}}
{{-- NOTE: In core menu.blade.php, custom module sidebars are included INSIDE an existing <x-menu-item> accordion.
     Therefore this partial must output ONLY <x-sub-menu-item> rows (not another <x-menu-item>), otherwise spacing breaks. --}}

<x-sub-menu-item :link="url('account/titan/zero')" :text="'Titan Zero'" />
<x-sub-menu-item :link="url('account/titan/zero/coaches')" :text="'— Coaches'" />
<x-sub-menu-item :link="url('account/titan/zero/coaches/business')" :text="'— Business Coach'" />
<x-sub-menu-item :link="url('account/titan/zero/coaches/foreman')" :text="'— Foreman Coach'" />
<x-sub-menu-item :link="url('account/titan/zero/coaches/compliance')" :text="'— Standards & Compliance'" />
