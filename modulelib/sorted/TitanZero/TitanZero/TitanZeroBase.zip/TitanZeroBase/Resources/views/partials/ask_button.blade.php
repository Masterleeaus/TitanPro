@php
  $tzIntent = $tzIntent ?? 'explain_page';
  $tzRecordType = $tzRecordType ?? null;
  $tzRecordId = $tzRecordId ?? null;
  $tzReturnUrl = $tzReturnUrl ?? url()->current();
  $tzResultMode = $tzResultMode ?? 'ui'; // 'ui' (Option A) or 'session' (Option B)
  $tzFields = $tzFields ?? [];
@endphp

<form method="POST" action="{{ route('titan.zero.intent.run') }}" class="d-inline">
  @csrf
  <input type="hidden" name="intent" value="{{ $tzIntent }}">
  <input type="hidden" name="record_type" value="{{ $tzRecordType }}">
  <input type="hidden" name="record_id" value="{{ $tzRecordId }}">
  <input type="hidden" name="return_url" value="{{ $tzReturnUrl }}">
  <input type="hidden" name="result_mode" value="{{ $tzResultMode }}">
  <input type="hidden" name="fields_json" value='@json($tzFields)'>
  <button type="submit" class="btn btn-sm btn-primary">
    Ask Titan Zero
  </button>
</form>
