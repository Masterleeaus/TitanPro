@php
    $pageTitle = $pageTitle ?? __('Titan Heroes');
    $pageIcon  = $pageIcon  ?? 'ti ti-shield-bolt';
@endphp

@include('titanzero::account.coach.index')
