@php
  $pageTitle = $pageTitle ?? 'Titan Zero • Result';
  $pageIcon  = $pageIcon  ?? 'ti ti-sparkles';
@endphp

@extends('layouts.app')

@section('content')
<div class="container py-3">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <div>
      <h4 class="mb-1">Titan Zero Result</h4>
      <div class="text-muted small">Run #{{ $run->id }} • Intent: {{ $run->intent }}</div>
    </div>
    <div class="d-flex gap-2">
      @if(!empty($returnUrl))
        <a href="{{ $returnUrl }}" class="btn btn-outline-secondary">Return</a>
      @endif
      <a href="{{ route('titan.zero.index') }}" class="btn btn-outline-primary">Titan Zero</a>
    </div>
  </div>

  <div class="card mb-3">
    <div class="card-body">
      <h5 class="mb-2">{{ data_get($result, 'title', 'Result') }}</h5>
      <p class="text-muted mb-0">{{ data_get($result, 'summary', 'Done.') }}</p>
    </div>
  </div>

  @php($items = data_get($result, 'items', []))
  @if(is_array($items) && count($items))
    <div class="card mb-3">
      <div class="card-body">
        <h6 class="mb-2">Details</h6>
        <ul class="mb-0">
          @foreach($items as $item)
            <li><strong>{{ ucfirst($item['type'] ?? 'info') }}:</strong> {{ $item['text'] ?? '' }}</li>
          @endforeach
        </ul>
      </div>
    </div>
  @endif

  @php($citations = data_get($result, 'citations', []))
  @if(is_array($citations) && count($citations))
    <div class="card mb-3">
      <div class="card-body">
        <h6 class="mb-2">Citations</h6>
        <div class="small text-muted">
          @foreach($citations as $c)
            <div>• {{ $c['doc'] ?? 'Document' }} — {{ $c['ref'] ?? '' }}</div>
          @endforeach
        </div>
      </div>
    </div>
  @endif

  <div class="card">
    <div class="card-body">
      <h6 class="mb-2">Raw</h6>
      <pre class="mb-0" style="white-space: pre-wrap;">{{ json_encode($result, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre>
    </div>
  </div>
</div>
@endsection
