-- Example SQL for adding a left-nav menu item. Adjust table/columns to match your install.
-- CREATE TABLE `menu_items` (`id` int unsigned AUTO_INCREMENT PRIMARY KEY, `title` varchar(120), `route` varchar(160), `permission` varchar(120), `icon` varchar(80), `position` int, `parent_id` int null, `created_at` timestamp null, `updated_at` timestamp null);

-- INSERT INTO `menu_items` (`title`,`route`,`permission`,`icon`,`position`,`parent_id`,`created_at`,`updated_at`)
-- VALUES ('AI Copilot','aicopilot.index','aicopilot.use','ti ti-robot',80,NULL,NOW(),NOW());
