@extends('titancommand::jobs.layouts.app')

@section('content')
<div class="card">
  <div class="muted">Worker assistant</div>
  <h2 style="margin:4px 0 12px">{{ $job ? ($job->title ?? ('Job #'.$job->id)) : 'General job guidance' }}</h2>
  @if($job)
    <div class="pill">Status: {{ $job->status ?? 'draft' }}</div>
    <div style="margin-top:10px" class="muted">Use this panel to guide proof capture, checklist completion, and site execution.</div>
  @endif
</div>

<div class="card">
  <h3 style="margin-top:0">Recommended next actions</h3>
  <ul>
    @foreach($suggestions as $suggestion)
      <li style="margin-bottom:8px">{{ $suggestion }}</li>
    @endforeach
  </ul>
</div>

<div class="card">
  <h3 style="margin-top:0">Quick links</h3>
  <div class="row">
    <a class="btn" href="{{ url('/dashboard/user/titango/today') }}">Today</a>
    <a class="btn" href="{{ url('/dashboard/user/titango/run-sheet') }}">Run Sheet</a>
    <a class="btn" href="{{ $job ? url('/dashboard/user/command/jobs/'.$job->id.'/checklists?html=1') : url('/dashboard/user/command/jobs?html=1') }}">Checklist</a>
    <a class="btn" href="{{ $job ? url('/dashboard/user/command/jobs/'.$job->id.'/evidence?html=1') : url('/dashboard/user/command/jobs?html=1') }}">Evidence</a>
  </div>
</div>
@endsection
