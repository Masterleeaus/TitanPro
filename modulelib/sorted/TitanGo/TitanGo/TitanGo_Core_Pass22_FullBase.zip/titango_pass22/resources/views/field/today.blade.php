@extends('titancommand::jobs.layouts.app')

@section('content')
<div class="row">
  <div class="card" style="flex:1;min-width:220px">
    <div class="muted">Completed Today</div>
    <div style="font-size:28px;font-weight:700">{{ $summary['completed_today'] ?? 0 }}</div>
  </div>
  <div class="card" style="flex:1;min-width:220px">
    <div class="muted">Active Jobs</div>
    <div style="font-size:28px;font-weight:700">{{ $summary['active_jobs'] ?? 0 }}</div>
  </div>
  <div class="card" style="flex:1;min-width:220px">
    <div class="muted">Proof Score</div>
    <div style="font-size:28px;font-weight:700">{{ $summary['proof_score'] ?? 0 }}%</div>
  </div>
</div>

<div class="card">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
    <div>
      <div class="muted">Run Sheet</div>
      <h2 style="margin:4px 0 0">Today's Jobs</h2>
    </div>
    <a class="btn primary" href="{{ url('/dashboard/user/command/jobs/create?html=1') }}">Create Job</a>
  </div>

  <table>
    <thead>
      <tr>
        <th>Job</th>
        <th>Type</th>
        <th>Status</th>
        <th>Window</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
    @forelse($jobs as $job)
      <tr>
        <td>
          <strong>{{ $job->title ?? ('Job #'.$job->id) }}</strong><br>
          <span class="muted">{{ $job->site_name ?? $job->location ?? 'Site pending' }}</span>
        </td>
        <td>{{ $job->job_type ?? 'general' }}</td>
        <td><span class="pill">{{ $job->status ?? 'draft' }}</span></td>
        <td>{{ $job->scheduled_start_at ?? '—' }}</td>
        <td><a class="btn" href="{{ url('/dashboard/user/command/jobs/'.$job->id.'?html=1') }}">Open</a></td>
      </tr>
    @empty
      <tr><td colspan="5" class="muted">No jobs scheduled yet.</td></tr>
    @endforelse
    </tbody>
  </table>
</div>
@endsection
