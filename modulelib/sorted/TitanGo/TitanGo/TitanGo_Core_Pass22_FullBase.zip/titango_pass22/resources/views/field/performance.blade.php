@extends('titancommand::jobs.layouts.app')

@section('content')
<div class="row">
  <div class="card" style="flex:1;min-width:220px">
    <div class="muted">Checklist Completion</div>
    <div style="font-size:28px;font-weight:700">{{ $summary['checklist_completion_rate'] ?? 0 }}%</div>
    <div class="muted">{{ $summary['completed_items'] ?? 0 }} / {{ $summary['total_items'] ?? 0 }} items complete</div>
  </div>
  <div class="card" style="flex:1;min-width:220px">
    <div class="muted">Evidence Captured</div>
    <div style="font-size:28px;font-weight:700">{{ $summary['evidence_count'] ?? 0 }}</div>
  </div>
  <div class="card" style="flex:1;min-width:220px">
    <div class="muted">Overdue Jobs</div>
    <div style="font-size:28px;font-weight:700">{{ $summary['overdue_jobs'] ?? 0 }}</div>
  </div>
</div>

<div class="card">
  <div class="muted">Worker efficiency</div>
  <h2 style="margin:4px 0 12px">Status Breakdown</h2>
  <table>
    <thead>
      <tr><th>Status</th><th>Total</th></tr>
    </thead>
    <tbody>
    @forelse(($summary['status_breakdown'] ?? []) as $status => $total)
      <tr><td>{{ $status }}</td><td>{{ $total }}</td></tr>
    @empty
      <tr><td colspan="2" class="muted">No job activity yet.</td></tr>
    @endforelse
    </tbody>
  </table>
</div>
@endsection
