<nav class="nav">
  @php
    $path = request()->path();
    $isPath = fn($value) => $path === $value || str_starts_with($path, $value.'/');
  @endphp
  <a href="{{ url('/dashboard/user/titango/today') }}" class="{{ $isPath('dashboard/user/titango/today') || $isPath('dashboard/user/titango') ? 'active' : '' }}">Today</a>
  <a href="{{ url('/dashboard/user/titango/run-sheet') }}" class="{{ $isPath('dashboard/user/titango/run-sheet') ? 'active' : '' }}">Run Sheet</a>
  <a href="{{ url('/dashboard/user/command/jobs?html=1') }}" class="{{ $isPath('dashboard/user/command/jobs') ? 'active' : '' }}">All Jobs</a>
  <a href="{{ url('/dashboard/user/command/jobs/dispatch?html=1') }}" class="{{ $isPath('dashboard/user/command/jobs/dispatch') ? 'active' : '' }}">Dispatch</a>
  <a href="{{ url('/dashboard/user/titango/performance') }}" class="{{ $isPath('dashboard/user/titango/performance') ? 'active' : '' }}">Performance</a>
  <a href="{{ url('/dashboard/user/titango/assistant') }}" class="{{ $isPath('dashboard/user/titango/assistant') ? 'active' : '' }}">Assistant</a>
  <a href="{{ url('/dashboard/user/command/jobs/reports?html=1') }}" class="{{ $isPath('dashboard/user/command/jobs/reports') ? 'active' : '' }}">Reports</a>
  <a href="{{ url('/dashboard/user/command/jobs/settings?html=1') }}" class="{{ $isPath('dashboard/user/command/jobs/settings') ? 'active' : '' }}">Settings</a>
</nav>
