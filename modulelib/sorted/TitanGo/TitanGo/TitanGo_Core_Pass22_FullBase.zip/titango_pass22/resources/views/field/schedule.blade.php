@extends('titancommand::jobs.layouts.app')

@section('content')
<div class="card">
  <div class="muted">Route + schedule</div>
  <h2 style="margin:4px 0 12px">Run Sheet</h2>
  <table>
    <thead>
      <tr>
        <th>Start</th>
        <th>Job</th>
        <th>Status</th>
        <th>Site</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      @forelse($jobs as $job)
        <tr>
          <td>{{ $job->scheduled_start_at ?? '—' }}</td>
          <td>{{ $job->title ?? ('Job #'.$job->id) }}</td>
          <td><span class="pill">{{ $job->status ?? 'draft' }}</span></td>
          <td>{{ $job->site_name ?? $job->location ?? '—' }}</td>
          <td><a class="btn" href="{{ url('/dashboard/user/command/jobs/'.$job->id.'/timeline?html=1') }}">Timeline</a></td>
        </tr>
      @empty
        <tr><td colspan="5" class="muted">No scheduled jobs available.</td></tr>
      @endforelse
    </tbody>
  </table>
</div>
@endsection
