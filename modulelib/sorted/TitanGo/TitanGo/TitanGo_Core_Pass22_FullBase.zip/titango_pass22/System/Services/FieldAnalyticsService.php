<?php

namespace App\Extensions\TitanCommand\System\Services;

use App\Extensions\TitanCommand\System\Models\Work\WorkJob;
use App\Extensions\TitanCommand\System\Models\Work\WorkJobChecklistItem;
use App\Extensions\TitanCommand\System\Models\Work\WorkJobEvidence;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class FieldAnalyticsService
{
    public function summary(int $companyId, int $userId): array
    {
        $today = Carbon::now()->startOfDay();
        $jobs = WorkJob::query()
            ->where('company_id', $companyId)
            ->where('user_id', $userId);

        $completedToday = (clone $jobs)
            ->whereDate('updated_at', '>=', $today->toDateString())
            ->whereIn('status', ['completed', 'closed'])
            ->count();

        $active = (clone $jobs)
            ->whereIn('status', ['assigned', 'scheduled', 'in_progress'])
            ->count();

        $overdue = (clone $jobs)
            ->whereDate('scheduled_end_at', '<', Carbon::now()->toDateString())
            ->whereNotIn('status', ['completed', 'closed', 'cancelled'])
            ->count();

        $evidenceCount = WorkJobEvidence::query()
            ->where('company_id', $companyId)
            ->where('user_id', $userId)
            ->count();

        $checklistProgress = WorkJobChecklistItem::query()
            ->where('company_id', $companyId)
            ->where('user_id', $userId)
            ->selectRaw('SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) as completed_items, COUNT(*) as total_items', ['done'])
            ->first();

        $completedItems = (int) ($checklistProgress->completed_items ?? 0);
        $totalItems = (int) ($checklistProgress->total_items ?? 0);

        $proofScore = 0;
        if ($active + $completedToday > 0) {
            $proofScore = (int) round(($evidenceCount / max(1, $active + $completedToday)) * 20);
        }
        $proofScore = max(0, min(100, $proofScore));

        return [
            'completed_today' => $completedToday,
            'active_jobs' => $active,
            'overdue_jobs' => $overdue,
            'evidence_count' => $evidenceCount,
            'completed_items' => $completedItems,
            'total_items' => $totalItems,
            'checklist_completion_rate' => $totalItems > 0 ? round(($completedItems / $totalItems) * 100, 1) : 0.0,
            'proof_score' => $proofScore,
            'status_breakdown' => (clone $jobs)
                ->select('status', DB::raw('COUNT(*) as total'))
                ->groupBy('status')
                ->pluck('total', 'status')
                ->toArray(),
        ];
    }
}
