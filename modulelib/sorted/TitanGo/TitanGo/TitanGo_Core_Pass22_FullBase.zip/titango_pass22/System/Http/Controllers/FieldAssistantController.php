<?php

namespace App\Extensions\TitanCommand\System\Http\Controllers;

use App\Extensions\TitanCommand\System\Models\Work\WorkJob;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class FieldAssistantController
{
    private function tenantIds(): array
    {
        $userId = (int) (auth()->id() ?? 0);
        return [$userId, $userId];
    }

    public function index(Request $request, ?int $job = null): View
    {
        [$companyId, $userId] = $this->tenantIds();

        $jobModel = null;
        if ($job) {
            $jobModel = WorkJob::query()
                ->where('company_id', $companyId)
                ->where('user_id', $userId)
                ->findOrFail($job);
        }

        $suggestions = [
            'Check access instructions before arrival.',
            'Capture before photos before touching the site.',
            'Complete checklist items in execution order.',
            'Record any hazards or client notes immediately.',
            'Capture after photos before signoff.',
        ];

        if ($jobModel && in_array($jobModel->job_type, ['cleaner', 'cleaning'], true)) {
            $suggestions = [
                'Start with access and alarm notes.',
                'Capture before photos for kitchens, bathrooms, and high-risk areas.',
                'Follow room checklist top to bottom to avoid misses.',
                'Log chemical use or consumables where needed.',
                'Capture after photos and request client signoff.',
            ];
        }

        return view('titancommand::field.assistant', [
            'heading' => 'Job Assistant',
            'title' => 'Titan Go — Job Assistant',
            'job' => $jobModel,
            'suggestions' => $suggestions,
        ]);
    }
}
