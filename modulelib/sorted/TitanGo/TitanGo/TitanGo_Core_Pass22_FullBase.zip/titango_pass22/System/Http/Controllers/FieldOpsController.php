<?php

namespace App\Extensions\TitanCommand\System\Http\Controllers;

use App\Extensions\TitanCommand\System\Models\Work\WorkJob;
use App\Extensions\TitanCommand\System\Services\FieldAnalyticsService;
use Carbon\Carbon;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class FieldOpsController
{
    public function __construct(private readonly FieldAnalyticsService $analytics)
    {
    }

    private function tenantIds(): array
    {
        $userId = (int) (auth()->id() ?? 0);
        return [$userId, $userId];
    }

    public function today(Request $request): View
    {
        [$companyId, $userId] = $this->tenantIds();
        $today = Carbon::now()->toDateString();

        $jobs = WorkJob::query()
            ->where('company_id', $companyId)
            ->where('user_id', $userId)
            ->where(function ($query) use ($today) {
                $query->whereDate('scheduled_start_at', $today)
                    ->orWhereDate('scheduled_end_at', $today)
                    ->orWhereIn('status', ['assigned', 'in_progress']);
            })
            ->orderByRaw('COALESCE(scheduled_start_at, created_at) asc')
            ->limit(50)
            ->get();

        return view('titancommand::field.today', [
            'heading' => 'Today',
            'title' => 'Titan Go — Today',
            'jobs' => $jobs,
            'summary' => $this->analytics->summary($companyId, $userId),
        ]);
    }

    public function schedule(Request $request): View
    {
        [$companyId, $userId] = $this->tenantIds();

        $jobs = WorkJob::query()
            ->where('company_id', $companyId)
            ->where('user_id', $userId)
            ->orderByRaw('COALESCE(scheduled_start_at, created_at) asc')
            ->limit(100)
            ->get();

        return view('titancommand::field.schedule', [
            'heading' => 'Run Sheet',
            'title' => 'Titan Go — Run Sheet',
            'jobs' => $jobs,
        ]);
    }

    public function performance(Request $request): View
    {
        [$companyId, $userId] = $this->tenantIds();

        return view('titancommand::field.performance', [
            'heading' => 'Performance',
            'title' => 'Titan Go — Performance',
            'summary' => $this->analytics->summary($companyId, $userId),
        ]);
    }
}
