<?php

use App\Extensions\TitanCommand\System\Http\Controllers\FieldAssistantController;
use App\Extensions\TitanCommand\System\Http\Controllers\FieldOpsController;
use Illuminate\Support\Facades\Route;

Route::get('/', [FieldOpsController::class, 'today'])->name('index');
Route::get('/today', [FieldOpsController::class, 'today'])->name('today');
Route::get('/run-sheet', [FieldOpsController::class, 'schedule'])->name('run-sheet');
Route::get('/performance', [FieldOpsController::class, 'performance'])->name('performance');
Route::get('/assistant/{job?}', [FieldAssistantController::class, 'index'])->name('assistant');
