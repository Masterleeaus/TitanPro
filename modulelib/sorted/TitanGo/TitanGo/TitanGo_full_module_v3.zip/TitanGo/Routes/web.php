<?php

use Illuminate\Support\Facades\Route;

Route::group([
    'middleware' => ['web', 'auth'],
    'prefix' => 'dashboard/user/titango',
    'as' => 'dashboard.user.titango.',
    'namespace' => 'Modules\\TitanGo\\Http\\Controllers',
], function () {
    Route::get('/upgrade', 'UpgradeController@index')->name('upgrade');

    Route::group(['middleware' => ['titango.entitled']], function () {
        Route::get('/voice', 'VoiceController@index')->name('voice');

        // Optional server STT (uploads audio)
        Route::post('/voice/upload-audio', 'VoiceController@uploadAudio')->name('voice.upload_audio');

        // Optional server TTS (returns audio URL or stream)
        Route::post('/voice/tts', 'VoiceController@tts')->name('voice.tts');

        // Preview/confirm flow + Titan Zero dispatch
        Route::post('/voice/execute', 'VoiceController@execute')->name('voice.execute');
    });
});

Route::group([
    'middleware' => ['web', 'auth', 'admin'],
    'prefix' => 'dashboard/admin/settings/titango',
    'as' => 'dashboard.admin.titango.',
    'namespace' => 'Modules\\TitanGo\\Http\\Controllers\\Admin',
], function () {
    Route::get('/', 'SettingsController@index')->name('settings');
    Route::post('/', 'SettingsController@update')->name('settings.update');
});
