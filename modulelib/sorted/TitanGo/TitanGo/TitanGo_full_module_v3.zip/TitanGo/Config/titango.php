<?php

return [
    // Allow enabling Titan Go during dev/testing without billing wiring.
    'force_enabled' => env('TITANGO_FORCE_ENABLED', false),

    // Titan Zero action dispatch endpoint (same app). Example:
    // https://ops.tradiesm.art/dashboard/user/titanzero/actions/dispatch
    'titanzero_action_url' => env('TITANGO_TITANZERO_ACTION_URL', null),

    // Default locale for browser speech recognition
    'speech_lang' => env('TITANGO_SPEECH_LANG', 'en-AU'),

    // Speech-to-text mode:
    // - 'browser' uses Web Speech API in the client (default, zero cost)
    // - 'server' uploads audio to /voice/upload-audio and expects Titan Zero to transcribe
    'stt_mode' => env('TITANGO_STT_MODE', 'browser'),

    // If using server STT, this is the Titan Zero action key expected to perform transcription.
    'stt_action' => env('TITANGO_STT_ACTION', 'voice.transcribe'),

    // Max audio upload size in KB (server STT mode)
    'max_audio_kb' => (int) env('TITANGO_MAX_AUDIO_KB', 10240),

    // Text-to-speech mode:
    // - 'browser' uses speechSynthesis (default)
    // - 'server' calls /voice/tts (optional)
    'tts_mode' => env('TITANGO_TTS_MODE', 'browser'),

];
