<?php

namespace App\Services;

use App\Models\Business;
use App\Models\Conversation;
use App\Models\Order;
use App\Models\Appointment;

class VoiceAssistantService
{
    protected $openAIService;
    protected $twilioService;

    public function __construct(OpenAIService $openAIService, TwilioService $twilioService)
    {
        $this->openAIService = $openAIService;
        $this->twilioService = $twilioService;
    }

    public function processIncomingCall($from, $recordingUrl, $business)
    {
        $audioPath = $this->downloadRecording($recordingUrl);
        
        if (!$audioPath || !file_exists($audioPath) || filesize($audioPath) === 0) {
            throw new \Exception('Failed to download or invalid recording file');
        }

        $transcription = $this->openAIService->transcribeAudioWithLanguageDetection($audioPath);
        $text = $transcription['text'] ?? '';
        $language = $transcription['language'] ?? 'en';

        if (empty($text)) {
            throw new \Exception('Transcription failed or empty');
        }

        $conversation = Conversation::create([
            'business_id' => $business->id,
            'customer_phone' => $from,
            'channel' => 'voice',
            'transcript' => $text,
            'language' => $language,
            'status' => 'active',
        ]);

        $intent = $this->openAIService->extractIntent($text, $business->type);
        $conversation->update(['intent' => $intent]);

        $response = $this->handleIntent($intent, $text, $business, $conversation);

        return [
            'response' => $response,
            'language' => $language,
            'conversation' => $conversation,
        ];
    }

    public function processIncomingSms($from, $body, $business)
    {
        $conversation = Conversation::create([
            'business_id' => $business->id,
            'customer_phone' => $from,
            'channel' => 'sms',
            'transcript' => $body,
            'status' => 'active',
        ]);

        $intent = $this->openAIService->extractIntent($body, $business->type);
        $conversation->update(['intent' => $intent]);

        $response = $this->handleIntent($intent, $body, $business, $conversation);

        return $response;
    }

    protected function handleIntent($intent, $text, $business, $conversation)
    {
        switch ($intent) {
            case 'order':
                return $this->handleOrderIntent($text, $business, $conversation);
            case 'appointment':
                return $this->handleAppointmentIntent($text, $business, $conversation);
            case 'inquiry':
                return $this->handleInquiryIntent($text, $business);
            default:
                return $this->handleGeneralIntent($text, $business);
        }
    }

    protected function handleOrderIntent($text, $business, $conversation)
    {
        $menuItems = $business->menus()->where('available', true)->get()->toArray();

        if (empty($menuItems)) {
            return "I'm sorry, our menu is currently unavailable. Please try again later.";
        }

        $orderDetails = $this->openAIService->extractOrderDetails($text, $menuItems);

        if (empty($orderDetails) || !is_array($orderDetails)) {
            $menuList = collect($menuItems)->map(function ($item) {
                return "{$item['item_name']} - \${$item['price']}";
            })->join(", ");
            
            return "I'd be happy to help you place an order! Here's our menu: {$menuList}. What would you like to order?";
        }

        $totalAmount = 0;
        $validItems = [];
        $menuLookup = collect($menuItems)->keyBy('item_name');

        foreach ($orderDetails as $item) {
            if (!isset($item['item_name'], $item['quantity'], $item['price']) || 
                !is_numeric($item['quantity']) || !is_numeric($item['price'])) {
                continue;
            }

            $menuItem = $menuLookup->get($item['item_name']);
            if (!$menuItem) {
                continue;
            }

            $actualPrice = floatval($menuItem['price']);
            $quantity = max(1, intval($item['quantity']));

            $validItems[] = [
                'item_name' => $menuItem['item_name'],
                'quantity' => $quantity,
                'price' => $actualPrice,
            ];
            
            $totalAmount += $actualPrice * $quantity;
        }

        if (empty($validItems)) {
            return "I'm sorry, I couldn't understand your order. Could you please specify what you'd like to order?";
        }

        $order = Order::create([
            'business_id' => $business->id,
            'customer_phone' => $conversation->customer_phone,
            'items' => $validItems,
            'total_amount' => $totalAmount,
            'status' => 'pending',
        ]);

        $orderSummary = collect($validItems)->map(function ($item) {
            return "{$item['quantity']}x {$item['item_name']}";
        })->join(", ");

        return "Great! I've placed your order for {$orderSummary}. Your total is \${$totalAmount}. We'll have it ready soon!";
    }

    protected function handleAppointmentIntent($text, $business, $conversation)
    {
        $systemPrompt = "Extract appointment details from the text. Return ONLY valid JSON with: {\"service_type\": \"...\", \"preferred_date\": \"YYYY-MM-DD\", \"preferred_time\": \"HH:MM\"}";

        $messages = [
            ['role' => 'user', 'content' => $text]
        ];

        $response = $this->openAIService->chat($messages, $systemPrompt);
        $appointmentData = json_decode($response, true);

        if (!is_array($appointmentData) || !isset($appointmentData['service_type'], $appointmentData['preferred_date'], $appointmentData['preferred_time'])) {
            return "I'd be happy to help you book an appointment! What service are you interested in, and when would you prefer?";
        }

        try {
            $scheduledAt = $appointmentData['preferred_date'] . ' ' . $appointmentData['preferred_time'];

            Appointment::create([
                'business_id' => $business->id,
                'customer_phone' => $conversation->customer_phone,
                'service_type' => $appointmentData['service_type'],
                'scheduled_at' => $scheduledAt,
                'status' => 'pending',
            ]);

            return "Perfect! I've scheduled your {$appointmentData['service_type']} appointment for {$scheduledAt}. We'll send you a confirmation shortly!";
        } catch (\Exception $e) {
            return "I'm sorry, there was an issue scheduling your appointment. Could you please provide the service type and preferred date and time again?";
        }
    }

    protected function handleInquiryIntent($text, $business)
    {
        $systemPrompt = "You are a helpful assistant for {$business->name}, a {$business->type} business. "
            . "Answer customer questions professionally and helpfully. "
            . ($business->description ? "Business description: {$business->description}" : "");

        $messages = [
            ['role' => 'user', 'content' => $text]
        ];

        return $this->openAIService->chat($messages, $systemPrompt);
    }

    protected function handleGeneralIntent($text, $business)
    {
        $systemPrompt = "You are a friendly assistant for {$business->name}. "
            . "Help the customer and guide them to place orders or book appointments if relevant.";

        $messages = [
            ['role' => 'user', 'content' => $text]
        ];

        return $this->openAIService->chat($messages, $systemPrompt);
    }

    protected function downloadRecording($url)
    {
        $tempPath = storage_path('app/temp_recordings');
        if (!file_exists($tempPath)) {
            mkdir($tempPath, 0755, true);
        }

        $filename = $tempPath . '/' . uniqid() . '.mp3';
        $recordingData = $this->twilioService->fetchRecording($url);
        file_put_contents($filename, $recordingData);

        return $filename;
    }
}
