# Complete Multi-Tenant SaaS Implementation Guide

## What's Been Setup ✅

### Database Structure (Migrations Completed)
1. **tenants** table
   - company_name, domain, subdomain
   - is_active, trial_ends_at, plan
   
2. **tenant_settings** table  
   - twilio_account_sid, twilio_auth_token, twilio_phone_number
   - openai_api_key
   - Per-tenant API key storage
   
3. **users** table (updated)
   - tenant_id (foreign key)
   - role (super_admin, tenant_admin, tenant_user)
   
4. **businesses** table (updated)
   - tenant_id (foreign key)
   - Complete tenant isolation

5. **Laravel Breeze** - Authentication scaffolding installed

### Controllers Created
- `Admin/DashboardController` - Super admin panel
- `Tenant/DashboardController` - Tenant dashboard
- `Tenant/SettingsController` - Tenant API key configuration
- `Auth/TenantRegistrationController` - Customer signup

## Implementation Steps

### Step 1: Update Models

**app/Models/User.php**
```php
protected $fillable = ['name', 'email', 'password', 'tenant_id', 'role'];

public function tenant() {
    return $this->belongsTo(Tenant::class);
}

public function isSuperAdmin() {
    return $this->role === 'super_admin';
}

public function isTenantAdmin() {
    return $this->role === 'tenant_admin';
}
```

**app/Models/Tenant.php**
```php
protected $fillable = [
    'company_name', 'domain', 'subdomain', 
    'is_active', 'trial_ends_at', 'plan'
];

public function users() {
    return $this->hasMany(User::class);
}

public function settings() {
    return $this->hasOne(TenantSetting::class);
}

public function businesses() {
    return $this->hasMany(Business::class);
}
```

**app/Models/TenantSetting.php**
```php
protected $fillable = [
    'tenant_id', 'twilio_account_sid', 'twilio_auth_token',
    'twilio_phone_number', 'openai_api_key', 'additional_settings'
];

protected $casts = [
    'additional_settings' => 'array',
];

protected $hidden = [
    'twilio_auth_token', 'openai_api_key'
];

public function tenant() {
    return $this->belongsTo(Tenant::class);
}
```

### Step 2: Tenant Registration Flow

**Route:** `POST /register/tenant`

**Controller Logic:**
```php
// app/Http/Controllers/Auth/TenantRegistrationController.php

public function store(Request $request) {
    $validated = $request->validate([
        'company_name' => 'required|string|max:255',
        'name' => 'required|string|max:255',
        'email' => 'required|email|unique:users',
        'password' => 'required|min:8|confirmed',
    ]);

    DB::transaction(function () use ($validated) {
        // Create tenant
        $tenant = Tenant::create([
            'company_name' => $validated['company_name'],
            'subdomain' => Str::slug($validated['company_name']),
            'plan' => 'free',
            'trial_ends_at' => now()->addDays(14),
        ]);

        // Create tenant admin user
        $user = User::create([
            'tenant_id' => $tenant->id,
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'role' => 'tenant_admin',
        ]);

        // Create empty tenant settings
        TenantSetting::create([
            'tenant_id' => $tenant->id,
        ]);

        Auth::login($user);
    });

    return redirect()->route('tenant.dashboard');
}
```

### Step 3: Tenant Isolation Middleware

**app/Http/Middleware/EnsureTenantScope.php**
```php
public function handle($request, Closure $next) {
    if (!auth()->user()) {
        return redirect('/login');
    }

    if (auth()->user()->isSuperAdmin()) {
        return $next($request);
    }

    // Scope all queries to current tenant
    Business::addGlobalScope('tenant', function ($query) {
        $query->where('tenant_id', auth()->user()->tenant_id);
    });

    Order::addGlobalScope('tenant', function ($query) {
        $query->whereHas('business', function ($q) {
            $q->where('tenant_id', auth()->user()->tenant_id);
        });
    });

    // Repeat for all tenant-scoped models

    return $next($request);
}
```

### Step 4: Update Services to Use Per-Tenant API Keys

**app/Services/TwilioService.php**
```php
protected function getCredentials() {
    $user = auth()->user();
    
    if (!$user || !$user->tenant_id) {
        return null;
    }

    $settings = TenantSetting::where('tenant_id', $user->tenant_id)->first();
    
    if (!$settings) {
        return null;
    }

    return [
        'accountSid' => $settings->twilio_account_sid,
        'authToken' => $settings->twilio_auth_token,
        'phoneNumber' => $settings->twilio_phone_number,
    ];
}
```

**app/Services/OpenAIService.php**
```php
protected function getApiKey() {
    $user = auth()->user();
    
    if (!$user || !$user->tenant_id) {
        return env('OPENAI_API_KEY'); // Fallback
    }

    $settings = TenantSetting::where('tenant_id', $user->tenant_id)->first();
    
    return $settings->openai_api_key ?? env('OPENAI_API_KEY');
}
```

### Step 5: Dashboards

**Super Admin Dashboard** (`/admin/dashboard`)
- View all tenants
- Manage tenant status (activate/deactivate)
- View system-wide statistics
- Manage plans and pricing

**Tenant Dashboard** (`/dashboard`)
- View own businesses
- Manage orders and appointments
- Configure API keys in settings
- View usage statistics

### Step 6: Routes Setup

**routes/web.php**
```php
// Public routes
Route::get('/register/tenant', [TenantRegistrationController::class, 'create']);
Route::post('/register/tenant', [TenantRegistrationController::class, 'store']);

// Super Admin routes
Route::middleware(['auth', 'role:super_admin'])->prefix('admin')->group(function () {
    Route::get('/dashboard', [Admin\DashboardController::class, 'index']);
    Route::get('/tenants', [Admin\TenantsController::class, 'index']);
    Route::post('/tenants/{id}/toggle-status', [Admin\TenantsController::class, 'toggleStatus']);
});

// Tenant routes
Route::middleware(['auth', 'tenant.scope'])->group(function () {
    Route::get('/dashboard', [Tenant\DashboardController::class, 'index']);
    Route::get('/settings', [Tenant\SettingsController::class, 'index']);
    Route::post('/settings', [Tenant\SettingsController::class, 'update']);
    Route::resource('/businesses', Tenant\BusinessController::class);
});
```

## Key Features

### 1. Complete Tenant Isolation
- Each tenant can only see their own data
- API keys are per-tenant
- Businesses, orders, appointments are scoped to tenant

### 2. Role-Based Access Control
- **super_admin**: Full system access, manage all tenants
- **tenant_admin**: Manage own tenant, configure settings
- **tenant_user**: Access tenant resources, no settings access

### 3. Per-Tenant API Configuration
- Each tenant configures their own:
  - Twilio credentials
  - OpenAI API key
  - Custom settings

### 4. Subscription Plans
- Free trial (14 days)
- Plan-based access (free, basic, pro, enterprise)
- Trial expiration handling

## Next Development Steps

1. **Create Registration View**
   - `resources/views/auth/register-tenant.blade.php`
   - Company name, admin details, email verification

2. **Create Dashboards**
   - Admin dashboard with tenant list
   - Tenant dashboard with business management
   - Settings page for API key configuration

3. **Implement Tenant Scoping**
   - Add middleware to all tenant routes
   - Add global scopes to models

4. **Add Subscription Logic**
   - Plan limits (number of businesses, API calls)
   - Payment integration (Stripe)
   - Trial expiration handling

5. **Build Admin Panel**
   - Tenant management (CRUD)
   - System statistics
   - Plan management

## Security Considerations

- Encrypt API keys in database
- Add rate limiting per tenant
- Implement audit logs
- Add 2FA for admin accounts
- Regular security audits

## Testing

Create test tenants:
```bash
php artisan tinker

$tenant = Tenant::create([
    'company_name' => 'Test Restaurant',
    'subdomain' => 'test-restaurant',
    'plan' => 'pro',
]);

$user = User::create([
    'tenant_id' => $tenant->id,
    'name' => 'John Doe',
    'email' => 'john@test.com',
    'password' => Hash::make('password'),
    'role' => 'tenant_admin',
]);
```

## Current Status

✅ Database structure complete
✅ Multi-tenant foundation ready
✅ Authentication installed
✅ Controllers created
⏳ Views need to be created
⏳ Models need relationship updates
⏳ Services need per-tenant API key updates
⏳ Routes need to be configured

This foundation provides everything needed to build a complete multi-tenant SaaS platform!
