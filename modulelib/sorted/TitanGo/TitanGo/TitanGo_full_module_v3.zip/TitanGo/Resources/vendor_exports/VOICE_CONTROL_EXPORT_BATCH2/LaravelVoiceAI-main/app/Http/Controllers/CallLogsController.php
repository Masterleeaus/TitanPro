<?php

namespace App\Http\Controllers;

use App\Models\CallSession;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CallLogsController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();
        $tenantId = $user->tenant_id;

        // Get filter parameters
        $sourceFilter = $request->input('source', 'all');
        $statusFilter = $request->input('status', 'all');
        $dateFrom = $request->input('date_from');
        $dateTo = $request->input('date_to');

        // Build query - wrap in try-catch for PostgreSQL connection issues
        try {
            $query = CallSession::where('tenant_id', $tenantId)
                ->with(['costEvents', 'turns']);

            // Apply filters
            if ($sourceFilter !== 'all') {
                $query->where('source_channel', $sourceFilter);
            }

            if ($statusFilter !== 'all') {
                $query->where('status', $statusFilter);
            }

            if ($dateFrom) {
                $query->whereDate('started_at', '>=', $dateFrom);
            }

            if ($dateTo) {
                $query->whereDate('started_at', '<=', $dateTo);
            }

            // Get paginated results
            $callSessions = $query->orderBy('started_at', 'desc')->paginate(20);

            // Calculate summary stats
            $stats = [
                'total_calls' => CallSession::where('tenant_id', $tenantId)->count(),
                'web_calls' => CallSession::where('tenant_id', $tenantId)->where('source_channel', 'web')->count(),
                'mobile_calls' => CallSession::where('tenant_id', $tenantId)->where('source_channel', 'mobile')->count(),
                'twilio_calls' => CallSession::where('tenant_id', $tenantId)->where('source_channel', 'twilio')->count(),
                'total_cost' => CallSession::where('tenant_id', $tenantId)->sum('total_cost'),
                'total_duration' => CallSession::where('tenant_id', $tenantId)->sum('duration_seconds'),
            ];
        } catch (\Exception $e) {
            \Log::warning('Could not fetch call logs from PostgreSQL: ' . $e->getMessage());
            $callSessions = new \Illuminate\Pagination\LengthAwarePaginator([], 0, 20);
            $stats = [
                'total_calls' => 0,
                'web_calls' => 0,
                'mobile_calls' => 0,
                'twilio_calls' => 0,
                'total_cost' => 0,
                'total_duration' => 0,
            ];
        }

        return view('call-logs.index', compact('callSessions', 'stats', 'sourceFilter', 'statusFilter', 'dateFrom', 'dateTo'));
    }

    public function show($id)
    {
        $user = Auth::user();
        
        try {
            $callSession = CallSession::with(['costEvents', 'turns'])
                ->where('tenant_id', $user->tenant_id)
                ->findOrFail($id);

            return view('call-logs.show', compact('callSession'));
        } catch (\Exception $e) {
            \Log::warning('Could not fetch call log details from PostgreSQL: ' . $e->getMessage());
            return redirect()->route('call-logs.index')
                ->with('error', 'Call log tracking is currently unavailable. Please configure PostgreSQL database.');
        }
    }
}
