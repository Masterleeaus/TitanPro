<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Chat</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-white antialiased">
    
    <div class="min-h-screen flex flex-col">
        
        <!-- Top Navigation -->
        <nav class="border-b border-gray-200 bg-white sticky top-0 z-10">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center h-16">
                    <div class="flex items-center gap-8">
                        <a href="{{ route('dashboard') }}" class="text-gray-700 hover:text-gray-900 font-medium">Dashboard</a>
                        <a href="{{ route('call-logs.index') }}" class="text-gray-700 hover:text-gray-900 font-medium">Call Logs</a>
                        <a href="{{ route('settings.index') }}" class="text-gray-700 hover:text-gray-900 font-medium">Settings</a>
                    </div>
                    <div class="text-sm text-gray-600">{{ $tenant->company_name }}</div>
                </div>
            </div>
        </nav>

        <!-- Chat Container -->
        <div id="chatContainer" class="flex-1 flex flex-col">
            
            <!-- Welcome Screen -->
            <div id="welcomeScreen" class="flex-1 flex flex-col items-center justify-center px-6">
                <div class="w-full max-w-3xl mx-auto text-center">
                    
                    <h1 class="text-5xl font-light text-gray-900 mb-12">
                        What can I help with?
                    </h1>
                    
                    <div class="mb-10">
                        <div class="relative flex items-center bg-white rounded-full shadow-md border border-gray-200 hover:shadow-lg transition-shadow px-2">
                            <input 
                                type="text" 
                                id="messageInput" 
                                placeholder="Ask anything"
                                class="flex-1 py-5 px-6 bg-transparent border-0 focus:outline-none text-lg text-gray-900 placeholder-gray-400"
                                onkeypress="if(event.key === 'Enter') sendMessage()"
                            >
                            <button 
                                id="voiceBtn"
                                onclick="toggleVoiceRecording()"
                                class="p-3 text-gray-500 hover:text-gray-700 hover:bg-gray-50 rounded-full transition">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path>
                                </svg>
                            </button>
                            <button 
                                onclick="sendMessage()"
                                class="p-3 text-gray-400 hover:text-gray-700 hover:bg-gray-50 rounded-full transition">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                                </svg>
                            </button>
                        </div>

                        <div id="recordingIndicator" class="hidden mt-4">
                            <div class="flex items-center justify-center gap-2 text-red-500 mb-3">
                                <div class="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                                <span class="text-sm font-medium">Recording <span id="recordingTimer">0:00</span></span>
                            </div>
                            <div id="liveTranscription" class="bg-gray-50 rounded-xl px-6 py-4 text-gray-700 text-center min-h-[60px] max-w-2xl mx-auto border border-gray-200">
                                <span class="text-gray-400 italic">Start speaking...</span>
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3 max-w-xl mx-auto">
                        <button onclick="quickSend('Hello! Introduce yourself')" class="px-5 py-3 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-xl text-sm text-gray-700 transition text-left">
                            <span class="mr-2">👋</span> Introduce yourself
                        </button>
                        <button onclick="quickSend('வணக்கம்! நீங்கள் யார்?')" class="px-5 py-3 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-xl text-sm text-gray-700 transition text-left">
                            <span class="mr-2">🇮🇳</span> Tamil greeting
                        </button>
                        <button onclick="quickSend('नमस्ते! आप कौन हैं?')" class="px-5 py-3 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-xl text-sm text-gray-700 transition text-left">
                            <span class="mr-2">🙏</span> Hindi greeting
                        </button>
                        <button onclick="quickSend('你好！你是谁？')" class="px-5 py-3 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-xl text-sm text-gray-700 transition text-left">
                            <span class="mr-2">🇨🇳</span> Mandarin greeting
                        </button>
                    </div>
                    
                </div>
            </div>

            <!-- Conversation Screen -->
            <div id="conversationScreen" class="hidden flex-1 flex flex-col">
                <div class="flex-1 overflow-y-auto">
                    <div id="chatMessages" class="max-w-4xl mx-auto px-6 py-8 space-y-6"></div>
                    
                    <div id="typingIndicator" class="hidden max-w-4xl mx-auto px-6">
                        <div class="flex items-start gap-4 mb-6">
                            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center text-white text-sm font-semibold shadow-lg flex-shrink-0">
                                AI
                            </div>
                            <div class="bg-gray-100 rounded-2xl px-6 py-4">
                                <div class="flex gap-1.5">
                                    <div class="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                                    <div class="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style="animation-delay: 0.15s"></div>
                                    <div class="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style="animation-delay: 0.3s"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="border-t bg-white sticky bottom-0">
                    <div class="max-w-4xl mx-auto px-6 py-4">
                        <!-- Live Transcription in Chat Screen -->
                        <div id="chatRecordingIndicator" class="hidden mb-4">
                            <div class="flex items-center justify-center gap-2 text-red-500 mb-3">
                                <div class="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                                <span class="text-sm font-medium">Recording <span id="chatRecordingTimer">0:00</span></span>
                            </div>
                            <div id="chatLiveTranscription" class="bg-gray-50 rounded-xl px-6 py-4 text-gray-700 text-center min-h-[60px] border border-gray-200">
                                <span class="text-gray-400 italic">Start speaking...</span>
                            </div>
                        </div>
                        
                        <div class="flex items-center gap-2 bg-gray-50 rounded-full border border-gray-200 px-2">
                            <input 
                                type="text" 
                                id="chatInput" 
                                placeholder="Message..."
                                class="flex-1 py-4 px-6 bg-transparent border-0 focus:outline-none text-base text-gray-900 placeholder-gray-400"
                                onkeypress="if(event.key === 'Enter') sendChatMessage()"
                            >
                            <button 
                                id="chatVoiceBtn"
                                onclick="toggleVoiceRecording()"
                                class="p-3 text-gray-500 hover:text-gray-700 hover:bg-white rounded-full transition">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path>
                                </svg>
                            </button>
                            <button 
                                onclick="sendChatMessage()"
                                class="p-3 bg-black text-white hover:bg-gray-800 rounded-full transition">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                                </svg>
                            </button>
                        </div>
                        <div class="text-center mt-3">
                            <button onclick="newConversation()" class="text-xs text-gray-500 hover:text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition">
                                New conversation
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Mobile Phone Call UI -->
            <div id="phoneCallUI" class="hidden flex-1 flex flex-col bg-gradient-to-b from-gray-50 to-white">
                <!-- Call Start Screen -->
                <div id="callStartScreen" class="flex-1 flex flex-col items-center justify-center px-8 py-12">
                    <div class="text-center max-w-md mx-auto w-full">
                        <div class="mb-12">
                            <div class="w-32 h-32 mx-auto mb-8 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center shadow-lg">
                                <svg class="w-16 h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                </svg>
                            </div>
                            <h2 class="text-3xl font-bold text-gray-900 mb-3">{{ $tenant->company_name }}</h2>
                            <p class="text-lg text-gray-600">Ready to assist you</p>
                        </div>

                        <button 
                            id="startCallBtn"
                            onclick="startCall()"
                            class="w-full mb-6 bg-green-500 hover:bg-green-600 active:bg-green-700 text-white font-bold py-8 px-8 rounded-3xl shadow-2xl flex items-center justify-center gap-4 text-2xl transition-all duration-300 transform hover:scale-105 active:scale-95">
                            <svg class="w-10 h-10" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"></path>
                            </svg>
                            Call Now
                        </button>

                        <button 
                            id="switchToChatBtn"
                            onclick="switchToChatMode()"
                            class="w-full bg-white hover:bg-gray-50 text-gray-700 font-semibold py-5 px-6 rounded-2xl border-2 border-gray-200 transition-all duration-300 text-lg">
                            💬 Type your message
                        </button>
                    </div>
                </div>

                <!-- Active Call Screen -->
                <div id="activeCallScreen" class="hidden flex-1 flex flex-col relative">
                    <!-- Call Header - FIXED AT TOP -->
                    <div class="bg-gradient-to-r from-green-500 to-green-600 text-white py-4 px-4 text-center shadow-lg sticky top-0 z-10">
                        <div class="flex items-center justify-center gap-2 mb-1">
                            <div class="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                            <span class="text-xs font-bold tracking-wider">CALL IN PROGRESS</span>
                        </div>
                        <div id="callDuration" class="text-2xl font-bold font-mono">00:00</div>
                    </div>

                    <!-- Live Transcript - SCROLLABLE ONLY THIS PART -->
                    <div class="flex-1 overflow-y-auto px-4 py-4 bg-gray-50" style="height: calc(100vh - 280px);">
                        <div id="callMessages" class="max-w-2xl mx-auto pb-4"></div>
                        <div id="callTypingIndicator" class="hidden max-w-2xl mx-auto mt-4">
                            <div class="flex gap-2 p-3 bg-white rounded-2xl rounded-bl-sm shadow-md w-fit">
                                <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 0ms"></div>
                                <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 150ms"></div>
                                <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 300ms"></div>
                            </div>
                        </div>

                        <!-- Recording Indicator During Call -->
                        <div id="callRecordingIndicator" class="hidden max-w-2xl mx-auto mt-4">
                            <div class="bg-red-50 rounded-xl px-4 py-3 border-2 border-red-400 shadow-lg">
                                <div class="flex items-center justify-center gap-2 text-red-600 mb-2">
                                    <div class="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                                    <span class="text-xs font-bold">Recording...</span>
                                </div>
                                <div id="callLiveTranscription" class="text-gray-800 text-center min-h-[30px] text-sm">
                                    <span class="text-gray-400 italic text-xs">Start speaking...</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Call Controls - FIXED AT BOTTOM (Like WeChat) -->
                    <div class="bg-white border-t-2 border-gray-200 px-4 py-3 sticky bottom-0 z-10 shadow-lg">
                        <div class="max-w-md mx-auto space-y-2">
                            <!-- Push to Talk Button -->
                            <button 
                                id="pushToTalkBtn"
                                onmousedown="startPushToTalk(event)"
                                onmouseup="stopPushToTalk(event)"
                                onmouseleave="stopPushToTalk(event)"
                                ontouchstart="startPushToTalk(event)"
                                ontouchend="stopPushToTalk(event)"
                                class="w-full bg-green-500 active:bg-green-700 text-white font-bold py-4 px-4 rounded-2xl shadow-xl flex flex-col items-center justify-center gap-1 transition-all duration-200 active:scale-95 select-none">
                                <svg class="w-7 h-7" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clip-rule="evenodd"></path>
                                </svg>
                                <span id="pushToTalkText" class="text-sm font-bold">Hold to Talk</span>
                            </button>

                            <div class="flex gap-2">
                                <button 
                                    id="endCallBtn"
                                    onclick="endCall()"
                                    class="flex-1 bg-red-500 active:bg-red-700 text-white font-bold py-2.5 px-3 rounded-xl shadow-lg flex items-center justify-center gap-1.5 transition-all duration-200 active:scale-95 text-xs">
                                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"></path>
                                    </svg>
                                    <span>End</span>
                                </button>

                                <button 
                                    id="typeInCallBtn"
                                    onclick="showCallChatInput()"
                                    class="flex-1 bg-gray-100 active:bg-gray-300 text-gray-700 font-semibold py-2.5 px-3 rounded-xl transition-all duration-200 text-xs">
                                    💬 Type
                                </button>
                            </div>

                                <!-- Call Chat Input (hidden by default) -->
                                <div id="callChatInput" class="hidden">
                                    <div class="flex gap-2">
                                        <input 
                                            type="text" 
                                            id="callMessageInput" 
                                            placeholder="Type your message..."
                                            class="flex-1 py-3 px-4 bg-gray-100 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500"
                                            onkeypress="if(event.key === 'Enter') sendCallMessage()"
                                        >
                                        <button 
                                            onclick="sendCallMessage()"
                                            class="px-4 bg-green-500 hover:bg-green-600 text-white rounded-xl transition">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <script>
        // Mobile settings from PHP
        const mobileSettings = {
            callUiEnabled: {{ $mobileSettings->mobile_call_ui_enabled ?? 1 ? 'true' : 'false' }},
            showChatFallback: {{ $mobileSettings->mobile_show_chat_fallback ?? 1 ? 'true' : 'false' }},
            allowTypingDuringCall: {{ $mobileSettings->mobile_allow_typing_during_call ?? 1 ? 'true' : 'false' }},
            defaultMode: '{{ $mobileSettings->mobile_default_mode ?? "call" }}',
            autoEndSilenceSeconds: {{ $mobileSettings->mobile_auto_end_silence_seconds ?? 30 }}
        };
        
        console.log('Mobile settings loaded:', mobileSettings);

        // Mobile detection
        function isMobileDevice() {
            const userAgent = navigator.userAgent || navigator.vendor || window.opera;
            const isMobile = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(userAgent.toLowerCase());
            const isTablet = /ipad|android(?!.*mobile)/i.test(userAgent.toLowerCase());
            const hasTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
            const smallScreen = window.innerWidth <= 768;
            
            return (isMobile || isTablet || (hasTouch && smallScreen));
        }

        const isMobile = isMobileDevice();
        const usePhoneUI = isMobile && mobileSettings.callUiEnabled;

        let ws = null;
        let sessionId = 'chat_' + Date.now();
        let isRecording = false;
        let mediaRecorder = null;
        let audioChunks = [];
        let recordingStartTime = null;
        let recordingInterval = null;
        let reconnectTimeout = null;
        let lastInputWasVoice = false;
        let isInCall = false;
        let callStartTime = null;
        let callTimer = null;
        let silenceTimer = null;
        let currentCallSessionId = null; // Track call session for logging

        function connectWebSocket() {
            if (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)) {
                return;
            }

            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}/chat-ws`;
            
            try {
                ws = new WebSocket(wsUrl);

                ws.onopen = () => {
                    console.log('Connected');
                    if (reconnectTimeout) {
                        clearTimeout(reconnectTimeout);
                        reconnectTimeout = null;
                    }
                    
                    ws.send(JSON.stringify({
                        type: 'init',
                        sessionId: sessionId,
                        tenantId: {{ $tenant->id }},
                        language: 'en-IN'
                    }));
                };

                ws.onmessage = (event) => {
                    try {
                        const data = JSON.parse(event.data);
                        
                        if (data.type === 'response') {
                            hideTypingIndicator();
                            
                            addMessage(data.content, 'assistant', data.audioUrl);
                            
                            // Auto-play audio if last input was voice
                            if (lastInputWasVoice && data.audioUrl) {
                                setTimeout(() => {
                                    playAudioUrl(data.audioUrl);
                                }, 500);
                            }
                            
                            // Reset voice flag
                            lastInputWasVoice = false;
                        } else if (data.type === 'error') {
                            hideTypingIndicator();
                            addMessage('Sorry, something went wrong. Please try again.', 'assistant');
                        }
                    } catch (error) {
                        console.error('Error:', error);
                    }
                };

                ws.onerror = (error) => {
                    console.error('Connection error:', error);
                };

                ws.onclose = () => {
                    ws = null;
                    if (!reconnectTimeout) {
                        reconnectTimeout = setTimeout(connectWebSocket, 3000);
                    }
                };
            } catch (error) {
                console.error('Error:', error);
                if (!reconnectTimeout) {
                    reconnectTimeout = setTimeout(connectWebSocket, 3000);
                }
            }
        }

        function switchToConversation() {
            document.getElementById('welcomeScreen').classList.add('hidden');
            document.getElementById('conversationScreen').classList.remove('hidden');
        }

        function sendMessage() {
            const input = document.getElementById('messageInput');
            const message = input.value.trim();
            if (!message) return;
            
            if (!ws || ws.readyState !== WebSocket.OPEN) {
                alert('Connecting... please wait');
                return;
            }

            switchToConversation();
            addMessage(message, 'user');
            showTypingIndicator();
            lastInputWasVoice = false;
            
            ws.send(JSON.stringify({
                type: 'text',
                content: message,
                language: 'en-IN'
            }));

            input.value = '';
        }

        function sendChatMessage() {
            const input = document.getElementById('chatInput');
            const message = input.value.trim();
            if (!message) return;
            
            if (!ws || ws.readyState !== WebSocket.OPEN) {
                alert('Connecting... please wait');
                return;
            }

            addMessage(message, 'user');
            showTypingIndicator();
            lastInputWasVoice = false;
            
            ws.send(JSON.stringify({
                type: 'text',
                content: message,
                language: 'en-IN'
            }));

            input.value = '';
            input.focus();
        }

        function quickSend(message) {
            if (!ws || ws.readyState !== WebSocket.OPEN) {
                alert('Connecting... please wait');
                return;
            }
            
            switchToConversation();
            addMessage(message, 'user');
            showTypingIndicator();
            lastInputWasVoice = false;
            
            ws.send(JSON.stringify({
                type: 'text',
                content: message,
                language: 'en-IN'
            }));
        }

        async function toggleVoiceRecording() {
            if (!isRecording) {
                await startRecording();
            } else {
                stopRecording();
            }
        }

        let recognition = null;
        let interimTranscript = '';
        let finalTranscript = '';

        async function startRecording() {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorder = new MediaRecorder(stream);
                audioChunks = [];
                interimTranscript = '';
                finalTranscript = '';

                mediaRecorder.ondataavailable = (event) => {
                    audioChunks.push(event.data);
                };

                mediaRecorder.onstop = async () => {
                    const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                    await sendVoiceMessage(audioBlob);
                    stream.getTracks().forEach(track => track.stop());
                };

                mediaRecorder.start();
                isRecording = true;
                recordingStartTime = Date.now();
                
                // Update mic icons to red square stop icons
                updateMicIcons(true);
                
                // Show recording indicator on both screens
                document.getElementById('recordingIndicator').classList.remove('hidden');
                document.getElementById('liveTranscription').innerHTML = '<span class="text-gray-400 italic">Start speaking...</span>';
                document.getElementById('chatRecordingIndicator').classList.remove('hidden');
                document.getElementById('chatLiveTranscription').innerHTML = '<span class="text-gray-400 italic">Start speaking...</span>';
                recordingInterval = setInterval(updateRecordingTimer, 100);
                
                // Start live transcription using Web Speech API
                startLiveTranscription();
                
            } catch (error) {
                console.error('Microphone error:', error);
                alert('Please allow microphone access');
            }
        }

        function startLiveTranscription() {
            if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
                console.log('Speech recognition not supported');
                return;
            }

            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            recognition = new SpeechRecognition();
            
            recognition.continuous = true;
            recognition.interimResults = true;
            recognition.lang = 'en-US';

            recognition.onresult = (event) => {
                let interim = '';
                let final = '';

                for (let i = event.resultIndex; i < event.results.length; i++) {
                    const transcript = event.results[i][0].transcript;
                    if (event.results[i].isFinal) {
                        final += transcript + ' ';
                    } else {
                        interim += transcript;
                    }
                }

                if (final) {
                    finalTranscript += final;
                }
                
                const displayText = (finalTranscript + interim).trim() || 'Start speaking...';
                const displayHTML = displayText === 'Start speaking...' 
                    ? '<span class="text-gray-400 italic">Start speaking...</span>'
                    : `<span class="text-gray-900">${displayText}</span>`;
                
                // Update both transcription displays
                const liveTranscriptionEl = document.getElementById('liveTranscription');
                const chatLiveTranscriptionEl = document.getElementById('chatLiveTranscription');
                
                if (liveTranscriptionEl) {
                    liveTranscriptionEl.innerHTML = displayHTML;
                }
                if (chatLiveTranscriptionEl) {
                    chatLiveTranscriptionEl.innerHTML = displayHTML;
                }
            };

            recognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
            };

            recognition.start();
        }

        function updateRecordingTimer() {
            const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
            const minutes = Math.floor(elapsed / 60);
            const seconds = elapsed % 60;
            const timeText = `${minutes}:${seconds.toString().padStart(2, '0')}`;
            
            const timer1 = document.getElementById('recordingTimer');
            const timer2 = document.getElementById('chatRecordingTimer');
            
            if (timer1) timer1.textContent = timeText;
            if (timer2) timer2.textContent = timeText;
        }

        function stopRecording() {
            if (mediaRecorder && isRecording) {
                // Stop speech recognition
                if (recognition) {
                    recognition.stop();
                    recognition = null;
                }
                
                mediaRecorder.stop();
                isRecording = false;
                clearInterval(recordingInterval);
                
                // Show summary of what was said
                const fullTranscript = finalTranscript.trim();
                if (fullTranscript) {
                    const summary = summarizeText(fullTranscript);
                    const summaryHTML = `
                        <div class="text-left">
                            <div class="text-xs font-semibold text-gray-500 uppercase mb-2">Summary</div>
                            <div class="text-gray-900">${summary}</div>
                        </div>
                    `;
                    
                    const liveTranscriptionEl = document.getElementById('liveTranscription');
                    const chatLiveTranscriptionEl = document.getElementById('chatLiveTranscription');
                    
                    if (liveTranscriptionEl) {
                        liveTranscriptionEl.innerHTML = summaryHTML;
                    }
                    if (chatLiveTranscriptionEl) {
                        chatLiveTranscriptionEl.innerHTML = summaryHTML;
                    }
                    
                    // Hide after 2 seconds
                    setTimeout(() => {
                        document.getElementById('recordingIndicator').classList.add('hidden');
                        document.getElementById('chatRecordingIndicator').classList.add('hidden');
                    }, 2000);
                } else {
                    document.getElementById('recordingIndicator').classList.add('hidden');
                    document.getElementById('chatRecordingIndicator').classList.add('hidden');
                }
                
                // Restore mic icons
                updateMicIcons(false);
                
                // Show typing indicator immediately when recording stops
                switchToConversation();
                showTypingIndicator();
            }
        }

        function summarizeText(text) {
            const words = text.split(' ');
            if (words.length <= 10) {
                return text;
            }
            
            // Simple summarization: first 8 words + "..."
            const summary = words.slice(0, 8).join(' ') + '...';
            return summary;
        }

        function updateMicIcons(recording) {
            const voiceBtn = document.getElementById('voiceBtn');
            const chatVoiceBtn = document.getElementById('chatVoiceBtn');
            
            if (recording) {
                // Show red square stop icon
                const stopIcon = `<svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <rect x="6" y="6" width="12" height="12" rx="2"/>
                </svg>`;
                const stopIconSmall = `<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <rect x="6" y="6" width="12" height="12" rx="2"/>
                </svg>`;
                
                voiceBtn.innerHTML = stopIcon;
                voiceBtn.classList.remove('text-gray-500', 'hover:text-gray-700');
                voiceBtn.classList.add('text-red-500', 'hover:text-red-700');
                
                chatVoiceBtn.innerHTML = stopIconSmall;
                chatVoiceBtn.classList.remove('text-gray-500', 'hover:text-gray-700');
                chatVoiceBtn.classList.add('text-red-500', 'hover:text-red-700');
            } else {
                // Show microphone icon
                const micIcon = `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path>
                </svg>`;
                const micIconSmall = `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path>
                </svg>`;
                
                voiceBtn.innerHTML = micIcon;
                voiceBtn.classList.remove('text-red-500', 'hover:text-red-700');
                voiceBtn.classList.add('text-gray-500', 'hover:text-gray-700');
                
                chatVoiceBtn.innerHTML = micIconSmall;
                chatVoiceBtn.classList.remove('text-red-500', 'hover:text-red-700');
                chatVoiceBtn.classList.add('text-gray-500', 'hover:text-gray-700');
            }
        }

        async function sendVoiceMessage(audioBlob) {
            if (!ws || ws.readyState !== WebSocket.OPEN) {
                hideTypingIndicator();
                alert('Not connected');
                return;
            }

            lastInputWasVoice = true; // Mark that this is a voice input
            
            // Show the transcribed text immediately
            const transcriptText = finalTranscript.trim() || 'Voice message';
            addMessage(transcriptText, 'user');

            const reader = new FileReader();
            reader.onload = () => {
                const base64Audio = reader.result.split(',')[1];
                ws.send(JSON.stringify({
                    type: 'audio',
                    audio: base64Audio,
                    language: 'en-IN'
                }));
            };
            reader.readAsDataURL(audioBlob);
        }
        
        function playAudioUrl(url) {
            try {
                const audio = new Audio(url);
                audio.play().catch(e => {
                    console.error('Audio playback error:', e);
                });
            } catch (error) {
                console.error('Error creating audio:', error);
            }
        }

        function showTypingIndicator() {
            document.getElementById('typingIndicator').classList.remove('hidden');
            scrollToBottom();
        }

        function hideTypingIndicator() {
            document.getElementById('typingIndicator').classList.add('hidden');
        }

        function addMessage(content, role, audioUrl = null) {
            const messagesDiv = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            const isUser = role === 'user';
            
            const avatar = isUser 
                ? `<div class="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-700 text-sm font-semibold flex-shrink-0">U</div>`
                : `<div class="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center text-white text-sm font-semibold shadow-lg flex-shrink-0">AI</div>`;
            
            const bubbleClass = isUser 
                ? 'bg-gray-100 rounded-3xl rounded-tr-md' 
                : 'bg-white border border-gray-200 rounded-3xl rounded-tl-md shadow-sm';
            
            const audioPlayer = audioUrl ? `
                <button onclick="new Audio('${audioUrl}').play()" class="mt-3 text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1.5 font-medium">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"></path>
                    </svg>
                    Play audio
                </button>
            ` : '';
            
            messageDiv.className = `flex items-start gap-4 ${isUser ? 'flex-row-reverse' : ''}`;
            messageDiv.innerHTML = `
                ${avatar}
                <div class="${bubbleClass} px-6 py-4 max-w-2xl">
                    <div class="text-base text-gray-900 leading-relaxed whitespace-pre-wrap">${content}</div>
                    ${audioPlayer}
                </div>
            `;
            
            messagesDiv.appendChild(messageDiv);
            scrollToBottom();
        }

        function scrollToBottom() {
            const container = document.querySelector('#conversationScreen > div');
            if (container) {
                setTimeout(() => {
                    container.scrollTop = container.scrollHeight;
                }, 50);
            }
        }

        function newConversation() {
            sessionId = 'chat_' + Date.now();
            document.getElementById('conversationScreen').classList.add('hidden');
            document.getElementById('welcomeScreen').classList.remove('hidden');
            document.getElementById('chatMessages').innerHTML = '';
            
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({
                    type: 'init',
                    sessionId: sessionId,
                    tenantId: {{ $tenant->id }},
                    language: 'en-IN'
                }));
            }
        }

        // Phone Call UI Functions
        function initializeUI() {
            const welcomeScreen = document.getElementById('welcomeScreen');
            const conversationScreen = document.getElementById('conversationScreen');
            const phoneUI = document.getElementById('phoneCallUI');
            const switchToChatBtn = document.getElementById('switchToChatBtn');
            const typeInCallBtn = document.getElementById('typeInCallBtn');

            console.log('Initializing UI - isMobile:', isMobile, 'usePhoneUI:', usePhoneUI);

            if (usePhoneUI) {
                // Show phone UI on mobile - hide regular chat screens
                if (welcomeScreen) welcomeScreen.classList.add('hidden');
                if (conversationScreen) conversationScreen.classList.add('hidden');
                if (phoneUI) phoneUI.classList.remove('hidden');

                console.log('Mobile phone UI enabled');

                // Hide chat fallback button if disabled in settings
                if (!mobileSettings.showChatFallback && switchToChatBtn) {
                    switchToChatBtn.classList.add('hidden');
                }

                // Hide typing during call if disabled
                if (!mobileSettings.allowTypingDuringCall && typeInCallBtn) {
                    typeInCallBtn.classList.add('hidden');
                }
            } else {
                // Show regular chat UI on desktop
                if (phoneUI) phoneUI.classList.add('hidden');
                console.log('Desktop chat UI enabled');
            }
        }

        async function startCallSession() {
            try {
                const sourceChannel = isMobile ? 'mobile' : 'web';
                const response = await fetch('/api/calls/start', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: JSON.stringify({
                        session_id: sessionId,
                        source_channel: sourceChannel,
                        metadata: {
                            user_agent: navigator.userAgent,
                            device_type: isMobile ? 'mobile' : 'desktop'
                        }
                    })
                });

                if (response.ok) {
                    const data = await response.json();
                    currentCallSessionId = data.call_session_id;
                    console.log('Call session started:', currentCallSessionId, 'Source:', sourceChannel);
                }
            } catch (error) {
                console.error('Failed to start call session:', error);
            }
        }

        async function endCallSession(status = 'completed') {
            if (!currentCallSessionId) return;

            try {
                await fetch(`/api/calls/${sessionId}/end`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: JSON.stringify({ status })
                });

                console.log('Call session ended:', currentCallSessionId);
                currentCallSessionId = null;
            } catch (error) {
                console.error('Failed to end call session:', error);
            }
        }

        function startCall() {
            if (!ws || ws.readyState !== WebSocket.OPEN) {
                alert('Connecting... please wait');
                setTimeout(startCall, 1000);
                return;
            }

            isInCall = true;
            document.getElementById('callStartScreen').classList.add('hidden');
            document.getElementById('activeCallScreen').classList.remove('hidden');

            // Start call timer
            callStartTime = Date.now();
            updateCallTimer();
            callTimer = setInterval(updateCallTimer, 1000);

            // Reset silence timer
            resetSilenceTimer();

            // Start call session tracking
            startCallSession();

            console.log('Call started - push to talk mode enabled');
        }

        // Push to Talk Functions
        function startPushToTalk(event) {
            event.preventDefault();
            if (!isInCall || isRecording) return;

            console.log('Push to talk - recording started');
            const btn = document.getElementById('pushToTalkBtn');
            const text = document.getElementById('pushToTalkText');
            const indicator = document.getElementById('callRecordingIndicator');
            
            text.textContent = '🔴 Recording...';
            btn.classList.remove('bg-green-500');
            btn.classList.add('bg-red-500');
            indicator.classList.remove('hidden');

            // Start recording
            startRecording();
        }

        function stopPushToTalk(event) {
            event.preventDefault();
            if (!isInCall || !isRecording) return;

            console.log('Push to talk - recording stopped, sending audio');
            const btn = document.getElementById('pushToTalkBtn');
            const text = document.getElementById('pushToTalkText');
            const indicator = document.getElementById('callRecordingIndicator');
            
            text.textContent = 'Hold to Talk';
            btn.classList.remove('bg-red-500');
            btn.classList.add('bg-green-500');
            
            // Hide recording indicator immediately
            indicator.classList.add('hidden');
            
            // Clear live transcription
            const liveTranscript = document.getElementById('callLiveTranscription');
            if (liveTranscript) {
                liveTranscript.innerHTML = '<span class="text-gray-400 italic text-sm">Start speaking...</span>';
            }

            // Stop recording and send
            stopRecording();
        }

        function endCall() {
            isInCall = false;
            
            // End call session tracking
            endCallSession('completed');
            
            // Stop timers
            if (callTimer) {
                clearInterval(callTimer);
                callTimer = null;
            }
            if (silenceTimer) {
                clearTimeout(silenceTimer);
                silenceTimer = null;
            }

            // Stop recording if active
            if (isRecording) {
                stopRecording();
            }

            // Reset UI
            document.getElementById('activeCallScreen').classList.add('hidden');
            document.getElementById('callStartScreen').classList.remove('hidden');
            document.getElementById('callMessages').innerHTML = '';
            document.getElementById('callDuration').textContent = '00:00';
            document.getElementById('callChatInput').classList.add('hidden');
        }

        function updateCallTimer() {
            if (!isInCall || !callStartTime) return;
            
            const elapsed = Math.floor((Date.now() - callStartTime) / 1000);
            const minutes = Math.floor(elapsed / 60);
            const seconds = elapsed % 60;
            const display = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
            
            document.getElementById('callDuration').textContent = display;
        }

        function resetSilenceTimer() {
            if (silenceTimer) {
                clearTimeout(silenceTimer);
            }

            if (mobileSettings.autoEndSilenceSeconds > 0) {
                silenceTimer = setTimeout(() => {
                    if (isInCall) {
                        endCall();
                        alert('Call ended due to inactivity');
                    }
                }, mobileSettings.autoEndSilenceSeconds * 1000);
            }
        }

        function switchToChatMode() {
            const phoneUI = document.getElementById('phoneCallUI');
            const chatContainer = document.getElementById('chatContainer');
            
            phoneUI.classList.add('hidden');
            chatContainer.querySelector('#welcomeScreen').parentElement.classList.remove('hidden');
            chatContainer.querySelector('#welcomeScreen').classList.remove('hidden');
        }

        function showCallChatInput() {
            const chatInput = document.getElementById('callChatInput');
            chatInput.classList.toggle('hidden');
            if (!chatInput.classList.contains('hidden')) {
                document.getElementById('callMessageInput').focus();
            }
        }

        function sendCallMessage() {
            const input = document.getElementById('callMessageInput');
            const message = input.value.trim();
            if (!message) return;

            if (!ws || ws.readyState !== WebSocket.OPEN) {
                alert('Not connected');
                return;
            }

            addCallMessage(message, 'user');
            showCallTypingIndicator();
            resetSilenceTimer();
            lastInputWasVoice = false;

            ws.send(JSON.stringify({
                type: 'text',
                content: message,
                language: 'en-IN'
            }));

            input.value = '';
        }

        function addCallMessage(content, role, audioUrl = null) {
            const messagesDiv = document.getElementById('callMessages');
            const messageDiv = document.createElement('div');
            const isUser = role === 'user';
            
            const bubbleClass = isUser 
                ? 'bg-green-500 text-white ml-auto shadow-md' 
                : 'bg-white text-gray-900 shadow-md border border-gray-200';
            
            messageDiv.className = `flex ${isUser ? 'justify-end' : 'justify-start'} mb-3 animate-fade-in`;
            messageDiv.innerHTML = `
                <div class="${bubbleClass} rounded-2xl px-4 py-3 max-w-[80%] break-words">
                    <div class="text-base leading-normal">${content}</div>
                </div>
            `;
            
            messagesDiv.appendChild(messageDiv);
            
            // Smooth scroll to bottom
            setTimeout(() => {
                messagesDiv.scrollTop = messagesDiv.scrollHeight;
            }, 50);

            if (isUser) {
                resetSilenceTimer();
            }
        }

        function showCallTypingIndicator() {
            document.getElementById('callTypingIndicator').classList.remove('hidden');
            const messagesDiv = document.getElementById('callMessages');
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }

        function hideCallTypingIndicator() {
            document.getElementById('callTypingIndicator').classList.add('hidden');
        }

        // Override WebSocket message handler for phone UI
        const originalOnMessage = ws ? ws.onmessage : null;

        function handlePhoneUIMessage(data) {
            if (data.type === 'response') {
                hideCallTypingIndicator();
                addCallMessage(data.content, 'assistant', data.audioUrl);
                
                // Auto-play audio in call mode
                if (data.audioUrl) {
                    setTimeout(() => {
                        playAudioUrl(data.audioUrl);
                    }, 300);
                }

                resetSilenceTimer();
            } else if (data.type === 'error') {
                hideCallTypingIndicator();
                addCallMessage('Sorry, something went wrong. Please try again.', 'assistant');
            }
        }

        connectWebSocket();

        // Initialize UI after connection
        setTimeout(() => {
            initializeUI();

            // Override message handler if in phone UI mode
            if (usePhoneUI && ws) {
                const originalHandler = ws.onmessage;
                ws.onmessage = (event) => {
                    try {
                        const data = JSON.parse(event.data);
                        if (isInCall) {
                            handlePhoneUIMessage(data);
                        } else {
                            originalHandler(event);
                        }
                    } catch (error) {
                        console.error('Error:', error);
                    }
                };
            }
        }, 500);
    </script>

    <style>
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-6px); }
        }
        .animate-bounce {
            animation: bounce 1.4s infinite;
        }
        
        @keyframes fade-in {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fade-in 0.3s ease-out;
        }
        
        @keyframes pulse-slow {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.8; }
        }
        .animate-pulse-slow {
            animation: pulse-slow 2s ease-in-out infinite;
        }
        
        @keyframes ping {
            75%, 100% {
                transform: scale(2);
                opacity: 0;
            }
        }
        .animate-ping {
            animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;
        }
    </style>
</body>
</html>
