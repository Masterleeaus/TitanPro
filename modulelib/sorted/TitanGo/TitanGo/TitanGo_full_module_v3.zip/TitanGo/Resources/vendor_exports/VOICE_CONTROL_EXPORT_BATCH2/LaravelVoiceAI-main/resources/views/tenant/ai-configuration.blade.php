<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('AI Assistant Configuration') }}
        </h2>
    </x-slot>

    <div style="min-height: 100vh; padding: 2rem 1rem; background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #312e81 100%);">
        <div style="max-width: 1200px; margin: 0 auto;">
            <!-- Success Message -->
            @if (session('success'))
                <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 1rem 1.5rem; border-radius: 0.75rem; margin-bottom: 2rem; display: flex; align-items: center; gap: 0.75rem; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                    <svg style="width: 1.5rem; height: 1.5rem; flex-shrink: 0;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <span style="font-weight: 500;">{{ session('success') }}</span>
                </div>
            @endif

            <!-- Validation Errors -->
            @if ($errors->any())
                <div style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white; padding: 1rem 1.5rem; border-radius: 0.75rem; margin-bottom: 2rem; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                    <div style="font-weight: 600; margin-bottom: 0.5rem;">Please fix the following errors:</div>
                    <ul style="list-style: disc; margin-left: 1.5rem; font-size: 0.875rem;">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <!-- Main Content Card -->
            <div style="background: rgba(15, 23, 42, 0.6); backdrop-filter: blur(10px); border-radius: 1rem; padding: 2rem; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.3), 0 10px 10px -5px rgba(0, 0, 0, 0.2);">
                
                <!-- Header -->
                <div style="margin-bottom: 2rem;">
                    <h3 class="text-2xl font-bold" style="color: #c4b5fd; margin-bottom: 0.5rem;">🤖 AI Assistant Configuration</h3>
                    <p class="text-sm" style="color: #cbd5e1;">Train your AI assistant to match your business personality and needs. Customize how it speaks, what it knows, and how it responds to customers.</p>
                </div>

                <form method="POST" action="{{ route('ai-configuration.update') }}">
                    @csrf

                    <div style="border: 1px solid #8b5cf6; border-radius: 0.75rem; padding: 1.5rem; background: linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%);">
                        
                        <div class="space-y-6">
                            <!-- Business Type Selector -->
                            <div>
                                <label for="business_type" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Business Type</label>
                                <select name="business_type" id="business_type" onchange="loadTemplate(this.value)" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                    <option value="general" {{ old('business_type', $settings->business_type ?? 'general') == 'general' ? 'selected' : '' }}>General / Custom</option>
                                    <option value="restaurant" {{ old('business_type', $settings->business_type ?? 'general') == 'restaurant' ? 'selected' : '' }}>🍕 Restaurant / Food Service</option>
                                    <option value="medical" {{ old('business_type', $settings->business_type ?? 'general') == 'medical' ? 'selected' : '' }}>🏥 Medical Clinic / Healthcare</option>
                                    <option value="hotel" {{ old('business_type', $settings->business_type ?? 'general') == 'hotel' ? 'selected' : '' }}>🏨 Hotel / Hospitality</option>
                                    <option value="retail" {{ old('business_type', $settings->business_type ?? 'general') == 'retail' ? 'selected' : '' }}>🛍️ Retail Store</option>
                                    <option value="support" {{ old('business_type', $settings->business_type ?? 'general') == 'support' ? 'selected' : '' }}>💬 Customer Support</option>
                                </select>
                                <p style="font-size: 0.75rem; color: #9ca3af; margin-top: 0.5rem;">Select your business type to load a pre-built template, or choose General to create your own</p>
                            </div>

                            <!-- System Prompt -->
                            <div>
                                <label for="system_prompt" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">System Prompt (AI Instructions)</label>
                                <textarea name="system_prompt" id="system_prompt" rows="8" placeholder="You are a helpful assistant for..." style="width: 100%; padding: 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem; font-family: monospace; resize: vertical;">{{ old('system_prompt', $settings->system_prompt) }}</textarea>
                                <p style="font-size: 0.75rem; color: #9ca3af; margin-top: 0.5rem;">Tell the AI who it is, what it can do, and how it should behave. Be specific!</p>
                            </div>

                            <!-- Business Context -->
                            <div>
                                <label for="business_context" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Business Context (Menu, Services, Policies)</label>
                                <textarea name="business_context" id="business_context" rows="6" placeholder="Menu items, services offered, pricing, policies..." style="width: 100%; padding: 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem; resize: vertical;">{{ old('business_context', $settings->business_context) }}</textarea>
                                <p style="font-size: 0.75rem; color: #9ca3af; margin-top: 0.5rem;">Provide details about your offerings, prices, hours, and any important information the AI should know</p>
                            </div>

                            <!-- Voice Tone -->
                            <div>
                                <label for="voice_tone" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Voice Tone & Personality</label>
                                <select name="voice_tone" id="voice_tone" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                    <option value="professional" {{ old('voice_tone', $settings->voice_tone ?? 'professional') == 'professional' ? 'selected' : '' }}>Professional</option>
                                    <option value="friendly" {{ old('voice_tone', $settings->voice_tone ?? 'professional') == 'friendly' ? 'selected' : '' }}>Friendly & Casual</option>
                                    <option value="formal" {{ old('voice_tone', $settings->voice_tone ?? 'professional') == 'formal' ? 'selected' : '' }}>Formal & Polite</option>
                                    <option value="enthusiastic" {{ old('voice_tone', $settings->voice_tone ?? 'professional') == 'enthusiastic' ? 'selected' : '' }}>Enthusiastic & Energetic</option>
                                </select>
                            </div>

                            <!-- Operating Hours -->
                            <div>
                                <label for="operating_hours" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Operating Hours</label>
                                <input type="text" name="operating_hours" id="operating_hours" value="{{ old('operating_hours', $settings->operating_hours) }}" placeholder="Mon-Fri: 9 AM - 6 PM, Sat: 10 AM - 4 PM" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                <p style="font-size: 0.75rem; color: #9ca3af; margin-top: 0.5rem;">Your business hours so the AI can inform callers</p>
                            </div>

                            <!-- Default Language -->
                            <div>
                                <label for="default_language" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Default Language</label>
                                <select name="default_language" id="default_language" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                    <option value="en-IN" {{ old('default_language', $settings->default_language ?? 'en-IN') == 'en-IN' ? 'selected' : '' }}>🇮🇳 English (India)</option>
                                    <option value="en-US" {{ old('default_language', $settings->default_language ?? 'en-IN') == 'en-US' ? 'selected' : '' }}>🇺🇸 English (US)</option>
                                    <option value="ta-IN" {{ old('default_language', $settings->default_language ?? 'en-IN') == 'ta-IN' ? 'selected' : '' }}>தமிழ் Tamil</option>
                                    <option value="hi-IN" {{ old('default_language', $settings->default_language ?? 'en-IN') == 'hi-IN' ? 'selected' : '' }}>हिन्दी Hindi</option>
                                    <option value="cmn-CN" {{ old('default_language', $settings->default_language ?? 'en-IN') == 'cmn-CN' ? 'selected' : '' }}>中文 Mandarin</option>
                                    <option value="ms-MY" {{ old('default_language', $settings->default_language ?? 'en-IN') == 'ms-MY' ? 'selected' : '' }}>🇲🇾 Malay</option>
                                    <option value="id-ID" {{ old('default_language', $settings->default_language ?? 'en-IN') == 'id-ID' ? 'selected' : '' }}>🇮🇩 Indonesian</option>
                                    <option value="th-TH" {{ old('default_language', $settings->default_language ?? 'en-IN') == 'th-TH' ? 'selected' : '' }}>🇹🇭 Thai</option>
                                </select>
                                <p style="font-size: 0.75rem; color: #9ca3af; margin-top: 0.5rem;">Primary language for your AI assistant (auto-detects other languages too)</p>
                            </div>
                        </div>
                    </div>

                    <div style="display: flex; justify-content: flex-end; margin-top: 2rem;">
                        <button type="submit" class="btn" style="background: #3b82f6; color: white; padding: 0.75rem 2rem; border-radius: 0.5rem; font-weight: 500; border: none; cursor: pointer;">
                            Save Configuration
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <script>
    function loadTemplate(businessType) {
        const templates = {
            restaurant: {
                prompt: `You are a friendly and helpful voice assistant for a restaurant. Your role is to:
- Take food orders and answer questions about the menu
- Provide information about ingredients, allergens, and dietary options
- Accept delivery or pickup orders and collect required information (address, phone, payment method)
- Answer questions about operating hours, location, and policies
- Be warm, welcoming, and efficient

Always confirm orders back to the customer before finalizing.`,
                context: `Menu Items:
- Margherita Pizza: $12
- Pepperoni Pizza: $14
- Pasta Carbonara: $11
- Caesar Salad: $8
- Garlic Bread: $5

Delivery: Available within 5 miles, $3 delivery fee
Pickup: Available, ready in 20-30 minutes
Payment: Cash, card, online payment accepted`,
                hours: "Mon-Sun: 11 AM - 10 PM"
            },
            medical: {
                prompt: `You are a professional medical receptionist assistant. Your role is to:
- Schedule, reschedule, and cancel appointments
- Answer questions about services offered and office hours
- Collect patient information (name, date of birth, insurance)
- Provide directions to the clinic
- Handle urgent vs. routine appointment requests appropriately

IMPORTANT: Never provide medical advice. Always direct health questions to speak with a doctor.`,
                context: `Services:
- General Consultation: $80
- Follow-up Visit: $50
- Lab Tests: Varies
- Vaccinations: $30-$60

Insurance: Accepted for most major providers
Walk-ins: Limited availability, appointments preferred`,
                hours: "Mon-Fri: 8 AM - 6 PM, Sat: 9 AM - 2 PM"
            },
            hotel: {
                prompt: `You are a courteous hotel concierge assistant. Your role is to:
- Help guests book rooms and check availability
- Provide information about amenities, room types, and pricing
- Answer questions about check-in/check-out times and policies
- Assist with special requests (early check-in, late checkout, extra amenities)
- Provide local recommendations and directions

Maintain a professional yet warm tone, treating every guest as a valued visitor.`,
                context: `Room Types:
- Standard Room: $120/night
- Deluxe Room: $180/night
- Suite: $280/night

Amenities:
- Free WiFi, Pool, Gym, Restaurant
- Room service available 7 AM - 11 PM
- Free parking for guests

Policies:
- Check-in: 3 PM, Check-out: 11 AM
- Cancellation: Free up to 24 hours before arrival`,
                hours: "Front Desk: 24/7"
            },
            retail: {
                prompt: `You are a helpful retail store assistant. Your role is to:
- Answer questions about product availability, features, and pricing
- Help customers find products they're looking for
- Process orders and handle returns/exchanges
- Provide information about sales, promotions, and loyalty programs
- Assist with sizing, compatibility, and product recommendations

Be knowledgeable, patient, and customer-focused.`,
                context: `Product Categories:
- Electronics, Clothing, Home Goods, Beauty Products

Services:
- Free shipping on orders over $50
- 30-day return policy
- Price matching available
- Loyalty rewards program

Payment: All major credit cards, PayPal, gift cards accepted`,
                hours: "Mon-Sat: 10 AM - 9 PM, Sun: 11 AM - 6 PM"
            },
            support: {
                prompt: `You are a professional customer support assistant. Your role is to:
- Listen to customer issues and concerns patiently
- Troubleshoot common problems step-by-step
- Collect necessary information (account details, order numbers, etc.)
- Escalate complex issues to human agents when needed
- Follow up on previous support tickets

Maintain empathy, patience, and professionalism at all times.`,
                context: `Common Issues:
- Account access problems
- Billing questions
- Product troubleshooting
- Refund requests
- Service complaints

Response Time: Within 24 hours for tickets
Phone Support: Available during business hours`,
                hours: "Mon-Fri: 9 AM - 5 PM (Support), 24/7 (Emergency line)"
            }
        };

        if (templates[businessType]) {
            document.getElementById('system_prompt').value = templates[businessType].prompt;
            document.getElementById('business_context').value = templates[businessType].context;
            document.getElementById('operating_hours').value = templates[businessType].hours;
        }
    }
    </script>
</x-app-layout>
