<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Business;
use App\Models\Order;
use App\Models\Appointment;

class BusinessController extends Controller
{
    public function index()
    {
        $businesses = Business::with(['orders', 'appointments'])->get();
        return response()->json($businesses);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'type' => 'required|string|in:restaurant,salon,service_provider,hotel,other',
            'phone_number' => 'required|string|unique:businesses',
            'description' => 'nullable|string',
            'settings' => 'nullable|array',
        ]);

        $business = Business::create($validated);
        return response()->json($business, 201);
    }

    public function show($id)
    {
        $business = Business::with(['menus', 'orders', 'appointments', 'conversations'])->findOrFail($id);
        return response()->json($business);
    }

    public function update(Request $request, $id)
    {
        $business = Business::findOrFail($id);

        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'type' => 'sometimes|string',
            'phone_number' => 'sometimes|string|unique:businesses,phone_number,' . $id,
            'twilio_phone_number' => 'nullable|string',
            'description' => 'nullable|string',
            'settings' => 'nullable|array',
            'is_active' => 'sometimes|boolean',
        ]);

        $business->update($validated);
        return response()->json($business);
    }

    public function destroy($id)
    {
        $business = Business::findOrFail($id);
        $business->delete();
        return response()->json(['message' => 'Business deleted successfully']);
    }

    public function orders($id)
    {
        $business = Business::findOrFail($id);
        $orders = $business->orders()->latest()->get();
        return response()->json($orders);
    }

    public function appointments($id)
    {
        $business = Business::findOrFail($id);
        $appointments = $business->appointments()->latest()->get();
        return response()->json($appointments);
    }
}
