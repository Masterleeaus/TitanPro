import 'dotenv/config';
import express from 'express';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import speech from '@google-cloud/speech';
import axios from 'axios';
import { createProxyMiddleware } from 'http-proxy-middleware';
import ffmpeg from 'fluent-ffmpeg';
import { promises as fs } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { tmpdir } from 'os';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 5000;
const LARAVEL_PORT = 8080; // Laravel will run on 8080
const REPLIT_DOMAIN = process.env.REPLIT_DEV_DOMAIN || 'localhost';
const LARAVEL_URL = `https://${REPLIT_DOMAIN}:${LARAVEL_PORT}`;

const app = express();
const server = createServer(app);

// WebSocket server for Twilio Media Streams (noServer mode)
const wss = new WebSocketServer({ 
    noServer: true
});

// Store active call sessions
const activeCalls = new Map();

console.log(`🚀 Combined Server starting...`);
console.log(`📡 Laravel backend: ${LARAVEL_URL}`);
console.log(`🎙️  WebSocket path: /ws`);

wss.on('error', (error) => {
    console.error('❌ Twilio WebSocket Server Error:', error);
});

wss.on('connection', (ws, req) => {
    console.log('📞 New Twilio Media Stream connection from:', req.socket.remoteAddress);
    console.log('📋 Headers:', JSON.stringify(req.headers, null, 2));
    
    let callSession = {
        streamSid: null,
        callSid: null,
        recognizeStream: null,
        conversationHistory: [],
        tenantId: null,
        detectedLanguage: null,
        audioBuffer: Buffer.alloc(0),
        lastTranscriptTime: Date.now(),
        lastInterimResult: null,
        lastInterimTime: null
    };

    ws.on('message', async (message) => {
        try {
            const msg = JSON.parse(message);
            
            switch (msg.event) {
                case 'connected':
                    console.log('✅ Twilio connected');
                    break;
                    
                case 'start':
                    console.log('🎬 Stream started:', msg.start.streamSid);
                    callSession.streamSid = msg.start.streamSid;
                    callSession.callSid = msg.start.callSid;
                    
                    // Extract tenant info from custom parameters
                    if (msg.start.customParameters) {
                        callSession.tenantId = msg.start.customParameters.tenantId;
                        callSession.from = msg.start.customParameters.from;
                        callSession.to = msg.start.customParameters.to;
                    }
                    
                    // Initialize Google Speech-to-Text
                    const client = new speech.SpeechClient();
                    
                    // Fetch tenant's default language from Laravel
                    let primaryLang = 'en-IN'; // Default fallback
                    if (callSession.tenantId) {
                        try {
                            const langResponse = await axios.get(`${LARAVEL_URL}/api/tenants/${callSession.tenantId}/language`);
                            if (langResponse.data && langResponse.data.language) {
                                primaryLang = langResponse.data.language;
                                console.log(`🌍 Using tenant's default language: ${primaryLang}`);
                            }
                        } catch (err) {
                            console.log(`⚠️ Could not fetch tenant language, using default: en-IN`);
                        }
                    }
                    
                    // Build alternative languages list (exclude primary)
                    const allLanguages = ['ta-IN', 'hi-IN', 'en-IN', 'en-US', 'cmn-CN', 'ms-MY', 'id-ID', 'th-TH'];
                    const alternativeLangs = allLanguages.filter(lang => 
                        !lang.toLowerCase().startsWith(primaryLang.split('-')[0].toLowerCase())
                    ).slice(0, 4); // Google STT allows max 4 alternatives
                    
                    console.log(`🎤 STT Config - Primary: ${primaryLang}, Alternatives: ${alternativeLangs.join(', ')}`);
                    
                    callSession.recognizeStream = client
                        .streamingRecognize({
                            config: {
                                encoding: 'MULAW',
                                sampleRateHertz: 8000,
                                languageCode: primaryLang,
                                alternativeLanguageCodes: alternativeLangs,
                                enableAutomaticPunctuation: true,
                                model: 'latest_long',
                                useEnhanced: false,  // Disable for better multi-language
                                enableWordTimeOffsets: false,
                                enableWordConfidence: false,
                                maxAlternatives: 3,  // Get multiple language alternatives
                            },
                            interimResults: true,
                            singleUtterance: false,
                        })
                        .on('error', (error) => {
                            console.error('❌ Speech recognition error:', error.message);
                        })
                        .on('data', async (data) => {
                            const result = data.results[0];
                            if (result && result.alternatives[0]) {
                                // Only process final results (not interim)
                                if (result.isFinal) {
                                    const transcript = result.alternatives[0].transcript.trim();
                                    const detectedLang = result.languageCode || 'en-IN';
                                    
                                    // Skip empty transcripts but use last interim if available
                                    if (!transcript || transcript.length === 0) {
                                        console.log('⚠️  Empty final transcript received');
                                        
                                        // If we have a recent interim result, use it
                                        if (callSession.lastInterimResult && callSession.lastInterimTime) {
                                            const timeSinceInterim = Date.now() - callSession.lastInterimTime;
                                            if (timeSinceInterim < 2000) { // Within 2 seconds
                                                console.log(`✅ Using interim result instead: ${callSession.lastInterimResult.transcript}`);
                                                await processTranscript(
                                                    ws, 
                                                    callSession, 
                                                    callSession.lastInterimResult.transcript,
                                                    callSession.lastInterimResult.languageCode
                                                );
                                                callSession.lastInterimResult = null;
                                            }
                                        }
                                        return;
                                    }
                                    
                                    console.log(`🗣️  Detected (${detectedLang}): ${transcript}`);
                                    
                                    callSession.detectedLanguage = detectedLang;
                                    callSession.lastTranscriptTime = Date.now();
                                    callSession.lastInterimResult = null; // Clear interim result
                                    
                                    // Call Laravel API to process speech
                                    await processTranscript(ws, callSession, transcript, detectedLang);
                                } else {
                                    // Store interim results for potential fallback
                                    const interimTranscript = result.alternatives[0].transcript.trim();
                                    const interimLang = result.languageCode || 'en-IN';
                                    
                                    if (interimTranscript && interimTranscript.length > 3) {
                                        callSession.lastInterimResult = {
                                            transcript: interimTranscript,
                                            languageCode: interimLang
                                        };
                                        callSession.lastInterimTime = Date.now();
                                        console.log(`🔊 Interim (${interimLang}): ${interimTranscript}`);
                                    } else {
                                        console.log(`🔊 Interim: ${interimTranscript}`);
                                    }
                                }
                            }
                        })
                        .on('end', () => {
                            console.log('⚠️  Recognition stream ended');
                        });
                    
                    activeCalls.set(msg.start.streamSid, callSession);
                    break;
                    
                case 'media':
                    if (callSession.recognizeStream && !callSession.recognizeStream.destroyed) {
                        try {
                            // Decode audio payload (base64 mulaw)
                            const audioChunk = Buffer.from(msg.media.payload, 'base64');
                            
                            // Send ONLY audio content to Google Speech-to-Text
                            // Don't wrap in object - send raw buffer
                            callSession.recognizeStream.write(audioChunk);
                            
                            // Buffer audio for later playback if needed
                            callSession.audioBuffer = Buffer.concat([
                                callSession.audioBuffer, 
                                audioChunk
                            ]);
                            
                            // Limit buffer size to 30 seconds
                            const maxBufferSize = 8000 * 30;
                            if (callSession.audioBuffer.length > maxBufferSize) {
                                callSession.audioBuffer = callSession.audioBuffer.slice(-maxBufferSize);
                            }
                        } catch (error) {
                            if (!callSession.recognizeStream.destroyed) {
                                console.error('❌ Error writing to recognition stream:', error.message);
                            }
                        }
                    }
                    break;
                    
                case 'stop':
                    console.log('🛑 Stream stopped');
                    if (callSession.recognizeStream && !callSession.recognizeStream.destroyed) {
                        try {
                            callSession.recognizeStream.end();
                        } catch (error) {
                            console.error('Error ending stream:', error.message);
                        }
                    }
                    activeCalls.delete(callSession.streamSid);
                    break;
            }
        } catch (error) {
            console.error('❌ WebSocket message error:', error);
        }
    });

    ws.on('close', () => {
        console.log('🔌 WebSocket connection closed');
        if (callSession.recognizeStream && !callSession.recognizeStream.destroyed) {
            try {
                callSession.recognizeStream.end();
            } catch (error) {
                console.error('Error ending stream on close:', error.message);
            }
        }
        if (callSession.streamSid) {
            activeCalls.delete(callSession.streamSid);
        }
    });

    ws.on('error', (error) => {
        console.error('❌ WebSocket error:', error);
    });
});

async function processTranscript(ws, callSession, transcript, detectedLanguage) {
    try {
        console.log('🤖 Calling Laravel API to process transcript...');
        
        const apiUrl = `${LARAVEL_URL}/api/media-stream/process`;
        
        const response = await axios.post(apiUrl, {
            callSid: callSession.callSid,
            streamSid: callSession.streamSid,
            transcript: transcript,
            detectedLanguage: detectedLanguage,
            conversationHistory: callSession.conversationHistory,
            tenantId: callSession.tenantId,
            from: callSession.from,
            to: callSession.to
        }, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            timeout: 30000
        });

        if (response.data.success) {
            const aiResponse = response.data.aiResponse;
            const audioUrl = response.data.audioUrl;
            
            console.log(`💬 AI Response: ${aiResponse.substring(0, 100)}...`);
            
            // Add to conversation history
            callSession.conversationHistory.push({
                role: 'user',
                content: transcript
            });
            callSession.conversationHistory.push({
                role: 'assistant',
                content: aiResponse
            });
            
            // Keep only last 10 exchanges
            if (callSession.conversationHistory.length > 20) {
                callSession.conversationHistory = callSession.conversationHistory.slice(-20);
            }
            
            // Stream audio back to Twilio
            if (audioUrl) {
                await streamAudioToTwilio(ws, callSession.streamSid, audioUrl);
            }
        } else {
            console.error('❌ Laravel API error:', response.data);
        }
        
    } catch (error) {
        console.error('❌ Error processing transcript:', error.message);
        if (error.response) {
            console.error('Response data:', error.response.data);
            console.error('Response status:', error.response.status);
        }
    }
}

async function streamAudioToTwilio(ws, streamSid, audioUrl) {
    let tempMp3Path = null;
    let tempMulawPath = null;
    
    try {
        console.log('📥 Downloading audio from:', audioUrl);
        
        // Download MP3 audio file
        const audioResponse = await axios.get(audioUrl, {
            responseType: 'arraybuffer',
            timeout: 10000
        });
        
        const audioBuffer = Buffer.from(audioResponse.data);
        console.log(`📦 Audio downloaded: ${audioBuffer.length} bytes (MP3)`);
        
        // Save MP3 to temp file
        tempMp3Path = path.join(tmpdir(), `temp_${Date.now()}.mp3`);
        await fs.writeFile(tempMp3Path, audioBuffer);
        
        // Convert MP3 to mulaw format (8kHz, 1 channel)
        tempMulawPath = path.join(tmpdir(), `temp_${Date.now()}.ulaw`);
        
        await new Promise((resolve, reject) => {
            ffmpeg(tempMp3Path)
                .audioCodec('pcm_mulaw')
                .audioChannels(1)
                .audioFrequency(8000)
                .audioBitrate('64k')
                .format('mulaw')
                .audioFilters('volume=1.5')  // Boost volume for clarity
                .on('end', () => {
                    console.log('🔄 Audio converted to mulaw format');
                    resolve();
                })
                .on('error', (err) => {
                    console.error('❌ FFmpeg error:', err.message);
                    reject(err);
                })
                .save(tempMulawPath);
        });
        
        // Read converted mulaw audio
        const mulawBuffer = await fs.readFile(tempMulawPath);
        console.log(`📦 Mulaw audio ready: ${mulawBuffer.length} bytes`);
        
        // Split audio into chunks and send to Twilio
        const chunkSize = 160; // 20ms at 8kHz mulaw
        let chunksSent = 0;
        
        for (let i = 0; i < mulawBuffer.length; i += chunkSize) {
            const chunk = mulawBuffer.slice(i, Math.min(i + chunkSize, mulawBuffer.length));
            const payload = chunk.toString('base64');
            
            const message = {
                event: 'media',
                streamSid: streamSid,
                media: {
                    track: 'outbound',
                    payload: payload
                }
            };
            
            ws.send(JSON.stringify(message));
            chunksSent++;
            
            // Minimal delay for buffering - Twilio handles the pacing
            if (chunksSent % 50 === 0) {
                await new Promise(resolve => setImmediate(resolve));
            }
        }
        
        // Send mark to indicate completion
        ws.send(JSON.stringify({
            event: 'mark',
            streamSid: streamSid,
            mark: {
                name: 'audio_complete_' + Date.now()
            }
        }));
        
        console.log(`✅ Audio streamed to Twilio (${chunksSent} chunks)`);
        
    } catch (error) {
        console.error('❌ Error streaming audio:', error.message);
    } finally {
        // Clean up temp files
        try {
            if (tempMp3Path) await fs.unlink(tempMp3Path).catch(() => {});
            if (tempMulawPath) await fs.unlink(tempMulawPath).catch(() => {});
        } catch (e) {
            // Ignore cleanup errors
        }
    }
}

// WebSocket server for browser chat (noServer mode to handle upgrades manually)
const chatWss = new WebSocketServer({ 
    noServer: true 
});

chatWss.on('error', (error) => {
    console.error('❌ Chat WebSocket Server Error:', error);
});

const activeChatSessions = new Map();

// Handle ALL WebSocket upgrades manually (single handler for both Twilio and chat)
server.on('upgrade', (request, socket, head) => {
    const pathname = request.url;
    
    console.log('🔄 Upgrade request for:', pathname);
    
    if (pathname === '/ws') {
        console.log('📞 Handling Twilio WebSocket upgrade');
        wss.handleUpgrade(request, socket, head, (ws) => {
            wss.emit('connection', ws, request);
        });
    } else if (pathname === '/chat-ws') {
        console.log('💬 Handling chat WebSocket upgrade');
        chatWss.handleUpgrade(request, socket, head, (ws) => {
            chatWss.emit('connection', ws, request);
        });
    } else {
        console.log('❌ Unknown WebSocket path, destroying socket');
        socket.destroy();
    }
});

chatWss.on('connection', (ws, req) => {
    console.log('✅ New browser chat connection established');
    console.log('📋 Client IP:', req.headers['x-forwarded-for'] || req.socket.remoteAddress);
    
    let chatSession = {
        sessionId: null,
        tenantId: null,
        language: 'en-IN',
        messages: []
    };
    
    ws.on('message', async (message) => {
        try {
            const msg = JSON.parse(message);
            
            switch (msg.type) {
                case 'init':
                    chatSession.sessionId = msg.sessionId || generateSessionId();
                    chatSession.tenantId = msg.tenantId || 1;
                    chatSession.language = msg.language || 'en-IN';
                    
                    console.log(`💬 Chat session initialized: ${chatSession.sessionId}`);
                    
                    ws.send(JSON.stringify({
                        type: 'ready',
                        sessionId: chatSession.sessionId
                    }));
                    break;
                    
                case 'text':
                    console.log(`💬 Text message: ${msg.content}`);
                    
                    try {
                        const response = await axios.post(`${LARAVEL_URL}/api/chat/message`, {
                            sessionId: chatSession.sessionId,
                            tenantId: chatSession.tenantId,
                            message: msg.content,
                            language: chatSession.language
                        });
                        
                        ws.send(JSON.stringify({
                            type: 'response',
                            content: response.data.response,
                            language: response.data.language,
                            audioUrl: response.data.audioUrl
                        }));
                    } catch (error) {
                        console.error('❌ Chat API error:', error.message);
                        ws.send(JSON.stringify({
                            type: 'error',
                            message: 'Failed to process message'
                        }));
                    }
                    break;
                    
                case 'audio':
                    console.log(`🎤 Voice message received`);
                    
                    try {
                        const audioData = Buffer.from(msg.audio, 'base64');
                        const audioPath = path.join(tmpdir(), `chat_audio_${Date.now()}.webm`);
                        await fs.writeFile(audioPath, audioData);
                        
                        console.log(`🎤 Sending audio to Laravel for processing...`);
                        
                        const response = await axios.post(`${LARAVEL_URL}/api/chat/voice`, {
                            sessionId: chatSession.sessionId,
                            tenantId: chatSession.tenantId,
                            audioPath: audioPath,
                            language: chatSession.language
                        }, {
                            timeout: 30000,
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        });
                        
                        console.log(`✅ Voice processed successfully, sending response to client`);
                        
                        ws.send(JSON.stringify({
                            type: 'response',
                            content: response.data.response,
                            transcript: response.data.transcript,
                            language: response.data.language,
                            audioUrl: response.data.audioUrl
                        }));
                        
                        await fs.unlink(audioPath).catch(() => {});
                    } catch (error) {
                        console.error('❌ Voice processing error:', error.message);
                        console.error('❌ Error details:', error.response?.data || error);
                        ws.send(JSON.stringify({
                            type: 'error',
                            message: 'Failed to process voice message'
                        }));
                    }
                    break;
            }
        } catch (error) {
            console.error('❌ Chat WebSocket error:', error.message);
        }
    });
    
    ws.on('close', () => {
        console.log(`💬 Chat session closed: ${chatSession.sessionId}`);
        if (chatSession.sessionId) {
            activeChatSessions.delete(chatSession.sessionId);
        }
    });
});

function generateSessionId() {
    return 'chat_' + Date.now() + '_' + Math.random().toString(36).substring(7);
}

// Proxy all other requests to Laravel (but skip WebSocket paths)
app.use((req, res, next) => {
    // Skip WebSocket paths
    if (req.url === '/ws' || req.url === '/chat-ws') {
        return next();
    }
    
    // Proxy everything else to Laravel
    createProxyMiddleware({
        target: LARAVEL_URL,
        changeOrigin: true,
        ws: false,
        onError: (err, req, res) => {
            console.error('Proxy error:', err);
            res.status(502).send('Laravel backend not available');
        }
    })(req, res, next);
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`\n✅ Combined Server running on port ${PORT}`);
    console.log(`🎙️  Twilio WebSocket: wss://[your-domain]/ws`);
    console.log(`💬 Browser Chat WebSocket: wss://[your-domain]/chat-ws`);
    console.log(`🔀 Proxying requests to Laravel on port ${LARAVEL_PORT}\n`);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down server...');
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});
