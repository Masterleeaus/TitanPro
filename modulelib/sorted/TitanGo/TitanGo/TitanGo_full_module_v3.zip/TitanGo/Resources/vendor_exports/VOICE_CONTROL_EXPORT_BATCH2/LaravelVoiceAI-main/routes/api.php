<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BusinessController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\MediaStreamApiController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\Api\V1\ConversationController;
use App\Http\Controllers\Api\CallSessionController;
use App\Http\Controllers\Api\TenantAIController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::prefix('media-stream')->group(function () {
    Route::post('/process', [MediaStreamApiController::class, 'processTranscript']);
});

Route::get('/tenants/{tenantId}/language', [MediaStreamApiController::class, 'getTenantLanguage']);
Route::get('/tenants/{tenantId}/ai-config', [TenantAIController::class, 'getConfiguration']);

Route::prefix('chat')->group(function () {
    Route::post('/message', [ChatController::class, 'handleMessage']);
    Route::post('/voice', [ChatController::class, 'handleVoice']);
    Route::get('/history/{sessionId}', [ChatController::class, 'getHistory']);
});

// Call session tracking endpoints (protected with auth + tenant middleware)
Route::prefix('calls')->middleware(['auth', \App\Http\Middleware\EnsureTenantUser::class])->group(function () {
    Route::post('/start', [CallSessionController::class, 'start']);
    Route::post('/{sessionId}/update', [CallSessionController::class, 'update']);
    Route::post('/{sessionId}/end', [CallSessionController::class, 'end']);
    Route::get('/{sessionId}', [CallSessionController::class, 'show']);
});

Route::prefix('v1')->middleware('api.key')->group(function () {
    Route::post('/chat', [ConversationController::class, 'sendMessage']);
    Route::post('/voice', [ConversationController::class, 'sendVoice']);
    Route::get('/conversations', [ConversationController::class, 'getConversations']);
    Route::get('/conversations/{sessionId}', [ConversationController::class, 'getConversation']);
});

Route::prefix('businesses')->middleware('auth:sanctum')->group(function () {
    Route::get('/', [BusinessController::class, 'index']);
    Route::post('/', [BusinessController::class, 'store']);
    Route::get('/{id}', [BusinessController::class, 'show']);
    Route::put('/{id}', [BusinessController::class, 'update']);
    Route::delete('/{id}', [BusinessController::class, 'destroy']);
    
    Route::get('/{id}/orders', [BusinessController::class, 'orders']);
    Route::get('/{id}/appointments', [BusinessController::class, 'appointments']);
    
    Route::prefix('/{businessId}/menus')->group(function () {
        Route::get('/', [MenuController::class, 'index']);
        Route::post('/', [MenuController::class, 'store']);
        Route::put('/{id}', [MenuController::class, 'update']);
        Route::delete('/{id}', [MenuController::class, 'destroy']);
    });
});
