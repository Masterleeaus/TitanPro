<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Voice Assistant - Test Chat</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 h-screen flex flex-col">
    <div class="bg-blue-600 text-white p-4 shadow-lg">
        <h1 class="text-2xl font-bold">🤖 AI Voice Assistant - Test Chat</h1>
        <p class="text-sm opacity-90">Test your multilingual AI assistant (supports Tamil, Hindi, English, Mandarin, Malay, Indonesian, Thai)</p>
    </div>

    <div class="flex-1 flex flex-col max-w-4xl mx-auto w-full p-4">
        <div id="chatMessages" class="flex-1 bg-white rounded-lg shadow-lg p-4 overflow-y-auto mb-4 space-y-3">
            <div class="text-center text-gray-500 py-8">
                <p class="text-lg">👋 Start a conversation!</p>
                <p class="text-sm mt-2">Try speaking in different languages - the AI will detect and respond accordingly</p>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-lg p-4">
            <div class="flex gap-2 mb-3">
                <input 
                    type="text" 
                    id="messageInput" 
                    placeholder="Type your message here..."
                    class="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    onkeypress="if(event.key === 'Enter') sendMessage()"
                >
                <button 
                    onclick="sendMessage()"
                    class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
                    Send
                </button>
                <button 
                    id="voiceBtn"
                    onclick="toggleVoiceRecording()"
                    class="bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 transition">
                    🎤 Record
                </button>
            </div>
            
            <div class="flex gap-2">
                <select id="languageSelect" class="px-3 py-2 border border-gray-300 rounded-lg text-sm">
                    <option value="en-IN">English</option>
                    <option value="ta-IN">Tamil (தமிழ்)</option>
                    <option value="hi-IN">Hindi (हिंदी)</option>
                    <option value="cmn-CN">Mandarin (中文)</option>
                    <option value="ms-MY">Malay</option>
                    <option value="id-ID">Indonesian</option>
                    <option value="th-TH">Thai (ไทย)</option>
                </select>
                <span id="status" class="flex-1 text-sm text-gray-600 flex items-center px-3"></span>
            </div>
        </div>
    </div>

    <script>
        let ws = null;
        let sessionId = 'test_' + Date.now();
        let isRecording = false;
        let mediaRecorder = null;
        let audioChunks = [];

        function connectWebSocket() {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}/chat-ws`;
            
            updateStatus('Connecting...');
            ws = new WebSocket(wsUrl);

            ws.onopen = () => {
                console.log('WebSocket connected');
                updateStatus('Connected ✅');
                
                ws.send(JSON.stringify({
                    type: 'init',
                    sessionId: sessionId,
                    tenantId: 1,
                    language: document.getElementById('languageSelect').value
                }));
            };

            ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                console.log('Received:', data);

                switch(data.type) {
                    case 'ready':
                        updateStatus('Ready to chat 💬');
                        break;
                    case 'response':
                        addMessage(data.content, 'assistant', data.language);
                        if (data.audioUrl) {
                            playAudio(data.audioUrl);
                        }
                        if (data.transcript) {
                            console.log('Transcript:', data.transcript);
                        }
                        break;
                    case 'error':
                        updateStatus('Error: ' + data.message);
                        break;
                }
            };

            ws.onerror = (error) => {
                console.error('WebSocket error:', error);
                updateStatus('Connection error ❌');
            };

            ws.onclose = () => {
                updateStatus('Disconnected. Reconnecting...');
                setTimeout(connectWebSocket, 3000);
            };
        }

        function sendMessage() {
            const input = document.getElementById('messageInput');
            const message = input.value.trim();
            
            if (!message || !ws || ws.readyState !== WebSocket.OPEN) return;

            addMessage(message, 'user');
            
            ws.send(JSON.stringify({
                type: 'text',
                content: message
            }));

            input.value = '';
        }

        async function toggleVoiceRecording() {
            const btn = document.getElementById('voiceBtn');
            
            if (!isRecording) {
                try {
                    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                    mediaRecorder = new MediaRecorder(stream);
                    audioChunks = [];

                    mediaRecorder.ondataavailable = (event) => {
                        audioChunks.push(event.data);
                    };

                    mediaRecorder.onstop = async () => {
                        const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                        const reader = new FileReader();
                        
                        reader.onload = () => {
                            const base64Audio = reader.result.split(',')[1];
                            
                            if (ws && ws.readyState === WebSocket.OPEN) {
                                addMessage('🎤 Voice message sent', 'user');
                                ws.send(JSON.stringify({
                                    type: 'audio',
                                    audio: base64Audio
                                }));
                            }
                        };
                        
                        reader.readAsDataURL(audioBlob);
                        
                        stream.getTracks().forEach(track => track.stop());
                    };

                    mediaRecorder.start();
                    isRecording = true;
                    btn.textContent = '⏹️ Stop';
                    btn.classList.replace('bg-red-600', 'bg-gray-600');
                    updateStatus('Recording... 🎤');
                } catch (error) {
                    console.error('Error accessing microphone:', error);
                    updateStatus('Microphone access denied ❌');
                }
            } else {
                mediaRecorder.stop();
                isRecording = false;
                btn.textContent = '🎤 Record';
                btn.classList.replace('bg-gray-600', 'bg-red-600');
                updateStatus('Processing...');
            }
        }

        function addMessage(content, role, language = '') {
            const messagesDiv = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            
            const isUser = role === 'user';
            const langLabel = language ? ` (${language})` : '';
            
            messageDiv.className = `flex ${isUser ? 'justify-end' : 'justify-start'}`;
            messageDiv.innerHTML = `
                <div class="${isUser ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'} rounded-lg px-4 py-2 max-w-md">
                    <div class="text-xs opacity-75 mb-1">${isUser ? 'You' : 'AI'}${langLabel}</div>
                    <div>${content}</div>
                </div>
            `;
            
            messagesDiv.appendChild(messageDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }

        function playAudio(url) {
            const audio = new Audio(url);
            audio.play().catch(e => console.error('Audio playback error:', e));
        }

        function updateStatus(message) {
            document.getElementById('status').textContent = message;
        }

        connectWebSocket();
    </script>
</body>
</html>
