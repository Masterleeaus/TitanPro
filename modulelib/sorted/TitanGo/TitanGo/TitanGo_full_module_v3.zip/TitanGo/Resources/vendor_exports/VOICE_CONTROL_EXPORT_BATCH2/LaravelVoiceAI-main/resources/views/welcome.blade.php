<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VoiceAI - Multi-Tenant Voice Assistant Platform</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 50%, #1a1a1a 100%);
            min-height: 100vh;
            color: #fff;
        }
        nav { 
            background: rgba(31, 41, 55, 0.5);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid #374151;
        }
        .container { max-width: 1280px; margin: 0 auto; padding: 0 1.5rem; }
        .nav-content { display: flex; justify-content: space-between; align-items: center; height: 4rem; }
        .logo { font-size: 1.5rem; font-weight: bold; }
        .btn { 
            padding: 0.5rem 1.5rem; 
            border-radius: 0.5rem; 
            text-decoration: none;
            font-weight: 600;
            transition: all 0.2s;
        }
        .btn-primary { 
            background: #3b82f6; 
            color: #fff;
        }
        .btn-primary:hover { background: #2563eb; transform: scale(1.05); }
        .hero { text-align: center; padding: 4rem 0; }
        .hero h2 { font-size: 3rem; font-weight: 800; margin-bottom: 1.5rem; }
        .hero .blue { color: #3b82f6; }
        .hero p { font-size: 1.25rem; color: #d1d5db; max-width: 48rem; margin: 0 auto 3rem; }
        .features { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
            gap: 2rem; 
            margin: 4rem 0;
        }
        .card { 
            background: rgba(31, 41, 55, 0.5);
            backdrop-filter: blur(10px);
            padding: 2rem;
            border-radius: 1rem;
            border: 1px solid #374151;
            text-align: center;
        }
        .card-icon { font-size: 3rem; margin-bottom: 1rem; }
        .card h3 { font-size: 1.25rem; font-weight: bold; margin-bottom: 0.75rem; }
        .card p { color: #d1d5db; }
        .demo-section { 
            background: rgba(31, 41, 55, 0.3);
            backdrop-filter: blur(10px);
            padding: 2rem;
            border-radius: 1rem;
            border: 1px solid #374151;
            margin: 5rem 0;
        }
        .demo-section h3 { font-size: 2rem; font-weight: bold; text-align: center; margin-bottom: 2rem; }
        .demo-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
            gap: 1.5rem;
        }
        .demo-card { 
            background: rgba(17, 24, 39, 0.5);
            padding: 1.5rem;
            border-radius: 0.75rem;
            border: 1px solid #4b5563;
            transition: all 0.2s;
        }
        .demo-card:hover { border-color: #3b82f6; transform: translateY(-2px); }
        .demo-icon { font-size: 2rem; text-align: center; margin-bottom: 0.75rem; }
        .demo-card h4 { font-weight: bold; text-align: center; margin-bottom: 0.5rem; }
        .demo-card .subtitle { font-size: 0.875rem; color: #9ca3af; text-align: center; margin-bottom: 1rem; }
        .credentials { 
            background: #1f2937;
            padding: 0.75rem;
            border-radius: 0.5rem;
        }
        .credentials code { 
            display: block;
            font-size: 0.75rem;
            margin: 0.25rem 0;
        }
        .email { color: #60a5fa; }
        .password { color: #9ca3af; }
        .cta-center { text-align: center; margin-top: 2rem; }
        .btn-large { 
            display: inline-block;
            padding: 1rem 2rem; 
            font-size: 1.125rem;
            background: #3b82f6;
            color: #fff;
            text-decoration: none;
            border-radius: 0.5rem;
            font-weight: 600;
            box-shadow: 0 10px 15px -3px rgba(0,0,0,0.5);
        }
        .btn-large:hover { background: #2563eb; transform: scale(1.05); }
        .tech-stack { text-align: center; margin: 4rem 0; }
        .tech-stack h4 { color: #9ca3af; font-size: 1.125rem; margin-bottom: 1rem; }
        .tech-list { display: flex; flex-wrap: wrap; justify-content: center; gap: 1rem; }
        .tech-item { 
            background: rgba(31, 41, 55, 0.5);
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            font-size: 0.875rem;
            color: #9ca3af;
        }
        footer { 
            border-top: 1px solid #374151;
            margin-top: 5rem;
            padding: 2rem 0;
            text-align: center;
            color: #9ca3af;
        }
    </style>
</head>
<body>
    <nav>
        <div class="container">
            <div class="nav-content">
                <div class="logo">🎤 VoiceAI Platform</div>
                <div>
                    @auth
                        <a href="{{ route('dashboard') }}" class="btn btn-primary">Dashboard</a>
                    @else
                        <a href="{{ route('login') }}" class="btn btn-primary">Login</a>
                    @endauth
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="hero">
            <h2>AI-Powered Voice Assistant<br/><span class="blue">For Your Business</span></h2>
            <p>Multi-tenant SaaS platform using Twilio Voice & SMS, OpenAI GPT-4, and Whisper. Perfect for restaurants, salons, hotels, and any business that needs intelligent voice automation.</p>
            <a href="{{ route('login') }}" class="btn btn-large">Login to Dashboard →</a>
        </div>

        <div class="features">
            <div class="card">
                <div class="card-icon">🍕</div>
                <h3>Restaurants</h3>
                <p>Automated order taking via phone calls with menu integration and multilingual support.</p>
            </div>
            <div class="card">
                <div class="card-icon">💆</div>
                <h3>Salons & Spas</h3>
                <p>Appointment booking, SMS reminders, and service scheduling powered by AI.</p>
            </div>
            <div class="card">
                <div class="card-icon">🏨</div>
                <h3>Hotels</h3>
                <p>Room reservations, concierge services, and guest support in any language.</p>
            </div>
        </div>

        <div class="demo-section">
            <h3>🔐 Demo Logins</h3>
            <div class="demo-grid">
                <div class="demo-card">
                    <div class="demo-icon">👨‍💼</div>
                    <h4>Super Admin</h4>
                    <div class="subtitle">Full system access</div>
                    <div class="credentials">
                        <code class="email">admin@voiceai.com</code>
                        <code class="password">admin123</code>
                    </div>
                </div>
                <div class="demo-card">
                    <div class="demo-icon">🍕</div>
                    <h4>Joe's Pizza</h4>
                    <div class="subtitle">Restaurant (Pro Plan)</div>
                    <div class="credentials">
                        <code class="email">joe@joespizza.com</code>
                        <code class="password">pizza123</code>
                    </div>
                </div>
                <div class="demo-card">
                    <div class="demo-icon">💆</div>
                    <h4>Serenity Spa</h4>
                    <div class="subtitle">Salon (Basic Plan)</div>
                    <div class="credentials">
                        <code class="email">sarah@serenityspa.com</code>
                        <code class="password">spa123</code>
                    </div>
                </div>
                <div class="demo-card">
                    <div class="demo-icon">🏨</div>
                    <h4>Grand Vista Hotel</h4>
                    <div class="subtitle">Hotel (Enterprise)</div>
                    <div class="credentials">
                        <code class="email">mike@grandvista.com</code>
                        <code class="password">hotel123</code>
                    </div>
                </div>
            </div>
            <div class="cta-center">
                <a href="{{ route('login') }}" class="btn btn-large">Try a Demo Login →</a>
            </div>
        </div>

        <div class="tech-stack">
            <h4>Powered By</h4>
            <div class="tech-list">
                <span class="tech-item">Laravel</span>
                <span class="tech-item">Twilio Voice/SMS</span>
                <span class="tech-item">OpenAI GPT-4</span>
                <span class="tech-item">Whisper API</span>
                <span class="tech-item">PostgreSQL</span>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <p>Multi-Tenant Voice Assistant SaaS Platform - Built with Laravel, Twilio, and OpenAI</p>
        </div>
    </footer>
</body>
</html>
