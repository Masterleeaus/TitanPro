<?php

namespace App\Services;

use Twilio\Rest\Client;
use Twilio\TwiML\VoiceResponse;
use Twilio\TwiML\MessagingResponse;
use App\Models\TenantSetting;

class TwilioService
{
    protected $client;
    protected $accountSid;
    protected $phoneNumber;
    protected $authToken;
    protected $tenantSettings;

    public function __construct($tenantId = null)
    {
        if ($tenantId) {
            $this->initializeForTenant($tenantId);
        } else {
            $this->initializeFromReplit();
        }
    }

    protected function initializeForTenant($tenantId)
    {
        $this->tenantSettings = TenantSetting::where('tenant_id', $tenantId)->first();
        
        if (!$this->tenantSettings || !$this->tenantSettings->twilio_account_sid) {
            return;
        }

        $this->accountSid = $this->tenantSettings->twilio_account_sid;
        $this->authToken = $this->tenantSettings->twilio_auth_token;
        $this->phoneNumber = $this->tenantSettings->twilio_phone_number;

        $this->client = new Client($this->accountSid, $this->authToken);
    }

    protected function initializeFromReplit()
    {
        $credentials = $this->getReplitCredentials();
        
        if (!$credentials) {
            $this->initializeFromEnv();
            return;
        }

        $this->accountSid = $credentials['accountSid'];
        $this->authToken = $credentials['authToken'];
        $this->phoneNumber = $credentials['phoneNumber'];

        $this->client = new Client($credentials['apiKey'], $credentials['apiKeySecret'], $this->accountSid);
    }

    protected function initializeFromEnv()
    {
        $this->accountSid = env('TWILIO_ACCOUNT_SID');
        $this->authToken = env('TWILIO_AUTH_TOKEN');
        $this->phoneNumber = env('TWILIO_PHONE_NUMBER');

        if ($this->accountSid && $this->authToken) {
            $this->client = new Client($this->accountSid, $this->authToken);
        }
    }

    protected function getReplitCredentials()
    {
        $hostname = env('REPLIT_CONNECTORS_HOSTNAME');
        $xReplitToken = env('REPL_IDENTITY') 
            ? 'repl ' . env('REPL_IDENTITY')
            : (env('WEB_REPL_RENEWAL') ? 'depl ' . env('WEB_REPL_RENEWAL') : null);

        if (!$xReplitToken || !$hostname) {
            return null;
        }

        try {
            $response = file_get_contents(
                'https://' . $hostname . '/api/v2/connection?include_secrets=true&connector_names=twilio',
                false,
                stream_context_create([
                    'http' => [
                        'header' => "Accept: application/json\r\nX_REPLIT_TOKEN: " . $xReplitToken
                    ]
                ])
            );

            $data = json_decode($response, true);
            $connectionSettings = $data['items'][0] ?? null;

            if (!$connectionSettings) {
                return null;
            }

            return [
                'accountSid' => $connectionSettings['settings']['account_sid'],
                'apiKey' => $connectionSettings['settings']['api_key'],
                'apiKeySecret' => $connectionSettings['settings']['api_key_secret'],
                'phoneNumber' => $connectionSettings['settings']['phone_number'],
                'authToken' => $connectionSettings['settings']['auth_token'] ?? $connectionSettings['settings']['api_key_secret']
            ];
        } catch (\Exception $e) {
            return null;
        }
    }

    public function sendSms($to, $message)
    {
        if (!$this->client) {
            throw new \Exception('Twilio client not initialized');
        }

        return $this->client->messages->create($to, [
            'from' => $this->phoneNumber,
            'body' => $message
        ]);
    }

    public function makeCall($to, $twimlUrl)
    {
        if (!$this->client) {
            throw new \Exception('Twilio client not initialized');
        }

        return $this->client->calls->create($to, $this->phoneNumber, [
            'url' => $twimlUrl
        ]);
    }

    public function createVoiceResponse()
    {
        return new VoiceResponse();
    }

    public function createMessagingResponse()
    {
        return new MessagingResponse();
    }

    public function getFromPhoneNumber()
    {
        return $this->phoneNumber;
    }

    public function getAuthToken()
    {
        return $this->authToken;
    }

    public function fetchRecording($recordingSid)
    {
        if (!$this->client) {
            throw new \Exception('Twilio client not initialized');
        }

        $recording = $this->client->recordings($recordingSid)->fetch();
        $mediaUrl = str_replace('.json', '.wav', 'https://api.twilio.com' . $recording->uri);
        
        $context = stream_context_create([
            'http' => [
                'header' => "Authorization: Basic " . base64_encode($this->accountSid . ':' . $this->authToken)
            ]
        ]);

        return file_get_contents($mediaUrl, false, $context);
    }

    public static function getTenantByPhoneNumber($phoneNumber)
    {
        $settings = TenantSetting::where('twilio_phone_number', $phoneNumber)->first();
        return $settings ? $settings->tenant_id : null;
    }

    public function getAccountBalance()
    {
        if (!$this->client || !$this->accountSid) {
            return null;
        }

        try {
            $balance = $this->client->api->v2010->accounts($this->accountSid)->balance->fetch();
            $account = $this->client->api->v2010->accounts($this->accountSid)->fetch();
            
            return [
                'balance' => floatval($balance->balance),
                'currency' => $balance->currency ?? 'USD',
                'status' => $account->status,
                'friendly_name' => $account->friendlyName ?? 'Twilio Account'
            ];
        } catch (\Exception $e) {
            \Log::error('Failed to fetch Twilio account balance: ' . $e->getMessage());
            return null;
        }
    }
}
