import 'dotenv/config';
import { WebSocketServer } from 'ws';
import speech from '@google-cloud/speech';
import axios from 'axios';

const PORT = process.env.MEDIA_STREAM_PORT || 8081;
const LARAVEL_API_URL = process.env.APP_URL || 'http://localhost:5000';

const wss = new WebSocketServer({ 
    port: PORT,
    verifyClient: (info, callback) => {
        console.log('🔍 WebSocket connection attempt from:', info.origin || 'unknown');
        callback(true);
    }
});

wss.on('error', (error) => {
    console.error('❌ WebSocket Server Error:', error);
});

wss.on('listening', () => {
    console.log(`🎙️  Media Stream WebSocket Server running on port ${PORT}`);
    console.log(`📡 Laravel API: ${LARAVEL_API_URL}`);
    console.log(`🔗 Listening for connections...`);
});

// Store active call sessions
const activeCalls = new Map();

wss.on('connection', (ws, req) => {
    console.log('📞 New Twilio Media Stream connection from:', req.socket.remoteAddress);
    console.log('📋 Headers:', req.headers);
    
    let callSession = {
        streamSid: null,
        callSid: null,
        recognizeStream: null,
        conversationHistory: [],
        tenantId: null,
        detectedLanguage: null,
        audioBuffer: Buffer.alloc(0),
        lastTranscriptTime: Date.now()
    };

    ws.on('message', async (message) => {
        try {
            const msg = JSON.parse(message);
            
            switch (msg.event) {
                case 'connected':
                    console.log('✅ Twilio connected');
                    break;
                    
                case 'start':
                    console.log('🎬 Stream started:', msg.start.streamSid);
                    callSession.streamSid = msg.start.streamSid;
                    callSession.callSid = msg.start.callSid;
                    
                    // Extract tenant info from custom parameters
                    if (msg.start.customParameters) {
                        callSession.tenantId = msg.start.customParameters.tenantId;
                        callSession.from = msg.start.customParameters.from;
                        callSession.to = msg.start.customParameters.to;
                    }
                    
                    // Initialize Google Speech-to-Text
                    const client = new speech.SpeechClient();
                    
                    const request = {
                        config: {
                            encoding: 'MULAW',
                            sampleRateHertz: 8000,
                            languageCode: 'en-IN',
                            alternativeLanguageCodes: [
                                'ta-IN', 'hi-IN', 'cmn-CN', 
                                'ms-MY', 'id-ID', 'th-TH', 'en-US'
                            ],
                            enableAutomaticPunctuation: true,
                            model: 'phone_call',
                        },
                        interimResults: false,
                    };
                    
                    callSession.recognizeStream = client
                        .streamingRecognize(request)
                        .on('error', (error) => {
                            console.error('❌ Speech recognition error:', error);
                        })
                        .on('data', async (data) => {
                            const result = data.results[0];
                            if (result && result.alternatives[0]) {
                                const transcript = result.alternatives[0].transcript;
                                const detectedLang = result.languageCode || 'en-IN';
                                
                                console.log(`🗣️  Detected (${detectedLang}): ${transcript}`);
                                
                                callSession.detectedLanguage = detectedLang;
                                callSession.lastTranscriptTime = Date.now();
                                
                                // Call Laravel API to process speech
                                await processTranscript(ws, callSession, transcript, detectedLang);
                            }
                        });
                    
                    activeCalls.set(msg.start.streamSid, callSession);
                    break;
                    
                case 'media':
                    if (callSession.recognizeStream) {
                        // Decode audio payload (base64 mulaw)
                        const audioChunk = Buffer.from(msg.media.payload, 'base64');
                        
                        // Send to Google Speech-to-Text
                        callSession.recognizeStream.write({
                            audioContent: audioChunk
                        });
                        
                        // Buffer audio for later playback if needed
                        callSession.audioBuffer = Buffer.concat([
                            callSession.audioBuffer, 
                            audioChunk
                        ]);
                        
                        // Limit buffer size to 30 seconds
                        const maxBufferSize = 8000 * 30; // 30 seconds at 8kHz
                        if (callSession.audioBuffer.length > maxBufferSize) {
                            callSession.audioBuffer = callSession.audioBuffer.slice(-maxBufferSize);
                        }
                    }
                    break;
                    
                case 'stop':
                    console.log('🛑 Stream stopped');
                    if (callSession.recognizeStream) {
                        callSession.recognizeStream.end();
                    }
                    activeCalls.delete(callSession.streamSid);
                    break;
            }
        } catch (error) {
            console.error('❌ Error processing message:', error);
        }
    });

    ws.on('close', () => {
        console.log('📴 WebSocket connection closed');
        if (callSession.recognizeStream) {
            callSession.recognizeStream.end();
        }
        if (callSession.streamSid) {
            activeCalls.delete(callSession.streamSid);
        }
    });

    ws.on('error', (error) => {
        console.error('❌ WebSocket error:', error);
    });
});

async function processTranscript(ws, session, transcript, detectedLanguage) {
    try {
        // Normalize language codes
        const languageMap = {
            'ta-IN': 'ta-IN',
            'en-IN': 'en-IN',
            'en-US': 'en-IN',
            'en-GB': 'en-IN',
            'hi-IN': 'hi-IN',
            'cmn-CN': 'cmn-CN',
            'zh-CN': 'cmn-CN',
            'ms-MY': 'ms-MY',
            'id-ID': 'id-ID',
            'th-TH': 'th-TH',
        };
        
        const normalizedLang = languageMap[detectedLanguage] || 'en-IN';
        
        // Add to conversation history
        session.conversationHistory.push({
            role: 'customer',
            content: transcript,
            language: normalizedLang,
            timestamp: new Date().toISOString()
        });
        
        // Call Laravel API for AI response
        console.log(`📤 Calling Laravel API for response...`);
        
        const response = await axios.post(`${LARAVEL_API_URL}/api/media-stream/process`, {
            callSid: session.callSid,
            streamSid: session.streamSid,
            tenantId: session.tenantId,
            from: session.from,
            to: session.to,
            transcript: transcript,
            detectedLanguage: normalizedLang,
            conversationHistory: session.conversationHistory
        }, {
            timeout: 15000,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });
        
        const { aiResponse, audioUrl, closingMessage, closingAudioUrl } = response.data;
        
        console.log(`🤖 AI Response (${normalizedLang}): ${aiResponse}`);
        
        // Add AI response to history
        session.conversationHistory.push({
            role: 'assistant',
            content: aiResponse,
            language: normalizedLang,
            timestamp: new Date().toISOString()
        });
        
        // Stream audio back to Twilio
        if (audioUrl) {
            await streamAudioToTwilio(ws, session.streamSid, audioUrl);
        }
        
        // Play closing message if needed
        if (closingAudioUrl && session.conversationHistory.length > 6) {
            await streamAudioToTwilio(ws, session.streamSid, closingAudioUrl);
            
            // Hang up after closing message
            setTimeout(() => {
                ws.close();
            }, 2000);
        }
        
    } catch (error) {
        console.error('❌ Error processing transcript:', error.message);
        if (error.response) {
            console.error('Response data:', error.response.data);
        }
    }
}

async function streamAudioToTwilio(ws, streamSid, audioUrl) {
    try {
        // Download audio file
        const audioResponse = await axios.get(audioUrl, {
            responseType: 'arraybuffer'
        });
        
        const audioBuffer = Buffer.from(audioResponse.data);
        
        // Convert to mulaw if needed (assuming Google TTS returns compatible format)
        // For now, we'll use the audio as-is since Google TTS can output mulaw
        
        // Split audio into chunks and send to Twilio
        const chunkSize = 160; // 20ms at 8kHz
        
        for (let i = 0; i < audioBuffer.length; i += chunkSize) {
            const chunk = audioBuffer.slice(i, i + chunkSize);
            const payload = chunk.toString('base64');
            
            const message = {
                event: 'media',
                streamSid: streamSid,
                media: {
                    track: 'outbound',
                    payload: payload
                }
            };
            
            ws.send(JSON.stringify(message));
            
            // Small delay to match realtime playback
            await new Promise(resolve => setTimeout(resolve, 20));
        }
        
        // Send mark to indicate completion
        ws.send(JSON.stringify({
            event: 'mark',
            streamSid: streamSid,
            mark: {
                name: 'audio_complete_' + Date.now()
            }
        }));
        
        console.log('✅ Audio streamed to Twilio');
        
    } catch (error) {
        console.error('❌ Error streaming audio:', error.message);
    }
}

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down Media Stream server...');
    wss.close(() => {
        console.log('✅ Server closed');
        process.exit(0);
    });
});

process.on('SIGTERM', () => {
    console.log('\n🛑 Shutting down Media Stream server...');
    wss.close(() => {
        console.log('✅ Server closed');
        process.exit(0);
    });
});
