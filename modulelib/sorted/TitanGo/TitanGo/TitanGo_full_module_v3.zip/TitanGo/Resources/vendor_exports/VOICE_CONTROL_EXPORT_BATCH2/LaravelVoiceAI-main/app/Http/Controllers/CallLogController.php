<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CallLog;
use Illuminate\Support\Facades\Auth;

class CallLogController extends Controller
{
    public function index(Request $request)
    {
        $tenant = Auth::user()->tenant;
        
        $query = CallLog::where('tenant_id', $tenant->id)
            ->with('business');

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('direction')) {
            $query->where('direction', $request->direction);
        }

        if ($request->filled('language')) {
            $query->where('language_code', $request->language);
        }

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('from_number', 'like', '%' . $request->search . '%')
                  ->orWhere('transcription', 'like', '%' . $request->search . '%')
                  ->orWhere('ai_summary', 'like', '%' . $request->search . '%');
            });
        }

        $callLogs = $query->orderBy('created_at', 'desc')
            ->paginate(20)
            ->appends($request->all());

        $totalCost = CallLog::where('tenant_id', $tenant->id)->sum('total_cost');
        
        $languages = CallLog::where('tenant_id', $tenant->id)
            ->whereNotNull('language_code')
            ->distinct()
            ->pluck('language_code');

        return view('tenant.call-logs', compact('callLogs', 'totalCost', 'languages'));
    }

    public function show($id)
    {
        $tenant = Auth::user()->tenant;
        
        $callLog = CallLog::where('tenant_id', $tenant->id)
            ->with('business')
            ->findOrFail($id);

        return view('tenant.call-log-detail', compact('callLog'));
    }
}
