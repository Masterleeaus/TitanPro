<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\TenantSetting;

class AIConfigurationController extends Controller
{
    public function index()
    {
        $tenant = Auth::user()->tenant;
        $tenantId = $tenant->id;

        $settings = TenantSetting::where('tenant_id', $tenantId)->first();
        
        if (!$settings) {
            $settings = TenantSetting::create(['tenant_id' => $tenantId]);
        }

        return view('tenant.ai-configuration', compact('tenant', 'settings'));
    }

    public function update(Request $request)
    {
        $tenant = Auth::user()->tenant;
        
        $validated = $request->validate([
            'system_prompt' => 'nullable|string|max:5000',
            'business_type' => 'nullable|string|in:general,restaurant,medical,hotel,retail,support',
            'business_context' => 'nullable|string|max:3000',
            'voice_tone' => 'nullable|string|in:professional,friendly,formal,enthusiastic',
            'operating_hours' => 'nullable|string|max:255',
            'default_language' => 'nullable|string|max:10',
        ]);

        $settings = TenantSetting::where('tenant_id', $tenant->id)->first();
        
        if (!$settings) {
            $settings = TenantSetting::create(['tenant_id' => $tenant->id]);
        }

        $settings->update($validated);

        return redirect()->route('ai-configuration.index')
            ->with('success', 'AI assistant configuration updated successfully!');
    }
}
