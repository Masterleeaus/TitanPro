<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CallCostEvent extends Model
{
    protected $connection = 'pgsql';
    
    protected $fillable = [
        'call_session_id',
        'vendor',
        'event_type',
        'units',
        'unit_type',
        'unit_price',
        'cost',
        'metadata',
    ];

    protected $casts = [
        'unit_price' => 'decimal:8',
        'cost' => 'decimal:6',
        'metadata' => 'array',
    ];

    public function callSession(): BelongsTo
    {
        return $this->belongsTo(CallSession::class);
    }
}
