<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VoiceConfiguration extends Model
{
    protected $fillable = [
        'tenant_id',
        'name',
        'language_code',
        'voice_name',
        'gender',
        'speaking_rate',
        'pitch',
        'is_default',
        'priority',
    ];

    protected $casts = [
        'speaking_rate' => 'float',
        'pitch' => 'float',
        'is_default' => 'boolean',
        'priority' => 'integer',
    ];

    protected static function boot()
    {
        parent::boot();

        static::saving(function ($config) {
            if ($config->is_default && $config->isDirty('is_default')) {
                $query = static::where('tenant_id', $config->tenant_id);
                
                if ($config->exists) {
                    $query->where('id', '!=', $config->id);
                }
                
                $query->update(['is_default' => false]);
            }
        });
    }

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public static function getAvailableVoices()
    {
        return [
            'ta-IN' => [
                'female' => [
                    'ta-IN-Wavenet-A' => 'Tamil Female - Natural & Conversational (Premium)',
                    'ta-IN-Wavenet-C' => 'Tamil Female - Warm & Friendly (Premium)',
                    'ta-IN-Standard-A' => 'Tamil Female - Clear & Professional (Standard)',
                    'ta-IN-Standard-C' => 'Tamil Female - Calm & Gentle (Standard)',
                ],
                'male' => [
                    'ta-IN-Wavenet-B' => 'Tamil Male - Natural & Confident (Premium)',
                    'ta-IN-Wavenet-D' => 'Tamil Male - Deep & Authoritative (Premium)',
                    'ta-IN-Standard-B' => 'Tamil Male - Clear & Professional (Standard)',
                    'ta-IN-Standard-D' => 'Tamil Male - Steady & Reliable (Standard)',
                ],
            ],
            'en-IN' => [
                'female' => [
                    'en-IN-Wavenet-A' => 'English Female - Natural & Conversational (Premium)',
                    'en-IN-Wavenet-C' => 'English Female - Warm & Friendly (Premium)',
                    'en-IN-Standard-A' => 'English Female - Clear & Professional (Standard)',
                    'en-IN-Standard-C' => 'English Female - Calm & Gentle (Standard)',
                ],
                'male' => [
                    'en-IN-Wavenet-B' => 'English Male - Natural & Confident (Premium)',
                    'en-IN-Wavenet-D' => 'English Male - Deep & Authoritative (Premium)',
                    'en-IN-Standard-B' => 'English Male - Clear & Professional (Standard)',
                    'en-IN-Standard-D' => 'English Male - Steady & Reliable (Standard)',
                ],
            ],
            'cmn-CN' => [
                'female' => [
                    'cmn-CN-Wavenet-A' => 'Mandarin Female - Natural & Conversational (Premium)',
                    'cmn-CN-Wavenet-C' => 'Mandarin Female - Warm & Friendly (Premium)',
                    'cmn-CN-Standard-A' => 'Mandarin Female - Clear & Professional (Standard)',
                    'cmn-CN-Standard-C' => 'Mandarin Female - Calm & Gentle (Standard)',
                ],
                'male' => [
                    'cmn-CN-Wavenet-B' => 'Mandarin Male - Natural & Confident (Premium)',
                    'cmn-CN-Wavenet-D' => 'Mandarin Male - Deep & Authoritative (Premium)',
                    'cmn-CN-Standard-B' => 'Mandarin Male - Clear & Professional (Standard)',
                    'cmn-CN-Standard-D' => 'Mandarin Male - Steady & Reliable (Standard)',
                ],
            ],
            'ms-MY' => [
                'female' => [
                    'ms-MY-Wavenet-A' => 'Malay Female - Natural & Conversational (Premium)',
                    'ms-MY-Wavenet-C' => 'Malay Female - Warm & Friendly (Premium)',
                    'ms-MY-Standard-A' => 'Malay Female - Clear & Professional (Standard)',
                    'ms-MY-Standard-C' => 'Malay Female - Calm & Gentle (Standard)',
                ],
                'male' => [
                    'ms-MY-Wavenet-B' => 'Malay Male - Natural & Confident (Premium)',
                    'ms-MY-Wavenet-D' => 'Malay Male - Deep & Authoritative (Premium)',
                    'ms-MY-Standard-B' => 'Malay Male - Clear & Professional (Standard)',
                    'ms-MY-Standard-D' => 'Malay Male - Steady & Reliable (Standard)',
                ],
            ],
            'hi-IN' => [
                'female' => [
                    'hi-IN-Wavenet-A' => 'Hindi Female - Natural & Conversational (Premium)',
                    'hi-IN-Wavenet-D' => 'Hindi Female - Warm & Friendly (Premium)',
                    'hi-IN-Standard-A' => 'Hindi Female - Clear & Professional (Standard)',
                    'hi-IN-Standard-D' => 'Hindi Female - Calm & Gentle (Standard)',
                ],
                'male' => [
                    'hi-IN-Wavenet-B' => 'Hindi Male - Natural & Confident (Premium)',
                    'hi-IN-Wavenet-C' => 'Hindi Male - Deep & Authoritative (Premium)',
                    'hi-IN-Standard-B' => 'Hindi Male - Clear & Professional (Standard)',
                    'hi-IN-Standard-C' => 'Hindi Male - Steady & Reliable (Standard)',
                ],
            ],
            'th-TH' => [
                'female' => [
                    'th-TH-Standard-A' => 'Thai Female - Clear & Professional (Standard)',
                ],
                'male' => [
                    'th-TH-Standard-B' => 'Thai Male - Clear & Professional (Standard)',
                ],
            ],
            'id-ID' => [
                'female' => [
                    'id-ID-Wavenet-A' => 'Indonesian Female - Natural & Conversational (Premium)',
                    'id-ID-Wavenet-C' => 'Indonesian Female - Warm & Friendly (Premium)',
                    'id-ID-Standard-A' => 'Indonesian Female - Clear & Professional (Standard)',
                    'id-ID-Standard-C' => 'Indonesian Female - Calm & Gentle (Standard)',
                ],
                'male' => [
                    'id-ID-Wavenet-B' => 'Indonesian Male - Natural & Confident (Premium)',
                    'id-ID-Wavenet-D' => 'Indonesian Male - Deep & Authoritative (Premium)',
                    'id-ID-Standard-B' => 'Indonesian Male - Clear & Professional (Standard)',
                    'id-ID-Standard-D' => 'Indonesian Male - Steady & Reliable (Standard)',
                ],
            ],
        ];
    }
}
