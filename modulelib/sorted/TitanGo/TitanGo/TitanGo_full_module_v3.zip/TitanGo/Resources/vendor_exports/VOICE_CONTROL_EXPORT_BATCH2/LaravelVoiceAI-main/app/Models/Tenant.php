<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tenant extends Model
{
    protected $fillable = [
        'company_name',
        'domain',
        'subdomain',
        'database',
        'is_active',
        'trial_ends_at',
        'plan',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'trial_ends_at' => 'datetime',
    ];

    public function users()
    {
        return $this->hasMany(User::class);
    }

    public function settings()
    {
        return $this->hasOne(TenantSetting::class);
    }

    public function businesses()
    {
        return $this->hasMany(Business::class);
    }

    public function voiceConfigurations()
    {
        return $this->hasMany(VoiceConfiguration::class);
    }

    public function defaultVoiceConfiguration()
    {
        return $this->hasOne(VoiceConfiguration::class)->where('is_default', true);
    }
}
