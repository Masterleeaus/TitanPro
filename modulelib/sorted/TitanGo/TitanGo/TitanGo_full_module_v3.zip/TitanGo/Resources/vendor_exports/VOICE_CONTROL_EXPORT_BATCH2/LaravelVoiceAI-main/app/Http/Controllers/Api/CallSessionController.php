<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CallSession;
use App\Models\CallTurn;
use App\Services\CallCostCalculator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class CallSessionController extends Controller
{
    protected $costCalculator;

    public function __construct(CallCostCalculator $costCalculator)
    {
        $this->costCalculator = $costCalculator;
    }

    /**
     * Start a new call session
     * POST /api/calls/start
     */
    public function start(Request $request)
    {
        $validated = $request->validate([
            'session_id' => 'required|string',
            'source_channel' => 'required|in:web,mobile,twilio',
            'call_sid' => 'nullable|string',
            'metadata' => 'nullable|array',
        ]);

        $user = Auth::user();
        $tenantId = $user->tenant_id;

        try {
            $session = CallSession::create([
                'tenant_id' => $tenantId,
                'session_id' => $validated['session_id'],
                'source_channel' => $validated['source_channel'],
                'call_sid' => $validated['call_sid'] ?? null,
                'started_at' => now(),
                'status' => 'active',
                'metadata' => $validated['metadata'] ?? [],
            ]);

            Log::info('Call session started', [
                'id' => $session->id,
                'session_id' => $session->session_id,
                'source' => $session->source_channel,
                'tenant_id' => $tenantId,
            ]);

            return response()->json([
                'success' => true,
                'call_session_id' => $session->id,
                'session_id' => $session->session_id,
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to start call session', [
                'error' => $e->getMessage(),
                'session_id' => $validated['session_id'],
            ]);

            return response()->json(['error' => 'Failed to create session'], 500);
        }
    }

    /**
     * Update call session with usage and transcript
     * POST /api/calls/{session_id}/update
     */
    public function update(Request $request, string $sessionId)
    {
        $validated = $request->validate([
            'usage' => 'nullable|array',
            'usage.openai' => 'nullable|array',
            'usage.tts' => 'nullable|array',
            'usage.stt' => 'nullable|array',
            'usage.twilio' => 'nullable|array',
            'turn' => 'nullable|array',
            'turn.speaker' => 'nullable|in:user,assistant',
            'turn.content' => 'nullable|string',
            'turn.language' => 'nullable|string',
            'turn.confidence' => 'nullable|numeric',
        ]);

        $user = Auth::user();
        $tenantId = $user->tenant_id;

        try {
            $session = CallSession::where('session_id', $sessionId)
                ->where('tenant_id', $tenantId)
                ->firstOrFail();

            // Update costs if usage provided
            if (isset($validated['usage']) && !empty($validated['usage'])) {
                $this->costCalculator->updateSessionCosts($session, $validated['usage']);
            }

            // Add conversation turn if provided
            if (isset($validated['turn']) && !empty($validated['turn'])) {
                CallTurn::create([
                    'call_session_id' => $session->id,
                    'speaker' => $validated['turn']['speaker'],
                    'content' => $validated['turn']['content'],
                    'spoken_at' => now(),
                    'language' => $validated['turn']['language'] ?? null,
                    'confidence' => $validated['turn']['confidence'] ?? null,
                ]);

                // Update transcript summary (last 5 turns)
                $recentTurns = $session->turns()->orderBy('spoken_at', 'desc')->limit(5)->get();
                $summary = $recentTurns->reverse()->map(function ($turn) {
                    return $turn->speaker . ': ' . $turn->content;
                })->implode("\n");
                
                $session->transcript_summary = $summary;
                $session->save();
            }

            return response()->json([
                'success' => true,
                'total_cost' => $session->total_cost,
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to update call session', [
                'error' => $e->getMessage(),
                'session_id' => $sessionId,
            ]);

            return response()->json(['error' => 'Failed to update session'], 500);
        }
    }

    /**
     * End call session
     * POST /api/calls/{session_id}/end
     */
    public function end(Request $request, string $sessionId)
    {
        $validated = $request->validate([
            'usage' => 'nullable|array',
            'status' => 'nullable|in:completed,failed,cancelled',
        ]);

        $user = Auth::user();
        $tenantId = $user->tenant_id;

        try {
            $session = CallSession::where('session_id', $sessionId)
                ->where('tenant_id', $tenantId)
                ->firstOrFail();

            // Update final costs if usage provided
            if (isset($validated['usage']) && !empty($validated['usage'])) {
                $this->costCalculator->updateSessionCosts($session, $validated['usage']);
            }

            // Calculate duration
            $session->ended_at = now();
            $session->duration_seconds = $session->started_at->diffInSeconds($session->ended_at);
            $session->status = $validated['status'] ?? 'completed';
            $session->save();

            Log::info('Call session ended', [
                'id' => $session->id,
                'session_id' => $session->session_id,
                'duration' => $session->duration_seconds,
                'total_cost' => $session->total_cost,
            ]);

            return response()->json([
                'success' => true,
                'duration_seconds' => $session->duration_seconds,
                'total_cost' => $session->total_cost,
                'costs' => [
                    'openai' => $session->cost_openai,
                    'tts' => $session->cost_tts,
                    'stt' => $session->cost_stt,
                    'twilio' => $session->cost_twilio,
                ],
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to end call session', [
                'error' => $e->getMessage(),
                'session_id' => $sessionId,
            ]);

            return response()->json(['error' => 'Failed to end session'], 500);
        }
    }

    /**
     * Get call session details
     * GET /api/calls/{session_id}
     */
    public function show(string $sessionId)
    {
        $user = Auth::user();
        $tenantId = $user->tenant_id;

        try {
            $session = CallSession::with(['costEvents', 'turns'])
                ->where('session_id', $sessionId)
                ->where('tenant_id', $tenantId)
                ->firstOrFail();

            return response()->json([
                'success' => true,
                'data' => $session,
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Session not found'], 404);
        }
    }
}
