<?php

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        if ($user->isSuperAdmin()) {
            return $this->superAdminDashboard();
        }

        return $this->tenantDashboard();
    }

    protected function superAdminDashboard()
    {
        $tenants = Tenant::with(['users', 'settings', 'businesses'])->get();
        $stats = [
            'total_tenants' => Tenant::count(),
            'active_tenants' => Tenant::where('is_active', true)->count(),
            'total_users' => User::count(),
        ];

        return view('admin.dashboard', compact('tenants', 'stats'));
    }

    protected function tenantDashboard()
    {
        $user = auth()->user();
        $tenant = $user->tenant;
        $settings = $tenant->settings;
        $businesses = $tenant->businesses;

        return view('tenant.dashboard', compact('tenant', 'settings', 'businesses'));
    }

    public function chat()
    {
        $user = auth()->user();
        $tenant = $user->tenant;
        
        // Ensure tenant has settings
        $mobileSettings = $tenant->settings;
        if (!$mobileSettings) {
            $mobileSettings = \App\Models\TenantSetting::create([
                'tenant_id' => $tenant->id,
                'mobile_call_ui_enabled' => true,
                'mobile_show_chat_fallback' => true,
                'mobile_allow_typing_during_call' => true,
                'mobile_default_mode' => 'call',
                'mobile_auto_end_silence_seconds' => 30
            ]);
        }

        return view('dashboard.chat', compact('tenant', 'mobileSettings'));
    }
}
