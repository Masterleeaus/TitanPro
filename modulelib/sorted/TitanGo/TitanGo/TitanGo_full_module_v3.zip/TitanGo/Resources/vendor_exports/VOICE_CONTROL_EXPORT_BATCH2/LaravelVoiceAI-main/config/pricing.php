<?php

return [
    /*
    |--------------------------------------------------------------------------
    | API Pricing Configuration
    |--------------------------------------------------------------------------
    |
    | Cost per unit for various AI and telephony services
    | Prices in USD
    |
    */

    'openai' => [
        // GPT-4o-mini pricing per 1,000 tokens
        'gpt_4o_mini_input' => env('PRICING_OPENAI_GPT4O_MINI_INPUT', 0.00015), // $0.15 per 1M input tokens
        'gpt_4o_mini_output' => env('PRICING_OPENAI_GPT4O_MINI_OUTPUT', 0.0006), // $0.60 per 1M output tokens
    ],

    'google' => [
        // Google Cloud Text-to-Speech pricing per 1 million characters
        'tts_standard' => env('PRICING_GOOGLE_TTS_STANDARD', 4.00), // $4.00 per 1M characters
        'tts_wavenet' => env('PRICING_GOOGLE_TTS_WAVENET', 16.00), // $16.00 per 1M characters
        'tts_neural2' => env('PRICING_GOOGLE_TTS_NEURAL2', 16.00), // $16.00 per 1M characters
        
        // Google Cloud Speech-to-Text pricing per minute of audio
        'stt_standard' => env('PRICING_GOOGLE_STT_STANDARD', 0.024), // $0.024 per minute (enhanced models)
        'stt_chirp' => env('PRICING_GOOGLE_STT_CHIRP', 0.016), // $0.016 per minute (Chirp 2)
    ],

    'twilio' => [
        // Twilio Voice pricing per minute
        'voice_inbound' => env('PRICING_TWILIO_VOICE_INBOUND', 0.0085), // $0.0085 per minute
        'voice_outbound' => env('PRICING_TWILIO_VOICE_OUTBOUND', 0.014), // $0.014 per minute
    ],

    // Default voice types (can be overridden in tenant settings)
    'defaults' => [
        'tts_voice_type' => env('DEFAULT_TTS_VOICE_TYPE', 'neural2'), // standard, wavenet, neural2
        'stt_model_type' => env('DEFAULT_STT_MODEL_TYPE', 'chirp'), // standard, chirp
    ],
];
