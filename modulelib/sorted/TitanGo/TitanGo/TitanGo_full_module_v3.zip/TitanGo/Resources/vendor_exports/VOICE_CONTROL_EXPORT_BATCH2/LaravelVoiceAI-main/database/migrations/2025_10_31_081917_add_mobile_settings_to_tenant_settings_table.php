<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('tenant_settings', function (Blueprint $table) {
            $table->boolean('mobile_call_ui_enabled')->default(true);
            $table->boolean('mobile_show_chat_fallback')->default(true);
            $table->boolean('mobile_allow_typing_during_call')->default(true);
            $table->string('mobile_default_mode')->default('call');
            $table->integer('mobile_auto_end_silence_seconds')->default(30);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('tenant_settings', function (Blueprint $table) {
            $table->dropColumn([
                'mobile_call_ui_enabled',
                'mobile_show_chat_fallback',
                'mobile_allow_typing_during_call',
                'mobile_default_mode',
                'mobile_auto_end_silence_seconds'
            ]);
        });
    }
};
