<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Conversation extends Model
{
    protected $fillable = [
        'business_id',
        'customer_phone',
        'channel',
        'twilio_sid',
        'transcript',
        'messages',
        'intent',
        'language',
        'status',
    ];

    protected $casts = [
        'messages' => 'array',
    ];

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }
}
