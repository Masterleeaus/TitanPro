<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('call_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
            
            // Source tracking
            $table->enum('source_channel', ['web', 'mobile', 'twilio'])->index();
            $table->string('session_id')->unique(); // WebSocket session ID or Twilio Call SID
            $table->string('call_sid')->nullable(); // Twilio Call SID (for phone calls only)
            
            // Timing
            $table->timestamp('started_at')->nullable();
            $table->timestamp('ended_at')->nullable();
            $table->integer('duration_seconds')->nullable(); // Total duration in seconds
            
            // Status
            $table->enum('status', ['active', 'completed', 'failed', 'cancelled'])->default('active');
            
            // Transcript and summary
            $table->text('transcript_summary')->nullable(); // Denormalized latest transcript
            $table->json('metadata')->nullable(); // Additional metadata (device info, IP, etc.)
            
            // Cost tracking
            $table->decimal('cost_openai', 10, 6)->default(0); // OpenAI API costs
            $table->decimal('cost_tts', 10, 6)->default(0); // Google TTS costs
            $table->decimal('cost_stt', 10, 6)->default(0); // Google STT costs
            $table->decimal('cost_twilio', 10, 6)->default(0); // Twilio voice minutes (phone only)
            $table->decimal('total_cost', 10, 6)->default(0); // Sum of all costs
            
            // Usage metrics
            $table->integer('openai_tokens')->default(0); // Total tokens used
            $table->integer('tts_characters')->default(0); // Total TTS characters
            $table->integer('stt_audio_seconds')->default(0); // Total STT audio duration
            $table->integer('twilio_billed_seconds')->nullable(); // Twilio billed minutes
            
            $table->timestamps();
            
            $table->index(['tenant_id', 'created_at']);
            $table->index(['source_channel', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('call_sessions');
    }
};
