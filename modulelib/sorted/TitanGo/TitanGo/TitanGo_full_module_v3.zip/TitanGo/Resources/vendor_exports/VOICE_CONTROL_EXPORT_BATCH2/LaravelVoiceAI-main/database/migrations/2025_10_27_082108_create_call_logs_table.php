<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('call_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
            $table->foreignId('business_id')->constrained()->onDelete('cascade');
            $table->string('call_sid')->unique();
            $table->string('from_number');
            $table->string('to_number');
            $table->enum('direction', ['inbound', 'outbound']);
            $table->enum('status', ['ringing', 'in-progress', 'completed', 'failed', 'busy', 'no-answer'])->default('ringing');
            $table->integer('duration')->nullable();
            $table->text('recording_url')->nullable();
            $table->text('transcription')->nullable();
            $table->text('ai_summary')->nullable();
            $table->json('ai_response')->nullable();
            $table->string('intent')->nullable();
            $table->json('extracted_data')->nullable();
            $table->timestamps();
            
            $table->index(['tenant_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('call_logs');
    }
};
