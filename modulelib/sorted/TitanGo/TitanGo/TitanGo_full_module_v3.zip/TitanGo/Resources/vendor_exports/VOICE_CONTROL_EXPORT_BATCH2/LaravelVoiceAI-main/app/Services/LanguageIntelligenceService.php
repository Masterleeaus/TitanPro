<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use OpenAI;

class LanguageIntelligenceService
{
    private array $languagePatterns;
    private array $commonWords;
    private float $switchThreshold = 0.75;
    private float $persistThreshold = 0.6;

    public function __construct()
    {
        $this->initializeLanguagePatterns();
        $this->initializeCommonWords();
    }

    private function initializeLanguagePatterns(): void
    {
        // Phonetic patterns for each language (romanized/transliterated forms)
        $this->languagePatterns = [
            'ta-in' => [
                'patterns' => [
                    '/\b(vendum|venum|vanakkam|nandri|enna|eppadi|enakku|ungal|panna|pannu|mudiyum|sollu|paruda|sapadu|thanni)\b/i',
                    '/\b(illa|irukku|podu|vaa|po|varen|poren|vendaam|sari|okey)\b/i',
                ],
                'characters' => '/[அ-ஔக-னா-ௌ]/u', // Tamil unicode characters
                'syllables' => ['um', 'am', 'an', 'nu', 'du', 'ru', 'ku'],
            ],
            'hi-in' => [
                'patterns' => [
                    '/\b(chahiye|karna|hai|hain|main|mujhe|tumhe|aap|kya|kaise|namaste|dhanyavaad|theek|achha)\b/i',
                    '/\b(nahi|haan|bhi|aur|lekin|kyunki|woh|yeh|wahan|yahan|kab|kahan)\b/i',
                ],
                'characters' => '/[अ-औक-नप-यर-ह]/u', // Devanagari characters
                'syllables' => ['ye', 'hai', 'kar', 'na'],
            ],
            'cmn-cn' => [
                'patterns' => [
                    '/\b(ni hao|xie xie|zai jian|duoshao|shenme|weishenme|zenme|nali|shei|ma)\b/i',
                ],
                'characters' => '/[\x{4E00}-\x{9FFF}]/u', // Chinese characters
                'syllables' => ['ma', 'le', 'de'],
            ],
            'ms-my' => [
                'patterns' => [
                    '/\b(saya|anda|apa|bagaimana|terima kasih|tolong|boleh|mahu|hendak|ada|tidak|ya)\b/i',
                ],
                'syllables' => ['lah', 'kan', 'kah'],
            ],
            'id-id' => [
                'patterns' => [
                    '/\b(saya|anda|apa|bagaimana|terima kasih|tolong|bisa|mau|ingin|ada|tidak|ya)\b/i',
                ],
                'syllables' => ['nya', 'kan', 'lah'],
            ],
            'th-TH' => [
                'patterns' => [
                    '/\b(sawatdee|khop khun|chai|mai|arai|tammaimai|yang ngai)\b/i',
                ],
                'characters' => '/[ก-๙]/u', // Thai characters
                'syllables' => ['kha', 'khrap', 'ka'],
            ],
        ];
    }

    private function initializeCommonWords(): void
    {
        // Most common words in each language (for frequency analysis)
        $this->commonWords = [
            'ta-in' => ['vendum', 'enna', 'enakku', 'nandri', 'vanakkam', 'sapadu', 'illa', 'irukku', 'panna'],
            'hi-in' => ['hai', 'chahiye', 'main', 'mujhe', 'kya', 'aap', 'nahi', 'theek', 'achha'],
            'en-in' => ['the', 'is', 'are', 'can', 'you', 'please', 'want', 'need', 'how', 'what'],
            'en-us' => ['the', 'is', 'are', 'can', 'you', 'please', 'want', 'need', 'how', 'what'],
            'cmn-cn' => ['ma', 'de', 'le', 'shi', 'wo'],
            'ms-my' => ['saya', 'anda', 'lah', 'boleh', 'ada'],
            'id-id' => ['saya', 'anda', 'nya', 'bisa', 'ada'],
            'th-th' => ['chai', 'mai', 'kha', 'khrap'],
        ];
    }

    /**
     * SIMPLIFIED Fast language detection for real-time conversation
     * 
     * Flow:
     * 1. Check if customer explicitly requested language switch
     * 2. Get current session language (cached)
     * 3. Quick check: Is customer speaking a DIFFERENT language?
     * 4. If yes -> switch, if no -> keep current
     * 
     * @param string $transcript The transcribed text
     * @param string $currentLanguage Current session language (from cache or default)
     * @param string|null $streamSid Call session ID for caching
     * @return array ['language' => string, 'switched' => bool]
     */
    public function detectLanguage(string $transcript, string $currentLanguage, ?string $streamSid = null): array
    {
        // Priority 1: Explicit language switch request (e.g., "speak in Tamil")
        $explicitLanguage = $this->detectExplicitLanguageSwitch($transcript);
        if ($explicitLanguage && $explicitLanguage !== $currentLanguage) {
            $this->cacheSessionLanguage($streamSid, $explicitLanguage);
            Log::info('Language switched (explicit)', [
                'from' => $currentLanguage,
                'to' => $explicitLanguage,
                'transcript' => $transcript
            ]);
            return [
                'language' => $explicitLanguage,
                'switched' => true,
            ];
        }

        // Priority 2: Check if customer is speaking DIFFERENT language than current
        $detectedLanguage = $this->fastLanguageCheck($transcript, $currentLanguage);
        
        if ($detectedLanguage && $detectedLanguage !== $currentLanguage) {
            $this->cacheSessionLanguage($streamSid, $detectedLanguage);
            Log::info('Language switched (detected)', [
                'from' => $currentLanguage,
                'to' => $detectedLanguage,
                'transcript' => $transcript
            ]);
            return [
                'language' => $detectedLanguage,
                'switched' => true,
            ];
        }

        // No language switch detected - stay in current language
        return [
            'language' => $currentLanguage,
            'switched' => false,
        ];
    }

    /**
     * Fast language check - just look for clear indicators of specific language
     * Returns language code if detected, null if current language is fine
     */
    private function fastLanguageCheck(string $text, string $currentLanguage): ?string
    {
        $text_lower = strtolower($text);
        
        // Check for native script (Tamil, Hindi, Chinese, Thai characters)
        $scriptDetected = $this->detectScripts($text);
        foreach ($scriptDetected as $lang => $score) {
            if ($score > 0.3 && $lang !== $currentLanguage) {
                return $lang; // Strong script signal
            }
        }

        // Check for phonetic patterns (romanized Tamil, Hindi, etc.)
        $phoneticScores = $this->analyzePhoneticPatterns($text);
        foreach ($phoneticScores as $lang => $score) {
            if ($score > 0.2 && $lang !== $currentLanguage) {
                return $lang; // Clear phonetic match
            }
        }

        // No different language detected
        return null;
    }

    /**
     * Analyze phonetic patterns in romanized text
     */
    private function analyzePhoneticPatterns(string $text): array
    {
        $scores = [];
        $text_lower = strtolower($text);

        foreach ($this->languagePatterns as $lang => $config) {
            $score = 0;
            $matches = 0;

            // Check regex patterns
            if (isset($config['patterns'])) {
                foreach ($config['patterns'] as $pattern) {
                    if (preg_match_all($pattern, $text_lower, $m)) {
                        $matches += count($m[0]);
                        $score += count($m[0]) * 0.2; // 0.2 per match
                    }
                }
            }

            // Check syllable patterns
            if (isset($config['syllables'])) {
                foreach ($config['syllables'] as $syllable) {
                    $count = substr_count($text_lower, $syllable);
                    $score += $count * 0.05; // 0.05 per syllable
                }
            }

            $scores[$lang] = min($score, 1.0); // Cap at 1.0
        }

        return $scores;
    }

    /**
     * Detect scripts (Tamil, Devanagari, Chinese, Thai characters)
     */
    private function detectScripts(string $text): array
    {
        $scores = [];

        foreach ($this->languagePatterns as $lang => $config) {
            if (isset($config['characters'])) {
                if (preg_match_all($config['characters'], $text, $matches)) {
                    $charCount = count($matches[0]);
                    $totalChars = mb_strlen($text);
                    $ratio = $totalChars > 0 ? $charCount / $totalChars : 0;
                    $scores[$lang] = min($ratio * 2, 1.0); // Scale and cap at 1.0
                }
            }
        }

        return $scores;
    }

    /**
     * Analyze word frequency to detect language
     */
    private function analyzeWordFrequency(string $text): array
    {
        $scores = [];
        $words = preg_split('/\s+/', strtolower($text));

        foreach ($this->commonWords as $lang => $commonWords) {
            $matches = 0;
            foreach ($words as $word) {
                if (in_array($word, $commonWords)) {
                    $matches++;
                }
            }
            $totalWords = count($words);
            $scores[$lang] = $totalWords > 0 ? ($matches / $totalWords) : 0;
        }

        return $scores;
    }

    /**
     * Cache session language (simple, no complex scoring)
     */
    private function cacheSessionLanguage(?string $streamSid, string $language): void
    {
        if (!$streamSid) {
            return;
        }

        $cacheKey = "session_language:{$streamSid}";
        Cache::put($cacheKey, $language, 600); // 10 minute TTL
    }

    /**
     * Get cached session language
     */
    public function getSessionLanguage(?string $streamSid): ?string
    {
        if (!$streamSid) {
            return null;
        }

        $cacheKey = "session_language:{$streamSid}";
        return Cache::get($cacheKey);
    }

    /**
     * Detect explicit language switch requests like "switch to Tamil", "speak in Hindi", etc.
     */
    private function detectExplicitLanguageSwitch(string $text): ?string
    {
        $text_lower = strtolower($text);
        
        $switchPatterns = [
            'ta-in' => [
                '/(speak|talk|switch|change).*(tamil|தமிழ்)/i',
                '/(only know|speak).*(tamil)/i',
                '/tamil.*please/i',
            ],
            'hi-in' => [
                '/(speak|talk|switch|change).*(hindi|हिंदी)/i',
                '/(only know|speak).*(hindi)/i',
            ],
            'en-in' => [
                '/(speak|talk|switch|change).*(english)/i',
                '/english.*please/i',
            ],
            'cmn-cn' => [
                '/(speak|talk|switch|change).*(mandarin|chinese|中文)/i',
            ],
            'ms-my' => [
                '/(speak|talk|switch|change).*(malay)/i',
            ],
            'id-id' => [
                '/(speak|talk|switch|change).*(indonesian|bahasa.*indonesia)/i',
            ],
            'th-th' => [
                '/(speak|talk|switch|change).*(thai|ภาษาไทย)/i',
            ],
        ];

        foreach ($switchPatterns as $lang => $patterns) {
            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $text_lower)) {
                    return $lang;
                }
            }
        }

        return null;
    }

    /**
     * Use OpenAI to classify language from transcript content
     * This is especially powerful for detecting language from phonetically transcribed text
     */
    private function classifyLanguageWithAI(string $transcript): array
    {
        if (strlen($transcript) < 3) {
            return []; // Too short for AI classification
        }

        $apiKey = env('OPENAI_API_KEY');
        if (!$apiKey) {
            return [];
        }

        $client = OpenAI::client($apiKey);

        $prompt = <<<EOT
Analyze the following text and determine which language(s) it contains. The text may be:
1. Written in native script (தமிழ், हिंदी, 中文, etc.)
2. Phonetically transcribed/romanized (e.g., "vendum" = Tamil "வேண்டும்")
3. Code-mixed (Tanglish, Hinglish, Singlish - mixing multiple languages)

Text: "{$transcript}"

Identify which of these languages are present and estimate confidence (0-1):
- Tamil (ta-in)
- Hindi (hi-in)
- English (en-in)
- Mandarin Chinese (cmn-cn)
- Malay (ms-my)
- Indonesian (id-id)
- Thai (th-th)

Respond ONLY with JSON in this format:
{"ta-in": 0.0, "hi-in": 0.0, "en-in": 0.0, "cmn-cn": 0.0, "ms-my": 0.0, "id-id": 0.0, "th-th": 0.0}

Example: If text is "vendum pizza" (Tamil word + English word), respond:
{"ta-in": 0.6, "hi-in": 0.0, "en-in": 0.4, "cmn-cn": 0.0, "ms-my": 0.0, "id-id": 0.0, "th-th": 0.0}
EOT;

        try {
            // Set timeout for API call (5 seconds max)
            $response = $client->chat()->create([
                'model' => 'gpt-4o-mini',
                'messages' => [
                    ['role' => 'system', 'content' => 'You are a language detection expert specializing in South Asian languages and code-mixing. Respond only with valid JSON.'],
                    ['role' => 'user', 'content' => $prompt],
                ],
                'temperature' => 0.1,
                'max_tokens' => 100,
                'timeout' => 5.0, // 5 second timeout
            ]);

            $content = $response->choices[0]->message->content ?? '{}';
            Log::info('OpenAI raw response', ['content' => $content]);
            
            // Try to parse JSON directly first
            $scores = json_decode($content, true);
            if (is_array($scores) && isset($scores['ta-in'])) {
                Log::info('OpenAI parsed successfully (direct JSON)', ['scores' => $scores]);
                return $scores;
            }
            
            // Extract JSON from response with regex
            if (preg_match('/\{[^}]+\}/', $content, $matches)) {
                $scores = json_decode($matches[0], true);
                if (is_array($scores)) {
                    Log::info('OpenAI parsed successfully (regex)', ['scores' => $scores]);
                    return $scores;
                }
            }

            Log::warning('OpenAI response could not be parsed', ['content' => $content]);
            return [];
        } catch (\Exception $e) {
            Log::error('OpenAI language classification error', [
                'error' => $e->getMessage(),
                'trace' => substr($e->getTraceAsString(), 0, 500)
            ]);
            return [];
        }
    }

    /**
     * Detect if text contains code-mixed speech (Tanglish, Hinglish, etc.)
     */
    public function detectCodeMixing(string $text): array
    {
        $detectedLanguages = [];
        
        // Check for multiple language signals in the same text
        $phoneticScores = $this->analyzePhoneticPatterns($text);
        $scriptScores = $this->detectScripts($text);

        foreach ($phoneticScores as $lang => $score) {
            if ($score > 0.2) { // Threshold for presence
                $detectedLanguages[] = $lang;
            }
        }

        foreach ($scriptScores as $lang => $score) {
            if ($score > 0.1 && !in_array($lang, $detectedLanguages)) {
                $detectedLanguages[] = $lang;
            }
        }

        $isCodeMixed = count($detectedLanguages) > 1;

        return [
            'is_code_mixed' => $isCodeMixed,
            'languages' => $detectedLanguages,
        ];
    }
}
