<?php

namespace App\Services;

use OpenAI\Laravel\Facades\OpenAI;
use App\Models\TenantSetting;

class OpenAIService
{
    protected $apiKey;
    protected $model;

    public function __construct($tenantId = null)
    {
        if ($tenantId) {
            $settings = TenantSetting::where('tenant_id', $tenantId)->first();
            if ($settings && $settings->openai_api_key) {
                $this->apiKey = $settings->openai_api_key;
                $this->model = $settings->openai_model ?? 'gpt-4o-mini';
            } else {
                $this->apiKey = env('OPENAI_API_KEY');
                $this->model = env('OPENAI_MODEL', 'gpt-4o-mini');
            }
        } else {
            $this->apiKey = env('OPENAI_API_KEY');
            $this->model = env('OPENAI_MODEL', 'gpt-4o-mini');
        }
    }

    protected function getClient()
    {
        if ($this->apiKey && $this->apiKey !== env('OPENAI_API_KEY')) {
            return \OpenAI::client($this->apiKey);
        }
        return OpenAI::getFacadeRoot();
    }

    public function transcribeAudio($audioFilePath)
    {
        $client = $this->getClient();
        $response = $client->audio()->transcribe([
            'model' => 'whisper-1',
            'file' => fopen($audioFilePath, 'r'),
            'response_format' => 'json',
        ]);

        return $response->text;
    }

    public function transcribeAudioWithLanguageDetection($audioFilePath)
    {
        $client = $this->getClient();
        $response = $client->audio()->transcribe([
            'model' => 'whisper-1',
            'file' => fopen($audioFilePath, 'r'),
            'response_format' => 'verbose_json',
        ]);

        return [
            'text' => $response->text,
            'language' => $response->language ?? 'en',
        ];
    }

    public function chat($messages, $systemPrompt = null)
    {
        $allMessages = [];

        if ($systemPrompt) {
            $allMessages[] = ['role' => 'system', 'content' => $systemPrompt];
        }

        $allMessages = array_merge($allMessages, $messages);

        $client = $this->getClient();
        $response = $client->chat()->create([
            'model' => $this->model,
            'messages' => $allMessages,
            'temperature' => 0.7,
        ]);

        return $response->choices[0]->message->content;
    }

    public function chatFast($messages, $systemPrompt = null)
    {
        $allMessages = [];

        if ($systemPrompt) {
            $allMessages[] = ['role' => 'system', 'content' => $systemPrompt];
        }

        // OPTIMIZATION: Only keep last 2 turns of conversation history (reduce tokens = faster)
        $recentMessages = array_slice($messages, -4); // Last 2 turns (2 user + 2 assistant)
        $allMessages = array_merge($allMessages, $recentMessages);

        $client = $this->getClient();
        $response = $client->chat()->create([
            'model' => $this->model,
            'messages' => $allMessages,
            'temperature' => 0.7, // Lower temperature = faster generation
            'max_tokens' => 50, // Short responses = faster
        ]);

        return $response->choices[0]->message->content;
    }

    public function extractIntent($text, $businessType)
    {
        $systemPrompt = "You are an AI assistant helping to classify customer intent for a {$businessType} business. "
            . "Analyze the customer message and return ONLY ONE of these intents: order, appointment, inquiry, complaint, other. "
            . "Return only the single word intent, nothing else.";

        $client = $this->getClient();
        $response = $client->chat()->create([
            'model' => $this->model,
            'messages' => [
                ['role' => 'system', 'content' => $systemPrompt],
                ['role' => 'user', 'content' => $text],
            ],
            'temperature' => 0.3,
        ]);

        return strtolower(trim($response->choices[0]->message->content));
    }

    public function extractOrderDetails($text, $menuItems)
    {
        $menuList = collect($menuItems)->map(function ($item) {
            return "{$item['item_name']} - \${$item['price']}";
        })->join("\n");

        $systemPrompt = "You are an AI assistant helping to extract order details from customer messages. "
            . "Available menu items:\n{$menuList}\n\n"
            . "Extract the items and quantities from the customer message. "
            . "Return a JSON array with items like: [{\"item_name\": \"Pizza\", \"quantity\": 2, \"price\": 15.99}]";

        $client = $this->getClient();
        $response = $client->chat()->create([
            'model' => $this->model,
            'messages' => [
                ['role' => 'system', 'content' => $systemPrompt],
                ['role' => 'user', 'content' => $text],
            ],
            'temperature' => 0.3,
        ]);

        $result = $response->choices[0]->message->content;
        return json_decode($result, true);
    }

    public function generateTextToSpeech($text, $voice = 'alloy')
    {
        $client = $this->getClient();
        $response = $client->audio()->speech([
            'model' => 'tts-1',
            'input' => $text,
            'voice' => $voice,
        ]);

        return $response;
    }

    public function summarize($text)
    {
        $client = $this->getClient();
        $response = $client->chat()->create([
            'model' => 'gpt-3.5-turbo',
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'Summarize the following conversation in one concise sentence.'
                ],
                [
                    'role' => 'user',
                    'content' => $text
                ]
            ],
            'temperature' => 0.5,
            'max_tokens' => 100
        ]);

        return $response->choices[0]->message->content;
    }
}
