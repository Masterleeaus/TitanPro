<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ChatSession;
use App\Models\ChatMessage;
use App\Models\Business;
use App\Models\VoiceConfiguration;
use App\Services\OpenAIService;
use App\Services\GoogleTTSService;
use App\Services\LanguageIntelligenceService;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class ConversationController extends Controller
{
    public function sendMessage(Request $request)
    {
        try {
            $validated = $request->validate([
                'message' => 'required|string',
                'session_id' => 'nullable|string',
                'language' => 'nullable|string',
                'customer_id' => 'nullable|string',
            ]);

            $tenantId = $request->get('tenant_id');
            $sessionId = $validated['session_id'] ?? 'api_' . Str::random(16);
            $message = $validated['message'];
            $language = $validated['language'] ?? 'en-IN';

            $session = ChatSession::firstOrCreate(
                ['session_id' => $sessionId, 'tenant_id' => $tenantId],
                [
                    'channel' => 'api',
                    'customer_identifier' => $validated['customer_id'] ?? null,
                    'language' => $language,
                    'status' => 'active',
                    'last_activity_at' => now(),
                ]
            );

            $session->update(['last_activity_at' => now()]);

            ChatMessage::create([
                'session_id' => $session->id,
                'role' => 'user',
                'content' => $message,
                'language' => $language,
            ]);

            $business = Business::where('tenant_id', $tenantId)->first();
            $voiceConfig = VoiceConfiguration::where('tenant_id', $tenantId)
                ->where('is_default', true)
                ->first();
            
            $languageIntelligence = new LanguageIntelligenceService();
            $langResult = $languageIntelligence->detectLanguage(
                $message,
                $session->language,
                $sessionId
            );
            
            $effectiveLanguage = $langResult['language'];
            if ($langResult['switched']) {
                $session->update(['language' => $effectiveLanguage]);
            }

            $recentMessages = ChatMessage::where('session_id', $session->id)
                ->latest()
                ->take(6)
                ->get()
                ->reverse()
                ->values();

            $conversationHistory = $recentMessages->map(function ($msg) {
                return [
                    'role' => $msg->role === 'user' ? 'user' : 'assistant',
                    'content' => $msg->content
                ];
            })->toArray();

            $openAIService = new OpenAIService($tenantId);
            
            $languageNames = [
                'en-IN' => 'English',
                'ta-IN' => 'Tamil',
                'hi-IN' => 'Hindi',
                'cmn-CN' => 'Mandarin Chinese',
                'ms-MY' => 'Malay',
                'id-ID' => 'Indonesian',
                'th-TH' => 'Thai',
            ];
            
            $languageName = $languageNames[$effectiveLanguage] ?? 'English';
            $languageInstruction = "IMPORTANT: Respond ONLY in {$languageName}. Use {$languageName} language exclusively.";

            $systemPrompt = $business 
                ? "{$languageInstruction}\n\nYou are a helpful AI for {$business->name}, a {$business->type}. Be extremely brief - max 10 words per response."
                : "{$languageInstruction}\n\nYou are a helpful AI assistant. Be extremely brief - max 10 words per response.";

            $aiResponse = $openAIService->chatFast($conversationHistory, $systemPrompt);

            ChatMessage::create([
                'session_id' => $session->id,
                'role' => 'assistant',
                'content' => $aiResponse,
                'language' => $effectiveLanguage,
            ]);

            $ttsService = new GoogleTTSService();
            $audioUrl = $ttsService->synthesize($aiResponse, $effectiveLanguage, $voiceConfig);

            return response()->json([
                'session_id' => $sessionId,
                'message' => $aiResponse,
                'language' => $effectiveLanguage,
                'audio_url' => url($audioUrl),
                'language_switched' => $langResult['switched'],
            ]);

        } catch (\Exception $e) {
            Log::error('API v1 message error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'error' => 'Failed to process message',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function sendVoice(Request $request)
    {
        try {
            $validated = $request->validate([
                'audio' => 'required|file|mimes:mp3,wav,m4a,webm,ogg',
                'session_id' => 'nullable|string',
                'language' => 'nullable|string',
                'customer_id' => 'nullable|string',
            ]);

            $tenantId = $request->get('tenant_id');
            $audioFile = $validated['audio'];
            
            $audioPath = $audioFile->store('temp-audio', 'local');
            $fullPath = storage_path('app/' . $audioPath);

            $openAIService = new OpenAIService($tenantId);
            $transcription = $openAIService->transcribeAudio($fullPath);

            @unlink($fullPath);

            return $this->sendMessage(new Request([
                'message' => $transcription,
                'session_id' => $validated['session_id'] ?? null,
                'language' => $validated['language'] ?? null,
                'customer_id' => $validated['customer_id'] ?? null,
                'tenant_id' => $tenantId,
            ]));

        } catch (\Exception $e) {
            Log::error('API v1 voice error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'error' => 'Failed to process voice message',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function getConversations(Request $request)
    {
        try {
            $tenantId = $request->get('tenant_id');
            $limit = $request->get('limit', 20);
            $offset = $request->get('offset', 0);

            $sessions = ChatSession::where('tenant_id', $tenantId)
                ->where('channel', 'api')
                ->orderBy('last_activity_at', 'desc')
                ->skip($offset)
                ->take($limit)
                ->get();

            return response()->json([
                'conversations' => $sessions,
                'total' => ChatSession::where('tenant_id', $tenantId)->where('channel', 'api')->count(),
                'limit' => $limit,
                'offset' => $offset,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to get conversations',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function getConversation($sessionId, Request $request)
    {
        try {
            $tenantId = $request->get('tenant_id');

            $session = ChatSession::where('session_id', $sessionId)
                ->where('tenant_id', $tenantId)
                ->first();
            
            if (!$session) {
                return response()->json(['error' => 'Conversation not found'], 404);
            }

            $messages = ChatMessage::where('session_id', $session->id)
                ->orderBy('created_at', 'asc')
                ->get();

            return response()->json([
                'session' => $session,
                'messages' => $messages,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to get conversation',
                'message' => $e->getMessage()
            ], 500);
        }
    }
}
