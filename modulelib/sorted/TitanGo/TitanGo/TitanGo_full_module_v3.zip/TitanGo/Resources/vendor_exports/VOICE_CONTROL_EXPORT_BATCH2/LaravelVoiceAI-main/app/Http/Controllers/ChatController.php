<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ChatSession;
use App\Models\ChatMessage;
use App\Models\Business;
use App\Models\VoiceConfiguration;
use App\Models\TenantSetting;
use App\Services\OpenAIService;
use App\Services\GoogleTTSService;
use App\Services\LanguageIntelligenceService;
use Illuminate\Support\Facades\Log;

class ChatController extends Controller
{
    public function handleMessage(Request $request)
    {
        try {
            $validated = $request->validate([
                'sessionId' => 'required|string',
                'tenantId' => 'required|integer',
                'message' => 'required|string',
                'language' => 'nullable|string',
            ]);

            $sessionId = $validated['sessionId'];
            $tenantId = $validated['tenantId'];
            $message = $validated['message'];
            $language = $validated['language'] ?? 'en-IN';

            $session = ChatSession::firstOrCreate(
                ['session_id' => $sessionId, 'tenant_id' => $tenantId],
                [
                    'channel' => 'web',
                    'language' => $language,
                    'status' => 'active',
                    'last_activity_at' => now(),
                ]
            );

            $session->update(['last_activity_at' => now()]);

            ChatMessage::create([
                'session_id' => $session->id,
                'role' => 'user',
                'content' => $message,
                'language' => $language,
            ]);

            $business = Business::where('tenant_id', $tenantId)->first();

            $voiceConfig = VoiceConfiguration::where('tenant_id', $tenantId)
                ->where('is_default', true)
                ->first();
            
            $defaultLanguage = $voiceConfig ? $voiceConfig->language_code : 'en-IN';
            
            $languageIntelligence = new LanguageIntelligenceService();
            $langResult = $languageIntelligence->detectLanguage(
                $message,
                $session->language,
                $sessionId
            );
            
            $effectiveLanguage = $langResult['language'];
            if ($langResult['switched']) {
                $session->update(['language' => $effectiveLanguage]);
            }

            $recentMessages = ChatMessage::where('session_id', $session->id)
                ->latest()
                ->take(6)
                ->get()
                ->reverse()
                ->values();

            $conversationHistory = $recentMessages->map(function ($msg) {
                return [
                    'role' => $msg->role === 'user' ? 'user' : 'assistant',
                    'content' => $msg->content
                ];
            })->toArray();

            $openAIService = new OpenAIService($tenantId);

            $languageNames = [
                'en-IN' => 'English',
                'en-in' => 'English',
                'ta-IN' => 'Tamil',
                'ta-in' => 'Tamil',
                'hi-IN' => 'Hindi',
                'hi-in' => 'Hindi',
                'cmn-CN' => 'Mandarin Chinese',
                'cmn-cn' => 'Mandarin Chinese',
                'ms-MY' => 'Malay',
                'ms-my' => 'Malay',
                'id-ID' => 'Indonesian',
                'id-id' => 'Indonesian',
                'th-TH' => 'Thai',
                'th-th' => 'Thai',
            ];
            
            $languageName = $languageNames[$effectiveLanguage] ?? 'English';
            $languageInstruction = "CRITICAL: You MUST respond ONLY in {$languageName}. Write your entire response in {$languageName} language. Use native {$languageName} script.";

            // Fetch tenant's custom AI configuration
            $tenantSettings = TenantSetting::where('tenant_id', $tenantId)->first();
            
            // Build system prompt from tenant configuration
            // Start with custom prompt or default
            if ($tenantSettings && $tenantSettings->system_prompt) {
                // Use custom system prompt
                $systemPrompt = "{$languageInstruction}\n\n{$tenantSettings->system_prompt}";
            } else {
                // Fallback to default system prompt
                $systemPrompt = $business 
                    ? "{$languageInstruction}\n\nYou are a helpful AI for {$business->name}, a {$business->type}. Be extremely brief - max 10 words per response."
                    : "{$languageInstruction}\n\nYou are a helpful AI assistant. Be extremely brief - max 10 words per response.";
            }
            
            // Always append business context, hours, and tone if provided (even without custom prompt)
            if ($tenantSettings) {
                if ($tenantSettings->business_context) {
                    $systemPrompt .= "\n\nBusiness Information:\n{$tenantSettings->business_context}";
                }
                
                if ($tenantSettings->operating_hours) {
                    $systemPrompt .= "\n\nOperating Hours: {$tenantSettings->operating_hours}";
                }
                
                // Add voice tone instruction
                $toneInstructions = [
                    'professional' => 'Maintain a professional and courteous tone.',
                    'friendly' => 'Be warm, friendly, and casual in your responses.',
                    'formal' => 'Use formal and polite language at all times.',
                    'enthusiastic' => 'Be energetic, enthusiastic, and upbeat in your responses.',
                ];
                $tone = $tenantSettings->voice_tone ?? 'professional';
                if (isset($toneInstructions[$tone])) {
                    $systemPrompt .= "\n\n{$toneInstructions[$tone]}";
                }
            }
            
            // Add brief response instruction for chat
            if ($tenantSettings && $tenantSettings->system_prompt) {
                $systemPrompt .= "\n\nIMPORTANT: Keep responses brief and conversational.";
            }

            $aiResponse = $openAIService->chatFast($conversationHistory, $systemPrompt);

            ChatMessage::create([
                'session_id' => $session->id,
                'role' => 'assistant',
                'content' => $aiResponse,
                'language' => $effectiveLanguage,
            ]);

            $ttsService = new GoogleTTSService();
            
            if ($voiceConfig) {
                $audioUrl = $ttsService->generateSpeechWithConfig(
                    $aiResponse,
                    $voiceConfig->voice_name,
                    $voiceConfig->gender,
                    $voiceConfig->speaking_rate ?? 1.0,
                    $voiceConfig->pitch ?? 0.0
                );
            } else {
                $audioUrl = $ttsService->generateSpeech($aiResponse, $effectiveLanguage);
            }

            return response()->json([
                'response' => $aiResponse,
                'language' => $effectiveLanguage,
                'audioUrl' => url($audioUrl),
            ]);

        } catch (\Exception $e) {
            Log::error('Chat message error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'error' => 'Failed to process message',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function handleVoice(Request $request)
    {
        try {
            $validated = $request->validate([
                'sessionId' => 'required|string',
                'tenantId' => 'required|integer',
                'audioPath' => 'required|string',
                'language' => 'nullable|string',
            ]);

            $sessionId = $validated['sessionId'];
            $tenantId = $validated['tenantId'];
            $audioPath = $validated['audioPath'];
            $language = $validated['language'] ?? 'en-IN';

            $openAIService = new OpenAIService($tenantId);
            $transcription = $openAIService->transcribeAudio($audioPath);

            return $this->handleMessage(new Request([
                'sessionId' => $sessionId,
                'tenantId' => $tenantId,
                'message' => $transcription,
                'language' => $language,
            ]));

        } catch (\Exception $e) {
            Log::error('Voice message error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'error' => 'Failed to process voice message',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function getHistory($sessionId)
    {
        try {
            $session = ChatSession::where('session_id', $sessionId)->first();
            
            if (!$session) {
                return response()->json(['error' => 'Session not found'], 404);
            }

            $messages = ChatMessage::where('session_id', $session->id)
                ->orderBy('created_at', 'asc')
                ->get();

            return response()->json([
                'session' => $session,
                'messages' => $messages,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Failed to get history',
                'message' => $e->getMessage()
            ], 500);
        }
    }
}
