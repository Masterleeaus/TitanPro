<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('call_turns', function (Blueprint $table) {
            $table->id();
            $table->foreignId('call_session_id')->constrained()->onDelete('cascade');
            
            // Turn details
            $table->enum('speaker', ['user', 'assistant']); // Who spoke
            $table->text('content'); // What was said
            $table->timestamp('spoken_at'); // When it was said
            
            // Metadata
            $table->decimal('confidence', 5, 4)->nullable(); // STT confidence score (0-1)
            $table->string('language')->nullable(); // Detected language
            $table->integer('duration_ms')->nullable(); // Audio duration in milliseconds
            
            $table->timestamps();
            
            $table->index(['call_session_id', 'spoken_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('call_turns');
    }
};
