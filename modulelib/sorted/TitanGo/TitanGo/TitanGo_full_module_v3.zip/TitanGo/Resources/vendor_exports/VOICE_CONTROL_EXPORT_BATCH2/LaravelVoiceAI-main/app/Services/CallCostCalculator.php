<?php

namespace App\Services;

use App\Models\CallSession;
use App\Models\CallCostEvent;

class CallCostCalculator
{
    /**
     * Calculate OpenAI GPT-4o-mini cost
     */
    public function calculateOpenAICost(int $inputTokens, int $outputTokens): array
    {
        $inputCost = ($inputTokens / 1000) * config('pricing.openai.gpt_4o_mini_input');
        $outputCost = ($outputTokens / 1000) * config('pricing.openai.gpt_4o_mini_output');
        $totalCost = $inputCost + $outputCost;

        return [
            'input_tokens' => $inputTokens,
            'output_tokens' => $outputTokens,
            'total_tokens' => $inputTokens + $outputTokens,
            'input_cost' => round($inputCost, 6),
            'output_cost' => round($outputCost, 6),
            'total_cost' => round($totalCost, 6),
        ];
    }

    /**
     * Calculate Google TTS cost
     */
    public function calculateTTSCost(int $characters, string $voiceType = 'neural2'): array
    {
        $priceKey = 'pricing.google.tts_' . $voiceType;
        $pricePerMillion = config($priceKey, config('pricing.google.tts_neural2'));
        
        $cost = ($characters / 1000000) * $pricePerMillion;

        return [
            'characters' => $characters,
            'voice_type' => $voiceType,
            'cost' => round($cost, 6),
        ];
    }

    /**
     * Calculate Google STT cost
     */
    public function calculateSTTCost(int $audioSeconds, string $modelType = 'chirp'): array
    {
        $priceKey = 'pricing.google.stt_' . $modelType;
        $pricePerMinute = config($priceKey, config('pricing.google.stt_chirp'));
        
        $audioMinutes = $audioSeconds / 60;
        $cost = $audioMinutes * $pricePerMinute;

        return [
            'audio_seconds' => $audioSeconds,
            'audio_minutes' => round($audioMinutes, 2),
            'model_type' => $modelType,
            'cost' => round($cost, 6),
        ];
    }

    /**
     * Calculate Twilio Voice cost
     */
    public function calculateTwilioCost(int $billedSeconds, string $direction = 'inbound'): array
    {
        $priceKey = 'pricing.twilio.voice_' . $direction;
        $pricePerMinute = config($priceKey, config('pricing.twilio.voice_inbound'));
        
        $billedMinutes = ceil($billedSeconds / 60); // Twilio rounds up to nearest minute
        $cost = $billedMinutes * $pricePerMinute;

        return [
            'billed_seconds' => $billedSeconds,
            'billed_minutes' => $billedMinutes,
            'direction' => $direction,
            'cost' => round($cost, 6),
        ];
    }

    /**
     * Add cost event to call session
     */
    public function addCostEvent(
        CallSession $session,
        string $vendor,
        string $eventType,
        ?int $units,
        ?string $unitType,
        float $cost,
        array $metadata = []
    ): CallCostEvent {
        return $session->costEvents()->create([
            'vendor' => $vendor,
            'event_type' => $eventType,
            'units' => $units,
            'unit_type' => $unitType,
            'cost' => $cost,
            'metadata' => $metadata,
        ]);
    }

    /**
     * Update call session costs from usage metrics
     */
    public function updateSessionCosts(
        CallSession $session,
        array $usage
    ): void {
        // Update OpenAI costs
        if (isset($usage['openai'])) {
            $openaiCost = $this->calculateOpenAICost(
                $usage['openai']['input_tokens'] ?? 0,
                $usage['openai']['output_tokens'] ?? 0
            );
            
            $session->increment('openai_tokens', $openaiCost['total_tokens']);
            $session->increment('cost_openai', $openaiCost['total_cost']);

            $this->addCostEvent(
                $session,
                'openai',
                'completion',
                $openaiCost['total_tokens'],
                'tokens',
                $openaiCost['total_cost'],
                $openaiCost
            );
        }

        // Update Google TTS costs
        if (isset($usage['tts'])) {
            $ttsCost = $this->calculateTTSCost(
                $usage['tts']['characters'],
                $usage['tts']['voice_type'] ?? 'neural2'
            );
            
            $session->increment('tts_characters', $ttsCost['characters']);
            $session->increment('cost_tts', $ttsCost['cost']);

            $this->addCostEvent(
                $session,
                'google_tts',
                'tts_generation',
                $ttsCost['characters'],
                'characters',
                $ttsCost['cost'],
                $ttsCost
            );
        }

        // Update Google STT costs
        if (isset($usage['stt'])) {
            $sttCost = $this->calculateSTTCost(
                $usage['stt']['audio_seconds'],
                $usage['stt']['model_type'] ?? 'chirp'
            );
            
            $session->increment('stt_audio_seconds', $sttCost['audio_seconds']);
            $session->increment('cost_stt', $sttCost['cost']);

            $this->addCostEvent(
                $session,
                'google_stt',
                'stt_transcription',
                $sttCost['audio_seconds'],
                'seconds',
                $sttCost['cost'],
                $sttCost
            );
        }

        // Update Twilio costs (phone calls only)
        if (isset($usage['twilio'])) {
            $twilioCost = $this->calculateTwilioCost(
                $usage['twilio']['billed_seconds'],
                $usage['twilio']['direction'] ?? 'inbound'
            );
            
            $session->twilio_billed_seconds = $twilioCost['billed_seconds'];
            $session->cost_twilio = $twilioCost['cost'];

            $this->addCostEvent(
                $session,
                'twilio',
                'voice_minute',
                $twilioCost['billed_minutes'],
                'minutes',
                $twilioCost['cost'],
                $twilioCost
            );
        }

        // Calculate total cost
        $session->calculateTotalCost();
    }
}
