<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CallLog extends Model
{
    protected $fillable = [
        'tenant_id',
        'business_id',
        'call_sid',
        'from_number',
        'to_number',
        'direction',
        'status',
        'duration',
        'twilio_cost',
        'openai_cost',
        'tts_cost',
        'total_cost',
        'recording_url',
        'transcription',
        'ai_summary',
        'ai_response',
        'intent',
        'extracted_data',
        'language_code',
    ];

    protected $casts = [
        'ai_response' => 'array',
        'extracted_data' => 'array',
        'twilio_cost' => 'decimal:4',
        'openai_cost' => 'decimal:4',
        'tts_cost' => 'decimal:4',
        'total_cost' => 'decimal:4',
    ];

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }
}
