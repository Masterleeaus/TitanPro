<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('voice_configurations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->onDelete('cascade');
            $table->string('name')->default('Default Voice');
            $table->string('language_code', 10);
            $table->string('voice_name', 50);
            $table->enum('gender', ['male', 'female']);
            $table->decimal('speaking_rate', 3, 1)->default(1.0);
            $table->decimal('pitch', 3, 1)->default(0.0);
            $table->boolean('is_default')->default(false);
            $table->integer('priority')->default(0);
            $table->timestamps();
            
            $table->index(['tenant_id', 'is_default']);
            $table->index(['tenant_id', 'language_code']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('voice_configurations');
    }
};
