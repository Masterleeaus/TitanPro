# Where to drop extracted repo code

You already have two export bundles:
- worksuite_voice_control_code_exports.zip
- worksuite_voice_control_code_exports_batch2.zip

Suggested placement inside this extension:

## Browser STT / wake-word / command grammar
Put reusable JS snippets into:
- resources/views/titango/partials/voice_js.blade.php

## Audio recording / waveform / encoder libs
Put client assets under:
- resources/views/titango/partials/
OR publish to public via your preferred asset pipeline.

## Server TTS providers
Create provider clients in:
- System/Services/Tts/

## Queue/workers
If you want async processing, create jobs in:
- System/Jobs/
and dispatch from VoiceCommandService (still thin + structured).
