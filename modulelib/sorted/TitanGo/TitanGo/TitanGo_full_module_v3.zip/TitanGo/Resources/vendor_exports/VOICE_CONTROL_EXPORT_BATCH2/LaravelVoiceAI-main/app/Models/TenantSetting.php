<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TenantSetting extends Model
{
    protected $fillable = [
        'tenant_id',
        'twilio_account_sid',
        'twilio_auth_token',
        'twilio_phone_number',
        'openai_api_key',
        'additional_settings',
        'system_prompt',
        'business_type',
        'business_context',
        'voice_tone',
        'operating_hours',
        'default_language',
    ];

    protected $casts = [
        'additional_settings' => 'array',
    ];

    protected $hidden = [
        'twilio_auth_token',
        'openai_api_key',
    ];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }
}
