# API Authentication Guide

## Overview
The Voice Assistant API uses Laravel Sanctum for API authentication.

## Getting Started

### 1. Create a User Account
First, register a user account using the registration endpoint or create one directly in the database.

### 2. Generate API Token
Use Laravel Sanctum to generate a personal access token:

```bash
php artisan tinker
```

```php
$user = App\Models\User::first(); // or create a new user
$token = $user->createToken('api-token')->plainTextToken;
echo $token;
```

### 3. Using the Token
Include the token in your API requests:

**Header:**
```
Authorization: Bearer YOUR_TOKEN_HERE
```

**Example Request:**
```bash
curl -H "Authorization: Bearer YOUR_TOKEN_HERE" \
     https://your-domain.repl.co/api/businesses
```

## Public Endpoints
The following endpoints do NOT require authentication (webhooks):
- `POST /twilio/voice` - Twilio voice webhook
- `POST /twilio/voice/recording` - Twilio recording webhook  
- `POST /twilio/sms` - Twilio SMS webhook

These webhooks are protected by Twilio signature validation instead.

## Protected Endpoints
All business management API endpoints require authentication:
- `GET /api/businesses`
- `POST /api/businesses`
- `GET /api/businesses/{id}`
- `PUT /api/businesses/{id}`
- `DELETE /api/businesses/{id}`
- All menu management endpoints

## Security Notes
- Keep your API tokens secure and never commit them to version control
- Twilio webhooks validate requests using signature validation
- CSRF protection is disabled for Twilio webhook routes only
- All recording downloads are authenticated with Twilio credentials
