# Titan Go (titango) — WorkSuite Voice Control Extension

This is a **WorkSuite-first** extension scaffold that adds a **voice console** UI and a **structured command pipeline**.

## Non-negotiables (matches your platform rules)
- **No raw provider calls in controllers**
- **All AI/intent routing must go through Titan Zero** (structured action request + artifact saving)
- **Controllers are thin** (authorize → validate → delegate)
- Routes are **strictly prefixed/namespaced**:
  - user: `dashboard/user/titango/...` names `dashboard.user.titango.*`
  - admin: `dashboard/admin/settings/titango/...` names `dashboard.admin.titango.*`

## Install (your canonical commands)
```bash
cd /home/saassmar/domains/ops.tradiesm.art/public_html
php artisan ext:register-all --migrations
php artisan migrate
php artisan optimize:clear
```

## Enable provider
Ensure `App\Extensions\TitanGo\System\TitanGoServiceProvider::class` is registered via:
`app/Domains/Marketplace/MarketplaceServiceProvider::$extensionProviders`
and that the DB row in `extensions` has `slug='titango'` and `installed=1`.

## What you get
- `/dashboard/user/titango/voice` → Voice Console page (mic → transcript → Titan Zero action → result)
- `/dashboard/user/titango/voice/command` → POST endpoint for transcript
- `/dashboard/user/titango/voice/tts` → optional server TTS endpoint (disabled by default)

## Where to paste extracted code
- Browser STT/TTS helpers: `resources/views/titango/partials/voice_js.blade.php`
- Any server TTS provider clients: `System/Services/Tts/*`

## TODO (wire to your core Titan Zero)
Implement `System/Services/TitanZeroBridge.php` to call your real Titan Zero layer.
