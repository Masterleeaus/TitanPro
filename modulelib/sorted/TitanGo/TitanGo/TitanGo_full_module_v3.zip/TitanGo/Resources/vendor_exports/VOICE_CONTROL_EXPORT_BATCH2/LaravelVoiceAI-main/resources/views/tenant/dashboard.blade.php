<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ $tenant->company_name }} - Dashboard
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            
            <!-- Welcome Message -->
            <div class="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-6">
                <h3 class="text-lg font-semibold text-blue-900 dark:text-blue-100 mb-2">
                    Welcome, {{ auth()->user()->name }}!
                </h3>
                <p class="text-blue-700 dark:text-blue-300">
                    You're logged in as <strong>{{ ucfirst(auth()->user()->role) }}</strong> for {{ $tenant->company_name }}
                </p>
            </div>

            <!-- Subscription Info -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="text-gray-500 dark:text-gray-400 text-sm">Subscription Plan</div>
                        <div class="text-2xl font-bold text-gray-900 dark:text-gray-100">{{ ucfirst($tenant->plan) }}</div>
                    </div>
                </div>
                
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="text-gray-500 dark:text-gray-400 text-sm">Trial Expires</div>
                        <div class="text-2xl font-bold text-gray-900 dark:text-gray-100">
                            {{ $tenant->trial_ends_at ? $tenant->trial_ends_at->diffForHumans() : 'N/A' }}
                        </div>
                    </div>
                </div>
                
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="text-gray-500 dark:text-gray-400 text-sm">Account Status</div>
                        <div class="text-2xl font-bold {{ $tenant->is_active ? 'text-green-600' : 'text-red-600' }}">
                            {{ $tenant->is_active ? 'Active' : 'Inactive' }}
                        </div>
                    </div>
                </div>
            </div>

            <!-- API Configuration Status -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">API Configuration</h3>
                    
                    <div class="space-y-3">
                        <div class="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                            <div>
                                <div class="font-medium text-gray-900 dark:text-gray-100">Twilio Configuration</div>
                                <div class="text-sm text-gray-500 dark:text-gray-400">Phone: {{ $settings->twilio_phone_number ?? 'Not configured' }}</div>
                            </div>
                            <span class="px-3 py-1 text-xs font-semibold rounded-full 
                                {{ $settings && $settings->twilio_account_sid ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' }}">
                                {{ $settings && $settings->twilio_account_sid ? 'Configured' : 'Pending' }}
                            </span>
                        </div>
                        
                        <div class="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                            <div>
                                <div class="font-medium text-gray-900 dark:text-gray-100">OpenAI Configuration</div>
                                <div class="text-sm text-gray-500 dark:text-gray-400">GPT-4 & Whisper API</div>
                            </div>
                            <span class="px-3 py-1 text-xs font-semibold rounded-full 
                                {{ $settings && $settings->openai_api_key ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' }}">
                                {{ $settings && $settings->openai_api_key ? 'Configured' : 'Pending' }}
                            </span>
                        </div>
                    </div>

                    @if($settings && (!$settings->twilio_account_sid || !$settings->openai_api_key))
                    <div class="mt-4 p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                        <p class="text-sm text-yellow-800 dark:text-yellow-200">
                            Configure your API keys in Settings to start using the voice assistant features.
                        </p>
                    </div>
                    @endif
                </div>
            </div>

            <!-- Businesses -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Your Businesses</h3>
                        <a href="#" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                            Add Business
                        </a>
                    </div>
                    
                    @if($businesses->count() > 0)
                    <div class="space-y-3">
                        @foreach($businesses as $business)
                        <div class="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                            <div class="flex justify-between items-start">
                                <div>
                                    <h4 class="font-medium text-gray-900 dark:text-gray-100">{{ $business->name }}</h4>
                                    <p class="text-sm text-gray-500 dark:text-gray-400">Type: {{ ucfirst($business->type) }}</p>
                                    <p class="text-sm text-gray-500 dark:text-gray-400">Phone: {{ $business->phone_number }}</p>
                                </div>
                                <a href="#" class="text-blue-600 hover:text-blue-700 text-sm font-medium">
                                    Manage
                                </a>
                            </div>
                        </div>
                        @endforeach
                    </div>
                    @else
                    <div class="text-center py-8">
                        <p class="text-gray-500 dark:text-gray-400">No businesses yet. Add your first business to get started!</p>
                    </div>
                    @endif
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Quick Actions</h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <a href="#" class="p-4 border-2 border-gray-200 dark:border-gray-700 rounded-lg hover:border-blue-500 dark:hover:border-blue-500 transition">
                            <div class="text-2xl mb-2">⚙️</div>
                            <div class="font-medium text-gray-900 dark:text-gray-100">Settings</div>
                            <div class="text-sm text-gray-500 dark:text-gray-400">Configure API keys</div>
                        </a>
                        
                        <a href="#" class="p-4 border-2 border-gray-200 dark:border-gray-700 rounded-lg hover:border-blue-500 dark:hover:border-blue-500 transition">
                            <div class="text-2xl mb-2">📞</div>
                            <div class="font-medium text-gray-900 dark:text-gray-100">Call Logs</div>
                            <div class="text-sm text-gray-500 dark:text-gray-400">View call history</div>
                        </a>
                        
                        <a href="#" class="p-4 border-2 border-gray-200 dark:border-gray-700 rounded-lg hover:border-blue-500 dark:hover:border-blue-500 transition">
                            <div class="text-2xl mb-2">📊</div>
                            <div class="font-medium text-gray-900 dark:text-gray-100">Analytics</div>
                            <div class="text-sm text-gray-500 dark:text-gray-400">Usage statistics</div>
                        </a>
                        
                        <a href="#" class="p-4 border-2 border-gray-200 dark:border-gray-700 rounded-lg hover:border-blue-500 dark:hover:border-blue-500 transition">
                            <div class="text-2xl mb-2">📋</div>
                            <div class="font-medium text-gray-900 dark:text-gray-100">Orders</div>
                            <div class="text-sm text-gray-500 dark:text-gray-400">Manage orders</div>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</x-app-layout>
