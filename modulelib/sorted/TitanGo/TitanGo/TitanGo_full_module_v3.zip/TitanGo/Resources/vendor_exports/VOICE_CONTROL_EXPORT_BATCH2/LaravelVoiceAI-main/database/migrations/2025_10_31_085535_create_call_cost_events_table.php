<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('call_cost_events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('call_session_id')->constrained()->onDelete('cascade');
            
            // Event details
            $table->enum('vendor', ['openai', 'google_tts', 'google_stt', 'twilio']);
            $table->string('event_type'); // e.g., 'completion', 'tts_generation', 'stt_transcription', 'voice_minute'
            
            // Usage
            $table->integer('units')->nullable(); // tokens, characters, seconds, etc.
            $table->string('unit_type')->nullable(); // 'tokens', 'characters', 'seconds', 'minutes'
            
            // Cost
            $table->decimal('unit_price', 10, 8)->nullable(); // Price per unit
            $table->decimal('cost', 10, 6)->default(0); // Total cost for this event
            
            // Details
            $table->json('metadata')->nullable(); // Additional event details (model name, voice ID, etc.)
            
            $table->timestamps();
            
            $table->index(['call_session_id', 'vendor']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('call_cost_events');
    }
};
