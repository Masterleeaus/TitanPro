<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\ApiKey;

class ValidateApiKey
{
    public function handle(Request $request, Closure $next): Response
    {
        $apiKey = $request->header('X-API-Key') ?? $request->get('api_key');

        if (!$apiKey) {
            return response()->json([
                'error' => 'API key required',
                'message' => 'Please provide an API key via X-API-Key header or api_key parameter'
            ], 401);
        }

        $key = ApiKey::where('key', $apiKey)
            ->where('is_active', true)
            ->first();

        if (!$key) {
            return response()->json([
                'error' => 'Invalid API key',
                'message' => 'The provided API key is invalid or inactive'
            ], 401);
        }

        if ($key->expires_at && $key->expires_at->isPast()) {
            return response()->json([
                'error' => 'API key expired',
                'message' => 'The API key has expired'
            ], 401);
        }

        $key->recordUsage();

        $request->merge(['tenant_id' => $key->tenant_id]);
        $request->merge(['api_key_id' => $key->id]);

        return $next($request);
    }
}
