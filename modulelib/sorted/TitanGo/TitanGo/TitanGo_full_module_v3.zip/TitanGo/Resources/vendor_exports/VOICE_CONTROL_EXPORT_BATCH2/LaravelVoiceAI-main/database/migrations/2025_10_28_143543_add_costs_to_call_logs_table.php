<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('call_logs', function (Blueprint $table) {
            $table->decimal('twilio_cost', 10, 4)->default(0)->after('duration');
            $table->decimal('openai_cost', 10, 4)->default(0)->after('twilio_cost');
            $table->decimal('tts_cost', 10, 4)->default(0)->after('openai_cost');
            $table->decimal('total_cost', 10, 4)->default(0)->after('tts_cost');
            $table->string('language_code', 10)->nullable()->after('intent');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('call_logs', function (Blueprint $table) {
            $table->dropColumn(['twilio_cost', 'openai_cost', 'tts_cost', 'total_cost', 'language_code']);
        });
    }
};
