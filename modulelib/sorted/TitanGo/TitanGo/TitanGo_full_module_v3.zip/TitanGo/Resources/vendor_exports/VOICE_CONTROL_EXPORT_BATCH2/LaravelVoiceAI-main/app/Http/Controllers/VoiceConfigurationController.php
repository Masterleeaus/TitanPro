<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\VoiceConfiguration;
use App\Services\GoogleTTSService;

class VoiceConfigurationController extends Controller
{
    public function store(Request $request)
    {
        $tenant = Auth::user()->tenant;

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'language_code' => 'required|string|in:ta-IN,en-IN,cmn-CN,ms-MY,hi-IN,th-TH,id-ID',
            'voice_name' => 'required|string|max:50',
            'gender' => 'required|in:male,female',
            'speaking_rate' => 'required|numeric|min:0.25|max:4.0',
            'pitch' => 'nullable|numeric|min:-20.0|max:20.0',
        ]);

        $validated['tenant_id'] = $tenant->id;
        $validated['pitch'] = $validated['pitch'] ?? 0.0;

        $existingDefault = VoiceConfiguration::where('tenant_id', $tenant->id)
            ->where('is_default', true)
            ->exists();

        if (!$existingDefault) {
            $validated['is_default'] = true;
        } else {
            $validated['is_default'] = false;
        }

        $voiceConfig = VoiceConfiguration::create($validated);

        return redirect()->route('settings.index')
            ->with('success', 'Voice configuration added successfully!');
    }

    public function update(Request $request, VoiceConfiguration $voiceConfiguration)
    {
        $tenant = Auth::user()->tenant;

        if ($voiceConfiguration->tenant_id !== $tenant->id) {
            abort(403, 'Unauthorized action.');
        }

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'language_code' => 'required|string|in:ta-IN,en-IN,cmn-CN,ms-MY,hi-IN,th-TH,id-ID',
            'voice_name' => 'required|string|max:50',
            'gender' => 'required|in:male,female',
            'speaking_rate' => 'required|numeric|min:0.25|max:4.0',
            'pitch' => 'nullable|numeric|min:-20.0|max:20.0',
        ]);

        $voiceConfiguration->update($validated);

        return redirect()->route('settings.index')
            ->with('success', 'Voice configuration updated successfully!');
    }

    public function destroy(VoiceConfiguration $voiceConfiguration)
    {
        $tenant = Auth::user()->tenant;

        if ($voiceConfiguration->tenant_id !== $tenant->id) {
            abort(403, 'Unauthorized action.');
        }

        $wasDefault = $voiceConfiguration->is_default;

        $voiceConfiguration->delete();

        if ($wasDefault) {
            $newDefault = VoiceConfiguration::where('tenant_id', $tenant->id)
                ->orderBy('id', 'desc')
                ->first();

            if ($newDefault) {
                $newDefault->update(['is_default' => true]);
            }
        }

        return redirect()->route('settings.index')
            ->with('success', 'Voice configuration deleted successfully!');
    }

    public function setDefault(VoiceConfiguration $voiceConfiguration)
    {
        $tenant = Auth::user()->tenant;

        if ($voiceConfiguration->tenant_id !== $tenant->id) {
            abort(403, 'Unauthorized action.');
        }

        VoiceConfiguration::where('tenant_id', $tenant->id)
            ->update(['is_default' => false]);

        $voiceConfiguration->update(['is_default' => true]);

        return redirect()->route('settings.index')
            ->with('success', 'Default voice configuration updated!');
    }

    public function test(Request $request)
    {
        $validated = $request->validate([
            'language_code' => 'required|string|in:ta-IN,en-IN,cmn-CN,ms-MY,hi-IN,th-TH,id-ID',
            'voice_name' => 'required|string|max:50',
            'gender' => 'required|in:male,female',
            'speaking_rate' => 'required|numeric|min:0.25|max:4.0',
            'pitch' => 'nullable|numeric|min:-20.0|max:20.0',
            'test_text' => 'nullable|string|max:200',
        ]);

        $testText = $validated['test_text'] ?? $this->getDefaultTestText($validated['language_code']);

        $ttsService = new GoogleTTSService();
        
        try {
            $audioUrl = $ttsService->generateSpeechWithConfig(
                $testText,
                $validated['voice_name'],
                $validated['gender'],
                $validated['speaking_rate'],
                $validated['pitch'] ?? 0.0
            );

            return response()->json([
                'success' => true,
                'audio_url' => $audioUrl,
                'message' => 'Voice preview generated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate voice preview: ' . $e->getMessage()
            ], 500);
        }
    }

    private function getDefaultTestText($languageCode)
    {
        $texts = [
            'ta-IN' => 'வணக்கம்! உங்கள் வணிகத்திற்கு வரவேற்கிறோம். நான் உங்களுக்கு எவ்வாறு உதவ முடியும்?',
            'en-IN' => 'Hello! Welcome to your business. How may I help you today?',
        ];

        return $texts[$languageCode] ?? $texts['en-IN'];
    }
}
