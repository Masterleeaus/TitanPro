<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CallSession extends Model
{
    protected $connection = 'pgsql';
    
    protected $fillable = [
        'tenant_id',
        'source_channel',
        'session_id',
        'call_sid',
        'started_at',
        'ended_at',
        'duration_seconds',
        'status',
        'transcript_summary',
        'metadata',
        'cost_openai',
        'cost_tts',
        'cost_stt',
        'cost_twilio',
        'total_cost',
        'openai_tokens',
        'tts_characters',
        'stt_audio_seconds',
        'twilio_billed_seconds',
    ];

    protected $casts = [
        'started_at' => 'datetime',
        'ended_at' => 'datetime',
        'metadata' => 'array',
        'cost_openai' => 'decimal:6',
        'cost_tts' => 'decimal:6',
        'cost_stt' => 'decimal:6',
        'cost_twilio' => 'decimal:6',
        'total_cost' => 'decimal:6',
    ];

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function costEvents(): HasMany
    {
        return $this->hasMany(CallCostEvent::class);
    }

    public function turns(): HasMany
    {
        return $this->hasMany(CallTurn::class);
    }

    // Calculate total cost from individual costs
    public function calculateTotalCost(): void
    {
        $this->total_cost = 
            $this->cost_openai + 
            $this->cost_tts + 
            $this->cost_stt + 
            $this->cost_twilio;
        $this->save();
    }

    // Scope for filtering by source
    public function scopeBySource($query, string $source)
    {
        return $query->where('source_channel', $source);
    }

    // Scope for active calls
    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }
}
