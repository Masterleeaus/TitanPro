# EXTRACT_NOTES — LaravelVoiceAI-main

This folder contains files auto-extracted as *voice-control relevant* (TTS/STT/audio/calls/queues/websockets).
Paths are preserved from the original repo so you can transplant pieces into a WorkSuite module/extension cleanly.

## Extracted files (count)
110

## Likely entry points
- `app/Http/Controllers/AIConfigurationController.php`
- `app/Http/Controllers/Api/CallSessionController.php`
- `app/Http/Controllers/Api/TenantAIController.php`
- `app/Http/Controllers/Api/V1/ConversationController.php`
- `app/Http/Controllers/BusinessController.php`
- `app/Http/Controllers/CallLogController.php`
- `app/Http/Controllers/CallLogsController.php`
- `app/Http/Controllers/ChatController.php`
- `app/Http/Controllers/DashboardController.php`
- `app/Http/Controllers/MediaStreamApiController.php`
- `app/Http/Controllers/SettingsController.php`
- `app/Http/Controllers/TwilioWebhookController.php`
- `app/Http/Controllers/VoiceConfigurationController.php`
- `app/Models/CallCostEvent.php`
- `app/Models/CallLog.php`
- `app/Models/CallSession.php`
- `app/Models/CallTurn.php`
- `app/Models/VoiceConfiguration.php`
- `app/Services/ApiBalanceService.php`
- `app/Services/CallCostCalculator.php`
- `app/Services/GoogleTTSService.php`
- `app/Services/LanguageIntelligenceService.php`
- `app/Services/OpenAIService.php`
- `app/Services/TwilioService.php`
- `app/Services/VoiceAssistantService.php`
- `attached_assets/Pasted--type-service-account-project-id-ai-voice-476410-private-key-id-fdbc404374626-1761561687079_1761561687080.txt`
- `config/queue.php`
- `database/migrations/0001_01_01_000002_create_jobs_table.php`
- `database/migrations/2025_10_27_082108_create_call_logs_table.php`
- `database/migrations/2025_10_27_110950_create_voice_configurations_table.php`
- `database/migrations/2025_10_28_143543_add_costs_to_call_logs_table.php`
- `database/migrations/2025_10_31_085534_create_call_sessions_table.php`
- `database/migrations/2025_10_31_085535_create_call_cost_events_table.php`
- `database/migrations/2025_10_31_085536_create_call_turns_table.php`
- `resources/views/call-logs/index.blade.php`
- `resources/views/tenant/call-logs.blade.php`