<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'Laravel') }}</title>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #f1f5f9;
            line-height: 1.6;
        }
        
        /* BACKGROUND COLORS */
        .bg-white { background-color: #ffffff; }
        .bg-gray-50 { background-color: #f9fafb; }
        .bg-gray-100 { background-color: #f3f4f6; }
        .bg-gray-800 { background-color: #1f2937; }
        .bg-gray-900 { background-color: #111827; }
        .bg-blue-50 { background-color: #eff6ff; }
        .bg-blue-100 { background-color: #dbeafe; }
        .bg-blue-900\/20 { background-color: rgba(30, 58, 138, 0.2); }
        .bg-green-100 { background-color: #d1fae5; }
        .bg-yellow-100 { background-color: #fef3c7; }
        
        /* DARK MODE BACKGROUNDS */
        .dark\:bg-gray-800 { background-color: #1f2937; }
        .dark\:bg-gray-900 { background-color: #111827; }
        .dark\:bg-blue-900\/20 { background-color: rgba(30, 58, 138, 0.2); }
        
        /* TEXT COLORS */
        .text-gray-500 { color: #6b7280; }
        .text-gray-800 { color: #1f2937; }
        .text-gray-900 { color: #111827; }
        .text-blue-700 { color: #1d4ed8; }
        .text-blue-900 { color: #1e3a8a; }
        .text-green-600 { color: #16a34a; }
        .text-green-800 { color: #166534; }
        .text-red-600 { color: #dc2626; }
        .text-yellow-800 { color: #854d0e; }
        
        /* DARK MODE TEXT */
        .dark\:text-gray-100 { color: #f3f4f6; }
        .dark\:text-gray-200 { color: #e5e7eb; }
        .dark\:text-gray-400 { color: #9ca3af; }
        .dark\:text-blue-100 { color: #dbeafe; }
        .dark\:text-blue-300 { color: #93c5fd; }
        
        /* BORDERS */
        .border { border-width: 1px; }
        .border-gray-100 { border-color: #f3f4f6; }
        .border-gray-200 { border-color: #e5e7eb; }
        .border-blue-200 { border-color: #bfdbfe; }
        .dark\:border-gray-600 { border-color: #4b5563; }
        .dark\:border-gray-700 { border-color: #374151; }
        .dark\:border-blue-800 { border-color: #1e40af; }
        
        /* LAYOUT */
        .max-w-7xl { max-width: 80rem; margin-left: auto; margin-right: auto; }
        .mx-auto { margin-left: auto; margin-right: auto; }
        
        /* PADDING */
        .p-4 { padding: 1rem; }
        .p-6 { padding: 1.5rem; }
        .px-3 { padding-left: 0.75rem; padding-right: 0.75rem; }
        .px-4 { padding-left: 1rem; padding-right: 1rem; }
        .py-1 { padding-top: 0.25rem; padding-bottom: 0.25rem; }
        .py-12 { padding-top: 3rem; padding-bottom: 3rem; }
        
        @media (min-width: 640px) {
            .sm\:px-6 { padding-left: 1.5rem; padding-right: 1.5rem; }
        }
        @media (min-width: 1024px) {
            .lg\:px-8 { padding-left: 2rem; padding-right: 2rem; }
        }
        
        /* MARGIN */
        .mb-2 { margin-bottom: 0.5rem; }
        .mb-4 { margin-bottom: 1rem; }
        
        /* SPACING */
        .space-y-3 > * + * { margin-top: 0.75rem; }
        .space-y-6 > * + * { margin-top: 1.5rem; }
        .gap-4 { gap: 1rem; }
        .gap-6 { gap: 1.5rem; }
        
        /* GRID SYSTEM */
        .grid { display: grid; }
        .grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
        
        @media (min-width: 768px) {
            .md\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .md\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        }
        @media (min-width: 1024px) {
            .lg\:grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
        }
        
        /* FLEX */
        .flex { display: flex; }
        .items-center { align-items: center; }
        .justify-between { justify-content: space-between; }
        
        /* TYPOGRAPHY */
        .text-xs { font-size: 0.75rem; }
        .text-sm { font-size: 0.875rem; }
        .text-lg { font-size: 1.125rem; }
        .text-xl { font-size: 1.25rem; }
        .text-2xl { font-size: 1.5rem; }
        .font-medium { font-weight: 500; }
        .font-semibold { font-weight: 600; }
        .font-bold { font-weight: 700; }
        .leading-tight { line-height: 1.25; }
        
        /* BORDER RADIUS */
        .rounded-lg { border-radius: 0.5rem; }
        .rounded-full { border-radius: 9999px; }
        @media (min-width: 640px) {
            .sm\:rounded-lg { border-radius: 0.5rem; }
        }
        
        /* SHADOWS */
        .shadow-sm { box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3); }
        .overflow-hidden { overflow: hidden; }
        
        /* Navigation */
        nav { background: #1f2937; border-bottom: 1px solid #374151; }
        .nav-container { max-width: 80rem; margin: 0 auto; padding: 0 1rem; }
        .nav-flex { display: flex; justify-content: space-between; align-items: center; height: 4rem; }
        .nav-left { display: flex; align-items: center; gap: 2rem; }
        .nav-logo svg { height: 2.25rem; width: auto; fill: #f1f5f9; }
        .nav-links { display: none; gap: 1rem; }
        @media (min-width: 640px) { .nav-links { display: flex; } }
        
        .nav-link { 
            padding: 0.5rem 1rem;
            color: #cbd5e1;
            text-decoration: none;
            font-size: 0.875rem;
            font-weight: 500;
            border-radius: 0.375rem;
            transition: all 0.2s;
        }
        .nav-link:hover { background: #334155; color: #f1f5f9; }
        .nav-link.active { background: #334155; color: #f1f5f9; }
        
        /* Dropdown */
        .dropdown { position: relative; }
        .dropdown-btn { 
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: transparent;
            border: 1px solid #475569;
            color: #cbd5e1;
            font-size: 0.875rem;
            border-radius: 0.375rem;
            cursor: pointer;
            transition: all 0.2s;
        }
        .dropdown-btn:hover { background: #334155; color: #f1f5f9; }
        .dropdown-btn svg { width: 1rem; height: 1rem; fill: currentColor; }
        .dropdown-menu { 
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            margin-top: 0.5rem;
            min-width: 12rem;
            background: #1f2937;
            border: 1px solid #475569;
            border-radius: 0.5rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.5);
            overflow: hidden;
            z-index: 50;
        }
        .dropdown:hover .dropdown-menu { display: block; }
        .dropdown-item { 
            display: block;
            padding: 0.75rem 1rem;
            color: #cbd5e1;
            text-decoration: none;
            font-size: 0.875rem;
            transition: all 0.2s;
        }
        .dropdown-item:hover { background: #334155; color: #f1f5f9; }
        
        /* Mobile Menu */
        .mobile-btn { 
            display: flex;
            padding: 0.5rem;
            background: transparent;
            border: none;
            color: #cbd5e1;
            cursor: pointer;
        }
        @media (min-width: 640px) { .mobile-btn { display: none; } }
        .mobile-btn svg { width: 1.5rem; height: 1.5rem; stroke: currentColor; }
        .mobile-menu { display: none; background: #1f2937; border-top: 1px solid #475569; }
        .mobile-menu.show { display: block; }
        .mobile-link { 
            display: block;
            padding: 0.75rem 1rem;
            color: #cbd5e1;
            text-decoration: none;
            border-left: 3px solid transparent;
        }
        .mobile-link:hover, .mobile-link.active { 
            background: #334155;
            color: #f1f5f9;
            border-left-color: #3b82f6;
        }
        .mobile-user { padding: 1rem; border-top: 1px solid #475569; }
        .mobile-user-info { padding: 0 1rem 1rem; }
        .mobile-user-name { font-weight: 500; color: #f1f5f9; }
        .mobile-user-email { font-size: 0.875rem; color: #94a3b8; }
        
        /* Header */
        header { background: #1f2937; box-shadow: 0 1px 3px rgba(0,0,0,0.3); padding: 1.5rem 0; }
        
        /* Min Height */
        .min-h-screen { min-height: 100vh; }
    </style>
</head>
<body>
    <div class="min-h-screen">
        <!-- Navigation -->
        <nav x-data="{ open: false }">
            <div class="nav-container">
                <div class="nav-flex">
                    <div class="nav-left">
                        <a href="{{ route('dashboard') }}" class="nav-logo">
                            <svg viewBox="0 0 50 52" xmlns="http://www.w3.org/2000/svg">
                                <path d="M49.626 11.564a.809.809 0 0 1 .028.209v10.972a.8.8 0 0 1-.402.694l-9.209 5.302V39.25c0 .286-.152.55-.4.694L20.42 51.01c-.044.025-.092.041-.14.058-.018.006-.035.017-.054.022a.805.805 0 0 1-.41 0c-.022-.006-.042-.018-.063-.026-.044-.016-.09-.03-.132-.054L.402 39.944A.801.801 0 0 1 0 39.25V6.334c0-.072.01-.142.028-.21.006-.023.02-.044.028-.067.015-.042.029-.085.051-.124.015-.026.037-.047.055-.071.023-.032.044-.065.071-.093.023-.023.053-.04.079-.06.029-.024.055-.05.088-.069h.001l9.61-5.533a.802.802 0 0 1 .8 0l9.61 5.533h.002c.032.02.059.045.088.068.026.02.055.038.078.06.028.029.048.062.072.094.017.024.04.045.054.071.023.04.036.082.052.124.008.023.022.044.028.068a.809.809 0 0 1 .028.209v20.559l8.008-4.611v-10.51c0-.07.01-.141.028-.208.007-.024.02-.045.028-.068.016-.042.03-.085.052-.124.015-.026.037-.047.054-.071.024-.032.044-.065.072-.093.023-.023.052-.04.078-.06.03-.024.056-.05.088-.069h.001l9.611-5.533a.801.801 0 0 1 .8 0l9.61 5.533c.034.02.06.045.09.068.025.02.054.038.077.06.028.029.048.062.072.094.018.024.04.045.054.071.023.039.036.082.052.124.009.023.022.044.028.068zm-1.574 10.718v-9.124l-3.363 1.936-4.646 2.675v9.124l8.01-4.611zm-9.61 16.505v-9.13l-4.57 2.61-13.05 7.448v9.216l17.62-10.144zM1.602 7.719v31.068L19.22 48.93v-9.214l-9.204-5.209-.003-.002-.004-.002c-.031-.018-.057-.044-.086-.066-.025-.02-.054-.036-.076-.058l-.002-.003c-.026-.025-.044-.056-.066-.084-.02-.027-.044-.05-.06-.078l-.001-.003c-.018-.03-.029-.066-.042-.1-.013-.03-.03-.058-.038-.09v-.001c-.01-.038-.012-.078-.016-.117-.004-.03-.012-.06-.012-.09v-21.483L1.602 7.72zm8.81-5.994L2.405 6.334l8.005 4.609 8.006-4.61-8.006-4.608zm4.164 28.764l4.645-2.674V7.719l-3.363 1.936-4.646 2.675v20.096l3.364-1.937zM39.243 7.164l-8.006 4.609 8.006 4.609 8.005-4.61-8.005-4.608zm-.801 10.605l-4.646-2.675-3.363-1.936v9.124l4.645 2.674 3.364 1.937v-9.124zM20.02 38.33l11.743-6.704 5.87-3.35-8-4.606-9.211 5.303-8.395 4.833 7.993 4.524z"/>
                            </svg>
                        </a>
                        <div class="nav-links">
                            <a href="{{ route('dashboard') }}" class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">Dashboard</a>
                            @if(Auth::user()->role !== 'super_admin')
                            <a href="{{ route('dashboard.chat') }}" class="nav-link {{ request()->routeIs('dashboard.chat') ? 'active' : '' }}">AI Chat</a>
                            <a href="{{ route('ai-configuration.index') }}" class="nav-link {{ request()->routeIs('ai-configuration.*') ? 'active' : '' }}">AI Assistant</a>
                            <a href="{{ route('call-logs.index') }}" class="nav-link {{ request()->routeIs('call-logs.*') ? 'active' : '' }}">Call Logs</a>
                            <a href="{{ route('settings.index') }}" class="nav-link {{ request()->routeIs('settings.*') ? 'active' : '' }}">Settings</a>
                            @endif
                        </div>
                    </div>
                    
                    <div class="nav-links">
                        <div class="dropdown">
                            <button class="dropdown-btn">
                                <span>{{ Auth::user()->name }}</span>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </button>
                            <div class="dropdown-menu">
                                <a href="{{ route('profile.edit') }}" class="dropdown-item">Profile</a>
                            </div>
                        </div>
                        <form method="POST" action="{{ route('logout') }}" style="margin:0;display:inline-block;">
                            @csrf
                            <button type="submit" class="nav-link" style="background:transparent;border:none;cursor:pointer;font:inherit;">
                                Log Out
                            </button>
                        </form>
                    </div>
                    
                    <button @click="open = ! open" class="mobile-btn">
                        <svg fill="none" viewBox="0 0 24 24">
                            <path :class="{'hidden': open}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                            <path :class="{'hidden': ! open}" class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
            </div>
            
            <div :class="{'show': open}" class="mobile-menu">
                <a href="{{ route('dashboard') }}" class="mobile-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">Dashboard</a>
                @if(Auth::user()->role !== 'super_admin')
                <a href="{{ route('dashboard.chat') }}" class="mobile-link {{ request()->routeIs('dashboard.chat') ? 'active' : '' }}">AI Chat</a>
                <a href="{{ route('ai-configuration.index') }}" class="mobile-link {{ request()->routeIs('ai-configuration.*') ? 'active' : '' }}">AI Assistant</a>
                <a href="{{ route('call-logs.index') }}" class="mobile-link {{ request()->routeIs('call-logs.*') ? 'active' : '' }}">Call Logs</a>
                <a href="{{ route('settings.index') }}" class="mobile-link {{ request()->routeIs('settings.*') ? 'active' : '' }}">Settings</a>
                @endif
                <div class="mobile-user">
                    <div class="mobile-user-info">
                        <div class="mobile-user-name">{{ Auth::user()->name }}</div>
                        <div class="mobile-user-email">{{ Auth::user()->email }}</div>
                    </div>
                    <a href="{{ route('profile.edit') }}" class="mobile-link">Profile</a>
                </div>
                <form method="POST" action="{{ route('logout') }}" style="margin:0;">
                    @csrf
                    <button type="submit" class="mobile-link" style="width:100%;text-align:left;background:transparent;border:none;cursor:pointer;font:inherit;">
                        Log Out
                    </button>
                </form>
            </div>
        </nav>

        @isset($header)
        <header>
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                {{ $header }}
            </div>
        </header>
        @endisset

        <main>
            {{ $slot }}
        </main>
    </div>
</body>
</html>
