<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\TenantSetting;
use Illuminate\Http\Request;

class TenantAIController extends Controller
{
    /**
     * Get tenant's AI configuration for customizing conversations
     */
    public function getConfiguration($tenantId)
    {
        $settings = TenantSetting::where('tenant_id', $tenantId)->first();
        
        if (!$settings) {
            return response()->json([
                'system_prompt' => null,
                'business_type' => 'general',
                'business_context' => null,
                'voice_tone' => 'professional',
                'operating_hours' => null,
                'default_language' => 'en-IN',
            ]);
        }
        
        return response()->json([
            'system_prompt' => $settings->system_prompt,
            'business_type' => $settings->business_type ?? 'general',
            'business_context' => $settings->business_context,
            'voice_tone' => $settings->voice_tone ?? 'professional',
            'operating_hours' => $settings->operating_hours,
            'default_language' => $settings->default_language ?? 'en-IN',
        ]);
    }
}
