# Voice Assistant SaaS Platform

## Overview
A multi-tenant SaaS voice assistant platform built with Laravel (PHP 8.2) that enables businesses to handle orders, appointments, and bookings via phone calls, SMS, and voice notes in any language.

## Tech Stack
- **Backend**: Laravel 10+ (PHP 8.2)
- **Database**: PostgreSQL (Neon)
- **Communication**: Twilio Voice & SMS API
- **AI Services**: OpenAI (GPT-4o-mini for conversation, Whisper for transcription)
- **Voice Synthesis**: Google Cloud Text-to-Speech (Neural2, Wavenet Premium, Standard voices)
- **Speech Recognition**: Google Speech-to-Text V2 (telephony model) with multilingual support
- **Multi-tenancy**: Tenant isolation with customizable voice configurations per language

## Current State
✅ Laravel application fully configured and running on port 5000
✅ PostgreSQL database connected via Neon
✅ Database migrations completed (businesses, menus, orders, appointments, conversations)
✅ Eloquent models created with relationships
✅ Twilio integration service implemented with Replit connector
✅ OpenAI integration service for Whisper (speech-to-text) and GPT (conversation)
✅ Voice assistant service for processing calls and SMS
✅ Webhook endpoints for Twilio voice and SMS callbacks
✅ RESTful API for business management, menu upload, orders, and appointments
✅ Multi-language support via Whisper transcription

## Recent Changes (October 28, 2025)

### Latest Updates (Multilingual Expansion & API Dashboard)
- ✅ Expanded language support from 2 to **7 languages**: Tamil, English, Mandarin Chinese, Malay, Hindi, Thai, Indonesian
- ✅ Implemented **comprehensive language detection** using Unicode script detection (Tamil, Hindi, Thai, Chinese) and keyword detection (Malay, Indonesian)
- ✅ Added **Google Cloud Text-to-Speech** with premium Wavenet voices (Natural & Conversational, Warm & Friendly, Deep & Authoritative)
- ✅ Created **customizable voice configurations** per language with gender selection and speaking rate control
- ✅ Built **API Usage Dashboard** showing real-time Twilio balance, estimated OpenAI costs, and Google TTS costs
- ✅ Enhanced voice variety with Neural2 (best), Wavenet Premium, and Standard quality tiers for each language
- ✅ Automatic language-specific closing messages in all 7 supported languages
- ✅ Multi-tenant voice configuration system with priority and default settings

### Previous Updates (Voice Quality & Speed - October 27, 2025)
- ✅ Implemented **automatic language detection** (no menu/button press needed)
- ✅ Added **Indian female voice** (Amazon Polly Aditi) with natural accent
- ✅ Optimized AI responses to **1-2 seconds** (3x faster than before)
- ✅ Changed AI model from GPT-4 to **GPT-4o-mini** for faster responses and broader compatibility
- ✅ Enabled **English + Tamil support** with automatic switching
- ✅ Implemented **LIVE conversation mode** (real-time back-and-forth, not record-and-replay)
- ✅ Added natural, human-like conversation flow (not robotic)
- ✅ Removed language selection menu for seamless user experience

### Infrastructure & Security
- ✅ Fixed critical Replit proxy issue with **TrustProxies middleware** for HTTPS URL validation
- ✅ Resolved CSRF protection to allow Twilio webhooks at `/webhooks/twilio/*`
- ✅ Fixed database constraints by adding required `call_sid` field to CallLog
- ✅ Twilio signature validation working correctly with HTTPS URLs
- ✅ Initialized Laravel project with PHP 8.2
- ✅ Set up PostgreSQL database with all required tables
- ✅ Implemented Twilio and OpenAI service classes with security fixes
- ✅ Laravel server running on port 5000

## Security Improvements
- ✅ Twilio webhook signature validation implemented
- ✅ MessagingResponse used for SMS (not VoiceResponse)
- ✅ Authenticated recording downloads with Twilio credentials
- ✅ API endpoints protected with Laravel Sanctum
- ✅ CSRF protection exempted for Twilio webhook routes
- ✅ Proper error handling for malformed AI JSON responses
- ✅ Input validation for order and appointment data
- ✅ Menu item cross-validation (AI orders matched against actual menu)
- ✅ Recording download verification before transcription
- ✅ Empty transcription handling

## Authentication
- API endpoints require Laravel Sanctum Bearer tokens
- Twilio webhooks use signature validation (no token needed)
- See AUTHENTICATION.md for setup instructions

## Project Architecture

### Database Schema
1. **businesses** - Store business profiles with type, phone numbers, settings
2. **menus** - Restaurant menu items with pricing and availability
3. **orders** - Customer orders with items, totals, and status
4. **appointments** - Service bookings with scheduling and status
5. **conversations** - Call/SMS transcripts with intent and language detection

### Key Services
- **TwilioService**: Handles SMS, voice calls, and TwiML responses
- **OpenAIService**: Transcription, GPT chat, intent extraction, order parsing
- **VoiceAssistantService**: Main logic for processing calls and SMS

### API Endpoints
- `GET /api/businesses` - List all businesses
- `POST /api/businesses` - Create new business
- `GET /api/businesses/{id}` - Get business details
- `PUT /api/businesses/{id}` - Update business
- `DELETE /api/businesses/{id}` - Delete business
- `GET /api/businesses/{id}/orders` - Get business orders
- `GET /api/businesses/{id}/appointments` - Get business appointments
- `GET /api/businesses/{businessId}/menus` - List menu items
- `POST /api/businesses/{businessId}/menus` - Add menu item
- `PUT /api/businesses/{businessId}/menus/{id}` - Update menu item
- `DELETE /api/businesses/{businessId}/menus/{id}` - Delete menu item

### Webhook Endpoints
- `POST /twilio/voice` - Handle incoming voice calls
- `POST /twilio/voice/recording` - Process voice recordings
- `POST /twilio/sms` - Handle incoming SMS messages

## Business Types Supported
- **restaurant**: Menu upload, order placement via voice/text
- **salon**: Appointment booking and scheduling
- **service_provider**: Service bookings and reservations
- **hotel**: Table/room reservations
- **other**: General inquiry handling

## Features
✅ **Live real-time conversation** (natural back-and-forth dialogue)
✅ **7-language support** with automatic detection (Tamil, English, Chinese, Malay, Hindi, Thai, Indonesian)
✅ **Customizable voice configurations** - Gender selection, voice quality tiers, speaking rate control
✅ **API Usage Dashboard** - Real-time Twilio balance, estimated OpenAI & Google TTS costs, call statistics
✅ **Premium voice quality** - Neural2, Wavenet Premium, Standard Google Cloud TTS voices
✅ **Ultra-fast responses** (1-2 seconds, human-like speed)
✅ Multi-channel support (voice calls, SMS, voice notes)
✅ Multi-language transcription and conversation
✅ Intent recognition (order, appointment, inquiry, complaint)
✅ Natural language processing for extracting order details
✅ Automated order placement from voice/text
✅ Appointment scheduling with date/time extraction
✅ Business-specific conversation context
✅ Conversation logging and analytics
✅ Menu management API
✅ Order and appointment tracking
✅ Multi-tenant architecture with isolated settings per tenant

## Environment Variables
- `DATABASE_URL`, `PGHOST`, `PGPORT`, `PGDATABASE`, `PGUSER`, `PGPASSWORD` - PostgreSQL
- `OPENAI_API_KEY` - OpenAI API access
- Twilio credentials managed via Replit connector (automatic)

## User Preferences
- **Voice**: Customizable per language - Neural2, Wavenet Premium, and Standard voices available
- **Voice Quality Tiers**: Premium descriptive names (Natural & Conversational, Warm & Friendly, Deep & Authoritative)
- **Speed**: Fast responses (1-2 seconds) like human conversation with adjustable speaking rates
- **Languages**: 7 languages supported - Tamil, English, Mandarin Chinese, Malay, Hindi, Thai, Indonesian
- **Language Detection**: Automatic detection via Unicode script ranges and keyword matching
- **User Experience**: No menus, no button presses - natural conversation flow
- **AI Model**: GPT-4o-mini for accessibility and speed
- **Target Markets**: Singapore, Malaysia, India, Thailand with multilingual customer base

## Next Steps (Future Enhancements)
- Integration with third-party ordering systems (Toast, Square, Clover)
- Calendar integration (Google Calendar, Outlook)
- Payment processing for orders and deposits
- Admin panel for business configuration
- Customer management and history
- Multi-language voice synthesis
- Real-time availability checking
- SMS confirmation and reminders
- Business analytics dashboard
