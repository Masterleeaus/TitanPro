<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\TwilioService;
use App\Services\OpenAIService;
use App\Services\GoogleTTSService;
use App\Models\Business;
use App\Models\CallLog;
use App\Models\TenantSetting;
use App\Models\VoiceConfiguration;
use Twilio\Security\RequestValidator;

class TwilioWebhookController extends Controller
{
    protected function getTenantByPhone($phoneNumber)
    {
        $settings = TenantSetting::where('twilio_phone_number', $phoneNumber)->first();
        return $settings ? $settings->tenant_id : null;
    }

    protected function detectLanguage($text)
    {
        if (preg_match('/[\x{4E00}-\x{9FFF}]/u', $text)) {
            return 'cmn-CN';
        }
        
        if (preg_match('/[\x{0900}-\x{097F}]/u', $text)) {
            return 'hi-IN';
        }
        
        if (preg_match('/[\x{0E00}-\x{0E7F}]/u', $text)) {
            return 'th-TH';
        }
        
        if (preg_match('/[\x{0B80}-\x{0BFF}]/u', $text)) {
            return 'ta-IN';
        }
        
        $malayKeywords = preg_match('/\b(saya|anda|boleh|tolong|mahu|terima|kasih|apa|di|dengan|untuk|dari)\b/i', $text);
        if ($malayKeywords) {
            return 'ms-MY';
        }
        
        $indonesianKeywords = preg_match('/\b(saya|anda|bisa|tolong|mau|terima|kasih|apa|di|dengan|untuk|dari|yang)\b/i', $text);
        if ($indonesianKeywords) {
            return 'id-ID';
        }
        
        return 'en-IN';
    }

    protected function calculateCosts($duration, $inputTokens, $outputTokens, $ttsCharacters)
    {
        $twilioInboundPerMinute = 0.0085;
        $twilioOutboundPerMinute = 0.013;
        $twilioMinutes = $duration / 60;
        $twilioCost = $twilioMinutes * $twilioInboundPerMinute;
        
        $openaiInputCostPer1k = 0.00015;
        $openaiOutputCostPer1k = 0.0006;
        $openaiCost = ($inputTokens / 1000 * $openaiInputCostPer1k) + ($outputTokens / 1000 * $openaiOutputCostPer1k);
        
        $googleTTSCostPerChar = 0.000016;
        $ttsCost = $ttsCharacters * $googleTTSCostPerChar;
        
        $totalCost = $twilioCost + $openaiCost + $ttsCost;
        
        return [
            'twilio_cost' => round($twilioCost, 4),
            'openai_cost' => round($openaiCost, 4),
            'tts_cost' => round($ttsCost, 4),
            'total_cost' => round($totalCost, 4),
        ];
    }

    protected function validateTwilioRequest(Request $request, $authToken)
    {
        if (!$authToken) {
            return false;
        }

        $validator = new RequestValidator($authToken);
        $url = $request->fullUrl();
        $signature = $request->header('X-Twilio-Signature', '');
        $params = $request->all();

        return $validator->validate($signature, $url, $params);
    }

    public function handleVoiceCall(Request $request)
    {
        $from = $request->input('From');
        $to = $request->input('To');
        $callSid = $request->input('CallSid');

        \Log::info('Twilio webhook called', [
            'from' => $from,
            'to' => $to,
            'call_sid' => $callSid,
            'url' => $request->fullUrl(),
        ]);

        $tenantId = $this->getTenantByPhone($to);
        
        if (!$tenantId) {
            \Log::error('No tenant found for phone: ' . $to);
            $twilioService = new TwilioService();
            $authToken = $twilioService->getAuthToken();
            
            if (!$this->validateTwilioRequest($request, $authToken)) {
                \Log::error('Signature validation failed (no tenant)');
                return response('Unauthorized', 403);
            }

            $response = $twilioService->createVoiceResponse();
            $response->say('Sorry, this number is not configured.');
            return response($response)->header('Content-Type', 'text/xml');
        }

        \Log::info('Tenant found: ' . $tenantId);
        $twilioService = new TwilioService($tenantId);
        
        $isValid = $this->validateTwilioRequest($request, $twilioService->getAuthToken());
        \Log::info('Signature validation result: ' . ($isValid ? 'VALID' : 'INVALID'));
        
        if (!$isValid) {
            \Log::error('Signature validation failed for tenant: ' . $tenantId);
            return response('Unauthorized', 403);
        }

        $business = Business::where('tenant_id', $tenantId)->first();

        CallLog::create([
            'tenant_id' => $tenantId,
            'business_id' => $business->id ?? null,
            'call_sid' => $callSid,
            'from_number' => $from,
            'to_number' => $to,
            'direction' => 'inbound',
            'status' => 'in-progress',
            'twilio_cost' => 0,
            'openai_cost' => 0,
            'tts_cost' => 0,
            'total_cost' => 0,
        ]);

        $response = $twilioService->createVoiceResponse();
        
        $voiceConfig = VoiceConfiguration::where('tenant_id', $tenantId)
            ->where('is_default', true)
            ->orderBy('priority', 'desc')
            ->first();
        
        if (!$voiceConfig) {
            $voiceConfig = VoiceConfiguration::where('tenant_id', $tenantId)
                ->orderBy('id', 'desc')
                ->first();
        }
        
        $greetingLanguage = $voiceConfig ? $voiceConfig->language_code : 'en-IN';
        
        $greetings = [
            'ta-IN' => $business ? "{$business->name} இல் நான் உங்களுக்கு எவ்வாறு உதவ முடியும்?" : "நான் உங்களுக்கு எவ்வாறு உதவ முடியும்?",
            'en-IN' => $business ? "Welcome to {$business->name}! How may I help you today?" : "Hello! How may I help you today?",
            'hi-IN' => $business ? "{$business->name} में आपकी कैसे मदद कर सकता हूं?" : "मैं आपकी कैसे मदद कर सकता हूं?",
            'cmn-CN' => $business ? "欢迎来到{$business->name}！我能为您做什么？" : "您好！我能为您做什么？",
            'ms-MY' => $business ? "Selamat datang ke {$business->name}! Bagaimana saya boleh membantu anda?" : "Hello! Bagaimana saya boleh membantu anda?",
            'id-ID' => $business ? "Selamat datang di {$business->name}! Ada yang bisa saya bantu?" : "Halo! Ada yang bisa saya bantu?",
            'th-TH' => $business ? "ยินดีต้อนรับสู่ {$business->name}! ฉันจะช่วยอะไรคุณได้บ้าง?" : "สวัสดี! ฉันจะช่วยอะไรคุณได้บ้าง?",
        ];
        
        $greeting = $greetings[$greetingLanguage] ?? $greetings['en-IN'];
        
        $googleTTS = new GoogleTTSService();
        
        if ($voiceConfig) {
            $greetingAudioUrl = $googleTTS->generateSpeechWithConfig(
                $greeting,
                $voiceConfig->voice_name,
                $voiceConfig->gender,
                $voiceConfig->speaking_rate,
                $voiceConfig->pitch
            );
        } else {
            $greetingAudioUrl = $googleTTS->generateSpeech($greeting, $greetingLanguage, false);
        }
        
        $response->play($greetingAudioUrl);
        
        $domain = env('APP_URL') ?: ('https://' . env('REPLIT_DEV_DOMAIN', 'localhost:5000'));
        \Log::info('WebSocket Domain Debug', [
            'APP_URL' => env('APP_URL'),
            'REPLIT_DEV_DOMAIN' => env('REPLIT_DEV_DOMAIN'),
            'final_domain' => $domain
        ]);
        $websocketUrl = str_replace('https://', 'wss://', $domain) . '/ws';
        
        $connect = $response->connect();
        $stream = $connect->stream([
            'url' => $websocketUrl,
        ]);
        
        $stream->parameter(['name' => 'tenantId', 'value' => $tenantId]);
        $stream->parameter(['name' => 'from', 'value' => $from]);
        $stream->parameter(['name' => 'to', 'value' => $to]);

        $twiml = (string) $response;
        \Log::info('TwiML Response: ' . $twiml);

        return response($response)->header('Content-Type', 'text/xml');
    }

    public function handleLanguageSelection(Request $request)
    {
        $from = $request->input('From');
        $to = $request->input('To');
        $callSid = $request->input('CallSid');
        $digits = $request->input('Digits');

        \Log::info('Language selection', [
            'from' => $from,
            'digits' => $digits,
        ]);

        $tenantId = $this->getTenantByPhone($to);
        
        if (!$tenantId) {
            $twilioService = new TwilioService();
            $response = $twilioService->createVoiceResponse();
            $response->say('Sorry, this number is not configured.');
            return response($response)->header('Content-Type', 'text/xml');
        }

        $twilioService = new TwilioService($tenantId);
        
        if (!$this->validateTwilioRequest($request, $twilioService->getAuthToken())) {
            return response('Unauthorized', 403);
        }

        $business = Business::where('tenant_id', $tenantId)->first();
        $language = ($digits == '2') ? 'ta-IN' : 'en-US';
        $languageName = ($digits == '2') ? 'Tamil' : 'English';

        \Log::info('Language selected', [
            'call_sid' => $callSid,
            'language' => $language,
        ]);

        $callLog = CallLog::where('call_sid', $callSid)->latest()->first();
        if ($callLog) {
            $callLog->update([
                'transcription' => "Language selected: {$languageName}",
            ]);
        }

        $response = $twilioService->createVoiceResponse();
        
        if ($language == 'ta-IN') {
            $greeting = $business ? "{$business->name} இல் நான் உங்களுக்கு எவ்வாறு உதவ முடியும்?" : "நான் உங்களுக்கு எவ்வாறு உதவ முடியும்?";
        } else {
            $greeting = $business ? "How can I help you at {$business->name}?" : "How can I help you?";
        }
        
        $gather = $response->gather([
            'input' => 'speech',
            'timeout' => 2,
            'speechTimeout' => 'auto',
            'language' => $language,
            'speechModel' => 'googlev2_telephony',
            'action' => route('twilio.voice.process') . '?lang=' . $language,
            'method' => 'POST',
        ]);
        $gather->say($greeting);
        
        $response->say($language == 'ta-IN' ? 'நன்றி அழைத்ததற்கு!' : 'Thank you for calling.');

        return response($response)->header('Content-Type', 'text/xml');
    }

    public function processLiveSpeech(Request $request)
    {
        $from = $request->input('From');
        $to = $request->input('To');
        $callSid = $request->input('CallSid');
        $speechResult = $request->input('SpeechResult');

        \Log::info('Live speech processing', [
            'from' => $from,
            'speech' => $speechResult,
        ]);

        $tenantId = $this->getTenantByPhone($to);
        
        if (!$tenantId) {
            $twilioService = new TwilioService();
            $response = $twilioService->createVoiceResponse();
            $response->say('Sorry, this number is not configured.');
            return response($response)->header('Content-Type', 'text/xml');
        }

        $twilioService = new TwilioService($tenantId);
        
        if (!$this->validateTwilioRequest($request, $twilioService->getAuthToken())) {
            return response('Unauthorized', 403);
        }

        $business = Business::where('tenant_id', $tenantId)->first();
        
        if (!$speechResult) {
            $response = $twilioService->createVoiceResponse();
            $response->say('Sorry, I did not hear anything. Please call back.', ['voice' => 'Polly.Aditi', 'language' => 'en-IN']);
            $response->hangup();
            return response($response)->header('Content-Type', 'text/xml');
        }

        try {
            $twilioDetectedLanguage = $request->input('Language');
            
            $languageMap = [
                'ta-IN' => 'ta-IN',
                'en-IN' => 'en-IN',
                'en-US' => 'en-IN',
                'en-GB' => 'en-IN',
                'hi-IN' => 'hi-IN',
                'ms-MY' => 'ms-MY',
                'id-ID' => 'id-ID',
                'th-TH' => 'th-TH',
                'cmn-CN' => 'cmn-CN',
                'zh-CN' => 'cmn-CN',
                'zh-TW' => 'cmn-CN',
            ];
            
            if ($twilioDetectedLanguage && isset($languageMap[$twilioDetectedLanguage])) {
                $detectedLanguageCode = $languageMap[$twilioDetectedLanguage];
            } else {
                $detectedLanguageCode = $this->detectLanguage($speechResult);
            }
            
            \Log::info('Language detected', [
                'twilio_language' => $twilioDetectedLanguage,
                'detected_code' => $detectedLanguageCode,
                'speech' => substr($speechResult, 0, 100)
            ]);
            
            $languageInstructions = [
                'ta-IN' => 'CRITICAL: You MUST respond ONLY in Tamil language (தமிழ்). Do NOT use English.',
                'en-IN' => 'CRITICAL: You MUST respond ONLY in English language.',
                'hi-IN' => 'CRITICAL: You MUST respond ONLY in Hindi language (हिंदी). Do NOT use English.',
                'cmn-CN' => 'CRITICAL: You MUST respond ONLY in Mandarin Chinese (中文/普通话). Do NOT use English.',
                'ms-MY' => 'CRITICAL: You MUST respond ONLY in Malay language (Bahasa Melayu). Do NOT use English.',
                'id-ID' => 'CRITICAL: You MUST respond ONLY in Indonesian language (Bahasa Indonesia). Do NOT use English.',
                'th-TH' => 'CRITICAL: You MUST respond ONLY in Thai language (ภาษาไทย). Do NOT use English.',
            ];
            
            $languageInstruction = $languageInstructions[$detectedLanguageCode] ?? 'Respond in English.';
            
            $openAIService = new OpenAIService($tenantId);

            $systemPrompt = $business 
                ? "{$languageInstruction}\n\nYou are a friendly customer service representative for {$business->name}, a {$business->type}. Help customers warmly and professionally. Keep responses very brief (1-2 sentences max)."
                : "{$languageInstruction}\n\nYou are a friendly customer service representative. Help customers warmly. Keep responses very brief (1-2 sentences max).";

            $aiResponse = $openAIService->chatFast([
                ['role' => 'user', 'content' => $speechResult]
            ], $systemPrompt);

            \Log::info('AI Response Generated', [
                'customer_said' => $speechResult,
                'ai_responded' => $aiResponse,
                'detected_language' => $detectedLanguageCode
            ]);
            
            $languageClosingMessages = [
                'ta-IN' => 'அழைத்ததற்கு நன்றி!',
                'en-IN' => 'Thank you for calling!',
                'hi-IN' => 'कॉल करने के लिए धन्यवाद!',
                'cmn-CN' => '感谢您的来电!',
                'ms-MY' => 'Terima kasih kerana menghubungi!',
                'id-ID' => 'Terima kasih telah menelepon!',
                'th-TH' => 'ขอบคุณที่โทรมา!',
            ];
            
            $closingMessage = $languageClosingMessages[$detectedLanguageCode] ?? 'Thank you for calling!';

            $callLog = CallLog::where('call_sid', $callSid)
                ->latest()
                ->first();

            if ($callLog) {
                $existingTranscription = $callLog->transcription ?? '';
                
                $estimatedInputTokens = (int)(strlen($speechResult) / 4);
                $estimatedOutputTokens = (int)(strlen($aiResponse) / 4);
                $ttsCharacters = strlen($aiResponse) + strlen($closingMessage);
                $estimatedDuration = 60;
                
                $costs = $this->calculateCosts($estimatedDuration, $estimatedInputTokens, $estimatedOutputTokens, $ttsCharacters);
                
                $currentTwilioCost = (float)$callLog->twilio_cost;
                $currentOpenAICost = (float)$callLog->openai_cost;
                $currentTTSCost = (float)$callLog->tts_cost;
                
                $newTwilioCost = $currentTwilioCost + $costs['twilio_cost'];
                $newOpenAICost = $currentOpenAICost + $costs['openai_cost'];
                $newTTSCost = $currentTTSCost + $costs['tts_cost'];
                $newTotalCost = $newTwilioCost + $newOpenAICost + $newTTSCost;
                
                \Log::info('Cost calculation', [
                    'input_tokens' => $estimatedInputTokens,
                    'output_tokens' => $estimatedOutputTokens,
                    'tts_chars' => $ttsCharacters,
                    'twilio' => $costs['twilio_cost'],
                    'openai' => $costs['openai_cost'],
                    'tts' => $costs['tts_cost'],
                    'total_new' => $costs['total_cost'],
                    'cumulative_total' => $newTotalCost
                ]);
                
                $callLog->update([
                    'transcription' => $existingTranscription . "\nCustomer: " . $speechResult . "\nAssistant: " . $aiResponse,
                    'status' => 'in-progress',
                    'language_code' => $detectedLanguageCode,
                    'twilio_cost' => $newTwilioCost,
                    'openai_cost' => $newOpenAICost,
                    'tts_cost' => $newTTSCost,
                    'total_cost' => $newTotalCost,
                ]);
                
                \Log::info('Call log updated', [
                    'call_sid' => $callSid,
                    'language_code' => $detectedLanguageCode,
                    'total_cost' => $newTotalCost
                ]);
            }

            $response = $twilioService->createVoiceResponse();
            
            $responseLanguageCode = $detectedLanguageCode;
            
            $voiceConfig = VoiceConfiguration::where('tenant_id', $tenantId)
                ->where('language_code', $responseLanguageCode)
                ->where('is_default', true)
                ->first();
            
            if (!$voiceConfig) {
                $voiceConfig = VoiceConfiguration::where('tenant_id', $tenantId)
                    ->where('language_code', $responseLanguageCode)
                    ->orderBy('id', 'desc')
                    ->first();
                
                if (!$voiceConfig) {
                    \Log::warning('No voice configuration found for tenant', [
                        'tenant_id' => $tenantId,
                        'language_code' => $responseLanguageCode,
                        'fallback' => 'using default Google TTS'
                    ]);
                } else {
                    \Log::info('No default voice found, using latest voice configuration', [
                        'tenant_id' => $tenantId,
                        'language_code' => $responseLanguageCode,
                        'voice_config_id' => $voiceConfig->id
                    ]);
                }
            }
            
            $googleTTS = new GoogleTTSService();
            
            if ($voiceConfig) {
                $audioUrl = $googleTTS->generateSpeechWithConfig(
                    $aiResponse,
                    $voiceConfig->voice_name,
                    $voiceConfig->gender,
                    $voiceConfig->speaking_rate,
                    $voiceConfig->pitch
                );
            } else {
                $isTamilFallback = ($responseLanguageCode == 'ta-IN');
                $audioUrl = $googleTTS->generateSpeech($aiResponse, $responseLanguageCode, $isTamilFallback);
            }
            
            $gather = $response->gather([
                'input' => 'speech',
                'timeout' => 3,
                'speechTimeout' => 'auto',
                'language' => 'en-IN,ta-IN,hi-IN,ms-MY,id-ID,th-TH,cmn-CN',
                'speechModel' => 'phone_call',
                'action' => route('twilio.voice.process'),
                'method' => 'POST',
            ]);
            
            $gather->play($audioUrl);
            
            if ($voiceConfig) {
                $closingAudioUrl = $googleTTS->generateSpeechWithConfig(
                    $closingMessage,
                    $voiceConfig->voice_name,
                    $voiceConfig->gender,
                    $voiceConfig->speaking_rate,
                    $voiceConfig->pitch
                );
            } else {
                $isTamilFallback = ($responseLanguageCode == 'ta-IN');
                $closingAudioUrl = $googleTTS->generateSpeech($closingMessage, $responseLanguageCode, $isTamilFallback);
            }
            
            $response->play($closingAudioUrl);
            
        } catch (\Exception $e) {
            \Log::error('Live speech processing error: ' . $e->getMessage());
            $response = $twilioService->createVoiceResponse();
            $response->say('Sorry, I encountered an error. Please call back.');
            $response->hangup();
        }

        return response($response)->header('Content-Type', 'text/xml');
    }

    public function handleRecording(Request $request)
    {
        $from = $request->input('From');
        $to = $request->input('To');
        $recordingSid = $request->input('RecordingSid');

        \Log::info('Recording webhook called', [
            'from' => $from,
            'to' => $to,
            'recording_sid' => $recordingSid,
        ]);

        $tenantId = $this->getTenantByPhone($to);
        
        if (!$tenantId) {
            $twilioService = new TwilioService();
            $response = $twilioService->createVoiceResponse();
            $response->say('Sorry, this number is not configured.');
            return response($response)->header('Content-Type', 'text/xml');
        }

        $twilioService = new TwilioService($tenantId);
        
        if (!$this->validateTwilioRequest($request, $twilioService->getAuthToken())) {
            return response('Unauthorized', 403);
        }

        $business = Business::where('tenant_id', $tenantId)->first();

        if (!$recordingSid) {
            \Log::error('No recording SID provided');
            $response = $twilioService->createVoiceResponse();
            $response->say('Sorry, there was an error processing your request.');
            return response($response)->header('Content-Type', 'text/xml');
        }

        try {
            $audioData = $twilioService->fetchRecording($recordingSid);
            $tempFile = tempnam(sys_get_temp_dir(), 'recording_') . '.wav';
            file_put_contents($tempFile, $audioData);

            $openAIService = new OpenAIService($tenantId);
            $transcription = $openAIService->transcribeAudio($tempFile);
            unlink($tempFile);

            $intent = $openAIService->extractIntent($transcription, $business->type ?? 'general');

            $systemPrompt = $business 
                ? "You are a helpful AI assistant for {$business->name}, a {$business->type}. Help customers professionally and efficiently."
                : "You are a helpful AI assistant. Help customers professionally.";

            $aiResponse = $openAIService->chat([
                ['role' => 'user', 'content' => $transcription]
            ], $systemPrompt);

            $callLog = CallLog::where('tenant_id', $tenantId)
                ->where('from_number', $from)
                ->where('to_number', $to)
                ->latest()
                ->first();

            if ($callLog) {
                $callLog->update([
                    'transcription' => $transcription,
                    'ai_summary' => $openAIService->summarize($transcription),
                    'intent' => $intent,
                    'status' => 'completed',
                    'duration' => 30
                ]);
            }

            $response = $twilioService->createVoiceResponse();
            $response->say($aiResponse);
            $response->say('Is there anything else I can help you with?');
            $response->record([
                'maxLength' => 60,
                'action' => route('twilio.voice.recording'),
                'method' => 'POST',
            ]);
        } catch (\Exception $e) {
            \Log::error('Voice recording error: ' . $e->getMessage());
            $response = $twilioService->createVoiceResponse();
            $response->say('Sorry, I encountered an error. Please try again later.');
        }

        return response($response)->header('Content-Type', 'text/xml');
    }

    public function handleSms(Request $request)
    {
        $from = $request->input('From');
        $to = $request->input('To');
        $body = $request->input('Body');
        $messageSid = $request->input('MessageSid');

        $tenantId = $this->getTenantByPhone($to);
        
        if (!$tenantId) {
            $twilioService = new TwilioService();
            $twiml = $twilioService->createMessagingResponse();
            $twiml->message('Sorry, this number is not configured.');
            return response($twiml)->header('Content-Type', 'text/xml');
        }

        $twilioService = new TwilioService($tenantId);
        
        if (!$this->validateTwilioRequest($request, $twilioService->getAuthToken())) {
            $twiml = $twilioService->createMessagingResponse();
            $twiml->message('Unauthorized');
            return response($twiml)->header('Content-Type', 'text/xml');
        }

        $business = Business::where('tenant_id', $tenantId)->first();
        $twiml = $twilioService->createMessagingResponse();

        try {
            CallLog::create([
                'tenant_id' => $tenantId,
                'business_id' => $business->id ?? null,
                'call_sid' => $messageSid,
                'from_number' => $from,
                'to_number' => $to,
                'direction' => 'inbound',
                'status' => 'completed',
                'transcription' => $body,
            ]);

            $openAIService = new OpenAIService($tenantId);
            $intent = $openAIService->extractIntent($body, $business->type ?? 'general');

            $systemPrompt = $business 
                ? "You are a helpful AI assistant for {$business->name}, a {$business->type}. Respond to customer SMS messages professionally and concisely."
                : "You are a helpful AI assistant. Respond professionally.";

            $responseText = $openAIService->chat([
                ['role' => 'user', 'content' => $body]
            ], $systemPrompt);

            $twiml->message($responseText);
        } catch (\Exception $e) {
            \Log::error('SMS error: ' . $e->getMessage());
            $twiml->message('Sorry, I encountered an error. Please try again later.');
        }

        return response($twiml)->header('Content-Type', 'text/xml');
    }
}
