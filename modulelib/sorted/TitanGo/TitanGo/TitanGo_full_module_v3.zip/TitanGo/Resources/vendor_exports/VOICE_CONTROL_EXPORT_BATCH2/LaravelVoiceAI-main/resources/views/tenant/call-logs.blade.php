<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl">📞 Call History</h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <div class="card" style="margin-bottom: 1.5rem;">
                <div class="card-body">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                        <div>
                            <h3 class="text-lg font-semibold">Call History</h3>
                            <p class="text-sm text-secondary">Total Calls: {{ $callLogs->total() }} | Total Cost: ${{ number_format($totalCost, 4) }}</p>
                        </div>
                        <button onclick="toggleFilters()" style="background: #6366f1; color: white; padding: 0.625rem 1.25rem; border-radius: 0.5rem; font-weight: 500; border: none; cursor: pointer;">
                            🔍 Filters
                        </button>
                    </div>

                    <div id="filterPanel" style="display: none; background: #0f172a; padding: 1.5rem; border-radius: 0.75rem; margin-bottom: 1.5rem; border: 1px solid #475569;">
                        <form method="GET" action="{{ route('call-logs.index') }}">
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                                <div>
                                    <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Search</label>
                                    <input type="text" name="search" value="{{ request('search') }}" placeholder="Phone number, transcription..." style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                </div>

                                <div>
                                    <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Status</label>
                                    <select name="status" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                        <option value="">All Statuses</option>
                                        <option value="completed" {{ request('status') == 'completed' ? 'selected' : '' }}>Completed</option>
                                        <option value="in-progress" {{ request('status') == 'in-progress' ? 'selected' : '' }}>In Progress</option>
                                        <option value="failed" {{ request('status') == 'failed' ? 'selected' : '' }}>Failed</option>
                                        <option value="busy" {{ request('status') == 'busy' ? 'selected' : '' }}>Busy</option>
                                        <option value="no-answer" {{ request('status') == 'no-answer' ? 'selected' : '' }}>No Answer</option>
                                    </select>
                                </div>

                                <div>
                                    <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Direction</label>
                                    <select name="direction" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                        <option value="">All Directions</option>
                                        <option value="inbound" {{ request('direction') == 'inbound' ? 'selected' : '' }}>Inbound</option>
                                        <option value="outbound" {{ request('direction') == 'outbound' ? 'selected' : '' }}>Outbound</option>
                                    </select>
                                </div>

                                <div>
                                    <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Language</label>
                                    <select name="language" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                        <option value="">All Languages</option>
                                        @foreach($languages as $lang)
                                            <option value="{{ $lang }}" {{ request('language') == $lang ? 'selected' : '' }}>
                                                @if($lang == 'ta-IN') Tamil
                                                @elseif($lang == 'en-IN') English
                                                @elseif($lang == 'hi-IN') Hindi
                                                @elseif($lang == 'cmn-CN') Mandarin
                                                @elseif($lang == 'ms-MY') Malay
                                                @elseif($lang == 'id-ID') Indonesian
                                                @elseif($lang == 'th-TH') Thai
                                                @else {{ $lang }}
                                                @endif
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div>
                                    <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Date From</label>
                                    <input type="date" name="date_from" value="{{ request('date_from') }}" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                </div>

                                <div>
                                    <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Date To</label>
                                    <input type="date" name="date_to" value="{{ request('date_to') }}" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                </div>
                            </div>

                            <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                                <button type="submit" style="background: #10b981; color: white; padding: 0.625rem 1.5rem; border-radius: 0.5rem; font-weight: 500; border: none; cursor: pointer;">
                                    Apply Filters
                                </button>
                                <a href="{{ route('call-logs.index') }}" style="background: #475569; color: white; padding: 0.625rem 1.5rem; border-radius: 0.5rem; font-weight: 500; text-decoration: none; display: inline-block;">
                                    Clear All
                                </a>
                            </div>
                        </form>
                    </div>

                    @if($callLogs->count() > 0)
                    <div class="table-container">
                        <table style="width: 100%; border-collapse: collapse;">
                            <thead style="background: #0f172a;">
                                <tr>
                                    <th style="padding: 0.75rem 1rem; text-align: left; font-size: 0.75rem; font-weight: 600; color: #94a3b8; text-transform: uppercase;">Date/Time</th>
                                    <th style="padding: 0.75rem 1rem; text-align: left; font-size: 0.75rem; font-weight: 600; color: #94a3b8; text-transform: uppercase;">From</th>
                                    <th style="padding: 0.75rem 1rem; text-align: left; font-size: 0.75rem; font-weight: 600; color: #94a3b8; text-transform: uppercase;">Business</th>
                                    <th style="padding: 0.75rem 1rem; text-align: left; font-size: 0.75rem; font-weight: 600; color: #94a3b8; text-transform: uppercase;">Direction</th>
                                    <th style="padding: 0.75rem 1rem; text-align: left; font-size: 0.75rem; font-weight: 600; color: #94a3b8; text-transform: uppercase;">Duration</th>
                                    <th style="padding: 0.75rem 1rem; text-align: left; font-size: 0.75rem; font-weight: 600; color: #94a3b8; text-transform: uppercase;">Language</th>
                                    <th style="padding: 0.75rem 1rem; text-align: left; font-size: 0.75rem; font-weight: 600; color: #94a3b8; text-transform: uppercase;">Cost</th>
                                    <th style="padding: 0.75rem 1rem; text-align: left; font-size: 0.75rem; font-weight: 600; color: #94a3b8; text-transform: uppercase;">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($callLogs as $log)
                                <tr style="border-top: 1px solid #475569; cursor: pointer;" onclick="toggleDetails('details-{{ $log->id }}')">
                                    <td style="padding: 1rem; font-size: 0.875rem; color: #f1f5f9;">
                                        {{ $log->created_at->format('M d, Y') }}<br>
                                        <span style="color: #94a3b8; font-size: 0.75rem;">{{ $log->created_at->format('g:i A') }}</span>
                                    </td>
                                    <td style="padding: 1rem; font-size: 0.875rem; color: #f1f5f9;">{{ $log->from_number }}</td>
                                    <td style="padding: 1rem; font-size: 0.875rem; color: #f1f5f9;">{{ $log->business->name ?? 'N/A' }}</td>
                                    <td style="padding: 1rem; font-size: 0.875rem; color: #f1f5f9;">
                                        <span class="badge {{ $log->direction == 'inbound' ? 'badge-blue' : 'badge-green' }}">
                                            {{ ucfirst($log->direction) }}
                                        </span>
                                    </td>
                                    <td style="padding: 1rem; font-size: 0.875rem; color: #94a3b8;">
                                        {{ $log->duration ? gmdate('i:s', $log->duration) : '-' }}
                                    </td>
                                    <td style="padding: 1rem; font-size: 0.875rem; color: #f1f5f9;">
                                        @if($log->language_code)
                                            <span class="badge badge-purple">
                                                @if($log->language_code == 'ta-IN') Tamil
                                                @elseif($log->language_code == 'en-IN') English
                                                @elseif($log->language_code == 'hi-IN') Hindi
                                                @elseif($log->language_code == 'cmn-CN') Mandarin
                                                @elseif($log->language_code == 'ms-MY') Malay
                                                @elseif($log->language_code == 'id-ID') Indonesian
                                                @elseif($log->language_code == 'th-TH') Thai
                                                @else {{ $log->language_code }}
                                                @endif
                                            </span>
                                        @else
                                            <span style="color: #94a3b8;">-</span>
                                        @endif
                                    </td>
                                    <td style="padding: 1rem; font-size: 0.875rem; color: #f1f5f9;">
                                        <span style="font-weight: 600; color: #10b981;">${{ number_format($log->total_cost, 4) }}</span>
                                    </td>
                                    <td style="padding: 1rem; font-size: 0.875rem;">
                                        <span class="badge 
                                            {{ $log->status == 'completed' ? 'badge-green' : '' }}
                                            {{ $log->status == 'in-progress' ? 'badge-blue' : '' }}
                                            {{ $log->status == 'failed' ? 'badge-red' : '' }}
                                            {{ $log->status == 'busy' || $log->status == 'no-answer' ? 'badge-yellow' : '' }}
                                        ">
                                            {{ ucfirst($log->status) }}
                                        </span>
                                    </td>
                                </tr>
                                @if($log->transcription)
                                <tr id="details-{{ $log->id }}" style="display: none; border-top: 1px solid #334155;">
                                    <td colspan="8" style="padding: 1.5rem; background: #0f172a;">
                                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                                            <div>
                                                <div style="font-size: 0.75rem; color: #94a3b8; margin-bottom: 0.5rem; font-weight: 600;">💬 Transcription:</div>
                                                <div style="font-size: 0.875rem; color: #cbd5e1; line-height: 1.6;">{{ $log->transcription }}</div>
                                                
                                                @if($log->ai_summary)
                                                <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 1rem; margin-bottom: 0.5rem; font-weight: 600;">🤖 AI Summary:</div>
                                                <div style="font-size: 0.875rem; color: #93c5fd; line-height: 1.6;">{{ $log->ai_summary }}</div>
                                                @endif

                                                @if($log->intent)
                                                <div style="margin-top: 1rem;">
                                                    <span style="font-size: 0.75rem; color: #94a3b8; font-weight: 600;">Intent: </span>
                                                    <span class="badge badge-purple">{{ ucfirst($log->intent) }}</span>
                                                </div>
                                                @endif
                                            </div>

                                            <div>
                                                <div style="font-size: 0.75rem; color: #94a3b8; margin-bottom: 0.75rem; font-weight: 600;">💰 Cost Breakdown:</div>
                                                <div style="background: #1e293b; padding: 1rem; border-radius: 0.5rem; border: 1px solid #475569;">
                                                    <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                                                        <span style="font-size: 0.875rem; color: #94a3b8;">Twilio (Call):</span>
                                                        <span style="font-size: 0.875rem; color: #f1f5f9; font-weight: 500;">${{ number_format($log->twilio_cost, 4) }}</span>
                                                    </div>
                                                    <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                                                        <span style="font-size: 0.875rem; color: #94a3b8;">OpenAI (AI):</span>
                                                        <span style="font-size: 0.875rem; color: #f1f5f9; font-weight: 500;">${{ number_format($log->openai_cost, 4) }}</span>
                                                    </div>
                                                    <div style="display: flex; justify-content: space-between; margin-bottom: 0.75rem; padding-bottom: 0.75rem; border-bottom: 1px solid #475569;">
                                                        <span style="font-size: 0.875rem; color: #94a3b8;">Google TTS:</span>
                                                        <span style="font-size: 0.875rem; color: #f1f5f9; font-weight: 500;">${{ number_format($log->tts_cost, 4) }}</span>
                                                    </div>
                                                    <div style="display: flex; justify-content: space-between;">
                                                        <span style="font-size: 0.875rem; color: #10b981; font-weight: 600;">Total Cost:</span>
                                                        <span style="font-size: 0.875rem; color: #10b981; font-weight: 600;">${{ number_format($log->total_cost, 4) }}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                @endif
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <div style="margin-top: 1.5rem;">
                        {{ $callLogs->links() }}
                    </div>
                    @else
                    <div class="text-center" style="padding: 4rem 0;">
                        <div style="font-size: 3rem; margin-bottom: 1rem;">📞</div>
                        <h4 class="font-semibold mb-2" style="color: #f1f5f9;">No Call Logs Yet</h4>
                        <p style="color: #9ca3af;">Call logs will appear here once you start receiving calls.</p>
                        @if(request()->hasAny(['search', 'status', 'direction', 'language', 'date_from', 'date_to']))
                            <a href="{{ route('call-logs.index') }}" style="display: inline-block; margin-top: 1rem; background: #6366f1; color: white; padding: 0.625rem 1.25rem; border-radius: 0.5rem; font-weight: 500; text-decoration: none;">
                                Clear Filters
                            </a>
                        @endif
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleFilters() {
            const panel = document.getElementById('filterPanel');
            panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        }

        function toggleDetails(id) {
            const row = document.getElementById(id);
            if (row) {
                row.style.display = row.style.display === 'none' ? 'table-row' : 'none';
            }
        }

        @if(request()->hasAny(['search', 'status', 'direction', 'language', 'date_from', 'date_to']))
            document.getElementById('filterPanel').style.display = 'block';
        @endif
    </script>
</x-app-layout>
