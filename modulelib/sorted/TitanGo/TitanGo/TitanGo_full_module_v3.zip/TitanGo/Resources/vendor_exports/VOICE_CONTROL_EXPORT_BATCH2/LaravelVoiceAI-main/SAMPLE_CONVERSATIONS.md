# 📞 Sample Conversations - English, Tamil & Tanglish (Mixed)

## 🔥 Tanglish Conversation Example 1: Realistic Code-Switching (MOST COMMON!)

**AI:** *Welcome to Joe's Pizza! How may I help you today?*

**Customer:** *நான் pizza order செய்ய வேண்டும்* (I want to order pizza - mixing Tamil + English)

**AI:** *சரி! எத்தனை pizza வேண்டும்?* (Okay! How many pizzas do you want? - Tanglish)

**Customer:** *ஒரு large pepperoni pizza வேண்டும்*

**AI:** *நல்லது! Delivery வேண்டுமா அல்லது pickup?* (Good! Delivery or pickup? - Tanglish)

**Customer:** *Delivery please*

**AI:** *எங்கு delivery செய்ய வேண்டும்?* (Where should we deliver? - Tanglish)

**Customer:** *123 Main Street க்கு அனுப்புங்க*

**AI:** *சரி! வேறு ஏதாவது add செய்ய வேண்டுமா?* (Okay! Anything else to add? - Tanglish)

**Customer:** *இல்ல, அது போதும்*

**AI:** *நன்றி! 30 minutes ல delivery ஆகிடும்* (Thank you! Will deliver in 30 minutes - Tanglish)

---

## 🔥 Tanglish Conversation Example 2: Typical Indian Style

**AI:** *Welcome to Joe's Pizza! How may I help you today?*

**Customer:** *Pizza வேண்டும் boss* (Want pizza boss - very casual Tanglish)

**AI:** *சொல்லுங்க! என்ன size pizza வேண்டும்?* (Tell me! What size pizza? - Tanglish)

**Customer:** *Medium வேண்டும், extra cheese போடுங்க*

**AI:** *Medium pizza, extra cheese - சரி! தான் pickup or delivery?* (Medium pizza, extra cheese - okay! Pickup or delivery? - Tanglish)

**Customer:** *Pickup தான்*

**AI:** *15 minutes ல ready ஆகிடும். உங்கள் name?* (Will be ready in 15 minutes. Your name? - Tanglish)

**Customer:** *Karthik*

**AI:** *நன்றி Karthik! வந்துட்டு போங்க!* (Thank you Karthik! Come and pick it up! - Tanglish)

---

## 🔥 Tanglish Conversation Example 3: Very Natural Style

**AI:** *Welcome to Joe's Pizza! How may I help you today?*

**Customer:** *Bro, இன்னைக்கு special offer இருக்கா?* (Bro, is there a special offer today?)

**AI:** *இல்ல boss, but எங்கள் supreme pizza ரொம்ப popular!* (No boss, but our supreme pizza is very popular! - Tanglish)

**Customer:** *அதுல என்ன toppings இருக்கும்?*

**AI:** *Pepperoni, sausage, peppers, onions எல்லாம் இருக்கு! Medium வேண்டுமா?* (Has pepperoni, sausage, peppers, onions! Want medium? - Tanglish)

**Customer:** *ஆமா medium கொடுங்க, pickup தான்*

**AI:** *சரி! 15 minutes ல ready. Name சொல்லுங்க?* (Okay! Ready in 15 minutes. Tell me name? - Tanglish)

**Customer:** *Muthu*

**AI:** *நன்றி Muthu! See you soon!*

---

## English Conversation Example: Pure English

**AI:** *Welcome to Joe's Pizza! How may I help you today?*

**Customer:** *I want to order a large pepperoni pizza*

**AI:** *Great! Would you like delivery or pickup?*

**Customer:** *Delivery please to 123 Main Street*

**AI:** *Perfect! Anything else?*

**Customer:** *Add garlic bread and coke*

**AI:** *Got it! Total is about $25. We'll deliver in 30-40 minutes.*

**Customer:** *Thank you*

**AI:** *Thank you for calling!*

---

## Tamil Conversation Example: Pure Tamil

**AI:** *Welcome to Joe's Pizza! How may I help you today?*

**Customer:** *நான் பீட்சா ஆர்டர் செய்ய விரும்புகிறேன்* (I want to order pizza)

**AI:** *நிச்சயமாக! என்ன அளவு வேண்டும்?* (Sure! What size?)

**Customer:** *பெரிய அளவு பெப்பரோனி* (Large pepperoni)

**AI:** *சரி! டெலிவரி அல்லது பிக்கப்?* (Okay! Delivery or pickup?)

**Customer:** *டெலிவரி செய்யுங்கள்* (Please deliver)

**AI:** *எங்கு டெலிவரி செய்ய வேண்டும்?* (Where to deliver?)

**Customer:** *123 மெயின் ஸ்ட்ரீட்* (123 Main Street)

**AI:** *நன்றி! 30 நிமிடத்தில் வரும்* (Thank you! Will arrive in 30 minutes)

---

## Key Features:

✅ **Automatic Language Detection** - Understands Tamil, English, and mixed Tanglish  
✅ **Natural Code-Switching** - Responds exactly how Indians naturally speak  
✅ **Cultural Authenticity** - Uses common words like "boss", "bro", casual Tamil style  
✅ **Fast Responses** - 1-2 seconds per reply  
✅ **Authentic Tamil Voice** - Google Cloud TTS `ta-IN-Standard-A` (native Tamil speaker)  
✅ **Indian English Voice** - Google Cloud TTS `en-IN-Standard-A` (Indian accent)  
✅ **No Menus** - Just speak naturally!

## 🎤 Voice System:

**Tamil Responses** → Google Cloud Text-to-Speech with authentic `ta-IN-Standard-A` female voice  
**English Responses** → Google Cloud Text-to-Speech with Indian `en-IN-Standard-A` female voice  
**Tanglish Responses** → Automatically uses Tamil voice for mixed speech

The system detects whether you're speaking Tamil (தமிழ் script or Tanglish words like "vendum", "pannunga", "sollunga") and responds in the same language with the appropriate voice!  

---

## Test Your Call:

📞 **Call: +17628891674**

Try these phrases naturally:
- *"Pizza வேண்டும்"* (Tamil)
- *"I want pizza"* (English)
- *"Pizza order செய்ய வேண்டும்"* (Tanglish - MOST COMMON!)
- *"Delivery தாங்க boss"* (Very casual Tanglish)
- *"ஒரு large pizza delivery செய்யுங்க"* (Mixed style)

**The AI will match your speaking style automatically!** 🎉
