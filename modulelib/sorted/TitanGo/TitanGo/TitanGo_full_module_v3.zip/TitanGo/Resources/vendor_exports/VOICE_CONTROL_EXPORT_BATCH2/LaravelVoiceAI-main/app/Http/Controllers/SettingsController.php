<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TenantSetting;
use App\Models\VoiceConfiguration;
use App\Models\CallSession;
use App\Services\ApiBalanceService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class SettingsController extends Controller
{
    public function index()
    {
        $tenant = Auth::user()->tenant;
        $tenantId = Auth::user()->tenant_id;
        
        $settings = TenantSetting::where('tenant_id', $tenant->id)->first();

        if (!$settings) {
            $settings = TenantSetting::create(['tenant_id' => $tenant->id]);
        }

        $voiceConfigurations = VoiceConfiguration::where('tenant_id', $tenant->id)
            ->orderBy('is_default', 'desc')
            ->orderBy('priority', 'desc')
            ->get();

        $availableVoices = VoiceConfiguration::getAvailableVoices();

        // Get account balances
        $twilioBalance = null;
        if ($settings->twilio_account_sid && $settings->twilio_auth_token) {
            $twilioBalance = ApiBalanceService::getTwilioBalance(
                $settings->twilio_account_sid,
                $settings->twilio_auth_token
            );
        }

        $openaiStatus = null;
        if ($settings->openai_api_key) {
            $openaiStatus = ApiBalanceService::getOpenAIBalance($settings->openai_api_key);
        }

        // Get real API usage stats from PostgreSQL call_sessions
        try {
            $callStats = CallSession::where('tenant_id', $tenantId)
                ->selectRaw("
                    COUNT(*) as total_calls,
                    SUM(duration_seconds) as total_duration_seconds,
                    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_calls,
                    SUM(cost_openai) as total_openai_cost,
                    SUM(cost_tts) as total_tts_cost,
                    SUM(cost_stt) as total_stt_cost,
                    SUM(cost_twilio) as total_twilio_cost,
                    SUM(total_cost) as total_api_cost,
                    SUM(openai_tokens) as total_openai_tokens,
                    SUM(tts_characters) as total_tts_characters,
                    SUM(stt_audio_seconds) as total_stt_seconds,
                    SUM(twilio_billed_seconds) as total_twilio_seconds
                ")
                ->first();
        } catch (\Exception $e) {
            \Log::warning('Could not fetch call statistics from PostgreSQL: ' . $e->getMessage());
            $callStats = null;
        }

        $apiUsage = [
            'total_calls' => $callStats->total_calls ?? 0,
            'completed_calls' => $callStats->completed_calls ?? 0,
            'total_duration_minutes' => round(($callStats->total_duration_seconds ?? 0) / 60, 2),
            
            // Real costs from database
            'openai_cost' => $callStats->total_openai_cost ?? 0,
            'tts_cost' => $callStats->total_tts_cost ?? 0,
            'stt_cost' => $callStats->total_stt_cost ?? 0,
            'twilio_cost' => $callStats->total_twilio_cost ?? 0,
            'total_cost' => $callStats->total_api_cost ?? 0,
            
            // Usage metrics
            'openai_tokens' => $callStats->total_openai_tokens ?? 0,
            'tts_characters' => $callStats->total_tts_characters ?? 0,
            'stt_seconds' => $callStats->total_stt_seconds ?? 0,
            'twilio_seconds' => $callStats->total_twilio_seconds ?? 0,
        ];

        $balances = [
            'twilio' => $twilioBalance,
            'openai' => $openaiStatus,
        ];

        return view('tenant.settings', compact('tenant', 'settings', 'voiceConfigurations', 'availableVoices', 'apiUsage', 'balances'));
    }

    public function update(Request $request)
    {
        $tenant = Auth::user()->tenant;
        
        $validated = $request->validate([
            'twilio_account_sid' => 'nullable|string|max:255',
            'twilio_auth_token' => 'nullable|string|max:255',
            'twilio_phone_number' => 'nullable|string|max:20',
            'openai_api_key' => 'nullable|string|max:255',
            'openai_model' => 'nullable|string|max:50',
            'mobile_call_ui_enabled' => 'nullable|boolean',
            'mobile_show_chat_fallback' => 'nullable|boolean',
            'mobile_allow_typing_during_call' => 'nullable|boolean',
            'mobile_default_mode' => 'nullable|string|in:call,chat',
            'mobile_auto_end_silence_seconds' => 'nullable|integer|min:0|max:300',
        ]);

        $validated['mobile_call_ui_enabled'] = $request->has('mobile_call_ui_enabled');
        $validated['mobile_show_chat_fallback'] = $request->has('mobile_show_chat_fallback');
        $validated['mobile_allow_typing_during_call'] = $request->has('mobile_allow_typing_during_call');

        $settings = TenantSetting::updateOrCreate(
            ['tenant_id' => $tenant->id],
            $validated
        );

        return redirect()->route('settings.index')
            ->with('success', 'Settings updated successfully!');
    }
}
