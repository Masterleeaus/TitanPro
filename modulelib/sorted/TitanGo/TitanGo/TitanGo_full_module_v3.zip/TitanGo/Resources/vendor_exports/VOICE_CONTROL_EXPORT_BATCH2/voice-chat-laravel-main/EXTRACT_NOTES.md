# EXTRACT_NOTES — voice-chat-laravel-main

This folder contains files auto-extracted as *voice-control relevant* (TTS/STT/audio/calls/queues/websockets).
Paths are preserved from the original repo so you can transplant pieces into a WorkSuite module/extension cleanly.

## Extracted files (count)
20

## Likely entry points
- `app/Http/Controllers/VoiceController.php`
- `app/Http/Controllers/WhisperControlller.php`
- `config/queue.php`
- `database/migrations/0001_01_01_000002_create_jobs_table.php`
- `resources/views/voice-whisper.blade.php`
- `resources/views/voice.blade.php`