<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CallTurn extends Model
{
    protected $connection = 'pgsql';
    
    protected $fillable = [
        'call_session_id',
        'speaker',
        'content',
        'spoken_at',
        'confidence',
        'language',
        'duration_ms',
    ];

    protected $casts = [
        'spoken_at' => 'datetime',
        'confidence' => 'decimal:4',
    ];

    public function callSession(): BelongsTo
    {
        return $this->belongsTo(CallSession::class);
    }
}
