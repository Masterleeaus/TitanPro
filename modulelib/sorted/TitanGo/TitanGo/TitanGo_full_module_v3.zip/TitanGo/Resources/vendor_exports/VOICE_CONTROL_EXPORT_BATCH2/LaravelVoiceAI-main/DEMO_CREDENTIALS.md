# 🔐 Demo Login Credentials

## 🚀 Quick Start

**Login URL:** Click the web preview or visit `/login`

All demo accounts are ready to use immediately - no setup required!

---

## 🔑 Super Admin Account

**Access Level:** Full system access, manage all tenants

```
Email:    admin@voiceai.com
Password: admin123
Role:     Super Admin
```

**What You'll See:**
- Dashboard with all tenant statistics
- List of all tenants with their plans and status
- Total users across all tenants
- Complete system overview

**Capabilities:**
- View and manage all tenants
- Activate/deactivate tenant accounts
- System-wide statistics and monitoring
- Manage subscription plans

---

## 🍕 Tenant 1: Joe's Pizza Palace

**Business Type:** Restaurant (Orders)  
**Subscription Plan:** Pro Plan  
**Trial Expires:** 30 days from now

```
Email:    joe@joespizza.com
Password: pizza123
Role:     Tenant Admin
```

**What You'll See:**
- Company dashboard for Joe's Pizza Palace
- API configuration status (Twilio & OpenAI)
- Business listing (1 restaurant pre-configured)
- Quick action buttons for settings, call logs, analytics, orders

**Pre-configured Settings:**
- Twilio Phone: +1 (555) 123-4567
- Business Type: Restaurant
- Demo API Keys: Already configured
- Business: Joe's Pizza Palace

**Use Case:** Test restaurant ordering via phone calls, menu management, voice orders in multiple languages

---

## 💆 Tenant 2: Serenity Spa & Salon

**Business Type:** Salon (Appointments)  
**Subscription Plan:** Basic Plan  
**Trial Expires:** 14 days from now

```
Email:    sarah@serenityspa.com
Password: spa123
Role:     Tenant Admin
```

**What You'll See:**
- Company dashboard for Serenity Spa & Salon
- API configuration status
- Business listing (1 salon pre-configured)
- Appointment management features

**Pre-configured Settings:**
- Twilio Phone: +1 (555) 987-6543
- Business Type: Salon
- Demo API Keys: Already configured
- Business: Serenity Spa & Salon

**Use Case:** Test appointment booking via phone, SMS reminders, service scheduling

---

## 🏨 Tenant 3: Grand Vista Hotel

**Business Type:** Hotel (Reservations)  
**Subscription Plan:** Enterprise Plan  
**Trial Expires:** 60 days from now

```
Email:    mike@grandvista.com
Password: hotel123
Role:     Tenant Admin
```

**What You'll See:**
- Company dashboard for Grand Vista Hotel
- API configuration status
- Business listing (1 hotel pre-configured)
- Reservation management features

**Pre-configured Settings:**
- Twilio Phone: +1 (555) 555-1111
- Business Type: Hotel
- Demo API Keys: Already configured
- Business: Grand Vista Hotel

**Use Case:** Test hotel room reservations, concierge services, multilingual guest support

---

## 📋 Testing Scenarios

### As Super Admin
1. Login with `admin@voiceai.com` / `admin123`
2. View dashboard with all 3 tenants listed
3. See statistics: 3 total tenants, 3 active, 4 total users
4. Monitor different subscription plans (Free, Basic, Pro, Enterprise)

### As Tenant Admin
1. Login with any tenant account (joe, sarah, or mike)
2. View your company dashboard
3. See your subscription plan and trial expiration
4. Check API configuration status
5. View your business listings
6. Access quick action buttons (Settings, Call Logs, Analytics, Orders)

### Multi-Tenant Isolation Testing
- Each tenant can only see their own data
- Super admin can see all tenants
- Each tenant has separate API keys
- Businesses are scoped to their tenant
- Complete data separation verified

---

## 🎯 Dashboard Features

### Super Admin Dashboard
✅ System-wide statistics cards  
✅ Complete tenant list table  
✅ Tenant status indicators (Active/Inactive)  
✅ Plan badges (Free, Basic, Pro, Enterprise)  
✅ User and business counts per tenant  
✅ Trial expiration dates  

### Tenant Dashboard
✅ Welcome message with user name and role  
✅ Subscription plan and trial status  
✅ API configuration status (Twilio & OpenAI)  
✅ Business listings with details  
✅ Quick action cards (Settings, Call Logs, Analytics, Orders)  
✅ Add business button  

---

## 🔒 Security Features

- ✅ All passwords hashed using bcrypt
- ✅ API keys stored per-tenant in `tenant_settings` table
- ✅ Role-based access control enforced
- ✅ Complete tenant data isolation
- ✅ Authentication middleware on all protected routes
- ✅ Session-based authentication with Laravel Breeze

---

## 🛠️ Technical Details

**Database Tables:**
- `tenants` - Company information, plans, trial dates
- `tenant_settings` - Per-tenant API keys (Twilio & OpenAI)
- `users` - User accounts with tenant_id and role
- `businesses` - Business entities linked to tenants

**User Roles:**
- `super_admin` - Full system access (1 account)
- `tenant_admin` - Tenant management (3 accounts)
- `tenant_user` - Limited access (not in demo)

**Demo Data Created:**
- 3 Tenants (Joe's Pizza, Serenity Spa, Grand Vista Hotel)
- 4 Users (1 super admin + 3 tenant admins)
- 3 Tenant Settings records (with demo API keys)
- 3 Businesses (1 per tenant)

---

## 🚀 Next Steps After Login

1. **Explore the Dashboards** - Try logging in with different accounts to see how the views change
2. **Check API Configuration** - See how each tenant has their own API keys configured
3. **View Business Listings** - Each tenant has a pre-configured business
4. **Compare Plans** - Notice how different tenants have different subscription plans and trial periods

---

## 📞 Support & Documentation

For more information, see:
- `MULTI_TENANT_GUIDE.md` - Complete implementation guide for developers
- `README.md` - Project overview and setup instructions

---

**Platform:** Laravel Multi-Tenant SaaS Voice Assistant  
**Authentication:** Laravel Breeze  
**Created:** October 27, 2025  
**Ready to Use:** ✅ Yes - Login now!
