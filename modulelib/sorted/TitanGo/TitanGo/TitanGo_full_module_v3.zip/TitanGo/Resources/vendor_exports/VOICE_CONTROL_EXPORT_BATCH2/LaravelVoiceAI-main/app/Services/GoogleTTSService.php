<?php

namespace App\Services;

use Google\Cloud\TextToSpeech\V1\AudioConfig;
use Google\Cloud\TextToSpeech\V1\AudioEncoding;
use Google\Cloud\TextToSpeech\V1\SsmlVoiceGender;
use Google\Cloud\TextToSpeech\V1\SynthesisInput;
use Google\Cloud\TextToSpeech\V1\Client\TextToSpeechClient;
use Google\Cloud\TextToSpeech\V1\VoiceSelectionParams;
use Google\Cloud\TextToSpeech\V1\SynthesizeSpeechRequest;

class GoogleTTSService
{
    protected $client;

    public function __construct()
    {
        $credentialsPath = storage_path('app/google-credentials.json');
        
        putenv("GOOGLE_APPLICATION_CREDENTIALS={$credentialsPath}");
        
        $this->client = new TextToSpeechClient();
    }

    public function generateSpeech(string $text, string $language = 'en-IN', bool $isTamil = false): string
    {
        $input = new SynthesisInput();
        $input->setText($text);

        $voice = new VoiceSelectionParams();
        
        if ($isTamil) {
            $voice->setLanguageCode('ta-IN');
            $voice->setName('ta-IN-Standard-A');
            $voice->setSsmlGender(SsmlVoiceGender::FEMALE);
        } else {
            $voice->setLanguageCode('en-IN');
            $voice->setName('en-IN-Standard-A');
            $voice->setSsmlGender(SsmlVoiceGender::FEMALE);
        }

        $audioConfig = new AudioConfig();
        $audioConfig->setAudioEncoding(AudioEncoding::MP3);
        $audioConfig->setSpeakingRate(1.1);  // Slower for better clarity
        $audioConfig->setPitch(0.0);
        $audioConfig->setVolumeGainDb(2.0);  // Boost volume for clarity

        $request = new SynthesizeSpeechRequest();
        $request->setInput($input);
        $request->setVoice($voice);
        $request->setAudioConfig($audioConfig);

        $response = $this->client->synthesizeSpeech($request);
        
        $audioContent = $response->getAudioContent();

        $filename = 'tts_' . time() . '_' . uniqid() . '.mp3';
        $filepath = storage_path('app/public/tts/' . $filename);
        
        if (!file_exists(storage_path('app/public/tts'))) {
            mkdir(storage_path('app/public/tts'), 0755, true);
        }

        file_put_contents($filepath, $audioContent);

        return asset('storage/tts/' . $filename);
    }

    public function generateSpeechWithConfig(
        string $text,
        string $voiceName,
        string $gender,
        float $speakingRate = 1.0,
        float $pitch = 0.0
    ): string {
        \Log::info('Google TTS Request', [
            'voice_name' => $voiceName,
            'gender' => $gender,
            'speaking_rate' => $speakingRate,
            'pitch' => $pitch,
            'text_preview' => substr($text, 0, 50) . '...'
        ]);
        
        $input = new SynthesisInput();
        $input->setText($text);

        $voice = new VoiceSelectionParams();
        $voice->setName($voiceName);
        
        $languageCode = substr($voiceName, 0, 5);
        $voice->setLanguageCode($languageCode);
        
        $ssmlGender = $gender === 'male' ? SsmlVoiceGender::MALE : SsmlVoiceGender::FEMALE;
        $voice->setSsmlGender($ssmlGender);

        $audioConfig = new AudioConfig();
        $audioConfig->setAudioEncoding(AudioEncoding::MP3);
        $audioConfig->setSpeakingRate($speakingRate);
        $audioConfig->setPitch($pitch);
        $audioConfig->setVolumeGainDb(2.0);  // Boost volume for clarity

        $request = new SynthesizeSpeechRequest();
        $request->setInput($input);
        $request->setVoice($voice);
        $request->setAudioConfig($audioConfig);

        $response = $this->client->synthesizeSpeech($request);
        
        $audioContent = $response->getAudioContent();

        $filename = 'tts_' . time() . '_' . uniqid() . '.mp3';
        $filepath = storage_path('app/public/tts/' . $filename);
        
        if (!file_exists(storage_path('app/public/tts'))) {
            mkdir(storage_path('app/public/tts'), 0755, true);
        }

        file_put_contents($filepath, $audioContent);

        \Log::info('Google TTS Response generated', [
            'filename' => $filename,
            'file_size' => strlen($audioContent) . ' bytes'
        ]);

        return asset('storage/tts/' . $filename);
    }

    public function __destruct()
    {
        if ($this->client) {
            $this->client->close();
        }
    }
}
