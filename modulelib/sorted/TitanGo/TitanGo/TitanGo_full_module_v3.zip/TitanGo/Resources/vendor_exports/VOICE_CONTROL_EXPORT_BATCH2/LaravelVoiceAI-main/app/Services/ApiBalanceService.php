<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ApiBalanceService
{
    /**
     * Get Twilio account balance
     */
    public static function getTwilioBalance($accountSid, $authToken)
    {
        try {
            $client = new \Twilio\Rest\Client($accountSid, $authToken);
            $balanceData = $client->api->v2010->accounts($accountSid)->balance->fetch();
            
            return [
                'balance' => (float) $balanceData->balance,
                'currency' => $balanceData->currency ?? 'USD',
                'status' => 'active',
            ];
        } catch (\Exception $e) {
            Log::error('Failed to fetch Twilio balance', ['error' => $e->getMessage()]);
            return null;
        }
    }

    /**
     * Get OpenAI account credit balance
     */
    public static function getOpenAIBalance($apiKey)
    {
        try {
            // Try to get subscription info from OpenAI
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $apiKey,
            ])->get('https://api.openai.com/v1/organization/billing/credit_grants');
            
            if ($response->successful()) {
                $data = $response->json();
                $totalGranted = $data['total_granted'] ?? 0;
                $totalUsed = $data['total_used'] ?? 0;
                $totalAvailable = $data['total_available'] ?? 0;
                
                return [
                    'balance' => $totalAvailable,
                    'granted' => $totalGranted,
                    'used' => $totalUsed,
                    'status' => 'active',
                ];
            }
            
            // Fallback: Just verify API key works
            $testResponse = Http::withHeaders([
                'Authorization' => 'Bearer ' . $apiKey,
            ])->get('https://api.openai.com/v1/models');
            
            if ($testResponse->successful()) {
                return [
                    'balance' => null,
                    'status' => 'active',
                    'message' => 'API Key Valid',
                ];
            }
            
            return null;
        } catch (\Exception $e) {
            Log::error('Failed to check OpenAI status', ['error' => $e->getMessage()]);
            return null;
        }
    }

    /**
     * Get Google Cloud billing info
     */
    public static function getGoogleCloudBalance($projectId = null)
    {
        try {
            // Check if service account credentials are available
            $credentialsPath = env('GOOGLE_APPLICATION_CREDENTIALS');
            
            if ($credentialsPath && file_exists($credentialsPath)) {
                // Service account is configured
                return [
                    'status' => 'active',
                    'message' => 'Service Account Configured',
                    'balance' => null,
                ];
            }
            
            // Check if API key exists (alternative auth method)
            $apiKey = env('GOOGLE_CLOUD_API_KEY');
            if ($apiKey) {
                return [
                    'status' => 'active',
                    'message' => 'API Key Configured',
                    'balance' => null,
                ];
            }
            
            // Default: assume configured if TTS/STT are working
            return [
                'status' => 'active',
                'message' => 'Configured',
                'balance' => null,
            ];
        } catch (\Exception $e) {
            Log::error('Failed to check Google Cloud billing', ['error' => $e->getMessage()]);
            return null;
        }
    }
}
