<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Call Logs & Transactions') }}
        </h2>
    </x-slot>

    <div class="py-12" x-data="{ 
        showModal: false, 
        selectedCall: null,
        loading: false,
        viewCallDetails(sessionId) {
            this.loading = true;
            this.showModal = true;
            fetch(`/api/calls/${sessionId}`, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content
                }
            })
            .then(r => r.json())
            .then(data => {
                this.selectedCall = data.data;
                this.loading = false;
            })
            .catch(err => {
                console.error(err);
                this.loading = false;
                this.showModal = false;
            });
        }
    }">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Clean Stats Grid -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <div style="color: rgba(255,255,255,0.9); font-size: 0.875rem; margin-bottom: 0.5rem;">Total Calls</div>
                    <div style="color: white; font-size: 2rem; font-weight: bold;">{{ $stats['total_calls'] ?? 0 }}</div>
                </div>
                <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <div style="color: rgba(255,255,255,0.9); font-size: 0.875rem; margin-bottom: 0.5rem;">Web/Mobile</div>
                    <div style="color: white; font-size: 2rem; font-weight: bold;">{{ ($stats['web_calls'] ?? 0) + ($stats['mobile_calls'] ?? 0) }}</div>
                </div>
                <div style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <div style="color: rgba(255,255,255,0.9); font-size: 0.875rem; margin-bottom: 0.5rem;">Duration</div>
                    <div style="color: white; font-size: 2rem; font-weight: bold;">{{ gmdate("H:i:s", $stats['total_duration'] ?? 0) }}</div>
                </div>
                <div style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); padding: 1.5rem; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <div style="color: rgba(255,255,255,0.9); font-size: 0.875rem; margin-bottom: 0.5rem;">Total Cost</div>
                    <div style="color: white; font-size: 2rem; font-weight: bold;">${{ number_format($stats['total_cost'] ?? 0, 4) }}</div>
                </div>
            </div>

            <!-- Clean Transactions Table -->
            <div style="background: #1f2937; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); overflow: hidden;">
                <div style="padding: 1.5rem; border-bottom: 1px solid #374151;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <h3 style="font-size: 1.25rem; font-weight: bold; color: #f1f5f9;">Recent Transactions</h3>
                        <span style="font-size: 0.875rem; color: #94a3b8;">{{ $callSessions->total() }} records</span>
                    </div>
                </div>
                
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background: #111827; border-bottom: 2px solid #374151;">
                                <th style="padding: 1rem; text-align: left; font-size: 0.75rem; font-weight: 600; color: #9ca3af; text-transform: uppercase;">Date/Time</th>
                                <th style="padding: 1rem; text-align: left; font-size: 0.75rem; font-weight: 600; color: #9ca3af; text-transform: uppercase;">Source</th>
                                <th style="padding: 1rem; text-align: left; font-size: 0.75rem; font-weight: 600; color: #9ca3af; text-transform: uppercase;">Duration</th>
                                <th style="padding: 1rem; text-align: center; font-size: 0.75rem; font-weight: 600; color: #9ca3af; text-transform: uppercase;">Status</th>
                                <th style="padding: 1rem; text-align: right; font-size: 0.75rem; font-weight: 600; color: #9ca3af; text-transform: uppercase;">OpenAI</th>
                                <th style="padding: 1rem; text-align: right; font-size: 0.75rem; font-weight: 600; color: #9ca3af; text-transform: uppercase;">TTS</th>
                                <th style="padding: 1rem; text-align: right; font-size: 0.75rem; font-weight: 600; color: #9ca3af; text-transform: uppercase;">STT</th>
                                <th style="padding: 1rem; text-align: right; font-size: 0.75rem; font-weight: 600; color: #9ca3af; text-transform: uppercase;">Twilio</th>
                                <th style="padding: 1rem; text-align: right; font-size: 0.75rem; font-weight: 600; color: #9ca3af; text-transform: uppercase;">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($callSessions as $session)
                            <tr style="border-bottom: 1px solid #374151; cursor: pointer; transition: background-color 0.2s;" 
                                onmouseover="this.style.background='#374151'" 
                                onmouseout="this.style.background='transparent'"
                                @click="viewCallDetails('{{ $session->session_id }}')">
                                <td style="padding: 1rem; color: #e5e7eb; font-size: 0.875rem;">
                                    <div style="font-weight: 500;">{{ $session->started_at ? $session->started_at->format('M d, Y') : 'N/A' }}</div>
                                    <div style="color: #9ca3af; font-size: 0.75rem;">{{ $session->started_at ? $session->started_at->format('h:i A') : '' }}</div>
                                </td>
                                <td style="padding: 1rem;">
                                    @if($session->source_channel == 'web')
                                        <span style="display: inline-block; padding: 0.25rem 0.75rem; background: #1e40af; color: #93c5fd; border-radius: 9999px; font-size: 0.75rem; font-weight: 600;">Web</span>
                                    @elseif($session->source_channel == 'mobile')
                                        <span style="display: inline-block; padding: 0.25rem 0.75rem; background: #065f46; color: #6ee7b7; border-radius: 9999px; font-size: 0.75rem; font-weight: 600;">Mobile</span>
                                    @else
                                        <span style="display: inline-block; padding: 0.25rem 0.75rem; background: #6b21a8; color: #d8b4fe; border-radius: 9999px; font-size: 0.75rem; font-weight: 600;">Twilio</span>
                                    @endif
                                </td>
                                <td style="padding: 1rem; color: #e5e7eb; font-size: 0.875rem;">
                                    {{ $session->duration_seconds ? gmdate("H:i:s", $session->duration_seconds) : '00:00:00' }}
                                </td>
                                <td style="padding: 1rem; text-align: center;">
                                    @if($session->status == 'completed')
                                        <span style="display: inline-block; padding: 0.25rem 0.75rem; background: #065f46; color: #6ee7b7; border-radius: 9999px; font-size: 0.75rem; font-weight: 600;">Completed</span>
                                    @elseif($session->status == 'active')
                                        <span style="display: inline-block; padding: 0.25rem 0.75rem; background: #78350f; color: #fcd34d; border-radius: 9999px; font-size: 0.75rem; font-weight: 600;">Active</span>
                                    @else
                                        <span style="display: inline-block; padding: 0.25rem 0.75rem; background: #7f1d1d; color: #fca5a5; border-radius: 9999px; font-size: 0.75rem; font-weight: 600;">Failed</span>
                                    @endif
                                </td>
                                <td style="padding: 1rem; text-align: right; color: #d1d5db; font-size: 0.875rem;">${{ number_format($session->cost_openai, 4) }}</td>
                                <td style="padding: 1rem; text-align: right; color: #d1d5db; font-size: 0.875rem;">${{ number_format($session->cost_tts, 4) }}</td>
                                <td style="padding: 1rem; text-align: right; color: #d1d5db; font-size: 0.875rem;">${{ number_format($session->cost_stt, 4) }}</td>
                                <td style="padding: 1rem; text-align: right; color: #d1d5db; font-size: 0.875rem;">${{ number_format($session->cost_twilio, 4) }}</td>
                                <td style="padding: 1rem; text-align: right; color: #f1f5f9; font-size: 0.875rem; font-weight: bold;">${{ number_format($session->total_cost, 4) }}</td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="9" style="padding: 4rem; text-align: center;">
                                    <div style="color: #9ca3af; font-size: 1.125rem; font-weight: 500;">No call transactions yet</div>
                                    <div style="color: #6b7280; font-size: 0.875rem; margin-top: 0.5rem;">Make a call from the chat to see transactions here</div>
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                        @if($callSessions->count() > 0)
                        <tfoot style="background: #111827; border-top: 2px solid #4b5563;">
                            <tr style="font-weight: bold;">
                                <td colspan="4" style="padding: 1rem; text-align: right; color: #f1f5f9; font-size: 0.875rem; text-transform: uppercase;">TOTALS:</td>
                                <td style="padding: 1rem; text-align: right; color: #f1f5f9; font-size: 0.875rem;">${{ number_format($callSessions->sum('cost_openai'), 4) }}</td>
                                <td style="padding: 1rem; text-align: right; color: #f1f5f9; font-size: 0.875rem;">${{ number_format($callSessions->sum('cost_tts'), 4) }}</td>
                                <td style="padding: 1rem; text-align: right; color: #f1f5f9; font-size: 0.875rem;">${{ number_format($callSessions->sum('cost_stt'), 4) }}</td>
                                <td style="padding: 1rem; text-align: right; color: #f1f5f9; font-size: 0.875rem;">${{ number_format($callSessions->sum('cost_twilio'), 4) }}</td>
                                <td style="padding: 1rem; text-align: right; color: #f1f5f9; font-size: 0.875rem;">${{ number_format($callSessions->sum('total_cost'), 4) }}</td>
                            </tr>
                        </tfoot>
                        @endif
                    </table>
                </div>

                @if($callSessions->hasPages())
                <div style="padding: 1.5rem; border-top: 1px solid #374151;">
                    {{ $callSessions->links() }}
                </div>
                @endif
            </div>
        </div>

        <!-- Call Detail Modal -->
        <div x-show="showModal" 
             x-cloak
             @click.self="showModal = false"
             style="position: fixed; inset: 0; background: rgba(0,0,0,0.75); display: flex; align-items: center; justify-content: center; z-index: 50; padding: 1rem;">
            <div style="background: #1f2937; border-radius: 12px; max-width: 800px; width: 100%; max-height: 90vh; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.5);">
                <!-- Modal Header -->
                <div style="padding: 1.5rem; border-bottom: 1px solid #374151; display: flex; justify-content: space-between; align-items: center;">
                    <h3 style="font-size: 1.5rem; font-weight: bold; color: #f1f5f9;">Call Details</h3>
                    <button @click="showModal = false" style="color: #9ca3af; hover: #f1f5f9; background: transparent; border: none; font-size: 1.5rem; cursor: pointer;">&times;</button>
                </div>

                <!-- Modal Body -->
                <div style="padding: 1.5rem; overflow-y: auto; max-height: calc(90vh - 140px);">
                    <div x-show="loading" style="text-align: center; padding: 2rem;">
                        <div style="color: #9ca3af;">Loading...</div>
                    </div>

                    <div x-show="!loading && selectedCall" style="color: #e5e7eb;">
                        <!-- Call Info -->
                        <div style="margin-bottom: 1.5rem;">
                            <h4 style="font-size: 1.125rem; font-weight: 600; color: #f1f5f9; margin-bottom: 1rem;">Session Information</h4>
                            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; background: #111827; padding: 1rem; border-radius: 8px;">
                                <div>
                                    <div style="font-size: 0.75rem; color: #9ca3af; text-transform: uppercase;">Session ID</div>
                                    <div style="font-size: 0.875rem; color: #e5e7eb; margin-top: 0.25rem;" x-text="selectedCall?.session_id"></div>
                                </div>
                                <div>
                                    <div style="font-size: 0.75rem; color: #9ca3af; text-transform: uppercase;">Source</div>
                                    <div style="font-size: 0.875rem; color: #e5e7eb; margin-top: 0.25rem;" x-text="selectedCall?.source_channel"></div>
                                </div>
                                <div>
                                    <div style="font-size: 0.75rem; color: #9ca3af; text-transform: uppercase;">Started</div>
                                    <div style="font-size: 0.875rem; color: #e5e7eb; margin-top: 0.25rem;" x-text="selectedCall?.started_at"></div>
                                </div>
                                <div>
                                    <div style="font-size: 0.75rem; color: #9ca3af; text-transform: uppercase;">Ended</div>
                                    <div style="font-size: 0.875rem; color: #e5e7eb; margin-top: 0.25rem;" x-text="selectedCall?.ended_at || 'Active'"></div>
                                </div>
                                <div>
                                    <div style="font-size: 0.75rem; color: #9ca3af; text-transform: uppercase;">Duration</div>
                                    <div style="font-size: 0.875rem; color: #e5e7eb; margin-top: 0.25rem;" x-text="selectedCall?.duration_seconds ? new Date(selectedCall.duration_seconds * 1000).toISOString().substr(11, 8) : '00:00:00'"></div>
                                </div>
                                <div>
                                    <div style="font-size: 0.75rem; color: #9ca3af; text-transform: uppercase;">Status</div>
                                    <div style="font-size: 0.875rem; color: #e5e7eb; margin-top: 0.25rem;" x-text="selectedCall?.status"></div>
                                </div>
                            </div>
                        </div>

                        <!-- Cost Breakdown -->
                        <div style="margin-bottom: 1.5rem;">
                            <h4 style="font-size: 1.125rem; font-weight: 600; color: #f1f5f9; margin-bottom: 1rem;">Cost Breakdown</h4>
                            <div style="background: #111827; padding: 1rem; border-radius: 8px;">
                                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.75rem;">
                                    <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #374151;">
                                        <span style="color: #9ca3af;">OpenAI:</span>
                                        <span style="color: #e5e7eb; font-weight: 600;" x-text="'$' + (selectedCall?.cost_openai || 0).toFixed(4)"></span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #374151;">
                                        <span style="color: #9ca3af;">TTS:</span>
                                        <span style="color: #e5e7eb; font-weight: 600;" x-text="'$' + (selectedCall?.cost_tts || 0).toFixed(4)"></span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #374151;">
                                        <span style="color: #9ca3af;">STT:</span>
                                        <span style="color: #e5e7eb; font-weight: 600;" x-text="'$' + (selectedCall?.cost_stt || 0).toFixed(4)"></span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #374151;">
                                        <span style="color: #9ca3af;">Twilio:</span>
                                        <span style="color: #e5e7eb; font-weight: 600;" x-text="'$' + (selectedCall?.cost_twilio || 0).toFixed(4)"></span>
                                    </div>
                                </div>
                                <div style="display: flex; justify-content: space-between; padding: 1rem 0; margin-top: 0.75rem; border-top: 2px solid #4b5563;">
                                    <span style="color: #f1f5f9; font-weight: bold; font-size: 1.125rem;">Total Cost:</span>
                                    <span style="color: #f1f5f9; font-weight: bold; font-size: 1.125rem;" x-text="'$' + (selectedCall?.total_cost || 0).toFixed(4)"></span>
                                </div>
                            </div>
                        </div>

                        <!-- Conversation Transcript -->
                        <div x-show="selectedCall?.turns && selectedCall.turns.length > 0">
                            <h4 style="font-size: 1.125rem; font-weight: 600; color: #f1f5f9; margin-bottom: 1rem;">Conversation Transcript</h4>
                            <div style="background: #111827; padding: 1rem; border-radius: 8px; max-height: 300px; overflow-y: auto;">
                                <template x-for="turn in selectedCall?.turns || []" :key="turn.id">
                                    <div style="margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 1px solid #374151;">
                                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                                            <span style="font-weight: 600; color: #f1f5f9;" x-text="turn.speaker === 'user' ? 'User' : 'Assistant'"></span>
                                            <span style="font-size: 0.75rem; color: #9ca3af;" x-text="turn.spoken_at"></span>
                                        </div>
                                        <div style="color: #d1d5db; font-size: 0.875rem;" x-text="turn.content"></div>
                                        <div x-show="turn.language" style="font-size: 0.75rem; color: #9ca3af; margin-top: 0.25rem;">
                                            <span x-text="'Language: ' + turn.language"></span>
                                            <span x-show="turn.confidence" x-text="' • Confidence: ' + (turn.confidence * 100).toFixed(1) + '%'"></span>
                                        </div>
                                    </div>
                                </template>
                            </div>
                        </div>

                        <div x-show="!selectedCall?.turns || selectedCall.turns.length === 0" style="background: #111827; padding: 2rem; border-radius: 8px; text-align: center; color: #9ca3af;">
                            No conversation transcript available
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
