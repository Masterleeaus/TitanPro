<?php

namespace Database\Seeders;

use App\Models\Business;
use App\Models\Tenant;
use App\Models\TenantSetting;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DemoUsersSeeder extends Seeder
{
    public function run(): void
    {
        // Create Super Admin
        User::create([
            'name' => 'Super Admin',
            'email' => 'admin@voiceai.com',
            'password' => Hash::make('admin123'),
            'role' => 'super_admin',
            'tenant_id' => null,
        ]);

        // Create Demo Tenant 1: Pizza Restaurant
        $tenant1 = Tenant::create([
            'company_name' => 'Joe\'s Pizza Palace',
            'subdomain' => 'joes-pizza',
            'plan' => 'pro',
            'is_active' => true,
            'trial_ends_at' => now()->addDays(30),
        ]);

        TenantSetting::create([
            'tenant_id' => $tenant1->id,
            'twilio_account_sid' => 'demo_sid_pizza',
            'twilio_auth_token' => 'demo_token_pizza',
            'twilio_phone_number' => '+15551234567',
            'openai_api_key' => 'demo_openai_key_pizza',
        ]);

        User::create([
            'name' => 'Joe Pizza Owner',
            'email' => 'joe@joespizza.com',
            'password' => Hash::make('pizza123'),
            'role' => 'tenant_admin',
            'tenant_id' => $tenant1->id,
        ]);

        if (class_exists(Business::class)) {
            Business::create([
                'tenant_id' => $tenant1->id,
                'name' => 'Joe\'s Pizza Palace',
                'type' => 'restaurant',
                'phone_number' => '+15551234567',
            ]);
        }

        // Create Demo Tenant 2: Spa & Salon
        $tenant2 = Tenant::create([
            'company_name' => 'Serenity Spa & Salon',
            'subdomain' => 'serenity-spa',
            'plan' => 'basic',
            'is_active' => true,
            'trial_ends_at' => now()->addDays(14),
        ]);

        TenantSetting::create([
            'tenant_id' => $tenant2->id,
            'twilio_account_sid' => 'demo_sid_spa',
            'twilio_auth_token' => 'demo_token_spa',
            'twilio_phone_number' => '+15559876543',
            'openai_api_key' => 'demo_openai_key_spa',
        ]);

        User::create([
            'name' => 'Sarah Spa Manager',
            'email' => 'sarah@serenityspa.com',
            'password' => Hash::make('spa123'),
            'role' => 'tenant_admin',
            'tenant_id' => $tenant2->id,
        ]);

        if (class_exists(Business::class)) {
            Business::create([
                'tenant_id' => $tenant2->id,
                'name' => 'Serenity Spa & Salon',
                'type' => 'salon',
                'phone_number' => '+15559876543',
            ]);
        }

        // Create Demo Tenant 3: Hotel
        $tenant3 = Tenant::create([
            'company_name' => 'Grand Vista Hotel',
            'subdomain' => 'grand-vista',
            'plan' => 'enterprise',
            'is_active' => true,
            'trial_ends_at' => now()->addDays(60),
        ]);

        TenantSetting::create([
            'tenant_id' => $tenant3->id,
            'twilio_account_sid' => 'demo_sid_hotel',
            'twilio_auth_token' => 'demo_token_hotel',
            'twilio_phone_number' => '+15555551111',
            'openai_api_key' => 'demo_openai_key_hotel',
        ]);

        User::create([
            'name' => 'Mike Hotel Manager',
            'email' => 'mike@grandvista.com',
            'password' => Hash::make('hotel123'),
            'role' => 'tenant_admin',
            'tenant_id' => $tenant3->id,
        ]);

        if (class_exists(Business::class)) {
            Business::create([
                'tenant_id' => $tenant3->id,
                'name' => 'Grand Vista Hotel',
                'type' => 'hotel',
                'phone_number' => '+15555551111',
            ]);
        }

        echo "\n✅ Demo users created successfully!\n\n";
        echo "=== DEMO LOGINS ===\n\n";
        echo "🔑 Super Admin:\n";
        echo "   Email: admin@voiceai.com\n";
        echo "   Password: admin123\n\n";
        echo "🍕 Tenant 1 - Joe's Pizza Palace (Pro Plan):\n";
        echo "   Email: joe@joespizza.com\n";
        echo "   Password: pizza123\n\n";
        echo "💆 Tenant 2 - Serenity Spa & Salon (Basic Plan):\n";
        echo "   Email: sarah@serenityspa.com\n";
        echo "   Password: spa123\n\n";
        echo "🏨 Tenant 3 - Grand Vista Hotel (Enterprise Plan):\n";
        echo "   Email: mike@grandvista.com\n";
        echo "   Password: hotel123\n\n";
    }
}
