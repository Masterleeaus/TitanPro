<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('tenant_settings', function (Blueprint $table) {
            $table->text('system_prompt')->nullable()->after('additional_settings');
            $table->string('business_type')->default('general')->after('system_prompt');
            $table->text('business_context')->nullable()->after('business_type');
            $table->string('voice_tone')->default('professional')->after('business_context');
            $table->string('operating_hours')->nullable()->after('voice_tone');
            $table->string('default_language')->default('en-IN')->after('operating_hours');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('tenant_settings', function (Blueprint $table) {
            $table->dropColumn([
                'system_prompt',
                'business_type',
                'business_context',
                'voice_tone',
                'operating_hours',
                'default_language'
            ]);
        });
    }
};
