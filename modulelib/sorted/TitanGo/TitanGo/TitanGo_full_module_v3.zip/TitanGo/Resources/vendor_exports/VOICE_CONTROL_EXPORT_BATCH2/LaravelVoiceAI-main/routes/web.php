<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PageController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/chat', [PageController::class, 'chatTest'])->name('chat.test');

Route::get('/dashboard', [DashboardController::class, 'index'])
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

Route::get('/dashboard/chat', [DashboardController::class, 'chat'])
    ->middleware(['auth', 'verified'])
    ->name('dashboard.chat');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Tenant-only routes
Route::middleware(['auth', \App\Http\Middleware\EnsureTenantUser::class])->group(function () {
    // Settings
    Route::get('/settings', [App\Http\Controllers\SettingsController::class, 'index'])->name('settings.index');
    Route::post('/settings', [App\Http\Controllers\SettingsController::class, 'update'])->name('settings.update');
    
    // AI Configuration
    Route::get('/ai-configuration', [App\Http\Controllers\AIConfigurationController::class, 'index'])->name('ai-configuration.index');
    Route::post('/ai-configuration', [App\Http\Controllers\AIConfigurationController::class, 'update'])->name('ai-configuration.update');
    
    // Voice Configurations
    Route::post('/voice-configurations', [App\Http\Controllers\VoiceConfigurationController::class, 'store'])->name('voice-configurations.store');
    Route::put('/voice-configurations/{voiceConfiguration}', [App\Http\Controllers\VoiceConfigurationController::class, 'update'])->name('voice-configurations.update');
    Route::delete('/voice-configurations/{voiceConfiguration}', [App\Http\Controllers\VoiceConfigurationController::class, 'destroy'])->name('voice-configurations.destroy');
    Route::post('/voice-configurations/{voiceConfiguration}/set-default', [App\Http\Controllers\VoiceConfigurationController::class, 'setDefault'])->name('voice-configurations.set-default');
    Route::post('/voice-configurations/test', [App\Http\Controllers\VoiceConfigurationController::class, 'test'])->name('voice-configurations.test');
    
    // Call Logs (old Twilio logs)
    Route::get('/call-logs-old', [App\Http\Controllers\CallLogController::class, 'index'])->name('call-logs-old.index');
    
    // Call Sessions (new unified call tracking)
    Route::get('/call-logs', [App\Http\Controllers\CallLogsController::class, 'index'])->name('call-logs.index');
    Route::get('/call-logs/{id}', [App\Http\Controllers\CallLogsController::class, 'show'])->name('call-logs.show');
});

// Twilio Webhooks (no auth middleware - Twilio validates its own requests)
Route::post('/webhooks/twilio/voice', [App\Http\Controllers\TwilioWebhookController::class, 'handleVoiceCall'])->name('twilio.voice');
Route::post('/webhooks/twilio/voice/language', [App\Http\Controllers\TwilioWebhookController::class, 'handleLanguageSelection'])->name('twilio.voice.language');
Route::post('/webhooks/twilio/voice/process', [App\Http\Controllers\TwilioWebhookController::class, 'processLiveSpeech'])->name('twilio.voice.process');
Route::post('/webhooks/twilio/voice/recording', [App\Http\Controllers\TwilioWebhookController::class, 'handleRecording'])->name('twilio.voice.recording');
Route::post('/webhooks/twilio/sms', [App\Http\Controllers\TwilioWebhookController::class, 'handleSms'])->name('twilio.sms');

require __DIR__.'/auth.php';
