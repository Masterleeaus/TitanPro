<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tenant;
use App\Models\TenantSetting;
use App\Models\Business;
use App\Models\CallLog;
use App\Models\VoiceConfiguration;
use App\Services\OpenAIService;
use App\Services\GoogleTTSService;
use App\Services\LanguageIntelligenceService;
use Illuminate\Support\Facades\Log;

class MediaStreamApiController extends Controller
{
    public function processTranscript(Request $request)
    {
        try {
            $validated = $request->validate([
                'callSid' => 'required|string',
                'streamSid' => 'required|string',
                'tenantId' => 'nullable|string',
                'from' => 'required|string',
                'to' => 'required|string',
                'transcript' => 'required|string',
                'detectedLanguage' => 'required|string',
                'conversationHistory' => 'array'
            ]);

            $callSid = $validated['callSid'];
            $streamSid = $validated['streamSid'];
            $from = $validated['from'];
            $to = $validated['to'];
            $transcript = $validated['transcript'];
            $detectedLanguage = $validated['detectedLanguage'];
            $conversationHistory = $validated['conversationHistory'] ?? [];

            if (!$validated['tenantId']) {
                $tenantId = $this->getTenantByPhone($to);
            } else {
                $tenantId = $validated['tenantId'];
            }
            
            if (!$tenantId) {
                return response()->json([
                    'error' => 'Tenant not found',
                    'aiResponse' => 'Sorry, this number is not configured.',
                    'audioUrl' => null
                ], 404);
            }

            $business = Business::where('tenant_id', $tenantId)->first();
            
            // STEP 1: Get tenant's default language from settings first, then voice configuration
            $tenantSettings = TenantSetting::where('tenant_id', $tenantId)->first();
            $tenantDefaultLanguage = 'en-in'; // Final fallback
            
            if ($tenantSettings && $tenantSettings->default_language) {
                $tenantDefaultLanguage = strtolower($tenantSettings->default_language);
            } else {
                $defaultVoiceConfig = VoiceConfiguration::where('tenant_id', $tenantId)
                    ->where('is_default', true)
                    ->first();
                $tenantDefaultLanguage = $defaultVoiceConfig ? $defaultVoiceConfig->language_code : 'en-in';
            }
            
            // STEP 2: Get current session language (cached from previous turns, or use tenant default)
            $languageIntelligence = new LanguageIntelligenceService();
            $currentLanguage = $languageIntelligence->getSessionLanguage($streamSid) ?? $tenantDefaultLanguage;
            
            // STEP 3: Fast check - is customer speaking DIFFERENT language?
            $languageResult = $languageIntelligence->detectLanguage(
                $transcript,
                $currentLanguage,
                $streamSid
            );
            
            $effectiveLanguage = $languageResult['language'];
            $switched = $languageResult['switched'];
            
            Log::info('Fast language detection', [
                'transcript' => $transcript,
                'current_language' => $currentLanguage,
                'tenant_default' => $tenantDefaultLanguage,
                'final_language' => $effectiveLanguage,
                'switched' => $switched,
            ]);
            
            $languageInstructions = [
                'ta-in' => 'CRITICAL: You MUST respond ONLY in Tamil language (தமிழ்). Do NOT use English. Write your entire response in Tamil script.',
                'en-in' => 'CRITICAL: You MUST respond ONLY in English language.',
                'en-us' => 'CRITICAL: You MUST respond ONLY in English language.',
                'hi-in' => 'CRITICAL: You MUST respond ONLY in Hindi language (हिंदी). Do NOT use English. Write your entire response in Devanagari script.',
                'cmn-cn' => 'CRITICAL: You MUST respond ONLY in Mandarin Chinese (中文/普通话). Do NOT use English. Write your entire response in Chinese characters.',
                'ms-my' => 'CRITICAL: You MUST respond ONLY in Malay language (Bahasa Melayu). Do NOT use English.',
                'id-id' => 'CRITICAL: You MUST respond ONLY in Indonesian language (Bahasa Indonesia). Do NOT use English.',
                'th-th' => 'CRITICAL: You MUST respond ONLY in Thai language (ภาษาไทย). Do NOT use English. Write your entire response in Thai script.',
            ];
            
            $languageInstruction = $languageInstructions[$effectiveLanguage] ?? 'Respond in English.';
            
            // Use effective language for all processing
            $detectedLanguage = $effectiveLanguage;
            
            $openAIService = new OpenAIService($tenantId);

            // Build system prompt from tenant configuration
            // Start with custom prompt or default
            if ($tenantSettings && $tenantSettings->system_prompt) {
                // Use custom system prompt
                $systemPrompt = "{$languageInstruction}\n\n{$tenantSettings->system_prompt}";
            } else {
                // Fallback to default system prompt
                $systemPrompt = $business 
                    ? "{$languageInstruction}\n\nYou are a helpful AI for {$business->name}, a {$business->type}. Be extremely brief - max 10 words per response."
                    : "{$languageInstruction}\n\nYou are a helpful AI assistant. Be extremely brief - max 10 words per response.";
            }
            
            // Always append business context, hours, and tone if provided (even without custom prompt)
            if ($tenantSettings) {
                if ($tenantSettings->business_context) {
                    $systemPrompt .= "\n\nBusiness Information:\n{$tenantSettings->business_context}";
                }
                
                if ($tenantSettings->operating_hours) {
                    $systemPrompt .= "\n\nOperating Hours: {$tenantSettings->operating_hours}";
                }
                
                // Add voice tone instruction
                $toneInstructions = [
                    'professional' => 'Maintain a professional and courteous tone.',
                    'friendly' => 'Be warm, friendly, and casual in your responses.',
                    'formal' => 'Use formal and polite language at all times.',
                    'enthusiastic' => 'Be energetic, enthusiastic, and upbeat in your responses.',
                ];
                $tone = $tenantSettings->voice_tone ?? 'professional';
                if (isset($toneInstructions[$tone])) {
                    $systemPrompt .= "\n\n{$toneInstructions[$tone]}";
                }
            }
            
            // Add brief response instruction
            if ($tenantSettings && $tenantSettings->system_prompt) {
                $systemPrompt .= "\n\nIMPORTANT: Keep responses brief and conversational (max 2-3 sentences for voice calls).";
            }

            $messages = [];
            
            foreach ($conversationHistory as $turn) {
                if ($turn['role'] === 'customer') {
                    $messages[] = ['role' => 'user', 'content' => $turn['content']];
                } else {
                    $messages[] = ['role' => 'assistant', 'content' => $turn['content']];
                }
            }
            
            $messages[] = ['role' => 'user', 'content' => $transcript];

            $aiResponse = $openAIService->chatFast($messages, $systemPrompt);

            Log::info('Media Stream AI Response', [
                'call_sid' => $callSid,
                'customer_said' => $transcript,
                'ai_responded' => $aiResponse,
                'detected_language' => $detectedLanguage
            ]);
            
            // Use effective language for voice configuration
            $voiceConfig = VoiceConfiguration::where('tenant_id', $tenantId)
                ->where('language_code', $effectiveLanguage)
                ->first();
            
            if (!$voiceConfig) {
                $voiceConfig = VoiceConfiguration::where('tenant_id', $tenantId)
                    ->where('is_default', true)
                    ->first();
            }
            
            $googleTTS = new GoogleTTSService();
            
            if ($voiceConfig) {
                $audioUrl = $googleTTS->generateSpeechWithConfig(
                    $aiResponse,
                    $voiceConfig->voice_name,
                    $voiceConfig->gender,
                    $voiceConfig->speaking_rate,
                    $voiceConfig->pitch
                );
            } else {
                $audioUrl = $googleTTS->generateSpeech($aiResponse, $detectedLanguage, false);
            }
            
            $languageClosingMessages = [
                'ta-IN' => 'அழைத்ததற்கு நன்றி!',
                'en-IN' => 'Thank you for calling!',
                'hi-IN' => 'कॉल करने के लिए धन्यवाद!',
                'cmn-CN' => '感谢您的来电!',
                'ms-MY' => 'Terima kasih kerana menghubungi!',
                'id-ID' => 'Terima kasih telah menelepon!',
                'th-TH' => 'ขอบคุณที่โทรมา!',
            ];
            
            $closingMessage = $languageClosingMessages[$detectedLanguage] ?? 'Thank you for calling!';
            $closingAudioUrl = null;
            
            if (count($conversationHistory) > 6) {
                if ($voiceConfig) {
                    $closingAudioUrl = $googleTTS->generateSpeechWithConfig(
                        $closingMessage,
                        $voiceConfig->voice_name,
                        $voiceConfig->gender,
                        $voiceConfig->speaking_rate,
                        $voiceConfig->pitch
                    );
                } else {
                    $closingAudioUrl = $googleTTS->generateSpeech($closingMessage, $detectedLanguage, false);
                }
            }
            
            $callLog = CallLog::where('call_sid', $callSid)->latest()->first();
            
            if (!$callLog) {
                $callLog = CallLog::create([
                    'tenant_id' => $tenantId,
                    'call_sid' => $callSid,
                    'from_number' => $from,
                    'to_number' => $to,
                    'transcription' => '',
                    'status' => 'in-progress',
                    'language_code' => $detectedLanguage,
                    'duration' => 0,
                    'twilio_cost' => 0,
                    'openai_cost' => 0,
                    'tts_cost' => 0,
                    'total_cost' => 0,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
            
            $existingTranscription = $callLog->transcription ?? '';
            
            $estimatedInputTokens = (int)(strlen($transcript) / 4);
            $estimatedOutputTokens = (int)(strlen($aiResponse) / 4);
            $ttsCharacters = strlen($aiResponse) + strlen($closingMessage);
            $estimatedSTTSeconds = max(strlen($transcript) / 15, 3);
            $estimatedDuration = $estimatedSTTSeconds + 5;
            
            $costs = $this->calculateCosts($estimatedDuration, $estimatedInputTokens, $estimatedOutputTokens, $ttsCharacters, $estimatedSTTSeconds);
            
            $currentTwilioCost = (float)$callLog->twilio_cost;
            $currentOpenAICost = (float)$callLog->openai_cost;
            $currentTTSCost = (float)$callLog->tts_cost;
            $currentSTTCost = (float)($callLog->stt_cost ?? 0);
            
            $newTwilioCost = $currentTwilioCost + $costs['twilio_cost'];
            $newOpenAICost = $currentOpenAICost + $costs['openai_cost'];
            $newTTSCost = $currentTTSCost + $costs['tts_cost'];
            $newSTTCost = $currentSTTCost + $costs['stt_cost'];
            $newTotalCost = $newTwilioCost + $newOpenAICost + $newTTSCost + $newSTTCost;
            
            $callLog->update([
                'transcription' => $existingTranscription . "\nCustomer: " . $transcript . "\nAssistant: " . $aiResponse,
                'status' => 'in-progress',
                'language_code' => $detectedLanguage,
                'twilio_cost' => $newTwilioCost,
                'openai_cost' => $newOpenAICost,
                'tts_cost' => $newTTSCost,
                'stt_cost' => $newSTTCost,
                'total_cost' => $newTotalCost,
            ]);
            
            return response()->json([
                'success' => true,
                'aiResponse' => $aiResponse,
                'audioUrl' => url($audioUrl),
                'closingMessage' => count($conversationHistory) > 6 ? $closingMessage : null,
                'closingAudioUrl' => $closingAudioUrl ? url($closingAudioUrl) : null,
                'detectedLanguage' => $detectedLanguage,
            ]);
            
        } catch (\Exception $e) {
            Log::error('Media Stream API Error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'error' => 'Processing error',
                'message' => $e->getMessage()
            ], 500);
        }
    }
    
    private function getTenantByPhone($phoneNumber)
    {
        $settings = TenantSetting::where('twilio_phone_number', $phoneNumber)->first();
        return $settings ? $settings->tenant_id : null;
    }
    
    private function calculateCosts($durationSeconds, $inputTokens, $outputTokens, $ttsCharacters, $sttSeconds = 0)
    {
        $twilioCostPerMinute = 0.0085;
        $openaiInputCostPer1M = 0.150;
        $openaiOutputCostPer1M = 0.600;
        $googleTTSCostPer1MChars = 4.00;
        $googleSTTCostPerMinute = 0.006;
        
        $durationMinutes = $durationSeconds / 60;
        $twilioCost = $durationMinutes * $twilioCostPerMinute;
        
        $openaiInputCost = ($inputTokens / 1000000) * $openaiInputCostPer1M;
        $openaiOutputCost = ($outputTokens / 1000000) * $openaiOutputCostPer1M;
        $openaiCost = $openaiInputCost + $openaiOutputCost;
        
        $ttsCost = ($ttsCharacters / 1000000) * $googleTTSCostPer1MChars;
        
        $sttMinutes = $sttSeconds / 60;
        $sttCost = $sttMinutes * $googleSTTCostPerMinute;
        
        $totalCost = $twilioCost + $openaiCost + $ttsCost + $sttCost;
        
        return [
            'twilio_cost' => $twilioCost,
            'openai_cost' => $openaiCost,
            'tts_cost' => $ttsCost,
            'stt_cost' => $sttCost,
            'total_cost' => $totalCost,
        ];
    }
    
    public function getTenantLanguage($tenantId)
    {
        try {
            $voiceConfig = VoiceConfiguration::where('tenant_id', $tenantId)
                ->where('is_default', true)
                ->first();
            
            $language = $voiceConfig ? $voiceConfig->language_code : 'en-IN';
            
            return response()->json([
                'language' => $language
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'language' => 'en-IN'
            ]);
        }
    }
}
