<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class ApiKey extends Model
{
    protected $fillable = [
        'tenant_id',
        'name',
        'key',
        'permissions',
        'rate_limit',
        'is_active',
        'last_used_at',
        'expires_at',
    ];

    protected $casts = [
        'permissions' => 'array',
        'is_active' => 'boolean',
        'last_used_at' => 'datetime',
        'expires_at' => 'datetime',
    ];

    protected $hidden = [
        'key',
    ];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public static function generate($tenantId, $name)
    {
        return self::create([
            'tenant_id' => $tenantId,
            'name' => $name,
            'key' => 'sk_' . Str::random(48),
            'is_active' => true,
        ]);
    }

    public function recordUsage()
    {
        $this->update(['last_used_at' => now()]);
    }
}
