<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl">⚙️ API Settings</h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            @if (session('success'))
            <div class="alert alert-blue mb-6">
                <h3>Success!</h3>
                <p>{{ session('success') }}</p>
            </div>
            @endif

            <!-- Account Balances -->
            <div class="card mb-6">
                <div class="card-body">
                    <h3 class="text-lg font-semibold mb-6" style="color: #f1f5f9;">💰 Account Balances</h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <!-- Twilio Balance -->
                        <div style="background: linear-gradient(135deg, #1f2937 0%, #111827 100%); border: 2px solid #ef4444; border-radius: 0.75rem; padding: 1.5rem;">
                            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                                <div>
                                    <h4 style="color: #f1f5f9; font-weight: 600; font-size: 1rem; margin-bottom: 0.25rem;">📞 Twilio</h4>
                                    <p style="color: #9ca3af; font-size: 0.75rem;">Voice & SMS Balance</p>
                                </div>
                                @if($balances['twilio'])
                                <span style="display: inline-block; padding: 0.25rem 0.75rem; background: {{ $balances['twilio']['status'] == 'active' ? '#065f46' : '#7f1d1d' }}; color: {{ $balances['twilio']['status'] == 'active' ? '#6ee7b7' : '#fca5a5' }}; border-radius: 9999px; font-size: 0.75rem; font-weight: 600;">
                                    {{ ucfirst($balances['twilio']['status']) }}
                                </span>
                                @endif
                            </div>
                            @if($balances['twilio'])
                            <div style="font-size: 2.5rem; font-weight: 700; color: {{ $balances['twilio']['balance'] > 5 ? '#10b981' : ($balances['twilio']['balance'] > 1 ? '#f59e0b' : '#ef4444') }};">
                                ${{ number_format($balances['twilio']['balance'], 2) }}
                            </div>
                            <div style="color: #9ca3af; font-size: 0.875rem; margin-top: 0.5rem;">
                                {{ $balances['twilio']['currency'] ?? 'USD' }}
                            </div>
                            @else
                            <div style="color: #6b7280; font-size: 0.875rem;">
                                Not configured
                            </div>
                            @endif
                        </div>

                        <!-- OpenAI Status -->
                        <div style="background: linear-gradient(135deg, #1f2937 0%, #111827 100%); border: 2px solid #8b5cf6; border-radius: 0.75rem; padding: 1.5rem;">
                            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                                <div>
                                    <h4 style="color: #f1f5f9; font-weight: 600; font-size: 1rem; margin-bottom: 0.25rem;">🤖 OpenAI</h4>
                                    <p style="color: #9ca3af; font-size: 0.75rem;">GPT-4o-mini API</p>
                                </div>
                                @if($balances['openai'])
                                <span style="display: inline-block; padding: 0.25rem 0.75rem; background: {{ $balances['openai']['status'] == 'active' ? '#065f46' : '#7f1d1d' }}; color: {{ $balances['openai']['status'] == 'active' ? '#6ee7b7' : '#fca5a5' }}; border-radius: 9999px; font-size: 0.75rem; font-weight: 600;">
                                    {{ ucfirst($balances['openai']['status']) }}
                                </span>
                                @endif
                            </div>
                            @if($balances['openai'])
                                @if(isset($balances['openai']['balance']) && $balances['openai']['balance'] !== null)
                                <div style="font-size: 2.5rem; font-weight: 700; color: {{ $balances['openai']['balance'] > 5 ? '#10b981' : ($balances['openai']['balance'] > 1 ? '#f59e0b' : '#ef4444') }};">
                                    ${{ number_format($balances['openai']['balance'], 2) }}
                                </div>
                                <div style="color: #9ca3af; font-size: 0.875rem; margin-top: 0.5rem;">
                                    Credits Available
                                </div>
                                @else
                                <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                                    <div style="width: 12px; height: 12px; background: #10b981; border-radius: 50%;"></div>
                                    <span style="color: #10b981; font-weight: 600; font-size: 0.875rem;">Connected</span>
                                </div>
                                <div style="color: #9ca3af; font-size: 0.875rem;">
                                    {{ $balances['openai']['message'] ?? 'Usage tracked in Call Logs' }}
                                </div>
                                @endif
                            @else
                            <div style="color: #6b7280; font-size: 0.875rem;">
                                Not configured
                            </div>
                            @endif
                        </div>

                        <!-- Google Cloud Status -->
                        <div style="background: linear-gradient(135deg, #1f2937 0%, #111827 100%); border: 2px solid #3b82f6; border-radius: 0.75rem; padding: 1.5rem;">
                            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                                <div>
                                    <h4 style="color: #f1f5f9; font-weight: 600; font-size: 1rem; margin-bottom: 0.25rem;">☁️ Google Cloud</h4>
                                    <p style="color: #9ca3af; font-size: 0.75rem;">TTS & STT Services</p>
                                </div>
                                @php
                                    $gcBalance = App\Services\ApiBalanceService::getGoogleCloudBalance();
                                @endphp
                                @if($gcBalance)
                                <span style="display: inline-block; padding: 0.25rem 0.75rem; background: {{ $gcBalance['status'] == 'active' ? '#065f46' : '#7f1d1d' }}; color: {{ $gcBalance['status'] == 'active' ? '#6ee7b7' : '#fca5a5' }}; border-radius: 9999px; font-size: 0.75rem; font-weight: 600;">
                                    {{ ucfirst($gcBalance['status']) }}
                                </span>
                                @endif
                            </div>
                            @if($gcBalance)
                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                                <div style="width: 12px; height: 12px; background: #10b981; border-radius: 50%;"></div>
                                <span style="color: #10b981; font-weight: 600; font-size: 0.875rem;">Connected</span>
                            </div>
                            <div style="color: #9ca3af; font-size: 0.875rem;">
                                {{ $gcBalance['message'] ?? 'Usage tracked in Call Logs' }}
                            </div>
                            @else
                            <div style="color: #6b7280; font-size: 0.875rem;">
                                Not configured
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>

            <!-- API Usage Dashboard -->
            <div class="card mb-6">
                <div class="card-body">
                    <h3 class="text-lg font-semibold mb-6" style="color: #f1f5f9;">📊 API Usage Dashboard</h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <!-- OpenAI Cost -->
                        <div style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); border-radius: 0.75rem; padding: 1.5rem;">
                            <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;">
                                <span style="font-size: 2rem;">🤖</span>
                                <h4 style="color: rgba(255,255,255,0.9); font-weight: 600; font-size: 0.875rem; text-transform: uppercase;">OpenAI</h4>
                            </div>
                            <div style="margin-top: 1rem;">
                                <div style="font-size: 2rem; font-weight: 700; color: white;">
                                    ${{ number_format($apiUsage['openai_cost'], 4) }}
                                </div>
                                <div style="color: rgba(255,255,255,0.8); font-size: 0.75rem; margin-top: 0.25rem;">
                                    {{ number_format($apiUsage['openai_tokens']) }} tokens
                                </div>
                            </div>
                        </div>

                        <!-- Google TTS Cost -->
                        <div style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); border-radius: 0.75rem; padding: 1.5rem;">
                            <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;">
                                <span style="font-size: 2rem;">🔊</span>
                                <h4 style="color: rgba(255,255,255,0.9); font-weight: 600; font-size: 0.875rem; text-transform: uppercase;">TTS</h4>
                            </div>
                            <div style="margin-top: 1rem;">
                                <div style="font-size: 2rem; font-weight: 700; color: white;">
                                    ${{ number_format($apiUsage['tts_cost'], 4) }}
                                </div>
                                <div style="color: rgba(255,255,255,0.8); font-size: 0.75rem; margin-top: 0.25rem;">
                                    {{ number_format($apiUsage['tts_characters']) }} chars
                                </div>
                            </div>
                        </div>

                        <!-- Google STT Cost -->
                        <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); border-radius: 0.75rem; padding: 1.5rem;">
                            <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;">
                                <span style="font-size: 2rem;">🎤</span>
                                <h4 style="color: rgba(255,255,255,0.9); font-weight: 600; font-size: 0.875rem; text-transform: uppercase;">STT</h4>
                            </div>
                            <div style="margin-top: 1rem;">
                                <div style="font-size: 2rem; font-weight: 700; color: white;">
                                    ${{ number_format($apiUsage['stt_cost'], 4) }}
                                </div>
                                <div style="color: rgba(255,255,255,0.8); font-size: 0.75rem; margin-top: 0.25rem;">
                                    {{ gmdate("H:i:s", $apiUsage['stt_seconds']) }}
                                </div>
                            </div>
                        </div>

                        <!-- Twilio Cost -->
                        <div style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); border-radius: 0.75rem; padding: 1.5rem;">
                            <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;">
                                <span style="font-size: 2rem;">📞</span>
                                <h4 style="color: rgba(255,255,255,0.9); font-weight: 600; font-size: 0.875rem; text-transform: uppercase;">Twilio</h4>
                            </div>
                            <div style="margin-top: 1rem;">
                                <div style="font-size: 2rem; font-weight: 700; color: white;">
                                    ${{ number_format($apiUsage['twilio_cost'], 4) }}
                                </div>
                                <div style="color: rgba(255,255,255,0.8); font-size: 0.75rem; margin-top: 0.25rem;">
                                    {{ gmdate("H:i:s", $apiUsage['twilio_seconds']) }}
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Total Cost -->
                    <div style="margin-top: 1.5rem; padding: 1.5rem; background: linear-gradient(135deg, #f59e0b 0%, #f97316 100%); border-radius: 0.75rem;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <h4 style="color: rgba(255,255,255,0.9); font-weight: 600; font-size: 1rem; text-transform: uppercase; margin-bottom: 0.5rem;">Total API Cost</h4>
                                <p style="color: rgba(255,255,255,0.8); font-size: 0.75rem;">Across all services</p>
                            </div>
                            <div style="font-size: 2.5rem; font-weight: 700; color: white;">
                                ${{ number_format($apiUsage['total_cost'], 4) }}
                            </div>
                        </div>
                    </div>

                    <!-- Call Statistics -->
                    <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid #475569;">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div style="text-align: center;">
                                <div style="color: #cbd5e1; font-size: 0.875rem; margin-bottom: 0.5rem;">Total Calls</div>
                                <div style="font-size: 1.5rem; font-weight: 700; color: #f1f5f9;">{{ $apiUsage['total_calls'] }}</div>
                            </div>
                            <div style="text-align: center;">
                                <div style="color: #cbd5e1; font-size: 0.875rem; margin-bottom: 0.5rem;">Completed Calls</div>
                                <div style="font-size: 1.5rem; font-weight: 700; color: #10b981;">{{ $apiUsage['completed_calls'] }}</div>
                            </div>
                            <div style="text-align: center;">
                                <div style="color: #cbd5e1; font-size: 0.875rem; margin-bottom: 0.5rem;">Total Duration</div>
                                <div style="font-size: 1.5rem; font-weight: 700; color: #3b82f6;">{{ $apiUsage['total_duration_minutes'] }} min</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h3 class="text-lg font-semibold mb-4">Configure Your API Keys</h3>
                    <p class="text-secondary mb-6">Add your Twilio and OpenAI API credentials to enable voice assistant features for your business.</p>

                    <form method="POST" action="{{ route('settings.update') }}" class="space-y-6">
                        @csrf

                        <!-- Twilio Settings -->
                        <div style="border: 1px solid #475569; border-radius: 0.75rem; padding: 1.5rem; background: #0f172a;">
                            <h4 class="font-semibold mb-4" style="color: #f1f5f9;">📞 Twilio Configuration</h4>
                            <p class="text-sm mb-4" style="color: #cbd5e1;">Get your credentials from <a href="https://console.twilio.com" target="_blank" style="color: #3b82f6; text-decoration: underline;">Twilio Console</a></p>

                            <div class="grid grid-cols-1 gap-4">
                                <div>
                                    <label for="twilio_account_sid" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Account SID</label>
                                    <input type="text" name="twilio_account_sid" id="twilio_account_sid" value="{{ old('twilio_account_sid', $settings->twilio_account_sid) }}" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                </div>
                                <div>
                                    <label for="twilio_auth_token" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Auth Token</label>
                                    <input type="password" name="twilio_auth_token" id="twilio_auth_token" value="{{ old('twilio_auth_token', $settings->twilio_auth_token) }}" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                </div>
                                <div>
                                    <label for="twilio_phone_number" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Phone Number (E.164 format: +15551234567)</label>
                                    <input type="text" name="twilio_phone_number" id="twilio_phone_number" value="{{ old('twilio_phone_number', $settings->twilio_phone_number) }}" placeholder="+15551234567" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                </div>
                            </div>
                        </div>

                        <!-- OpenAI Settings -->
                        <div style="border: 1px solid #475569; border-radius: 0.75rem; padding: 1.5rem; background: #0f172a;">
                            <h4 class="font-semibold mb-4" style="color: #f1f5f9;">🤖 OpenAI Configuration</h4>
                            <p class="text-sm mb-4" style="color: #cbd5e1;">Get your API key from <a href="https://platform.openai.com/api-keys" target="_blank" style="color: #3b82f6; text-decoration: underline;">OpenAI Platform</a></p>

                            <div class="grid grid-cols-1 gap-4">
                                <div>
                                    <label for="openai_api_key" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">API Key</label>
                                    <input type="password" name="openai_api_key" id="openai_api_key" value="{{ old('openai_api_key', $settings->openai_api_key) }}" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                </div>
                                <div>
                                    <label for="openai_model" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Model (optional, default: gpt-4)</label>
                                    <select name="openai_model" id="openai_model" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                        <option value="gpt-4" {{ $settings->openai_model == 'gpt-4' ? 'selected' : '' }}>GPT-4</option>
                                        <option value="gpt-4-turbo" {{ $settings->openai_model == 'gpt-4-turbo' ? 'selected' : '' }}>GPT-4 Turbo</option>
                                        <option value="gpt-3.5-turbo" {{ $settings->openai_model == 'gpt-3.5-turbo' ? 'selected' : '' }}>GPT-3.5 Turbo</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Mobile Experience Settings -->
                        <div style="border: 1px solid #475569; border-radius: 0.75rem; padding: 1.5rem; background: #0f172a;">
                            <h4 class="font-semibold mb-4" style="color: #f1f5f9;">📱 Mobile Experience Settings</h4>
                            <p class="text-sm mb-4" style="color: #cbd5e1;">Configure how mobile users interact with your voice assistant</p>

                            <div class="grid grid-cols-1 gap-4">
                                <!-- Enable Phone Call UI -->
                                <div style="display: flex; align-items: start; gap: 0.75rem; padding: 1rem; background: #1e293b; border-radius: 0.5rem;">
                                    <input type="checkbox" name="mobile_call_ui_enabled" id="mobile_call_ui_enabled" value="1" {{ old('mobile_call_ui_enabled', $settings->mobile_call_ui_enabled ?? true) ? 'checked' : '' }} style="margin-top: 0.25rem; width: 1rem; height: 1rem;">
                                    <div style="flex: 1;">
                                        <label for="mobile_call_ui_enabled" style="display: block; font-weight: 500; color: #f1f5f9; margin-bottom: 0.25rem; cursor: pointer;">Enable phone call UI on mobile devices</label>
                                        <p style="font-size: 0.75rem; color: #9ca3af;">Show a call-like interface with big call button for mobile phones and tablets</p>
                                    </div>
                                </div>

                                <!-- Show Chat Fallback -->
                                <div style="display: flex; align-items: start; gap: 0.75rem; padding: 1rem; background: #1e293b; border-radius: 0.5rem;">
                                    <input type="checkbox" name="mobile_show_chat_fallback" id="mobile_show_chat_fallback" value="1" {{ old('mobile_show_chat_fallback', $settings->mobile_show_chat_fallback ?? true) ? 'checked' : '' }} style="margin-top: 0.25rem; width: 1rem; height: 1rem;">
                                    <div style="flex: 1;">
                                        <label for="mobile_show_chat_fallback" style="display: block; font-weight: 500; color: #f1f5f9; margin-bottom: 0.25rem; cursor: pointer;">Show chat fallback option</label>
                                        <p style="font-size: 0.75rem; color: #9ca3af;">Allow users to switch to text chat mode instead of voice call</p>
                                    </div>
                                </div>

                                <!-- Allow Typing During Call -->
                                <div style="display: flex; align-items: start; gap: 0.75rem; padding: 1rem; background: #1e293b; border-radius: 0.5rem;">
                                    <input type="checkbox" name="mobile_allow_typing_during_call" id="mobile_allow_typing_during_call" value="1" {{ old('mobile_allow_typing_during_call', $settings->mobile_allow_typing_during_call ?? true) ? 'checked' : '' }} style="margin-top: 0.25rem; width: 1rem; height: 1rem;">
                                    <div style="flex: 1;">
                                        <label for="mobile_allow_typing_during_call" style="display: block; font-weight: 500; color: #f1f5f9; margin-bottom: 0.25rem; cursor: pointer;">Allow typing during active call</label>
                                        <p style="font-size: 0.75rem; color: #9ca3af;">Enable text input while a voice call is in progress</p>
                                    </div>
                                </div>

                                <!-- Default Mobile Mode -->
                                <div style="padding: 1rem; background: #1e293b; border-radius: 0.5rem;">
                                    <label for="mobile_default_mode" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Default Mobile Mode</label>
                                    <select name="mobile_default_mode" id="mobile_default_mode" style="width: 100%; padding: 0.625rem 0.75rem; background: #0f172a; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                        <option value="call" {{ old('mobile_default_mode', $settings->mobile_default_mode ?? 'call') == 'call' ? 'selected' : '' }}>📞 Phone Call (Recommended)</option>
                                        <option value="chat" {{ old('mobile_default_mode', $settings->mobile_default_mode ?? 'call') == 'chat' ? 'selected' : '' }}>💬 Text Chat</option>
                                    </select>
                                    <p style="font-size: 0.75rem; color: #9ca3af; margin-top: 0.5rem;">Initial mode when mobile users open the chat page</p>
                                </div>

                                <!-- Auto-end Silence -->
                                <div style="padding: 1rem; background: #1e293b; border-radius: 0.5rem;">
                                    <label for="mobile_auto_end_silence_seconds" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Auto-end call after silence</label>
                                    <select name="mobile_auto_end_silence_seconds" id="mobile_auto_end_silence_seconds" style="width: 100%; padding: 0.625rem 0.75rem; background: #0f172a; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                        <option value="15" {{ old('mobile_auto_end_silence_seconds', $settings->mobile_auto_end_silence_seconds ?? 30) == 15 ? 'selected' : '' }}>15 seconds</option>
                                        <option value="30" {{ old('mobile_auto_end_silence_seconds', $settings->mobile_auto_end_silence_seconds ?? 30) == 30 ? 'selected' : '' }}>30 seconds</option>
                                        <option value="60" {{ old('mobile_auto_end_silence_seconds', $settings->mobile_auto_end_silence_seconds ?? 30) == 60 ? 'selected' : '' }}>60 seconds</option>
                                        <option value="0" {{ old('mobile_auto_end_silence_seconds', $settings->mobile_auto_end_silence_seconds ?? 30) == 0 ? 'selected' : '' }}>Never</option>
                                    </select>
                                    <p style="font-size: 0.75rem; color: #9ca3af; margin-top: 0.5rem;">Automatically end the call if no activity is detected</p>
                                </div>
                            </div>
                        </div>

                        <div style="display: flex; justify-content: flex-end;">
                            <button type="submit" class="btn" style="background: #3b82f6; color: white; padding: 0.75rem 2rem; border-radius: 0.5rem; font-weight: 500; border: none; cursor: pointer;">
                                Save Settings
                            </button>
                        </div>
                    </form>

                    <!-- Voice Configurations Section -->
                    <div style="margin-top: 3rem; padding-top: 2rem; border-top: 1px solid #475569;">
                        <h3 class="text-lg font-semibold mb-4" style="color: #f1f5f9;">🎤 Voice Configurations</h3>
                        <p class="text-sm mb-6" style="color: #cbd5e1;">Customize voice settings for different languages. Add multiple voices and test them before saving.</p>

                        <!-- Existing Voice Configurations -->
                        @if($voiceConfigurations->count() > 0)
                        <div style="margin-bottom: 2rem;">
                            <h4 class="font-semibold mb-3" style="color: #f1f5f9;">Your Voice Configurations</h4>
                            <div class="space-y-3">
                                @foreach($voiceConfigurations as $config)
                                <div style="background: #1e293b; border: 1px solid #475569; border-radius: 0.5rem; padding: 1rem;">
                                    <div id="view-{{ $config->id }}" style="display: flex; justify-content: space-between; align-items: start;">
                                        <div style="flex: 1;">
                                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                                <span style="font-weight: 600; color: #f1f5f9;">{{ $config->name }}</span>
                                                @if($config->is_default)
                                                <span style="background: #10b981; color: white; padding: 0.125rem 0.5rem; border-radius: 0.25rem; font-size: 0.75rem;">DEFAULT</span>
                                                @endif
                                            </div>
                                            <div style="font-size: 0.875rem; color: #cbd5e1; margin-bottom: 0.25rem;">
                                                <strong>Language:</strong> {{ $config->language_code }} | 
                                                <strong>Gender:</strong> {{ ucfirst($config->gender) }} | 
                                                <strong>Speed:</strong> {{ $config->speaking_rate }}x
                                            </div>
                                            <div style="font-size: 0.75rem; color: #9ca3af;">
                                                Voice: {{ $config->voice_name }}
                                            </div>
                                        </div>
                                        <div style="display: flex; gap: 0.5rem;">
                                            <button onclick="testVoice('{{ $config->id }}', '{{ $config->language_code }}', '{{ $config->voice_name }}', '{{ $config->gender }}', {{ $config->speaking_rate }}, {{ $config->pitch }})" style="background: #6366f1; color: white; padding: 0.5rem 1rem; border-radius: 0.375rem; font-size: 0.875rem; border: none; cursor: pointer;">
                                                🔊 Test
                                            </button>
                                            <button onclick="showEditForm({{ $config->id }})" style="background: #f59e0b; color: white; padding: 0.5rem 1rem; border-radius: 0.375rem; font-size: 0.875rem; border: none; cursor: pointer;">
                                                ✏️ Edit
                                            </button>
                                            @if(!$config->is_default)
                                            <form action="{{ route('voice-configurations.set-default', $config) }}" method="POST" style="display: inline;">
                                                @csrf
                                                <button type="submit" style="background: #10b981; color: white; padding: 0.5rem 1rem; border-radius: 0.375rem; font-size: 0.875rem; border: none; cursor: pointer;">
                                                    Set Default
                                                </button>
                                            </form>
                                            @endif
                                            <form action="{{ route('voice-configurations.destroy', $config) }}" method="POST" style="display: inline;" onsubmit="return confirm('Delete this voice configuration?');">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" style="background: #ef4444; color: white; padding: 0.5rem 1rem; border-radius: 0.375rem; font-size: 0.875rem; border: none; cursor: pointer;">
                                                    Delete
                                                </button>
                                            </form>
                                        </div>
                                    </div>

                                    <div id="edit-{{ $config->id }}" style="display: none;">
                                        <form action="{{ route('voice-configurations.update', $config) }}" method="POST" class="space-y-4">
                                            @csrf
                                            @method('PUT')
                                            
                                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                <div>
                                                    <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Configuration Name *</label>
                                                    <input type="text" name="name" value="{{ $config->name }}" required style="width: 100%; padding: 0.625rem 0.75rem; background: #0f172a; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                                </div>

                                                <div>
                                                    <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Language *</label>
                                                    <select name="language_code" id="edit_language_{{ $config->id }}" required onchange="updateEditVoiceOptions({{ $config->id }})" style="width: 100%; padding: 0.625rem 0.75rem; background: #0f172a; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                                        <option value="en-IN" {{ $config->language_code == 'en-IN' ? 'selected' : '' }}>🇮🇳 English (India)</option>
                                                        <option value="ta-IN" {{ $config->language_code == 'ta-IN' ? 'selected' : '' }}>🇮🇳 Tamil (India)</option>
                                                        <option value="hi-IN" {{ $config->language_code == 'hi-IN' ? 'selected' : '' }}>🇮🇳 Hindi (India)</option>
                                                        <option value="cmn-CN" {{ $config->language_code == 'cmn-CN' ? 'selected' : '' }}>🇨🇳 Mandarin Chinese</option>
                                                        <option value="ms-MY" {{ $config->language_code == 'ms-MY' ? 'selected' : '' }}>🇲🇾 Malay (Malaysia)</option>
                                                        <option value="id-ID" {{ $config->language_code == 'id-ID' ? 'selected' : '' }}>🇮🇩 Indonesian</option>
                                                        <option value="th-TH" {{ $config->language_code == 'th-TH' ? 'selected' : '' }}>🇹🇭 Thai (Thailand)</option>
                                                    </select>
                                                </div>

                                                <div>
                                                    <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Gender *</label>
                                                    <select name="gender" id="edit_gender_{{ $config->id }}" required onchange="updateEditVoiceOptions({{ $config->id }})" style="width: 100%; padding: 0.625rem 0.75rem; background: #0f172a; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                                        <option value="female" {{ $config->gender == 'female' ? 'selected' : '' }}>Female</option>
                                                        <option value="male" {{ $config->gender == 'male' ? 'selected' : '' }}>Male</option>
                                                    </select>
                                                </div>

                                                <div>
                                                    <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Voice Type *</label>
                                                    <select name="voice_name" id="edit_voice_{{ $config->id }}" required style="width: 100%; padding: 0.625rem 0.75rem; background: #0f172a; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                                        <option value="{{ $config->voice_name }}" selected>{{ $config->voice_name }}</option>
                                                    </select>
                                                </div>

                                                <div>
                                                    <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">
                                                        Speaking Speed: <span id="edit_speed_display_{{ $config->id }}">{{ $config->speaking_rate }}</span>x
                                                    </label>
                                                    <input type="range" name="speaking_rate" id="edit_speaking_rate_{{ $config->id }}" min="0.5" max="2.0" step="0.1" value="{{ $config->speaking_rate }}" oninput="document.getElementById('edit_speed_display_{{ $config->id }}').textContent = this.value" style="width: 100%;">
                                                </div>
                                            </div>

                                            <input type="hidden" name="pitch" value="{{ $config->pitch }}">

                                            <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #475569;">
                                                <button type="button" onclick="hideEditForm({{ $config->id }})" style="background: #64748b; color: white; padding: 0.75rem 1.5rem; border-radius: 0.5rem; font-weight: 500; border: none; cursor: pointer;">
                                                    Cancel
                                                </button>
                                                <button type="submit" style="background: #10b981; color: white; padding: 0.75rem 1.5rem; border-radius: 0.5rem; font-weight: 500; border: none; cursor: pointer;">
                                                    Update Configuration
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                        @endif

                        <!-- Add New Voice Configuration Form -->
                        <div style="border: 1px solid #475569; border-radius: 0.75rem; padding: 1.5rem; background: #0f172a;">
                            <h4 class="font-semibold mb-4" style="color: #f1f5f9;">➕ Add New Voice Configuration</h4>
                            
                            <form action="{{ route('voice-configurations.store') }}" method="POST" id="voiceConfigForm" class="space-y-4">
                                @csrf
                                
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label for="name" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Configuration Name *</label>
                                        <input type="text" name="name" id="name" placeholder="e.g., Tamil Fast Voice" required style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                    </div>

                                    <div>
                                        <label for="language_code" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Language *</label>
                                        <select name="language_code" id="language_code" required onchange="updateVoiceOptions()" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                            <option value="">Select Language</option>
                                            <option value="en-IN">🇮🇳 English (India)</option>
                                            <option value="ta-IN">🇮🇳 Tamil (India)</option>
                                            <option value="hi-IN">🇮🇳 Hindi (India)</option>
                                            <option value="cmn-CN">🇨🇳 Mandarin Chinese</option>
                                            <option value="ms-MY">🇲🇾 Malay (Malaysia)</option>
                                            <option value="id-ID">🇮🇩 Indonesian</option>
                                            <option value="th-TH">🇹🇭 Thai (Thailand)</option>
                                        </select>
                                    </div>

                                    <div>
                                        <label for="gender" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Gender *</label>
                                        <select name="gender" id="gender" required onchange="updateVoiceOptions()" style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                            <option value="">Select Gender</option>
                                            <option value="female">Female</option>
                                            <option value="male">Male</option>
                                        </select>
                                    </div>

                                    <div>
                                        <label for="voice_name" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">Voice Type *</label>
                                        <select name="voice_name" id="voice_name" required style="width: 100%; padding: 0.625rem 0.75rem; background: #1e293b; border: 1px solid #475569; border-radius: 0.375rem; color: #f1f5f9; font-size: 0.875rem;">
                                            <option value="">Select voice type first</option>
                                        </select>
                                    </div>

                                    <div>
                                        <label for="speaking_rate" style="display: block; font-size: 0.875rem; font-weight: 500; color: #e5e7eb; margin-bottom: 0.5rem;">
                                            Speaking Speed: <span id="speed_display">1.0</span>x
                                        </label>
                                        <input type="range" name="speaking_rate" id="speaking_rate" min="0.5" max="2.0" step="0.1" value="1.3" oninput="document.getElementById('speed_display').textContent = this.value" style="width: 100%;">
                                        <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: #9ca3af; margin-top: 0.25rem;">
                                            <span>0.5x (Slow)</span>
                                            <span>2.0x (Fast)</span>
                                        </div>
                                    </div>
                                </div>

                                <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 1.5rem;">
                                    <button type="button" onclick="testCurrentVoice()" style="background: #6366f1; color: white; padding: 0.75rem 1.5rem; border-radius: 0.5rem; font-weight: 500; border: none; cursor: pointer;">
                                        🔊 Test Voice
                                    </button>
                                    <button type="submit" style="background: #10b981; color: white; padding: 0.75rem 1.5rem; border-radius: 0.5rem; font-weight: 500; border: none; cursor: pointer;">
                                        Save Configuration
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <script>
                        const availableVoices = @json($availableVoices);

                        function updateVoiceOptions() {
                            const lang = document.getElementById('language_code').value;
                            const gender = document.getElementById('gender').value;
                            const voiceSelect = document.getElementById('voice_name');

                            console.log('Language:', lang, 'Gender:', gender);

                            voiceSelect.innerHTML = '<option value="">Select Voice Type</option>';

                            if (lang && gender && availableVoices[lang] && availableVoices[lang][gender]) {
                                console.log('Available voices for', lang, gender, ':', availableVoices[lang][gender]);
                                Object.entries(availableVoices[lang][gender]).forEach(([voiceCode, voiceName]) => {
                                    const option = document.createElement('option');
                                    option.value = voiceCode;
                                    option.textContent = voiceName;
                                    voiceSelect.appendChild(option);
                                });
                            } else {
                                console.log('No voices found for', lang, gender);
                            }
                        }

                        function testCurrentVoice() {
                            const lang = document.getElementById('language_code').value;
                            const voiceName = document.getElementById('voice_name').value;
                            const gender = document.getElementById('gender').value;
                            const speakingRate = document.getElementById('speaking_rate').value;

                            if (!lang || !voiceName || !gender) {
                                alert('Please select language, gender, and voice type first');
                                return;
                            }

                            testVoiceAPI(lang, voiceName, gender, speakingRate, 0.0);
                        }

                        function testVoice(id, lang, voiceName, gender, speakingRate, pitch) {
                            testVoiceAPI(lang, voiceName, gender, speakingRate, pitch);
                        }

                        function testVoiceAPI(lang, voiceName, gender, speakingRate, pitch) {
                            const testButton = event.target;
                            const originalText = testButton.innerHTML;
                            testButton.disabled = true;
                            testButton.innerHTML = '⏳ Generating...';

                            fetch('{{ route("voice-configurations.test") }}', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                                },
                                body: JSON.stringify({
                                    language_code: lang,
                                    voice_name: voiceName,
                                    gender: gender,
                                    speaking_rate: parseFloat(speakingRate),
                                    pitch: parseFloat(pitch)
                                })
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    const audio = new Audio(data.audio_url);
                                    audio.play();
                                    setTimeout(() => {
                                        testButton.disabled = false;
                                        testButton.innerHTML = originalText;
                                    }, 1000);
                                } else {
                                    alert('Error: ' + data.message);
                                    testButton.disabled = false;
                                    testButton.innerHTML = originalText;
                                }
                            })
                            .catch(error => {
                                alert('Error testing voice: ' + error);
                                testButton.disabled = false;
                                testButton.innerHTML = originalText;
                            });
                        }

                        function showEditForm(configId) {
                            document.getElementById('view-' + configId).style.display = 'none';
                            document.getElementById('edit-' + configId).style.display = 'block';
                            updateEditVoiceOptions(configId);
                        }

                        function hideEditForm(configId) {
                            document.getElementById('view-' + configId).style.display = 'flex';
                            document.getElementById('edit-' + configId).style.display = 'none';
                        }

                        function updateEditVoiceOptions(configId) {
                            const lang = document.getElementById('edit_language_' + configId).value;
                            const gender = document.getElementById('edit_gender_' + configId).value;
                            const voiceSelect = document.getElementById('edit_voice_' + configId);
                            const currentVoice = voiceSelect.value;

                            voiceSelect.innerHTML = '';

                            if (lang && gender && availableVoices[lang] && availableVoices[lang][gender]) {
                                Object.entries(availableVoices[lang][gender]).forEach(([voiceCode, voiceName]) => {
                                    const option = document.createElement('option');
                                    option.value = voiceCode;
                                    option.textContent = voiceName;
                                    if (voiceCode === currentVoice) {
                                        option.selected = true;
                                    }
                                    voiceSelect.appendChild(option);
                                });
                            }
                        }

                        document.getElementById('speaking_rate').value = 1.3;
                        document.getElementById('speed_display').textContent = '1.3';
                    </script>

                    <!-- Webhook URLs -->
                    <div style="margin-top: 3rem; padding-top: 2rem; border-top: 1px solid #475569;">
                        <h4 class="font-semibold mb-4" style="color: #f1f5f9;">🔗 Webhook URLs</h4>
                        <p class="text-sm mb-4" style="color: #cbd5e1;">Configure these URLs in your Twilio phone number settings:</p>
                        
                        <div class="space-y-3">
                            <div style="background: #1e293b; padding: 1rem; border-radius: 0.5rem; border: 1px solid #475569;">
                                <div style="font-size: 0.75rem; color: #9ca3af; margin-bottom: 0.25rem;">Voice Webhook:</div>
                                <code style="color: #60a5fa; font-size: 0.875rem;">{{ url('/webhooks/twilio/voice') }}</code>
                            </div>
                            <div style="background: #1e293b; padding: 1rem; border-radius: 0.5rem; border: 1px solid #475569;">
                                <div style="font-size: 0.75rem; color: #9ca3af; margin-bottom: 0.25rem;">SMS Webhook:</div>
                                <code style="color: #60a5fa; font-size: 0.875rem;">{{ url('/webhooks/twilio/sms') }}</code>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
