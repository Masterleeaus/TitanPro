(() => {
  const qs = (id) => document.getElementById(id);

  const startBtn = qs('tg_start');
  const stopBtn = qs('tg_stop');
  const transcriptEl = qs('tg_transcript');
  const statusEl = qs('tg_status');

  const previewBtn = qs('tg_preview');
  const previewBox = qs('tg_preview_box');
  const previewJson = qs('tg_preview_json');
  const confirmBtn = qs('tg_confirm');
  const cancelBtn = qs('tg_cancel');

  const resultBox = qs('tg_result_box');
  const resultJson = qs('tg_result_json');

  const recordTypeEl = qs('tg_record_type');
  const recordIdEl = qs('tg_record_id');

  const speakToggle = qs('tg_speak_toggle');

  let recognition = null;
  let lastPreviewPayload = null;

  // Browser STT (MVP)
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = document.documentElement.lang || 'en-AU';

    recognition.onresult = (event) => {
      let finalText = '';
      let interim = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const txt = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalText += txt + ' ';
        else interim += txt;
      }
      if (finalText.trim()) transcriptEl.value = (transcriptEl.value + ' ' + finalText).trim();
      statusEl.textContent = interim ? ('Listening… ' + interim) : 'Listening…';
    };

    recognition.onerror = (e) => statusEl.textContent = 'Voice error: ' + e.error;
    recognition.onend = () => {
      startBtn.disabled = false;
      stopBtn.disabled = true;
      statusEl.textContent = 'Stopped.';
    };
  } else {
    statusEl.textContent = 'Speech recognition not supported in this browser. You can still type.';
  }

  function speak(text) {
    try {
      if (!speakToggle || !speakToggle.checked) return;
      if (!('speechSynthesis' in window)) return;
      const u = new SpeechSynthesisUtterance(text);
      u.lang = document.documentElement.lang || 'en-AU';
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u);
    } catch (_) {}
  }

  startBtn && (startBtn.onclick = () => {
    if (!recognition) return;
    startBtn.disabled = true;
    stopBtn.disabled = false;
    statusEl.textContent = 'Listening…';
    recognition.start();
  });

  stopBtn && (stopBtn.onclick = () => {
    if (!recognition) return;
    recognition.stop();
  });

  previewBtn && (previewBtn.onclick = async () => {
    resultBox.classList.add('d-none');
    previewBox.classList.add('d-none');

    const transcript = transcriptEl.value.trim();
    if (!transcript) return alert('Please speak or type a command.');

    const body = {
      transcript,
      record_type: recordTypeEl.value || null,
      record_id: recordIdEl.value ? parseInt(recordIdEl.value, 10) : null,
      preview_only: true
    };

    const res = await fetch(window.TITANGO_EXECUTE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': window.TITANGO_CSRF
      },
      body: JSON.stringify(body)
    });

    const data = await res.json();
    if (!res.ok) return alert(data.message || 'Preview failed.');

    lastPreviewPayload = data.payload;
    previewJson.textContent = JSON.stringify(data.payload, null, 2);
    previewBox.classList.remove('d-none');
    speak('Ready to run ' + (data.payload.action || 'action') + '. Please confirm.');
  });

  cancelBtn && (cancelBtn.onclick = () => {
    lastPreviewPayload = null;
    previewBox.classList.add('d-none');
  });

  confirmBtn && (confirmBtn.onclick = async () => {
    if (!lastPreviewPayload) return;

    const res = await fetch(window.TITANGO_EXECUTE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': window.TITANGO_CSRF
      },
      body: JSON.stringify({...lastPreviewPayload, confirm: true})
    });

    const data = await res.json();
    resultJson.textContent = JSON.stringify(data, null, 2);
    resultBox.classList.remove('d-none');
    previewBox.classList.add('d-none');

    if (data?.ok) {
      speak('Done.');
    } else {
      speak('Action failed.');
    }
  });


  // ----------------------------
  // Fallback audio recording/upload (server STT mode)
  // ----------------------------
  const recStartBtn = qs('tg_record_start');
  const recStopBtn = qs('tg_record_stop');
  const audioFileEl = qs('tg_audio_file');

  let mediaRecorder = null;
  let recordedChunks = [];

  const uploadUrl = document.querySelector('meta[name="titango-upload-url"]')?.getAttribute('content');
  const sttMode = document.querySelector('meta[name="titango-stt-mode"]')?.getAttribute('content') || 'browser';

  async function uploadAudioBlob(blob) {
    if (!uploadUrl) {
      alert('Upload URL not configured.');
      return;
    }
    const fd = new FormData();
    fd.append('audio', blob, 'titango-recording.webm');
    fd.append('record_type', recordTypeEl.value || '');
    fd.append('record_id', recordIdEl.value || '');

    statusEl.textContent = 'Uploading audio for transcription…';

    const res = await fetch(uploadUrl, {
      method: 'POST',
      headers: { 'X-CSRF-TOKEN': csrfToken },
      body: fd
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      statusEl.textContent = 'Upload failed.';
      alert(data.message || 'Upload failed.');
      return;
    }

    // Try to discover transcript from TitanZero response
    const possibleTranscript =
      data?.result?.result?.transcript ||
      data?.result?.transcript ||
      data?.result?.text ||
      data?.payload?.input?.transcript;

    if (possibleTranscript) {
      transcriptEl.value = possibleTranscript;
      statusEl.textContent = 'Transcribed.';
    } else {
      statusEl.textContent = 'Uploaded. If Titan Zero returned a transcript, it will appear here.';
    }
  }

  async function startRecording() {
    if (!navigator.mediaDevices?.getUserMedia) {
      alert('Recording not supported in this browser.');
      return;
    }
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    recordedChunks = [];
    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.ondataavailable = (e) => { if (e.data && e.data.size > 0) recordedChunks.push(e.data); };
    mediaRecorder.onstop = async () => {
      const blob = new Blob(recordedChunks, { type: recordedChunks[0]?.type || 'audio/webm' });
      // populate file input for transparency
      try {
        const file = new File([blob], 'titango-recording.webm', { type: blob.type });
        const dt = new DataTransfer();
        dt.items.add(file);
        audioFileEl.files = dt.files;
      } catch (e) {}
      await uploadAudioBlob(blob);
      // stop tracks
      stream.getTracks().forEach(t => t.stop());
    };
    mediaRecorder.start();
    recStartBtn.disabled = true;
    recStopBtn.disabled = false;
    statusEl.textContent = 'Recording…';
  }

  function stopRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
    }
    recStartBtn.disabled = false;
    recStopBtn.disabled = true;
  }

  if (recStartBtn && recStopBtn) {
    recStartBtn.addEventListener('click', async () => {
      await startRecording();
    });
    recStopBtn.addEventListener('click', stopRecording);
  }

  if (audioFileEl) {
    audioFileEl.addEventListener('change', async () => {
      const file = audioFileEl.files?.[0];
      if (!file) return;
      await uploadAudioBlob(file);
    });
  }

  // Hint users if browser SR not supported or server mode enforced
  if (!SpeechRecognition || sttMode === 'server') {
    statusEl.textContent = sttMode === 'server'
      ? 'Server STT mode enabled — use Record/Upload.'
      : 'Speech recognition not supported — use Record/Upload.';
    if (startBtn) startBtn.disabled = true;
    if (stopBtn) stopBtn.disabled = true;
  }

})();
