<?php

namespace App\Extensions\TitanRewind\System\Services;

use Illuminate\Support\Facades\DB;

class RewindImpactAnalyzer
{
    public function analyze(array $context): array
    {
        $links = collect();
        if (!empty($context['process_id']) && DB::getSchemaBuilder()->hasTable('tz_rewind_links')) {
            $links = DB::table('tz_rewind_links')->where('company_id', $context['company_id'])->where('parent_process_id', $context['process_id'])->get();
        }

        $downstream = $links->map(fn ($row) => [
            'child_process_id' => $row->child_process_id,'child_entity_type' => $row->child_entity_type,'child_entity_id' => $row->child_entity_id,
            'relationship_type' => $row->relationship_type,'can_reuse' => (bool) $row->can_reuse,'must_reissue' => (bool) $row->must_reissue,
        ])->values()->all();

        return [
            'original_process_id' => $context['process_id'] ?? null,'entity_type' => $context['entity_type'] ?? null,'entity_id' => $context['entity_id'] ?? null,
            'affected_processes' => array_values(array_filter(array_column($downstream, 'child_process_id'))),'downstream' => $downstream,
            'counts' => ['downstream' => count($downstream),'must_reissue' => count(array_filter($downstream, fn ($item) => $item['must_reissue']))],
        ];
    }
}
