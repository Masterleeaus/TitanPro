<?php

namespace App\Extensions\TitanRewind\System\Services;

use Illuminate\Support\Facades\DB;
use App\Extensions\TitanRewind\System\Models\RewindCase;
use App\Extensions\TitanRewind\System\Models\RewindConflict;

class RewindEngine
{
    public function __construct(
        private readonly RewindCaseService $cases,
        private readonly RewindAuditService $audit,
        private readonly RewindImpactAnalyzer $impactAnalyzer,
    ) {}

    public function initiate(array $payload): RewindCase
    {
        return DB::transaction(function () use ($payload) {
            $impact = $this->impactAnalyzer->analyze($payload);
            $case = $this->cases->openCase([
                'company_id' => $payload['company_id'],'team_id' => $payload['team_id'] ?? null,'user_id' => $payload['user_id'] ?? null,
                'title' => $payload['title'] ?? ('Rewind ' . ($payload['entity_type'] ?? 'process')),'status' => 'rewinding','severity' => $payload['severity'] ?? 'high',
                'source_type' => $payload['source_type'] ?? 'manual','source_id' => $payload['source_id'] ?? null,'process_id' => $payload['process_id'] ?? null,
                'entity_type' => $payload['entity_type'] ?? null,'entity_id' => $payload['entity_id'] ?? null,
                'meta_json' => ['reason' => $payload['reason'] ?? null,'impact' => $impact],
            ]);

            foreach ($impact['downstream'] as $item) {
                DB::table('tz_rewind_links')->insert([
                    'company_id' => $payload['company_id'],'team_id' => $payload['team_id'] ?? null,'user_id' => $payload['user_id'] ?? null,'case_id' => $case->id,
                    'parent_process_id' => $payload['process_id'] ?? null,'child_process_id' => $item['child_process_id'],'parent_entity_type' => $payload['entity_type'] ?? null,
                    'parent_entity_id' => $payload['entity_id'] ?? null,'child_entity_type' => $item['child_entity_type'],'child_entity_id' => $item['child_entity_id'],
                    'relationship_type' => $item['relationship_type'] ?? 'cascade','can_reuse' => $item['can_reuse'],'must_reissue' => $item['must_reissue'],
                    'meta_json' => json_encode($item),'created_at' => now(),'updated_at' => now(),
                ]);
            }

            if (($payload['entity_type'] ?? null) === 'payments') {
                RewindConflict::query()->create([
                    'company_id' => $payload['company_id'],'team_id' => $payload['team_id'] ?? null,'user_id' => $payload['user_id'] ?? null,'case_id' => $case->id,
                    'process_id' => $payload['process_id'] ?? null,'entity_type' => 'payments','entity_id' => $payload['entity_id'] ?? null,
                    'conflict_type' => 'external-transaction','severity' => 'critical','status' => 'open',
                    'message' => 'Payment rewind requires refund/reissue review.','details_json' => ['resolution' => 'manual review and refund workflow'],
                    'resolution_hint' => 'Initiate refund, then create corrected payment process.',
                ]);
            }

            $this->audit->appendEvent([
                'company_id' => $payload['company_id'],'team_id' => $payload['team_id'] ?? null,'user_id' => $payload['user_id'] ?? null,'case_id' => $case->id,
                'event_type' => 'rewind_initiated','entity_type' => $payload['entity_type'] ?? null,'entity_id' => $payload['entity_id'] ?? null,
                'actor_type' => $payload['actor_type'] ?? 'user','actor_id' => $payload['actor_id'] ?? $payload['user_id'] ?? null,
                'payload_json' => ['reason' => $payload['reason'] ?? null,'impact' => $impact],'idempotency_key' => 'rewind_initiated:' . ($payload['process_id'] ?? $case->id),
            ]);

            return $case;
        });
    }
}
