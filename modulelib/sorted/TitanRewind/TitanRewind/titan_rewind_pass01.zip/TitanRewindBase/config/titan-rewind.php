<?php

return [
    'scheduler_enabled' => true,
    'process_limit' => 50,
    'allowlisted_fix_types' => ['metadata_update'],
    'allowlisted_target_tables' => ['titan_rewind_cases', 'tz_rewind_links', 'tz_rewind_conflicts'],
    'rewind_states' => ['initiated','signal-queued','awaiting-validation','validation-approved','validation-rejected','awaiting-processing','processing','processed','rewinding','awaiting-correction','rolled-back','conflict-hold','archived'],
    'domain_rules' => [
        'quotes' => ['children' => ['service_jobs'], 'default_reuse' => true],
        'service_jobs' => ['children' => ['checklists', 'invoices', 'service_issues'], 'default_reuse' => true],
        'checklists' => ['children' => [], 'default_reuse' => true],
        'invoices' => ['children' => ['payments'], 'default_reuse' => true],
        'payments' => ['children' => [], 'default_reuse' => false, 'always_conflict' => 'external-transaction'],
        'sites' => ['children' => ['service_jobs'], 'default_reuse' => true],
        'customer_details' => ['children' => ['sites', 'quotes'], 'default_reuse' => true],
        'service_issues' => ['children' => [], 'default_reuse' => true],
    ],
];
