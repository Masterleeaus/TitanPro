<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('tz_rewind_conflicts')) return;
        Schema::table('tz_rewind_conflicts', function (Blueprint $table) {
            if (!Schema::hasColumn('tz_rewind_conflicts', 'resolved_at')) {
                $table->timestamp('resolved_at')->nullable()->after('resolution_hint');
            }
            if (!Schema::hasColumn('tz_rewind_conflicts', 'resolved_by_type')) {
                $table->string('resolved_by_type', 20)->nullable()->after('resolved_at');
            }
            if (!Schema::hasColumn('tz_rewind_conflicts', 'resolved_by_id')) {
                $table->unsignedBigInteger('resolved_by_id')->nullable()->after('resolved_by_type');
            }
        });
    }
    public function down(): void {}
};
