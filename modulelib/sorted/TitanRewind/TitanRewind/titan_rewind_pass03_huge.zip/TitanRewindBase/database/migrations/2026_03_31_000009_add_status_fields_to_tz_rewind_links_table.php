<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('tz_rewind_links')) return;
        Schema::table('tz_rewind_links', function (Blueprint $table) {
            if (!Schema::hasColumn('tz_rewind_links', 'depth')) {
                $table->unsignedInteger('depth')->default(1)->after('relationship_type');
            }
            if (!Schema::hasColumn('tz_rewind_links', 'status')) {
                $table->string('status', 30)->default('held')->after('must_reissue');
            }
            if (!Schema::hasColumn('tz_rewind_links', 'action_required')) {
                $table->string('action_required', 30)->nullable()->after('status');
            }
            if (!Schema::hasColumn('tz_rewind_links', 'held_reason')) {
                $table->text('held_reason')->nullable()->after('action_required');
            }
        });
    }
    public function down(): void {}
};
