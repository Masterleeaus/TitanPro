<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('titan_rewind_cases')) return;
        Schema::table('titan_rewind_cases', function (Blueprint $table) {
            if (!Schema::hasColumn('titan_rewind_cases', 'correction_process_id')) {
                $table->string('correction_process_id', 80)->nullable()->after('process_id');
            }
            if (!Schema::hasColumn('titan_rewind_cases', 'replacement_process_id')) {
                $table->string('replacement_process_id', 80)->nullable()->after('correction_process_id');
            }
            if (!Schema::hasColumn('titan_rewind_cases', 'rollback_completed_at')) {
                $table->timestamp('rollback_completed_at')->nullable()->after('resolved_at');
            }
        });
    }
    public function down(): void {}
};
