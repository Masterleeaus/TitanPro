# Titan Rewind Pass 01

## Scope
- Fixed TitanPay namespace drift to TitanRewind.
- Normalized runtime tables from boxed_automation_* to titan_rewind_*.
- Added process-aware rewind initiation service.
- Added WorkCore-aware domain rule map for quotes/service_jobs/checklists/invoices/payments.
- Added rewind links and conflict persistence tables.

## New foundations
- `RewindEngine` initiates rewind cases from process/entity context.
- `RewindImpactAnalyzer` reads `tz_rewind_links` and computes downstream impact.
- `RewindConflict` persists payment/external rollback conflicts.
- `RewindLink` stores cascade edges for downstream reuse vs reissue.

## Next pass
- correction submission as new process
- rollback processor
- conflict detector for deep cascades and entity modified since processed
- timeline/printable history view
