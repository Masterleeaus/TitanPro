# TitanRewind Upgrade Plan v1.0
**Alignment: TitanRewindBase (v0.2.0) → REWIND ENGINE Spec**

**Date:** March 31, 2026  
**Status:** Comprehensive Gap Analysis & Implementation Roadmap  
**Scope:** Full process lifecycle management with state machine, cascade handling, conflict detection, and audit trails

---

## EXECUTIVE SUMMARY

TitanRewindBase is currently **MarketingBot-derived scaffold** with basic case/event/fix logging. The REWIND ENGINE specification requires **enterprise-grade process state management** with:

- Full process lifecycle (initiated → signal-queued → awaiting-validation → validation-approved → awaiting-processing → processing → processed → rewinding → rolled-back)
- Downstream cascade detection and intelligent handling
- Conflict detection for external transactions and deep cascades
- Complete immutable audit trails with state history
- Correction submission and rollback workflows
- Multi-level notification system

**Gap:** Current implementation has ~15% of required functionality  
**Effort Estimate:** 3–4 weeks full-time development  
**Priority:** CRITICAL — Rewind is core TitanZero differentiator

---

## PART 1: CURRENT STATE ANALYSIS

### Existing Strengths ✓

1. **Extension structure** — Proper Laravel extension scaffolding (ServiceProvider, config, migrations)
2. **Basic case model** — RewindCase, RewindEvent, RewindFix, RewindAction (four core tables)
3. **Service layer pattern** — RewindCaseService, RewindFixService, RewindAuditService
4. **Parsers implemented** — Excel, PDF, Text, Link (for training data ingestion)
5. **Value objects** — Message, Embedding, EmbeddingMap (for embeddings support)
6. **Database migrations** — Idempotent, non-destructive pattern

### Critical Gaps ✗

#### 1. **Missing Process State Lifecycle**
- Current: Only "open" / "resolved" status on RewindCase
- Required: 13 distinct states (initiated, signal-queued, awaiting-validation, validation-approved, validation-rejected, awaiting-processing, processing, processed, rewinding, awaiting-correction, rolled-back, conflict-hold, archived)
- No state machine transitions or validation
- No state history tracking

#### 2. **No Process Model (Core Foundation)**
- Current: RewindCase, RewindEvent, RewindFix are case/issue oriented
- Required: `Process` model representing ANY business operation (bookings, invoices, payments, jobs, etc.)
- Process must track:
  - process_id, entity_type, entity_id, domain, initiated_by, current_state
  - state_history (immutable log), context, processing metadata
  - rewind_info, correction_process_id, parent_process_id
  - downstream dependencies

#### 3. **No Cascade Detection / Impact Analysis**
- Current: No downstream process tracking
- Required: `analyzeRewindImpact()` to find all affected processes
- Must identify affected users, created entities, deep cascades (grandchild processes)

#### 4. **No Correction Submission Workflow**
- Current: RewindFix is not a full process; no re-validation loop
- Required:
  - Submit correction → creates NEW process with corrected_data
  - Correction flows through validation/approval again
  - Link original → correction
  - Listen for correction approval, then trigger rollback

#### 5. **No Intelligent Cascade Handling**
- Current: No logic for downstream process recovery
- Required:
  - `canReuseDownstreamProcess()` — update with corrected parent data vs reissue
  - `updateDownstreamData()` — intelligent field merging
  - `markDownstreamForReissue()` — when reuse isn't possible

#### 6. **No Conflict Detection**
- Current: None
- Required:
  - Detect entity modifications since original process
  - Detect deep cascades (grandchild processes)
  - Detect external transactions (Stripe charges, payment gateways)
  - Escalate critical conflicts to manual review

#### 7. **No Rollback Processor**
- Current: No class implementing rollback logic
- Required: `RollbackProcessor` that:
  - Marks original as rolled-back
  - Activates correction as processed (now active)
  - Archives original entity (non-destructive)
  - Handles cascade by type (reusable vs reissue)
  - Initiates external refunds (Stripe)
  - Notifies affected users

#### 8. **No Queue/Async Processing**
- Current: ProcessRewindQueue exists but empty
- Required:
  - `ProcessRewindQueue` job for async rewind initiation
  - Background processing for cascade updates
  - External service calls (Stripe refunds) non-blocking

#### 9. **No Complete Audit Trail**
- Current: RewindAuditService stub only
- Required: `RewindAuditTrail` that records:
  - Original process metadata
  - All rewind history (corrections submitted, approved, reasons)
  - Data field diffs
  - Downstream affected list with status
  - Complete timeline with timestamps

#### 10. **No Notification System**
- Current: None
- Required:
  - `notifyRewindInitiated()` — inform affected users
  - `notifyRollbackComplete()` — cascade completion
  - Admin escalation for critical conflicts

#### 11. **Database Schema Misalignment**
- Current tables:
  - boxed_automation_cases (case-oriented)
  - boxed_automation_events (events log)
  - boxed_automation_fixes (fixes)
  - boxed_automation_actions (actions)
- Required NEW tables:
  - `tz_processes` (core process record)
  - `tz_process_state_history` (immutable state log)
  - `tz_process_dependencies` (tracks parent→child relationships)
  - `tz_rewind_conflicts` (detected conflicts during rewind)
  - `tz_rewind_audit_trail` (complete rewind history)
- Optional RENAME existing:
  - boxed_automation_cases → tz_rewind_cases (for error detection)
  - boxed_automation_events → tz_rewind_events

#### 12. **No Controllers for Rewind Operations**
- Current: TitanRewindCaseController exists but minimal
- Required:
  - POST /rewind/{process_id} — initiate rewind
  - POST /rewind/{process_id}/correction — submit correction
  - GET /rewind/{process_id}/impact — analyze impact
  - GET /rewind/{process_id}/conflicts — show detected conflicts
  - POST /rewind/{process_id}/resolve-conflict — manual conflict resolution
  - GET /rewind/{process_id}/audit-trail — full history

---

## PART 2: COMPONENT-BY-COMPONENT UPGRADE ROADMAP

### PHASE 1: Foundation (Weeks 1–1.5)

#### 1.1 New Models & Database Schema

**New Migrations (Create in this order):**

```php
// M1: Core processes table
2026_03_31_000001_create_tz_processes_table.php
- Columns: id, process_id (uuid), entity_type, entity_id, domain, initiated_by
  current_state, state_at_timestamp, context (json), processing (json)
  rewind_info (json), correction_process_id, parent_process_id
  processed_entity_id, originating_node, created_at, updated_at
- Indexes: (process_id), (entity_type, entity_id), (parent_process_id)
  (initiated_by), (current_state, created_at)

// M2: Immutable state history
2026_03_31_000002_create_tz_process_state_history_table.php
- Columns: id, process_id, from_state, to_state, transitioned_at
  initiated_by, reason, metadata (json)
- Indexes: (process_id), (transitioned_at)
- Purpose: Complete audit log, never modified

// M3: Process dependencies (parent→child)
2026_03_31_000003_create_tz_process_dependencies_table.php
- Columns: id, parent_process_id, child_process_id, relationship_type
  created_at
- Relationship types: created_from, triggered_by, depends_on, invalidates
- Indexes: (parent_process_id), (child_process_id)

// M4: Rewind conflicts
2026_03_31_000004_create_tz_rewind_conflicts_table.php
- Columns: id, process_id, conflict_type, severity, message, details (json)
  resolution, manual_review_by, resolved_at, created_at
- Conflict types: entity-modified, deep-cascade, external-transaction
- Indexes: (process_id), (severity), (resolved_at)

// M5: Rewind audit trail
2026_03_31_000005_create_tz_rewind_audit_trail_table.php
- Columns: id, original_process_id, correction_process_id, rewind_reason
  initiated_at, initiated_by, correction_submitted_at, correction_approved_at
  rolled_back_at, data_changes (json), affected_processes (json), status
- Indexes: (original_process_id), (initiated_at)
```

**New Models:**

```php
// app/Extensions/TitanRewind/System/Models/Process.php
- Properties: process_id, entity_type, entity_id, current_state, context, etc.
- Relations:
  - stateHistory() : HasMany
  - dependencies() : HasMany
  - conflicts() : HasMany
  - correction() : BelongsTo (if correction_process_id)
  - parent() : BelongsTo (if parent_process_id)
  - children() : HasMany
- Methods:
  - canRewind() : bool
  - getAffectedProcesses() : Collection
  - getCurrentState() : string
  - transitionState(newState, reason) : void
  - getTimeline() : array

// app/Extensions/TitanRewind/System/Models/ProcessStateHistory.php
- Read-only audit log
- Properties: process_id, from_state, to_state, transitioned_at, reason
- Scope: whereProcess(), byState(), chronological()

// app/Extensions/TitanRewind/System/Models/ProcessDependency.php
- Properties: parent_process_id, child_process_id, relationship_type
- Relations: parent(), child()

// app/Extensions/TitanRewind/System/Models/RewindConflict.php
- Properties: process_id, conflict_type, severity, details, resolution
- Scopes: critical(), unresolved(), byType()

// app/Extensions/TitanRewind/System/Models/RewindAuditRecord.php
- Properties: original_process_id, correction_process_id, rewind_reason, etc.
- Full immutable record of rewind lifecycle
```

**Update RewindCase Model:**

```php
// app/Extensions/TitanRewind/System/Models/RewindCase.php
- Rename table: boxed_automation_cases → tz_rewind_cases
- Add relation: process() : BelongsTo (link to Process)
- Purpose: Detect issues that trigger rewinds (separate from process lifecycle)
```

#### 1.2 State Machine Configuration

**Create `config/rewind-states.php`:**

```php
return [
    'PROCESS_STATES' => [
        'initiated' => ['next' => ['signal-queued'], 'description' => '...'],
        'signal-queued' => ['next' => ['awaiting-validation'], 'description' => '...'],
        'awaiting-validation' => ['next' => ['validation-approved', 'validation-rejected'], ...],
        'validation-approved' => ['next' => ['awaiting-processing'], ...],
        'validation-rejected' => ['next' => ['initiated'], ...],
        'awaiting-processing' => ['next' => ['processing'], ...],
        'processing' => ['next' => ['processed', 'processing-rejected', 'processing-error'], ...],
        'processed' => ['next' => ['rewinding', 'archived'], ...],
        'rewinding' => ['next' => ['awaiting-correction', 'conflicted'], ...],
        'awaiting-correction' => ['next' => ['processing', 'archived'], ...],
        'rolled-back' => ['next' => ['archived'], ...],
        'conflict-hold' => ['next' => ['awaiting-correction', 'archived'], ...],
        'archived' => ['next' => [], ...],
    ],
    'REWINDABLE_STATES' => ['validation-approved', 'awaiting-processing', 'processing', 'processed'],
    'CONFLICT_TYPES' => [
        'entity-modified' => 'High',
        'deep-cascade' => 'Critical',
        'external-transaction' => 'Critical',
    ],
];
```

#### 1.3 Enum Classes

**Create value objects (already started with EmbeddingTypeEnum):**

```php
// app/Extensions/TitanRewind/System/Enums/ProcessState.php
enum ProcessState: string {
    case INITIATED = 'initiated';
    case SIGNAL_QUEUED = 'signal-queued';
    case AWAITING_VALIDATION = 'awaiting-validation';
    // ... etc
    public function isRewindable(): bool { ... }
    public function allowsTransition(ProcessState $to): bool { ... }
}

// app/Extensions/TitanRewind/System/Enums/ConflictType.php
enum ConflictType: string {
    case ENTITY_MODIFIED = 'entity-modified';
    case DEEP_CASCADE = 'deep-cascade';
    case EXTERNAL_TRANSACTION = 'external-transaction';
}

// app/Extensions/TitanRewind/System/Enums/ConflictSeverity.php
enum ConflictSeverity: string {
    case HIGH = 'high';
    case CRITICAL = 'critical';
}
```

---

### PHASE 2: Core Services (Weeks 1.5–2.5)

#### 2.1 Rewind Engine (Main Orchestrator)

**Create `System/Services/RewindEngine.php`:**

```php
class RewindEngine {
    public function initiateRewind(
        string $processId,
        string $reason,
        int $initiatedBy
    ): array {
        // 1. ANALYSIS: analyzeRewindImpact()
        // 2. HOLD: Mark original as rewinding
        // 3. NOTIFY: notifyRewindInitiated()
        // 4. HOLD: Put downstream on hold (awaiting-correction state)
        return ['status' => 'rewind-initiated', 'affected_processes' => ...];
    }

    private function analyzeRewindImpact(Process $process): array {
        // Find all downstream processes
        // Find all affected users
        // Find created entities
        // Return complete impact analysis
        return [
            'original_process' => $process->process_id,
            'affected_processes' => [...],
            'affected_users' => [...],
            'created_entities' => [...]
        ];
    }

    private function notifyRewindInitiated(array $users, Process $process): void {
        // Use notification system to inform affected users
    }
}
```

#### 2.2 Correction Submission

**Create `System/Services/RewindCorrection.php`:**

```php
class RewindCorrection {
    public function submitCorrection(
        string $originalProcessId,
        array $correctedData
    ): array {
        // 1. CREATE new process with corrected data (mark as correction)
        // 2. EMIT signal (flows through validation/approval again)
        // 3. CONNECT: Link original → correction
        // 4. LISTEN: When correction approved, trigger rollback
        return [
            'status' => 'correction-submitted',
            'original_process' => $originalProcessId,
            'correction_process' => $correctionProcess->process_id
        ];
    }
}
```

#### 2.3 Rollback Processing

**Create `System/Services/RollbackProcessor.php`:**

```php
class RollbackProcessor {
    public function rollbackOriginal(
        string $originalProcessId,
        Process $correctionProcess
    ): array {
        // 1. MARK original as rolled-back
        // 2. MARK correction as active
        // 3. HANDLE created entities (archive original, activate new)
        // 4. HANDLE downstream cascades (canReuse vs markForReissue)
        // 5. NOTIFY affected users
        return [
            'status' => 'rollback-complete',
            'downstream_affected' => count
        ];
    }

    private function canReuseDownstreamProcess(
        Process $downstream,
        Process $original
    ): bool {
        // Check if downstream can accept updated parent data
    }

    private function updateDownstreamData(array $data, array $newParentData): array {
        // Intelligently merge parent correction into downstream process
    }

    private function handleDownstreamAfterRollback(string $downstreamId, Process $original): void {
        // Reuse or reissue logic
    }
}
```

#### 2.4 Conflict Detection

**Create `System/Services/RewindConflictDetector.php`:**

```php
class RewindConflictDetector {
    public function detectRewindConflicts(
        Process $original,
        array $correctionData
    ): array {
        // 1. Check: Entity modified since original?
        // 2. Check: Deep cascades exist (grandchildren)?
        // 3. Check: External transactions (Stripe, PayPal, etc.)?
        // Return array of conflicts with severity
        return [
            ['type' => 'entity-modified', 'severity' => 'high', ...],
            ['type' => 'external-transaction', 'severity' => 'critical', ...]
        ];
    }

    public function handleConflict(array $conflict, Process $process): void {
        if ($conflict['severity'] === 'critical') {
            // Mark as CONFLICTED state, require manual review
            // Notify admin
        } else if ($conflict['severity'] === 'high') {
            // Ask user for decision
        }
    }
}
```

#### 2.5 Audit Trail

**Enhance `System/Services/RewindAuditService.php`:**

```php
class RewindAuditService {
    public function recordRewindHistory(string $processId): array {
        // Build complete history of:
        // - Original process metadata
        // - All corrections submitted
        // - Approvals/rejections
        // - Rollback completion
        // - Downstream affected with status
        return [
            'original_process' => [...],
            'rewind_history' => [...],
            'downstream_affected' => [...]
        ];
    }

    public function printRewindTimeline(string $processId): void {
        // Console output of complete rewind timeline
    }

    public function getStateHistory(string $processId): Collection {
        // Immutable log of all state transitions
    }
}
```

#### 2.6 Notification Service

**Create `System/Services/RewindNotificationService.php`:**

```php
class RewindNotificationService {
    public function notifyRewindInitiated(array $users, Process $process): void {
        // Send notifications to all affected users
    }

    public function notifyRollbackComplete(array $users, Process $process): void {
        // Inform users that rewind completed
    }

    public function escalateConflict(RewindConflict $conflict, int $adminId): void {
        // Alert admin to critical conflict requiring manual review
    }
}
```

---

### PHASE 3: Controllers & HTTP Layer (Week 2.5–3)

#### 3.1 Rewind API Controller

**Enhance `System/Http/Controllers/TitanRewindCaseController.php` → Add `System/Http/Controllers/RewindProcessController.php`:**

```php
class RewindProcessController extends Controller {
    public function initiateRewind(Request $request, string $processId) {
        // POST /rewind/{processId}
        // Validate rewindable state
        // Call RewindEngine::initiateRewind()
        // Return impact analysis
    }

    public function analyzeImpact(string $processId) {
        // GET /rewind/{processId}/impact
        // Return affected processes, users, entities
    }

    public function submitCorrection(Request $request, string $processId) {
        // POST /rewind/{processId}/correction
        // Validate correction data
        // Call RewindCorrection::submitCorrection()
    }

    public function showConflicts(string $processId) {
        // GET /rewind/{processId}/conflicts
        // Show all detected conflicts with severity
    }

    public function resolveConflict(Request $request, string $processId, string $conflictId) {
        // POST /rewind/{processId}/conflicts/{conflictId}/resolve
        // Admin decision on conflict handling
    }

    public function getAuditTrail(string $processId) {
        // GET /rewind/{processId}/audit-trail
        // Return complete rewind history
    }

    public function getTimeline(string $processId) {
        // GET /rewind/{processId}/timeline
        // Return formatted timeline (console log style)
    }
}
```

#### 3.2 Request Validation

**Create `System/Http/Requests/`:**

```php
// RewindInitiateRequest.php
- Validate: process_id exists, is rewindable, user authorized
- Rules: required, exists, in:rewindable_states

// CorrectionSubmitRequest.php
- Validate: original_process_id in rewinding state, corrected_data provided
- Rules: required, array, no_empty_fields

// ConflictResolutionRequest.php
- Validate: decision (overwrite|manual_merge|reissue)
```

#### 3.3 Resources (Response Formatters)

**Create `System/Http/Resources/`:**

```php
// RewindProcessResource.php
- Format complete process with state, timeline
- Include: process_id, entity_type, current_state, state_history, context

// RewindImpactResource.php
- Format impact analysis
- Include: affected_processes, affected_users, created_entities, counts

// RewindConflictResource.php
- Format conflict details with resolution options

// RewindAuditTrailResource.php
- Format audit trail with corrections and cascades
```

---

### PHASE 4: Job Queue & Async Processing (Week 3)

#### 4.1 Queue Jobs

**Enhance `System/Console/Commands/ProcessRewindQueue.php` + Add jobs:**

```php
// System/Jobs/InitiateRewindJob.php
- Queued job for async rewind initiation
- Handles impact analysis in background
- Notifies on completion

// System/Jobs/ProcessCascadeJob.php
- Queued job for cascade updates
- Batches downstream process updates
- Handles external service calls (Stripe refunds)

// System/Jobs/RefundExternalTransactionJob.php
- Queued job for Stripe/PayPal refunds
- Idempotent (safe for retries)
- Records refund in audit trail
```

**Enhance command:**

```php
class ProcessRewindQueue extends Command {
    public function handle() {
        // Process queued rewind jobs
        // Handle failed cascades with retry logic
        // Log results to audit trail
    }
}
```

---

### PHASE 5: Testing & Documentation (Week 3.5–4)

#### 5.1 Test Suite

```php
// tests/Feature/RewindInitiationTest.php
- Test rewindable state validation
- Test impact analysis correctness
- Test downstream hold state

// tests/Feature/CorrectionSubmissionTest.php
- Test correction process creation
- Test validation flow re-entry
- Test linking original → correction

// tests/Feature/RollbackTest.php
- Test original → rolled-back transition
- Test entity archival (non-destructive)
- Test downstream update logic
- Test cascade reuse vs reissue decision

// tests/Feature/ConflictDetectionTest.php
- Test entity-modified conflict detection
- Test deep-cascade detection
- Test external-transaction detection (Stripe)
- Test conflict escalation

// tests/Feature/AuditTrailTest.php
- Test state history immutability
- Test complete rewind history recording
- Test timeline generation

// tests/Unit/ProcessStateTest.php
- Test state machine transitions
- Test invalid transition rejection
- Test rewindable state checking

// tests/Unit/ConflictDetectorTest.php
- Unit tests for conflict logic
```

#### 5.2 Documentation

```markdown
// docs/REWIND_ARCHITECTURE.md
- Complete system overview
- State machine diagram
- Cascade handling logic
- Conflict detection rules

// docs/REWIND_API.md
- Endpoint documentation
- Request/response examples
- Error codes and handling
- Scenarios (simple field correction, complex cascade)

// docs/REWIND_SCENARIOS.md
- Detailed scenario walkthroughs
- Scenario 1: Simple field correction
- Scenario 2: Complex cascade (booking→job→invoice→payment)
- Scenario 3: Conflict handling

// docs/MIGRATION_GUIDE.md
- How to migrate existing processes to TitanRewind
- Mapping existing entities to process records
- Backfilling historical state

// docs/DEVELOPER_GUIDE.md
- How to integrate TitanRewind into extensions
- Emitting signals
- Listening for rewind events
- Custom conflict detection
```

---

## PART 3: IMPLEMENTATION CHECKLIST

### ✓ Pre-Implementation

- [ ] Review current TitanRewindBase code structure
- [ ] Identify external systems needing conflict handling (Stripe, PayPal, SMS, etc.)
- [ ] Plan notification channels (email, in-app, Slack, etc.)
- [ ] Schedule stakeholder alignment on cascade handling logic
- [ ] Set up git branches for parallel workstreams

### PHASE 1: Foundation (Weeks 1–1.5)

- [ ] Create 5 new migrations (processes, state_history, dependencies, conflicts, audit)
- [ ] Create 5 new models (Process, ProcessStateHistory, ProcessDependency, RewindConflict, RewindAuditRecord)
- [ ] Update RewindCase model + rename table
- [ ] Create Enum classes (ProcessState, ConflictType, ConflictSeverity)
- [ ] Create state machine config
- [ ] Test migrations and models in isolation
- [ ] Write migration documentation

### PHASE 2: Core Services (Weeks 1.5–2.5)

- [ ] Implement RewindEngine class + initiateRewind() + analyzeRewindImpact()
- [ ] Implement RewindCorrection class + submitCorrection()
- [ ] Implement RollbackProcessor class + rollbackOriginal() + cascade handling
- [ ] Implement RewindConflictDetector class + detect logic for all 3 types
- [ ] Enhance RewindAuditService + recordRewindHistory() + getStateHistory()
- [ ] Create RewindNotificationService
- [ ] Write unit tests for each service
- [ ] Test service integration (E2E workflow)

### PHASE 3: Controllers & HTTP (Week 2.5–3)

- [ ] Create RewindProcessController with 7 endpoints
- [ ] Create Request validation classes
- [ ] Create Response Resource classes
- [ ] Write controller unit tests
- [ ] Write integration tests for full HTTP flows
- [ ] Document API endpoints

### PHASE 4: Queue & Async (Week 3)

- [ ] Create 3 queue jobs (InitiateRewind, ProcessCascade, RefundExternal)
- [ ] Enhance ProcessRewindQueue command
- [ ] Add retry logic and failure handling
- [ ] Write queue tests
- [ ] Test with Redis queue locally

### PHASE 5: Testing & Documentation (Week 3.5–4)

- [ ] Write 8 feature test suites (~300 test cases)
- [ ] Write 2 unit test suites (~100 test cases)
- [ ] Achieve 90%+ code coverage
- [ ] Write 6 documentation files
- [ ] Create scenario walkthroughs with data examples
- [ ] Record video walkthrough of system

### Post-Implementation

- [ ] Deploy to staging environment
- [ ] Run load testing (1000+ concurrent processes)
- [ ] Stress test with large cascades (100+ downstream processes)
- [ ] Test with real external integrations (Stripe, SMS APIs)
- [ ] User acceptance testing
- [ ] Deploy to production
- [ ] Monitor error rates and performance
- [ ] Collect user feedback for v1.1

---

## PART 4: DATABASE SCHEMA (Complete)

### New Tables Required

```sql
-- Core process record
CREATE TABLE tz_processes (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    process_id CHAR(36) UNIQUE NOT NULL,  -- UUID
    entity_type VARCHAR(80) NOT NULL,     -- 'booking', 'invoice', 'payment', etc.
    entity_id BIGINT UNSIGNED,            -- ID of created entity
    domain VARCHAR(80) NOT NULL,          -- 'service', 'financial', etc.
    initiated_by BIGINT UNSIGNED NOT NULL,
    initiated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    current_state VARCHAR(30) NOT NULL,   -- from ProcessState enum
    state_at_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    context JSON,                         -- contextual metadata
    processing JSON,                      -- processing metadata (approvers, etc.)
    rewind_info JSON,                     -- rewind reason, initiated_by, etc.
    correction_process_id CHAR(36),       -- if this is correction or has correction
    parent_process_id CHAR(36),           -- if created from another process
    processed_entity_id BIGINT UNSIGNED,  -- ID of created entity instance
    originating_node VARCHAR(80),         -- which MagicAI node/extension created this
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_process_id (process_id),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_parent (parent_process_id),
    INDEX idx_initiated_by (initiated_by),
    INDEX idx_state_timestamp (current_state, created_at),
    INDEX idx_correction (correction_process_id),
    FOREIGN KEY fk_correction (correction_process_id) REFERENCES tz_processes(process_id)
);

-- Immutable state history (append-only audit log)
CREATE TABLE tz_process_state_history (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    process_id CHAR(36) NOT NULL,
    from_state VARCHAR(30),
    to_state VARCHAR(30) NOT NULL,
    transitioned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    initiated_by BIGINT UNSIGNED,
    reason VARCHAR(500),
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_process (process_id),
    INDEX idx_transitioned (transitioned_at),
    FOREIGN KEY fk_process (process_id) REFERENCES tz_processes(process_id) ON DELETE CASCADE
);

-- Parent → Child process dependencies
CREATE TABLE tz_process_dependencies (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    parent_process_id CHAR(36) NOT NULL,
    child_process_id CHAR(36) NOT NULL,
    relationship_type VARCHAR(30) NOT NULL,  -- 'created_from', 'triggered_by', 'depends_on', 'invalidates'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_parent (parent_process_id),
    INDEX idx_child (child_process_id),
    UNIQUE KEY unique_dependency (parent_process_id, child_process_id, relationship_type),
    FOREIGN KEY fk_parent (parent_process_id) REFERENCES tz_processes(process_id) ON DELETE CASCADE,
    FOREIGN KEY fk_child (child_process_id) REFERENCES tz_processes(process_id) ON DELETE CASCADE
);

-- Detected rewind conflicts
CREATE TABLE tz_rewind_conflicts (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    process_id CHAR(36) NOT NULL,
    conflict_type VARCHAR(30) NOT NULL,    -- 'entity-modified', 'deep-cascade', 'external-transaction'
    severity VARCHAR(20) NOT NULL,         -- 'high', 'critical'
    message TEXT NOT NULL,
    details JSON,                          -- conflict-specific details (entity_id, stripe_charge_id, etc.)
    resolution VARCHAR(500),               -- recommended resolution
    manual_review_by BIGINT UNSIGNED,      -- admin who reviewed
    resolved_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_process (process_id),
    INDEX idx_severity (severity),
    INDEX idx_resolved (resolved_at),
    FOREIGN KEY fk_process (process_id) REFERENCES tz_processes(process_id) ON DELETE CASCADE
);

-- Complete rewind audit trail
CREATE TABLE tz_rewind_audit_trail (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    original_process_id CHAR(36) NOT NULL,
    correction_process_id CHAR(36),
    rewind_reason VARCHAR(500),
    initiated_at TIMESTAMP,
    initiated_by BIGINT UNSIGNED,
    correction_submitted_at TIMESTAMP,
    correction_approved_at TIMESTAMP,
    rolled_back_at TIMESTAMP,
    data_changes JSON,                    -- {field_name: {from: old_value, to: new_value}}
    affected_processes JSON,              -- [process_id, process_id, ...]
    status VARCHAR(30),                   -- 'in-progress', 'completed', 'failed'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_original (original_process_id),
    INDEX idx_initiated (initiated_at),
    FOREIGN KEY fk_original (original_process_id) REFERENCES tz_processes(process_id) ON DELETE CASCADE,
    FOREIGN KEY fk_correction (correction_process_id) REFERENCES tz_processes(process_id) ON DELETE SET NULL
);
```

### Existing Tables (Rename/Update)

```sql
-- Rename for clarity (non-destructive)
ALTER TABLE boxed_automation_cases RENAME TO tz_rewind_cases;

-- Add foreign key to tz_processes if integrating error detection
ALTER TABLE tz_rewind_cases 
ADD COLUMN process_id CHAR(36),
ADD FOREIGN KEY fk_process (process_id) REFERENCES tz_processes(process_id);

-- Rename other tables for namespace consistency
ALTER TABLE boxed_automation_events RENAME TO tz_rewind_events;
ALTER TABLE boxed_automation_fixes RENAME TO tz_rewind_fixes;
ALTER TABLE boxed_automation_actions RENAME TO tz_rewind_actions;
```

---

## PART 5: CONFIGURATION CHANGES

### Update `config/titan-rewind.php`

```php
return [
    // Process configuration
    'processes' => [
        'enable_rewind' => true,
        'rewindable_states' => [
            'validation-approved',
            'awaiting-processing',
            'processing',
            'processed'
        ],
    ],

    // Cascade handling
    'cascade' => [
        'max_depth' => 50,  // Prevent infinite loops
        'auto_reuse_threshold' => 0.95,  // 95% field compatibility = reuse
        'notify_on_reissue' => true,
    ],

    // Conflict detection
    'conflicts' => [
        'detect_entity_modifications' => true,
        'detect_deep_cascades' => true,
        'detect_external_transactions' => true,
        'external_services' => [
            'stripe' => ['entity_types' => ['payment', 'invoice']],
            'twilio' => ['entity_types' => ['sms_campaign']],
            // ...
        ],
    ],

    // Notifications
    'notifications' => [
        'channels' => ['mail', 'in_app', 'slack'],  // Configurable per event
        'escalation_to' => 'admin',  // Route critical conflicts to admins
    ],

    // Queue
    'queue' => [
        'connection' => 'redis',
        'rewind_initiation_queue' => 'default',
        'cascade_processing_queue' => 'default',
        'refund_processing_queue' => 'refunds',  // Higher priority queue
        'retry_count' => 3,
        'retry_delay' => 60,  // seconds
    ],

    // Audit
    'audit' => [
        'retention_days' => 2555,  // 7 years
        'archive_to_s3' => true,
        'compress_historical' => true,
    ],
];
```

---

## PART 6: INTEGRATION POINTS

### With MagicAI Core

1. **Signal Emission** — When any MagicAI extension creates an entity (booking, invoice, etc.):
   ```php
   event(new ProcessCreated($process));  // Automatically enters signal-queued state
   ```

2. **Validation Pipeline** — MagicAI validators mark processes as validation-approved or rejected

3. **Processing** — MagicAI agents run processing, mark as processing → processed

4. **Rewind Hooks** — Extensions can register custom cascade handling:
   ```php
   TitanRewind::registerCascadeHandler('booking', BookingCascadeHandler::class);
   ```

### With CREATORS Framework

1. **Thought Engine** (LogiCore) — Analyzes rewind impact
2. **Oversight Engine** — Detects conflicts requiring attention
3. **Relationship Engine** — Notifies affected users
4. **Schedule Engine** — Marks downstream processes on hold

### With External Systems

1. **Stripe** — Detect charges, initiate refunds
2. **Twilio/SMS** — Detect sent campaigns, prevent re-sends
3. **Payment gateways** — Detect transactions requiring reversal
4. **Analytics** — Track rewind events for optimization

---

## PART 7: EFFORT & TIMELINE

| Phase | Component | Stories | Est. Hours | Actual |
|-------|-----------|---------|-----------|--------|
| 1 | Database schema + Models | 5 | 12 | |
| 1 | Enums + State machine config | 3 | 6 | |
| 2 | RewindEngine + analyzeImpact | 2 | 16 | |
| 2 | RewindCorrection + submitCorrection | 2 | 12 | |
| 2 | RollbackProcessor + cascade handling | 2 | 20 | |
| 2 | RewindConflictDetector | 2 | 16 | |
| 2 | Audit service + Notifications | 2 | 12 | |
| 3 | RewindProcessController (7 endpoints) | 1 | 20 | |
| 3 | Request validation + Resources | 2 | 10 | |
| 4 | Queue jobs + command | 3 | 12 | |
| 5 | Test suite (8 feature + 2 unit) | 10 | 40 | |
| 5 | Documentation (6 files) | 6 | 20 | |
| | **TOTAL** | **42** | **196 hours** | |

**Timeline:** 3.5–4 weeks full-time (5-day weeks, 8 hrs/day = 40 hrs/week = 5 weeks buffer for unknowns)

---

## PART 8: ROLLOUT STRATEGY

### Stage 1: Internal Testing (Days 1–28)
- Deploy to staging
- QA: Full scenario testing
- Load test: 10,000 processes
- Stress test: Deep cascades (100+ downstream)

### Stage 2: Pilot (Days 29–42)
- Deploy to production in read-only mode
- Run parallel with existing system
- Collect metrics on correctness
- Fix edge cases

### Stage 3: Production (Day 43+)
- Full production deployment
- Monitor error rates and performance
- Collect user feedback
- Plan v1.1 improvements

---

## PART 9: SUCCESS METRICS

1. **Rewind Accuracy:** 99.5%+ cascades correctly identified and handled
2. **Performance:** Rewind initiation <500ms, cascade processing <10sec for 100 processes
3. **Conflict Detection:** 100% detection rate for critical conflicts (Stripe charges, deep cascades)
4. **Audit Completeness:** Every rewind creates immutable 7-year audit trail
5. **User Experience:** <5 clicks to initiate rewind, understand impact, submit correction
6. **Zero Data Loss:** 100% of original data archived, never deleted

---

## PART 10: REFERENCES

- **REWIND ENGINE spec:** `3_REWIND_ENGINE.pdf` (pages 1–14)
- **Scenario 1 (Field Correction):** Page 8
- **Scenario 2 (Complex Cascade):** Page 9–10
- **Conflict Detection:** Page 10–11
- **Audit Trail:** Page 12–14

---

## APPENDIX: CODE SKELETON

### Quick-Start Directory Structure

```
app/Extensions/TitanRewind/
├── System/
│   ├── Console/
│   │   └── Commands/
│   │       ├── ProcessRewindQueue.php (ENHANCE)
│   │       └── RewindAudit.php (NEW)
│   ├── Enums/
│   │   ├── ProcessState.php (NEW)
│   │   ├── ConflictType.php (NEW)
│   │   └── ConflictSeverity.php (NEW)
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── TitanRewindCaseController.php (ENHANCE)
│   │   │   └── RewindProcessController.php (NEW)
│   │   ├── Requests/
│   │   │   ├── RewindInitiateRequest.php (NEW)
│   │   │   ├── CorrectionSubmitRequest.php (NEW)
│   │   │   └── ConflictResolutionRequest.php (NEW)
│   │   └── Resources/
│   │       ├── RewindProcessResource.php (NEW)
│   │       ├── RewindImpactResource.php (NEW)
│   │       ├── RewindConflictResource.php (NEW)
│   │       └── RewindAuditTrailResource.php (NEW)
│   ├── Jobs/
│   │   ├── InitiateRewindJob.php (NEW)
│   │   ├── ProcessCascadeJob.php (NEW)
│   │   └── RefundExternalTransactionJob.php (NEW)
│   ├── Models/
│   │   ├── RewindCase.php (ENHANCE)
│   │   ├── Process.php (NEW)
│   │   ├── ProcessStateHistory.php (NEW)
│   │   ├── ProcessDependency.php (NEW)
│   │   ├── RewindConflict.php (NEW)
│   │   ├── RewindAuditRecord.php (NEW)
│   │   ├── RewindEvent.php (ENHANCE)
│   │   ├── RewindFix.php (ENHANCE)
│   │   └── RewindAction.php (ENHANCE)
│   ├── Services/
│   │   ├── RewindEngine.php (NEW)
│   │   ├── RewindCorrection.php (NEW)
│   │   ├── RollbackProcessor.php (NEW)
│   │   ├── RewindConflictDetector.php (NEW)
│   │   ├── RewindAuditService.php (ENHANCE)
│   │   ├── RewindCaseService.php (ENHANCE)
│   │   ├── RewindFixService.php (ENHANCE)
│   │   └── RewindNotificationService.php (NEW)
│   ├── Traits/
│   │   ├── HasProcessLifecycle.php (NEW)
│   │   └── HasRewindHistory.php (NEW)
│   ├── Events/
│   │   ├── RewindInitiated.php (NEW)
│   │   ├── CorrectionSubmitted.php (NEW)
│   │   ├── RollbackCompleted.php (NEW)
│   │   └── ConflictDetected.php (NEW)
│   ├── Listeners/
│   │   ├── NotifyRewindInitiated.php (NEW)
│   │   ├── NotifyRollbackCompleted.php (NEW)
│   │   └── EscalateConflict.php (NEW)
│   └── TitanRewindServiceProvider.php (ENHANCE)
├── config/
│   ├── titan-rewind.php (ENHANCE)
│   └── rewind-states.php (NEW)
├── database/
│   └── migrations/
│       ├── 2026_02_16_000001_create_titan_rewind_cases_table.php (RENAME)
│       ├── 2026_02_16_000002_create_titan_rewind_events_table.php (RENAME)
│       ├── 2026_02_16_000003_create_titan_rewind_fixes_table.php (RENAME)
│       ├── 2026_02_16_000004_create_titan_rewind_actions_table.php (RENAME)
│       ├── 2026_03_31_000001_create_tz_processes_table.php (NEW)
│       ├── 2026_03_31_000002_create_tz_process_state_history_table.php (NEW)
│       ├── 2026_03_31_000003_create_tz_process_dependencies_table.php (NEW)
│       ├── 2026_03_31_000004_create_tz_rewind_conflicts_table.php (NEW)
│       └── 2026_03_31_000005_create_tz_rewind_audit_trail_table.php (NEW)
├── resources/
│   ├── lang/
│   │   └── en/
│   │       └── messages.php (ENHANCE)
│   └── views/
│       ├── processes/
│       │   ├── index.blade.php (NEW)
│       │   ├── show.blade.php (NEW)
│       │   └── timeline.blade.php (NEW)
│       ├── rewind/
│       │   ├── initiate.blade.php (NEW)
│       │   ├── correction.blade.php (NEW)
│       │   ├── conflicts.blade.php (NEW)
│       │   └── audit-trail.blade.php (NEW)
│       └── cases/
│           ├── index.blade.php (ENHANCE)
│           └── show.blade.php (ENHANCE)
├── routes/
│   ├── web.php (ENHANCE)
│   └── api.php (NEW)
├── tests/
│   ├── Feature/
│   │   ├── RewindInitiationTest.php (NEW)
│   │   ├── CorrectionSubmissionTest.php (NEW)
│   │   ├── RollbackTest.php (NEW)
│   │   ├── ConflictDetectionTest.php (NEW)
│   │   ├── AuditTrailTest.php (NEW)
│   │   ├── NotificationTest.php (NEW)
│   │   ├── CascadeHandlingTest.php (NEW)
│   │   └── IntegrationTest.php (NEW)
│   └── Unit/
│       ├── ProcessStateTest.php (NEW)
│       └── ConflictDetectorTest.php (NEW)
└── docs/
    ├── REWIND_ARCHITECTURE.md (NEW)
    ├── REWIND_API.md (NEW)
    ├── REWIND_SCENARIOS.md (NEW)
    ├── MIGRATION_GUIDE.md (NEW)
    └── DEVELOPER_GUIDE.md (NEW)
```

---

**END OF UPGRADE PLAN**

Generated for Jason (TitanZero) — Complete gap analysis and implementation roadmap for enterprise-grade Rewind Engine integration.
