# TitanRewind Pass 03 Notes

## Added in this pass
- dependency graph builder for domain-rule and stored-link cascades
- impact analyzer now returns graph, counts, affected users, reuse vs reissue totals
- notification staging service using rewind actions as durable queue records
- history service for timeline, links, actions, and conflicts bundle output
- conflict resolution service with audit event emission and conflict-hold release logic
- conflict resolution route/controller flow
- timeline JSON endpoint
- richer case view with correction, conflict, rollback, links, actions, and timeline sections
- rewind links now track depth, status, action_required, and held_reason
- rewind conflicts now track resolved_at and resolved_by fields
- rollback completion now updates replacement_process_id and rollback_completed_at

## Architecture shift
Pass 03 moves TitanRewind from simple correction handling into a more complete recovery supervisor:
- cases hold rewind state
- links hold cascade state
- conflicts hold manual review state
- actions log notifications and downstream decisions
- history bundles unify audit + cascade + actions for UI and APIs

## Remaining priorities
1. integrate directly with Titan Signal `tz_processes` and `tz_process_states`
2. add external payment refund/reissue adapters
3. add downstream entity patching for reusable links
4. add staged rollback orchestration for deep cascades
5. add admin/manual-review dashboard surfaces
