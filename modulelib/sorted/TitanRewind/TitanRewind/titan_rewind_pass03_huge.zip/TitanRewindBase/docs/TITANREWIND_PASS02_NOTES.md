# Titan Rewind Pass 02

This pass upgrades Titan Rewind from rewind-initiation only into a fuller correction and rollback substrate.

## Added
- `RewindConflictDetector`
- `RewindRollbackProcessor`
- correction submission endpoint
- rollback completion endpoint
- case metadata for `correction_process_id`, `replacement_process_id`, and completion timestamp
- timeline helper in `RewindAuditService`

## Behaviour
- rewind initiation now persists detected conflicts
- critical conflicts push the case into `conflict-hold`
- correction submission records correction metadata and immutable audit events
- rollback completion writes downstream reuse/reissue actions into `titan_rewind_actions`

## Remaining
- entity-level archive/update adapters per WorkCore domain
- automatic downstream hold/resume integration with Titan Signal process state tables
- notification fanout and manual review UI
