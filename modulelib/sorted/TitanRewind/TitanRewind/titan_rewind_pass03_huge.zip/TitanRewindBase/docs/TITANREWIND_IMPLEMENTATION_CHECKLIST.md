# TitanRewind Implementation Checklist
**Detailed Story Breakdown & Acceptance Criteria**

---

## PHASE 1: FOUNDATION (Weeks 1–1.5)

### STORY 1.1: Database Schema – Core Process Table
**Acceptance Criteria:**
- [ ] Migration creates `tz_processes` table with all required columns
- [ ] Indexes created on process_id, entity_type, parent_process_id, initiated_by, current_state
- [ ] Foreign key constraint to correction_process_id
- [ ] Migration is idempotent (safe to run multiple times)
- [ ] All columns have appropriate types and constraints
- [ ] Test: Can insert 10,000 process records without deadlock
- [ ] Test: Queries with indexed columns return in <10ms

**Files:**
- [ ] `database/migrations/2026_03_31_000001_create_tz_processes_table.php`

**Tasks:**
- [ ] Write migration
- [ ] Test in phpMyAdmin
- [ ] Document column purposes
- [ ] Review indexes with DBA

---

### STORY 1.2: Database Schema – State History (Immutable Audit Log)
**Acceptance Criteria:**
- [ ] Migration creates `tz_process_state_history` table
- [ ] Append-only (no UPDATE, only INSERT)
- [ ] Foreign key to tz_processes
- [ ] Indexes: process_id, transitioned_at
- [ ] Retention policy: 2,555 days (7 years)
- [ ] Test: Can insert 100 state transitions per process without slowdown
- [ ] Test: State history queries filtered by date range <50ms

**Files:**
- [ ] `database/migrations/2026_03_31_000002_create_tz_process_state_history_table.php`

**Tasks:**
- [ ] Write migration
- [ ] Create PHP method to enforce append-only (prevent UPDATE)
- [ ] Test cascading delete behavior
- [ ] Create retention cleanup job

---

### STORY 1.3: Database Schema – Process Dependencies
**Acceptance Criteria:**
- [ ] Migration creates `tz_process_dependencies` table
- [ ] Relationship types: created_from, triggered_by, depends_on, invalidates
- [ ] Foreign keys to parent and child processes
- [ ] Unique constraint on (parent_process_id, child_process_id, relationship_type)
- [ ] Indexes on both parent and child
- [ ] Test: Can insert 1000 dependency records <1 second
- [ ] Test: Find all downstream processes via graph traversal <100ms

**Files:**
- [ ] `database/migrations/2026_03_31_000003_create_tz_process_dependencies_table.php`

**Tasks:**
- [ ] Write migration
- [ ] Test recursive dependency queries (find grandchildren)
- [ ] Create utility method for breadth-first search
- [ ] Test circular dependency prevention

---

### STORY 1.4: Database Schema – Rewind Conflicts
**Acceptance Criteria:**
- [ ] Migration creates `tz_rewind_conflicts` table
- [ ] Columns: process_id, conflict_type, severity, message, details, resolution, manual_review_by, resolved_at
- [ ] Foreign key to tz_processes
- [ ] Indexes: process_id, severity, resolved_at
- [ ] Conflict types: entity-modified, deep-cascade, external-transaction
- [ ] Severity: high, critical
- [ ] Test: Can query unresolved critical conflicts <50ms
- [ ] Test: Bulk update conflicts on rollback succeeds

**Files:**
- [ ] `database/migrations/2026_03_31_000004_create_tz_rewind_conflicts_table.php`

**Tasks:**
- [ ] Write migration
- [ ] Create scopes for conflict queries (critical(), unresolved(), byType())
- [ ] Test data structure for 'details' JSON column
- [ ] Create admin notification for new conflicts

---

### STORY 1.5: Database Schema – Rewind Audit Trail
**Acceptance Criteria:**
- [ ] Migration creates `tz_rewind_audit_trail` table
- [ ] Columns: original_process_id, correction_process_id, rewind_reason, dates, initiated_by, data_changes, affected_processes, status
- [ ] Foreign keys to tz_processes
- [ ] Indexes: original_process_id, initiated_at
- [ ] Status: in-progress, completed, failed
- [ ] Data changes: {field_name: {from: old_value, to: new_value}}
- [ ] Test: Can insert complete rewind history for 100 corrections <1 second
- [ ] Test: Retrieve full history with all joins <100ms

**Files:**
- [ ] `database/migrations/2026_03_31_000005_create_tz_rewind_audit_trail_table.php`

**Tasks:**
- [ ] Write migration
- [ ] Create method to calculate data_changes diff
- [ ] Test JSON query performance (MySQL 5.7+ vs 8.0)
- [ ] Create audit trail visualization

---

### STORY 1.6: Models – Process (Core Entity)
**Acceptance Criteria:**
- [ ] Model class created with correct table mapping
- [ ] All mass-assignable properties fillable
- [ ] Casts: detected_at, state_at_timestamp, context, processing, rewind_info, data_changes as proper types
- [ ] Relations defined: stateHistory(), dependencies(), conflicts(), correction(), parent(), children()
- [ ] Methods:
  - [ ] canRewind() : bool — Check if in rewindable state
  - [ ] getAffectedProcesses() : Collection — Find all downstream
  - [ ] getCurrentState() : string
  - [ ] transitionState(newState, reason) : void
  - [ ] getTimeline() : array — Full state history
- [ ] Scopes: whereState(), whereEntity(), whereInitiatedBy()
- [ ] Test: Model relationships load correctly
- [ ] Test: Attribute casting works for all types
- [ ] Test: Queries use indexed columns

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Models/Process.php`

**Tasks:**
- [ ] Write model class
- [ ] Test all relations with real data
- [ ] Test scopes in isolation
- [ ] Add PHPDoc comments

---

### STORY 1.7: Models – ProcessStateHistory
**Acceptance Criteria:**
- [ ] Read-only model (prevent UPDATE/DELETE in application)
- [ ] Relation to Process
- [ ] Scopes: whereProcess(), byState(), chronological(), between(startDate, endDate)
- [ ] Method: describeTransition() : string
- [ ] Test: Cannot update or delete via Eloquent
- [ ] Test: Scopes return correct filtered results
- [ ] Test: Chronological ordering correct

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Models/ProcessStateHistory.php`

**Tasks:**
- [ ] Write model with read-only enforcement
- [ ] Test deletion attempt throws exception
- [ ] Create helper method to print timeline
- [ ] Test scope combinations

---

### STORY 1.8: Models – ProcessDependency, RewindConflict, RewindAuditRecord
**Acceptance Criteria:**
- [ ] ProcessDependency:
  - [ ] Relations: parent(), child()
  - [ ] Methods: findAllDownstream(maxDepth) : Collection
  - [ ] Test: Handles circular references safely
- [ ] RewindConflict:
  - [ ] Scopes: critical(), unresolved(), byType()
  - [ ] Methods: resolve(decision, resolvedBy) : void
  - [ ] Test: Cannot resolve critical without manual_review_by
- [ ] RewindAuditRecord:
  - [ ] Relation to original and correction processes
  - [ ] Method: getDataChangesSummary() : string
  - [ ] Test: Immutable after creation
- [ ] All models have proper testing

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Models/ProcessDependency.php`
- [ ] `app/Extensions/TitanRewind/System/Models/RewindConflict.php`
- [ ] `app/Extensions/TitanRewind/System/Models/RewindAuditRecord.php`

**Tasks:**
- [ ] Write all three models
- [ ] Test relations and methods
- [ ] Write unit tests for each
- [ ] Add proper validation rules

---

### STORY 1.9: Enum Classes – ProcessState, ConflictType, ConflictSeverity
**Acceptance Criteria:**
- [ ] ProcessState enum with 13 states
- [ ] ConflictType enum with 3 types
- [ ] ConflictSeverity enum with 2 levels
- [ ] ProcessState methods:
  - [ ] isRewindable() : bool
  - [ ] allowsTransition(ProcessState $to) : bool
  - [ ] description() : string
- [ ] Test: Valid state transitions allowed
- [ ] Test: Invalid transitions rejected
- [ ] Test: Only certain states are rewindable

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Enums/ProcessState.php`
- [ ] `app/Extensions/TitanRewind/System/Enums/ConflictType.php`
- [ ] `app/Extensions/TitanRewind/System/Enums/ConflictSeverity.php`

**Tasks:**
- [ ] Write enum classes
- [ ] Define all valid transitions in isRewindable()
- [ ] Test state machine logic
- [ ] Add documentation for each state

---

### STORY 1.10: Configuration – State Machine
**Acceptance Criteria:**
- [ ] File: `config/rewind-states.php`
- [ ] Defines all 13 states with:
  - [ ] Valid next states
  - [ ] Description
  - [ ] Visibility rules (who can see in this state)
- [ ] REWINDABLE_STATES constant
- [ ] CONFLICT_TYPES mapping
- [ ] Can be accessed: config('rewind-states.PROCESS_STATES')
- [ ] All values match enum definitions
- [ ] Test: Config loads without errors
- [ ] Test: All state references valid

**Files:**
- [ ] `config/titan-rewind.php` (ENHANCE)
- [ ] `config/rewind-states.php` (NEW)

**Tasks:**
- [ ] Write state machine config
- [ ] Verify consistency with enums
- [ ] Create validation to ensure all enum states in config
- [ ] Document each state

---

### STORY 1.11: Update RewindCase Model
**Acceptance Criteria:**
- [ ] Rename table (via migration): boxed_automation_cases → tz_rewind_cases
- [ ] Add foreign key to tz_processes
- [ ] Relation: process() : BelongsTo
- [ ] Purpose: Detect issues that trigger rewinds (separate from process lifecycle)
- [ ] Test: Existing data still accessible
- [ ] Test: New data can reference processes

**Files:**
- [ ] `database/migrations/2026_03_XX_XXXXXX_rename_rewind_cases_table.php`
- [ ] `app/Extensions/TitanRewind/System/Models/RewindCase.php` (ENHANCE)

**Tasks:**
- [ ] Create migration to rename table
- [ ] Add process_id column
- [ ] Update model class
- [ ] Test backward compatibility

---

### STORY 1.12: Testing – Model & Schema Tests
**Acceptance Criteria:**
- [ ] Database integration tests for all tables
- [ ] Model instantiation tests
- [ ] Relationship tests
- [ ] Scope tests
- [ ] 90%+ coverage on models
- [ ] All tests pass in CI/CD

**Files:**
- [ ] `tests/Feature/DatabaseSchemaTest.php`
- [ ] `tests/Feature/ModelRelationsTest.php`
- [ ] `tests/Unit/ModelTest.php`

**Tasks:**
- [ ] Write comprehensive test suite
- [ ] Test with fresh database
- [ ] Test migrations up and down
- [ ] Run code coverage

---

### ✓ PHASE 1 COMPLETE WHEN:
- All 5 migrations created and tested
- All 5 models created with relations
- All 3 enums defined and tested
- State machine config complete
- RewindCase model updated
- 90%+ test coverage
- Zero failing tests
- Documentation written for each component

---

## PHASE 2: CORE SERVICES (Weeks 1.5–2.5)

### STORY 2.1: RewindEngine – initiateRewind()
**Acceptance Criteria:**
- [ ] Method signature: initiateRewind(processId, reason, initiatedBy) : array
- [ ] Validates: process exists, is in rewindable state, user authorized
- [ ] Steps:
  1. [ ] Analyze impact (call analyzeRewindImpact)
  2. [ ] Mark original as rewinding state
  3. [ ] Notify affected users
  4. [ ] Put downstream processes on awaiting-correction hold
- [ ] Return: {status: 'rewind-initiated', affected_processes: [...], affected_users: [...]}
- [ ] Exceptions: ProcessNotFound, NotRewindable, Unauthorized
- [ ] Test: Correct impact analysis
- [ ] Test: Correct state transitions
- [ ] Test: All downstream marked as awaiting-correction
- [ ] Test: Notifications queued

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Services/RewindEngine.php`

**Tasks:**
- [ ] Implement RewindEngine class
- [ ] Implement analyzeRewindImpact() method
- [ ] Test with real process data
- [ ] Test error scenarios
- [ ] Add logging

---

### STORY 2.2: RewindEngine – analyzeRewindImpact()
**Acceptance Criteria:**
- [ ] Method signature: analyzeRewindImpact(process) : array
- [ ] Returns:
  - [ ] affected_processes: all downstream process IDs
  - [ ] affected_users: all users impacted
  - [ ] created_entities: {entity_type, entity_id, process_id} for each
- [ ] Uses ProcessDependency table for traversal
- [ ] Handles circular references (prevents infinite loops)
- [ ] Identifies grandchild processes (for deep-cascade conflicts)
- [ ] Test: Finds all levels of downstream
- [ ] Test: Handles circular references
- [ ] Test: Performance <1sec for 100+ processes
- [ ] Test: Correct user identification

**Files:**
- [ ] (Part of `System/Services/RewindEngine.php`)

**Tasks:**
- [ ] Implement BFS/DFS for process graph
- [ ] Test with real dependency chains
- [ ] Performance test with deep cascades
- [ ] Test circular reference prevention

---

### STORY 2.3: RewindCorrection – submitCorrection()
**Acceptance Criteria:**
- [ ] Method signature: submitCorrection(originalProcessId, correctedData) : array
- [ ] Validates: original process in rewinding state
- [ ] Steps:
  1. [ ] Create new Process record with corrected_data
  2. [ ] Mark correction: correction = true, corrects_process = original_id
  3. [ ] Emit signal (process enters signal-queued state)
  4. [ ] Link original → correction in database
  5. [ ] Listen for correction approval event
- [ ] Return: {status: 'correction-submitted', original_process: ..., correction_process: ..., next_step: '...'}
- [ ] Test: Correction process created correctly
- [ ] Test: Original linked to correction
- [ ] Test: Signal emitted and queued
- [ ] Test: Correction flows through validation

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Services/RewindCorrection.php`

**Tasks:**
- [ ] Implement RewindCorrection class
- [ ] Implement signal emission integration
- [ ] Test with real validation pipeline
- [ ] Test listener for approval event

---

### STORY 2.4: RollbackProcessor – rollbackOriginal()
**Acceptance Criteria:**
- [ ] Method signature: rollbackOriginal(originalProcessId, correctionProcess) : array
- [ ] Validates: correction process is in processed state
- [ ] Steps:
  1. [ ] Mark original as rolled-back
  2. [ ] Mark correction as processed (now active)
  3. [ ] Archive original entity (mark is_active: false, show in history)
  4. [ ] Handle cascade downstream processes
  5. [ ] Notify affected users
- [ ] Return: {status: 'rollback-complete', original_process_id: ..., correction_process_id: ..., downstream_affected: count}
- [ ] Test: Original state transition correct
- [ ] Test: Correction marked as active
- [ ] Test: Entity archived, not deleted
- [ ] Test: Cascade handling correct
- [ ] Test: All users notified

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Services/RollbackProcessor.php`

**Tasks:**
- [ ] Implement RollbackProcessor class
- [ ] Implement entity archival (non-destructive)
- [ ] Test state transitions
- [ ] Test cascade handling
- [ ] Add logging for audit trail

---

### STORY 2.5: RollbackProcessor – canReuseDownstreamProcess()
**Acceptance Criteria:**
- [ ] Method signature: canReuseDownstreamProcess(downstream, original) : bool
- [ ] Checks:
  - [ ] Is process in awaiting-correction state?
  - [ ] Do field requirements match?
  - [ ] Is field compatibility >95%?
- [ ] Return: true if can reuse, false if must reissue
- [ ] Test: Compatible processes detected
- [ ] Test: Incompatible processes rejected
- [ ] Test: Edge cases handled

**Files:**
- [ ] (Part of `System/Services/RollbackProcessor.php`)

**Tasks:**
- [ ] Implement compatibility checking logic
- [ ] Test with various field combinations
- [ ] Define compatibility scoring

---

### STORY 2.6: RollbackProcessor – updateDownstreamData()
**Acceptance Criteria:**
- [ ] Method signature: updateDownstreamData(downstreamData, newParentData) : array
- [ ] Intelligently merges parent correction into downstream
- [ ] Rules:
  - [ ] Don't overwrite downstream modifications
  - [ ] Update inherited fields only
  - [ ] Preserve downstream-specific values
- [ ] Return: merged data array
- [ ] Test: Inherited fields updated
- [ ] Test: Downstream modifications preserved
- [ ] Test: No data loss

**Files:**
- [ ] (Part of `System/Services/RollbackProcessor.php`)

**Tasks:**
- [ ] Implement field merging logic
- [ ] Test with real data structures
- [ ] Define merge rules

---

### STORY 2.7: RollbackProcessor – handleDownstreamAfterRollback()
**Acceptance Criteria:**
- [ ] Method signature: handleDownstreamAfterRollback(downstreamId, originalProcess) : void
- [ ] For each downstream in awaiting-correction:
  - [ ] If canReuse: update data, resume processing
  - [ ] If cannot reuse: mark for reissue (new process created)
- [ ] Test: Reusable processes updated and resumed
- [ ] Test: Non-reusable processes marked for reissue
- [ ] Test: No processes lost

**Files:**
- [ ] (Part of `System/Services/RollbackProcessor.php`)

**Tasks:**
- [ ] Implement cascade handling logic
- [ ] Test reuse path
- [ ] Test reissue path
- [ ] Test with deep cascades (3+ levels)

---

### STORY 2.8: RewindConflictDetector – detectRewindConflicts()
**Acceptance Criteria:**
- [ ] Method signature: detectRewindConflicts(original, correctionData) : array
- [ ] Detects:
  1. [ ] Entity-modified conflict (entity changed since original process)
  2. [ ] Deep-cascade conflict (grandchild processes exist)
  3. [ ] External-transaction conflict (Stripe charge, SMS sent, etc.)
- [ ] For each conflict:
  - [ ] Type
  - [ ] Severity (high or critical)
  - [ ] Message
  - [ ] Details (entity_id, charge_id, etc.)
  - [ ] Resolution (recommended action)
- [ ] Return: array of conflicts
- [ ] Test: All 3 conflict types detected
- [ ] Test: Severity correctly assigned
- [ ] Test: No false positives

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Services/RewindConflictDetector.php`

**Tasks:**
- [ ] Implement conflict detection logic
- [ ] Test each conflict type individually
- [ ] Test combination of conflicts
- [ ] Add external service integration (Stripe)

---

### STORY 2.9: RewindConflictDetector – handleConflict()
**Acceptance Criteria:**
- [ ] Method signature: handleConflict(conflict, originalProcess) : void
- [ ] Rules:
  - [ ] Critical: Mark as CONFLICTED state, notify admin, require manual review
  - [ ] High: Ask user for decision (overwrite or manual merge)
- [ ] Test: Critical conflicts escalate to admin
- [ ] Test: High conflicts prompt user
- [ ] Test: Notifications sent

**Files:**
- [ ] (Part of `System/Services/RewindConflictDetector.php`)

**Tasks:**
- [ ] Implement escalation logic
- [ ] Test admin notification
- [ ] Test user prompting

---

### STORY 2.10: RewindAuditService – recordRewindHistory()
**Acceptance Criteria:**
- [ ] Method signature: recordRewindHistory(processId) : array
- [ ] Returns:
  - [ ] original_process metadata
  - [ ] rewind_history: all corrections submitted, approved, reasons
  - [ ] downstream_affected: list with status
- [ ] Builds from ProcessStateHistory (immutable)
- [ ] Builds from RewindAuditRecord
- [ ] Test: Complete history recorded
- [ ] Test: All timestamps correct
- [ ] Test: No data loss

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Services/RewindAuditService.php` (ENHANCE)

**Tasks:**
- [ ] Implement history recording
- [ ] Test with real rewind scenario
- [ ] Test data integrity

---

### STORY 2.11: RewindAuditService – getStateHistory()
**Acceptance Criteria:**
- [ ] Method signature: getStateHistory(processId) : Collection
- [ ] Returns: immutable state history for process
- [ ] Ordered chronologically
- [ ] Includes: from_state, to_state, transitioned_at, reason
- [ ] Test: Correct order
- [ ] Test: All transitions included
- [ ] Test: Performance <50ms

**Files:**
- [ ] (Part of `System/Services/RewindAuditService.php`)

**Tasks:**
- [ ] Query ProcessStateHistory
- [ ] Test ordering
- [ ] Test performance

---

### STORY 2.12: RewindAuditService – printRewindTimeline()
**Acceptance Criteria:**
- [ ] Method signature: printRewindTimeline(processId) : void
- [ ] Console output showing:
  - [ ] ORIGINAL: created_at, processed_at, entity_id
  - [ ] CORRECTION(s): reason, submitted_at, approved_at, changes
  - [ ] DOWNSTREAM_AFFECTED: list with status
- [ ] Formatted for readability
- [ ] Test: Correct output for simple correction
- [ ] Test: Correct output for complex cascade

**Files:**
- [ ] (Part of `System/Services/RewindAuditService.php`)

**Tasks:**
- [ ] Implement timeline formatting
- [ ] Test output
- [ ] Make pretty for console

---

### STORY 2.13: RewindNotificationService
**Acceptance Criteria:**
- [ ] Method signature: notifyRewindInitiated(users, process) : void
- [ ] Method signature: notifyRollbackComplete(users, process) : void
- [ ] Method signature: escalateConflict(conflict, adminId) : void
- [ ] Sends via configured channels (mail, in_app, slack)
- [ ] Includes: process_id, reason, affected_processes, action_required
- [ ] Test: Notifications queued
- [ ] Test: Correct recipients
- [ ] Test: Correct content

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Services/RewindNotificationService.php`

**Tasks:**
- [ ] Implement notification service
- [ ] Create notification classes
- [ ] Test each notification type
- [ ] Test multi-channel delivery

---

### STORY 2.14: Testing – Service Tests
**Acceptance Criteria:**
- [ ] Integration tests for each service
- [ ] Test happy path for each scenario
- [ ] Test error scenarios
- [ ] Test database transactions
- [ ] 90%+ code coverage on services
- [ ] All tests pass

**Files:**
- [ ] `tests/Feature/RewindEngineTest.php`
- [ ] `tests/Feature/CorrectionSubmissionTest.php`
- [ ] `tests/Feature/RollbackProcessorTest.php`
- [ ] `tests/Feature/ConflictDetectionTest.php`
- [ ] `tests/Feature/AuditServiceTest.php`
- [ ] `tests/Feature/NotificationServiceTest.php`

**Tasks:**
- [ ] Write comprehensive test suite
- [ ] Test with transaction rollback
- [ ] Test with real process chains
- [ ] Run code coverage

---

### ✓ PHASE 2 COMPLETE WHEN:
- All 7 service classes implemented
- RewindEngine: initiateRewind + analyzeRewindImpact ✓
- RewindCorrection: submitCorrection ✓
- RollbackProcessor: rollbackOriginal + cascade handling ✓
- RewindConflictDetector: all 3 conflict types ✓
- RewindAuditService: complete history + timeline ✓
- RewindNotificationService: multi-channel notifications ✓
- 90%+ test coverage on all services
- All tests passing
- Services integrated and working E2E

---

## PHASE 3: CONTROLLERS & HTTP (Week 2.5–3)

### STORY 3.1: RewindProcessController – Setup
**Acceptance Criteria:**
- [ ] Controller class created
- [ ] Dependency injection: RewindEngine, RewindCorrection, RollbackProcessor, RewindConflictDetector, RewindAuditService
- [ ] Auth middleware applied
- [ ] Test: Controller instantiates

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Http/Controllers/RewindProcessController.php`

**Tasks:**
- [ ] Create controller
- [ ] Set up dependencies
- [ ] Add middleware

---

### STORY 3.2: RewindProcessController – initiateRewind (Endpoint)
**Acceptance Criteria:**
- [ ] Route: POST /rewind/{processId}
- [ ] Request: { reason: string }
- [ ] Validates: processId exists, is rewindable, user authorized
- [ ] Calls: RewindEngine::initiateRewind()
- [ ] Response: 200 {status: 'rewind-initiated', affected_processes: count, impact: {...}}
- [ ] Error: 404 (not found), 409 (not rewindable), 403 (unauthorized)
- [ ] Test: Valid rewind returns 200
- [ ] Test: Invalid process returns 404
- [ ] Test: Correct response structure

**Files:**
- [ ] (Part of `RewindProcessController.php`)

**Tasks:**
- [ ] Implement endpoint
- [ ] Create RewindInitiateRequest validation
- [ ] Test all error scenarios
- [ ] Test response format

---

### STORY 3.3: RewindProcessController – analyzeImpact (Endpoint)
**Acceptance Criteria:**
- [ ] Route: GET /rewind/{processId}/impact
- [ ] Returns: {affected_processes: [...], affected_users: [...], created_entities: [...], summary: {...}}
- [ ] Test: Correct structure
- [ ] Test: Accurate counts
- [ ] Test: Performance <500ms

**Files:**
- [ ] (Part of `RewindProcessController.php`)

**Tasks:**
- [ ] Implement endpoint
- [ ] Test with various process chains
- [ ] Test performance

---

### STORY 3.4: RewindProcessController – submitCorrection (Endpoint)
**Acceptance Criteria:**
- [ ] Route: POST /rewind/{processId}/correction
- [ ] Request: { corrected_data: {...} }
- [ ] Validates: processId in rewinding state
- [ ] Calls: RewindCorrection::submitCorrection()
- [ ] Response: 201 {status: 'correction-submitted', original_process: ..., correction_process: ..., next_step: '...'}
- [ ] Error: 400 (invalid data), 409 (not in rewinding state)
- [ ] Test: Valid correction returns 201
- [ ] Test: Invalid data returns 400
- [ ] Test: Correction queued for validation

**Files:**
- [ ] (Part of `RewindProcessController.php`)

**Tasks:**
- [ ] Implement endpoint
- [ ] Create CorrectionSubmitRequest validation
- [ ] Test request validation
- [ ] Test response

---

### STORY 3.5: RewindProcessController – showConflicts (Endpoint)
**Acceptance Criteria:**
- [ ] Route: GET /rewind/{processId}/conflicts
- [ ] Returns: [{type: ..., severity: ..., message: ..., details: ..., resolution: ...}, ...]
- [ ] Test: Returns all conflicts for process
- [ ] Test: No conflicts returns empty array

**Files:**
- [ ] (Part of `RewindProcessController.php`)

**Tasks:**
- [ ] Implement endpoint
- [ ] Test with conflicts
- [ ] Test without conflicts

---

### STORY 3.6: RewindProcessController – resolveConflict (Endpoint)
**Acceptance Criteria:**
- [ ] Route: POST /rewind/{processId}/conflicts/{conflictId}/resolve
- [ ] Request: { decision: 'overwrite'|'manual_merge'|'reissue' }
- [ ] Admin only (middleware)
- [ ] Calls: RewindConflictDetector::handleConflict()
- [ ] Response: 200 {status: 'conflict-resolved', decision: '...', next_step: '...'}
- [ ] Error: 403 (not admin), 404 (conflict not found)
- [ ] Test: Admin can resolve
- [ ] Test: Non-admin gets 403
- [ ] Test: Decision persisted

**Files:**
- [ ] (Part of `RewindProcessController.php`)

**Tasks:**
- [ ] Implement endpoint
- [ ] Create ConflictResolutionRequest validation
- [ ] Add admin middleware
- [ ] Test authorization

---

### STORY 3.7: RewindProcessController – getAuditTrail (Endpoint)
**Acceptance Criteria:**
- [ ] Route: GET /rewind/{processId}/audit-trail
- [ ] Returns: {original_process: {...}, rewind_history: [...], downstream_affected: [...]}
- [ ] Test: Complete history returned
- [ ] Test: All corrections included
- [ ] Test: Performance <1 second

**Files:**
- [ ] (Part of `RewindProcessController.php`)

**Tasks:**
- [ ] Implement endpoint
- [ ] Test with complex rewinds
- [ ] Test performance

---

### STORY 3.8: RewindProcessController – getTimeline (Endpoint)
**Acceptance Criteria:**
- [ ] Route: GET /rewind/{processId}/timeline
- [ ] Returns: formatted timeline (for console or UI display)
- [ ] Format:
  ```
  ORIGINAL: Created at ..., Processed at ...
  CORRECTION: Rewind reason ..., submitted at ..., approved at ...
  DOWNSTREAM: N processes affected
  ```
- [ ] Test: Formatted correctly
- [ ] Test: All information included

**Files:**
- [ ] (Part of `RewindProcessController.php`)

**Tasks:**
- [ ] Implement endpoint
- [ ] Format response nicely
- [ ] Test with various scenarios

---

### STORY 3.9: Request Validation Classes
**Acceptance Criteria:**
- [ ] RewindInitiateRequest:
  - [ ] reason: required, string, 10–500 chars
- [ ] CorrectionSubmitRequest:
  - [ ] corrected_data: required, array, no empty values
  - [ ] Validates against schema (TBD)
- [ ] ConflictResolutionRequest:
  - [ ] decision: required, in:overwrite,manual_merge,reissue
- [ ] Test: Valid requests pass
- [ ] Test: Invalid requests fail with proper messages

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Http/Requests/RewindInitiateRequest.php`
- [ ] `app/Extensions/TitanRewind/System/Http/Requests/CorrectionSubmitRequest.php`
- [ ] `app/Extensions/TitanRewind/System/Http/Requests/ConflictResolutionRequest.php`

**Tasks:**
- [ ] Write validation classes
- [ ] Test each rule
- [ ] Test error messages

---

### STORY 3.10: Response Resource Classes
**Acceptance Criteria:**
- [ ] RewindProcessResource: Single process with full state, timeline
- [ ] RewindImpactResource: Impact analysis (affected processes, users, entities)
- [ ] RewindConflictResource: Conflict details with resolution options
- [ ] RewindAuditTrailResource: Complete audit trail with corrections
- [ ] Each resource:
  - [ ] Includes relevant fields only
  - [ ] Formats dates consistently
  - [ ] Includes relationships when appropriate
- [ ] Test: All fields present
- [ ] Test: Proper formatting
- [ ] Test: No sensitive data leaked

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Http/Resources/RewindProcessResource.php`
- [ ] `app/Extensions/TitanRewind/System/Http/Resources/RewindImpactResource.php`
- [ ] `app/Extensions/TitanRewind/System/Http/Resources/RewindConflictResource.php`
- [ ] `app/Extensions/TitanRewind/System/Http/Resources/RewindAuditTrailResource.php`

**Tasks:**
- [ ] Write resource classes
- [ ] Test formatting
- [ ] Test with real data

---

### STORY 3.11: Routes – Web & API
**Acceptance Criteria:**
- [ ] Routes file: `routes/api.php`
- [ ] All 7 endpoints registered
- [ ] Proper HTTP verbs (GET, POST)
- [ ] Auth middleware applied
- [ ] Resource controllers used where applicable
- [ ] Test: Routes registered
- [ ] Test: Correct middleware applied

**Files:**
- [ ] `routes/api.php` (NEW)
- [ ] `routes/web.php` (ENHANCE if needed)

**Tasks:**
- [ ] Write routes
- [ ] Test all endpoints accessible
- [ ] Test auth middleware

---

### STORY 3.12: Testing – Controller Tests
**Acceptance Criteria:**
- [ ] Feature tests for each endpoint
- [ ] Test happy path
- [ ] Test error scenarios
- [ ] Test authorization
- [ ] Test request validation
- [ ] Test response format
- [ ] 90%+ coverage
- [ ] All tests pass

**Files:**
- [ ] `tests/Feature/RewindInitiationEndpointTest.php`
- [ ] `tests/Feature/CorrectionSubmissionEndpointTest.php`
- [ ] `tests/Feature/ConflictResolutionEndpointTest.php`
- [ ] `tests/Feature/AuditTrailEndpointTest.php`

**Tasks:**
- [ ] Write comprehensive endpoint tests
- [ ] Test each endpoint with real data
- [ ] Test error responses
- [ ] Run code coverage

---

### ✓ PHASE 3 COMPLETE WHEN:
- RewindProcessController fully implemented with 7 endpoints ✓
- All request validation classes created ✓
- All response resource classes created ✓
- Routes registered and tested ✓
- 90%+ coverage on controller layer
- All HTTP tests passing
- API documentation complete

---

## PHASE 4: QUEUE & ASYNC (Week 3)

### STORY 4.1: InitiateRewindJob
**Acceptance Criteria:**
- [ ] Job queued for async rewind initiation
- [ ] Handles RewindEngine::initiateRewind()
- [ ] Failed jobs retry 3x
- [ ] Logs to rewind audit trail on success/failure
- [ ] Test: Job enqueued and processed
- [ ] Test: Retry logic works
- [ ] Test: Audit trail updated

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Jobs/InitiateRewindJob.php`

**Tasks:**
- [ ] Implement job class
- [ ] Test job dispatch
- [ ] Test retry logic

---

### STORY 4.2: ProcessCascadeJob
**Acceptance Criteria:**
- [ ] Job queued for cascade updates
- [ ] Batches downstream process updates
- [ ] Handles both reuse and reissue paths
- [ ] Failed jobs retry 3x
- [ ] Logs progress to audit trail
- [ ] Test: Job processes cascade correctly
- [ ] Test: Batch processing works
- [ ] Test: All downstream processes handled

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Jobs/ProcessCascadeJob.php`

**Tasks:**
- [ ] Implement job class
- [ ] Test cascade processing
- [ ] Test batch functionality

---

### STORY 4.3: RefundExternalTransactionJob
**Acceptance Criteria:**
- [ ] Job queued for Stripe/PayPal refunds
- [ ] Idempotent (safe for retries with same data)
- [ ] Handles 429 rate limiting from payment APIs
- [ ] Failed jobs retry 5x with exponential backoff
- [ ] Logs refund request and response to audit trail
- [ ] Test: Refund initiated correctly
- [ ] Test: Idempotent processing
- [ ] Test: Audit trail updated

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Jobs/RefundExternalTransactionJob.php`

**Tasks:**
- [ ] Implement job class
- [ ] Add Stripe SDK integration
- [ ] Test refund logic
- [ ] Test retry logic

---

### STORY 4.4: ProcessRewindQueue Command (Enhance)
**Acceptance Criteria:**
- [ ] Command: `php artisan rewind:process-queue`
- [ ] Processes queued rewind jobs
- [ ] Handles failed cascades with retry logic
- [ ] Logs results to audit trail
- [ ] Can be run on schedule (cron)
- [ ] Test: Command runs successfully
- [ ] Test: Jobs processed
- [ ] Test: Failures handled

**Files:**
- [ ] `app/Extensions/TitanRewind/System/Console/Commands/ProcessRewindQueue.php` (ENHANCE)

**Tasks:**
- [ ] Implement queue processing
- [ ] Add logging
- [ ] Test with Redis queue

---

### STORY 4.5: Queue Configuration
**Acceptance Criteria:**
- [ ] Queue driver: Redis (default) or fallback to database
- [ ] 3 queues defined:
  - [ ] rewind (default): rewind initiation
  - [ ] cascade (default): cascade processing
  - [ ] refunds (high priority): external refunds
- [ ] Test: Jobs routed to correct queues
- [ ] Test: Retry configuration applied

**Files:**
- [ ] `config/queue.php` (system config, reference in extension)
- [ ] `config/titan-rewind.php` (ENHANCE)

**Tasks:**
- [ ] Configure queue settings
- [ ] Test job routing
- [ ] Test with Redis locally

---

### STORY 4.6: Testing – Queue Tests
**Acceptance Criteria:**
- [ ] Test each job class in isolation
- [ ] Test job dispatch
- [ ] Test job processing
- [ ] Test retry logic
- [ ] Test failure handling
- [ ] 90%+ coverage
- [ ] All tests pass

**Files:**
- [ ] `tests/Feature/InitiateRewindJobTest.php`
- [ ] `tests/Feature/ProcessCascadeJobTest.php`
- [ ] `tests/Feature/RefundExternalTransactionJobTest.php`

**Tasks:**
- [ ] Write queue tests
- [ ] Test with fake queue
- [ ] Test real queue with Redis

---

### ✓ PHASE 4 COMPLETE WHEN:
- All 3 job classes implemented ✓
- ProcessRewindQueue command enhanced ✓
- Queue configuration complete ✓
- 90%+ coverage on queue layer
- All queue tests passing
- Jobs tested locally with Redis

---

## PHASE 5: TESTING & DOCUMENTATION (Week 3.5–4)

### STORY 5.1: Feature Test Suites
**Acceptance Criteria:**
- [ ] 8 comprehensive feature test suites:
  1. [ ] RewindInitiationTest (10 tests)
  2. [ ] CorrectionSubmissionTest (10 tests)
  3. [ ] RollbackProcessorTest (15 tests)
  4. [ ] ConflictDetectionTest (12 tests)
  5. [ ] AuditTrailTest (10 tests)
  6. [ ] NotificationTest (8 tests)
  7. [ ] CascadeHandlingTest (15 tests)
  8. [ ] IntegrationTest (full E2E scenarios) (20 tests)
- [ ] ~100 total feature tests
- [ ] All tests pass

**Files:**
- [ ] `tests/Feature/RewindInitiationTest.php`
- [ ] `tests/Feature/CorrectionSubmissionTest.php`
- [ ] `tests/Feature/RollbackProcessorTest.php`
- [ ] `tests/Feature/ConflictDetectionTest.php`
- [ ] `tests/Feature/AuditTrailTest.php`
- [ ] `tests/Feature/NotificationTest.php`
- [ ] `tests/Feature/CascadeHandlingTest.php`
- [ ] `tests/Feature/IntegrationTest.php`

**Tasks:**
- [ ] Write comprehensive test suites
- [ ] Test happy paths
- [ ] Test error scenarios
- [ ] Test edge cases

---

### STORY 5.2: Unit Test Suites
**Acceptance Criteria:**
- [ ] 2 comprehensive unit test suites:
  1. [ ] ProcessStateTest (20 tests on state machine logic)
  2. [ ] ConflictDetectorTest (15 tests on detection logic)
- [ ] ~35 total unit tests
- [ ] All tests pass

**Files:**
- [ ] `tests/Unit/ProcessStateTest.php`
- [ ] `tests/Unit/ConflictDetectorTest.php`

**Tasks:**
- [ ] Write unit tests
- [ ] Test state transitions
- [ ] Test conflict detection logic

---

### STORY 5.3: Code Coverage
**Acceptance Criteria:**
- [ ] Overall coverage: 90%+
- [ ] All services: 90%+
- [ ] All models: 90%+
- [ ] All controllers: 85%+ (view methods harder to test)
- [ ] Coverage report generated
- [ ] Test: Run `php artisan test --coverage`

**Tasks:**
- [ ] Run code coverage
- [ ] Identify and fill gaps
- [ ] Generate coverage reports

---

### STORY 5.4: Documentation – REWIND_ARCHITECTURE.md
**Acceptance Criteria:**
- [ ] Complete system overview
- [ ] State machine diagram (ASCII or text)
- [ ] Process lifecycle explanation (13 states)
- [ ] Cascade handling logic explanation
- [ ] Conflict detection rules
- [ ] Database schema overview
- [ ] Service layer overview
- [ ] Queue architecture
- [ ] External integrations (Stripe, SMS, etc.)
- [ ] Test: Documentation clear and complete

**Files:**
- [ ] `docs/REWIND_ARCHITECTURE.md`

**Tasks:**
- [ ] Write comprehensive architecture doc
- [ ] Create diagrams
- [ ] Review for clarity

---

### STORY 5.5: Documentation – REWIND_API.md
**Acceptance Criteria:**
- [ ] All 7 endpoints documented
- [ ] For each endpoint:
  - [ ] Method and path
  - [ ] Required parameters
  - [ ] Example request
  - [ ] Example response (200, 400, 404, 409, etc.)
  - [ ] Error codes and handling
- [ ] Authentication requirements
- [ ] Rate limiting (if applicable)
- [ ] Pagination (if applicable)
- [ ] Test: API docs accurate and complete

**Files:**
- [ ] `docs/REWIND_API.md`

**Tasks:**
- [ ] Write API documentation
- [ ] Include all endpoints
- [ ] Include examples
- [ ] Keep updated with code

---

### STORY 5.6: Documentation – REWIND_SCENARIOS.md
**Acceptance Criteria:**
- [ ] Scenario 1: Simple field correction
  - [ ] Data example (booking with wrong date)
  - [ ] Step-by-step walkthrough
  - [ ] Expected state transitions
  - [ ] Expected audit trail
- [ ] Scenario 2: Complex cascade
  - [ ] Data example (booking→job→invoice→payment)
  - [ ] Rewind initiation
  - [ ] Cascade detection
  - [ ] Rollback and recovery
  - [ ] Expected audit trail
- [ ] Scenario 3: Conflict handling
  - [ ] External transaction (Stripe charge)
  - [ ] Conflict detection and escalation
  - [ ] Manual resolution
  - [ ] Refund processing
- [ ] Test: Scenarios clear and realistic

**Files:**
- [ ] `docs/REWIND_SCENARIOS.md`

**Tasks:**
- [ ] Write detailed scenario walkthroughs
- [ ] Include data examples
- [ ] Include expected outcomes

---

### STORY 5.7: Documentation – MIGRATION_GUIDE.md
**Acceptance Criteria:**
- [ ] How to migrate existing processes to TitanRewind
- [ ] Mapping existing entities to process records
- [ ] Backfilling historical state
- [ ] Data validation
- [ ] Rollback plan
- [ ] Testing checklist
- [ ] Test: Guide clear and actionable

**Files:**
- [ ] `docs/MIGRATION_GUIDE.md`

**Tasks:**
- [ ] Write migration guide
- [ ] Include migration scripts
- [ ] Include validation steps

---

### STORY 5.8: Documentation – DEVELOPER_GUIDE.md
**Acceptance Criteria:**
- [ ] How to integrate TitanRewind into extensions
- [ ] Emitting signals
- [ ] Listening for rewind events
- [ ] Custom cascade handling
- [ ] Custom conflict detection
- [ ] Event hooks
- [ ] Code examples
- [ ] Test: Guide clear and usable

**Files:**
- [ ] `docs/DEVELOPER_GUIDE.md`

**Tasks:**
- [ ] Write developer guide
- [ ] Include code examples
- [ ] Document event system

---

### STORY 5.9: README Update
**Acceptance Criteria:**
- [ ] Update root README with:
  - [ ] Quick overview of TitanRewind
  - [ ] Link to full docs
  - [ ] Quick-start example
  - [ ] Common use cases
- [ ] Test: README informative

**Files:**
- [ ] `README.md` (or `docs/README.md`)

**Tasks:**
- [ ] Update README
- [ ] Add quick-start
- [ ] Add links to docs

---

### STORY 5.10: Testing – Full Integration
**Acceptance Criteria:**
- [ ] End-to-end test of complete workflow:
  1. [ ] Create process
  2. [ ] Process reaches processed state
  3. [ ] Initiate rewind
  4. [ ] Verify impact analysis
  5. [ ] Submit correction
  6. [ ] Correction approved
  7. [ ] Rollback completed
  8. [ ] Audit trail created
  9. [ ] All notifications sent
  10. [ ] Cascade handled
- [ ] Test: All steps succeed
- [ ] Test: State transitions correct
- [ ] Test: Audit trail complete

**Files:**
- [ ] `tests/Feature/IntegrationTest.php`

**Tasks:**
- [ ] Write full integration test
- [ ] Test complete workflow
- [ ] Verify all side effects

---

### ✓ PHASE 5 COMPLETE WHEN:
- 8 feature test suites implemented (~100 tests) ✓
- 2 unit test suites implemented (~35 tests) ✓
- 90%+ code coverage achieved ✓
- All tests passing ✓
- 6 documentation files written ✓
- README updated ✓
- Full integration test passing ✓

---

## ✓ OVERALL COMPLETION CRITERIA

- [ ] All 42 stories completed
- [ ] All code written and reviewed
- [ ] 90%+ test coverage
- [ ] All ~135 tests passing
- [ ] Zero critical bugs
- [ ] All 6 documentation files written
- [ ] Code committed to git with clear messages
- [ ] Ready for staging deployment
- [ ] Architecture review completed
- [ ] Performance testing completed
- [ ] Security review completed

---

**END OF IMPLEMENTATION CHECKLIST**

Detailed story breakdown ready for sprint planning and development. Each story includes acceptance criteria, files to create/modify, and specific tasks. Estimated 196 hours (~4 weeks full-time development).
