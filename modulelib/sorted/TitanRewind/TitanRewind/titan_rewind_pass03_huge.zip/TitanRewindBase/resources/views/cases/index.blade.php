@extends('layouts.app')

@section('content')
<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0">TitanRewind — Cases</h3>
  </div>

  @if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
  @endif

  <div class="card mb-3">
    <div class="card-header"><strong>Initiate Rewind</strong></div>
    <div class="card-body">
      <form method="POST" action="{{ route('titanrewind.cases.initiate') }}" class="row g-3">
        @csrf
        <div class="col-md-3"><input class="form-control" name="process_id" placeholder="process_id"></div>
        <div class="col-md-3"><input class="form-control" name="entity_type" placeholder="entity_type" required></div>
        <div class="col-md-2"><input class="form-control" name="entity_id" placeholder="entity_id"></div>
        <div class="col-md-2"><input class="form-control" name="severity" value="high" placeholder="severity"></div>
        <div class="col-md-12"><textarea class="form-control" name="reason" rows="2" placeholder="Why does this need rewinding?" required></textarea></div>
        <div class="col-md-12"><button class="btn btn-primary" type="submit">Start Rewind</button></div>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="table-responsive">
      <table class="table mb-0">
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Entity</th>
            <th>Severity</th>
            <th>Status</th>
            <th>Detected</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          @forelse($cases as $c)
            <tr>
              <td>#{{ $c->id }}</td>
              <td>{{ $c->title }}</td>
              <td><code>{{ $c->entity_type }}</code>@if($c->entity_id) #{{ $c->entity_id }} @endif</td>
              <td><span class="badge bg-secondary">{{ $c->severity }}</span></td>
              <td><span class="badge bg-{{ in_array($c->status, ['resolved','rolled-back']) ? 'success' : ($c->status === 'conflict-hold' ? 'danger' : 'warning') }}">{{ $c->status }}</span></td>
              <td>{{ optional($c->detected_at)->format('Y-m-d H:i') }}</td>
              <td class="text-end">
                <a class="btn btn-sm btn-primary" href="{{ route('titanrewind.cases.show', ['case' => $c->id]) }}">Open</a>
              </td>
            </tr>
          @empty
            <tr><td colspan="7" class="text-center text-muted p-4">No cases yet.</td></tr>
          @endforelse
        </tbody>
      </table>
    </div>
  </div>

  <div class="mt-3">{{ $cases->links() }}</div>
</div>
@endsection
