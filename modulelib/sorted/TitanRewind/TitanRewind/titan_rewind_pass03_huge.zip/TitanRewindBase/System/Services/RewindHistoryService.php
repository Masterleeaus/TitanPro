<?php

namespace App\Extensions\TitanRewind\System\Services;

use Illuminate\Support\Facades\DB;
use App\Extensions\TitanRewind\System\Models\RewindCase;

class RewindHistoryService
{
    public function __construct(private readonly RewindAuditService $audit)
    {
    }

    public function history(RewindCase $case): array
    {
        $timeline = $this->audit->timeline($case->company_id, $case->id);
        $links = DB::table('tz_rewind_links')
            ->where('company_id', $case->company_id)
            ->where('case_id', $case->id)
            ->orderBy('depth')
            ->orderBy('id')
            ->get()
            ->map(fn ($link) => [
                'id' => $link->id,
                'parent_process_id' => $link->parent_process_id,
                'child_process_id' => $link->child_process_id,
                'parent_entity_type' => $link->parent_entity_type,
                'parent_entity_id' => $link->parent_entity_id,
                'child_entity_type' => $link->child_entity_type,
                'child_entity_id' => $link->child_entity_id,
                'relationship_type' => $link->relationship_type,
                'depth' => (int) ($link->depth ?? 1),
                'status' => $link->status ?? 'held',
                'action_required' => $link->action_required,
                'can_reuse' => (bool) $link->can_reuse,
                'must_reissue' => (bool) $link->must_reissue,
                'meta_json' => json_decode($link->meta_json ?? '[]', true) ?: [],
            ])->all();

        $actions = DB::table('titan_rewind_actions')
            ->where('company_id', $case->company_id)
            ->where('case_id', $case->id)
            ->orderBy('id')
            ->get()
            ->map(fn ($action) => [
                'id' => $action->id,
                'action_type' => $action->action_type,
                'target_type' => $action->target_type,
                'target_id' => $action->target_id,
                'success' => (bool) $action->success,
                'executed_at' => optional($action->executed_at)->toIso8601String(),
                'after_json' => json_decode($action->after_json ?? '[]', true) ?: [],
                'error_text' => $action->error_text,
            ])->all();

        $conflicts = DB::table('tz_rewind_conflicts')
            ->where('company_id', $case->company_id)
            ->where('case_id', $case->id)
            ->orderBy('id')
            ->get()
            ->map(fn ($conflict) => [
                'id' => $conflict->id,
                'conflict_type' => $conflict->conflict_type,
                'severity' => $conflict->severity,
                'status' => $conflict->status,
                'message' => $conflict->message,
                'resolution_hint' => $conflict->resolution_hint,
                'resolved_at' => $conflict->resolved_at,
                'resolved_by_id' => $conflict->resolved_by_id,
            ])->all();

        return [
            'case' => [
                'id' => $case->id,
                'status' => $case->status,
                'severity' => $case->severity,
                'process_id' => $case->process_id,
                'correction_process_id' => $case->correction_process_id,
                'replacement_process_id' => $case->replacement_process_id,
                'entity_type' => $case->entity_type,
                'entity_id' => $case->entity_id,
                'detected_at' => optional($case->detected_at)->toIso8601String(),
                'rollback_completed_at' => optional($case->rollback_completed_at)->toIso8601String(),
            ],
            'timeline' => $timeline,
            'links' => $links,
            'actions' => $actions,
            'conflicts' => $conflicts,
            'counts' => [
                'timeline' => count($timeline),
                'links' => count($links),
                'actions' => count($actions),
                'conflicts' => count($conflicts),
            ],
        ];
    }
}
