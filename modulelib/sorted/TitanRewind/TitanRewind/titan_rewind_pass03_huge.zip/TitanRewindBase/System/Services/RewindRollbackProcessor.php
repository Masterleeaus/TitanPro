<?php

namespace App\Extensions\TitanRewind\System\Services;

use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use App\Extensions\TitanRewind\System\Models\RewindCase;

class RewindRollbackProcessor
{
    public function __construct(private readonly RewindAuditService $audit, private readonly RewindNotificationService $notifications)
    {
    }

    public function submitCorrection(RewindCase $case, array $correctionData, array $actor): array
    {
        return DB::transaction(function () use ($case, $correctionData, $actor) {
            $correctionProcessId = (string) ($correctionData['process_id'] ?? ('corr-' . $case->id . '-' . now()->timestamp));
            $existingMeta = $case->meta_json ?? [];
            $existingMeta['correction'] = [
                'submitted_at' => now()->toIso8601String(),
                'submitted_by' => $actor,
                'correction_process_id' => $correctionProcessId,
                'correction_data' => $correctionData,
            ];

            $case->status = 'awaiting-correction';
            $case->correction_process_id = $correctionProcessId;
            $case->meta_json = $existingMeta;
            $case->save();

            DB::table('tz_rewind_links')
                ->where('company_id', $case->company_id)
                ->where('case_id', $case->id)
                ->update([
                    'status' => 'held',
                    'held_reason' => 'Parent rewind awaiting corrected process approval.',
                    'updated_at' => now(),
                ]);

            $this->audit->appendEvent([
                'company_id' => $case->company_id,
                'team_id' => $case->team_id,
                'user_id' => $case->user_id,
                'case_id' => $case->id,
                'event_type' => 'correction_submitted',
                'entity_type' => $case->entity_type,
                'entity_id' => $case->entity_id,
                'actor_type' => $actor['type'] ?? 'user',
                'actor_id' => $actor['id'] ?? null,
                'payload_json' => ['correction_process_id' => $correctionProcessId, 'correction_data' => $correctionData],
                'idempotency_key' => 'correction_submitted:' . $case->id . ':' . $correctionProcessId,
            ]);

            $notice = $this->notifications->queueCaseNotification(
                $case,
                'rewind-correction-submitted',
                'A correction was submitted and downstream work remains held until rollback completes.',
                ['correction_process_id' => $correctionProcessId]
            );

            return [
                'status' => 'correction-submitted',
                'case_id' => $case->id,
                'correction_process_id' => $correctionProcessId,
                'notifications' => $notice,
            ];
        });
    }

    public function completeRollback(RewindCase $case, array $actor, array $options = []): array
    {
        return DB::transaction(function () use ($case, $actor, $options) {
            $meta = $case->meta_json ?? [];
            $correction = Arr::get($meta, 'correction', []);
            $correctionProcessId = (string) ($options['correction_process_id'] ?? ($correction['correction_process_id'] ?? ('corr-' . $case->id)));
            $correctionEntityId = $options['correction_entity_id'] ?? Arr::get($correction, 'correction_data.entity_id');

            $meta['rollback'] = [
                'rolled_back_at' => now()->toIso8601String(),
                'rolled_back_by' => $actor,
                'correction_process_id' => $correctionProcessId,
                'correction_entity_id' => $correctionEntityId,
            ];
            $case->status = 'rolled-back';
            $case->replacement_process_id = $correctionProcessId;
            $case->meta_json = $meta;
            $case->rollback_completed_at = now();
            $case->resolved_at = now();
            $case->resolved_by_type = $actor['type'] ?? 'user';
            $case->resolved_by_id = $actor['id'] ?? null;
            $case->save();

            $reused = [];
            $reissued = [];
            $links = DB::table('tz_rewind_links')->where('company_id', $case->company_id)->where('case_id', $case->id)->get();
            foreach ($links as $link) {
                $mustReissue = (bool) $link->must_reissue;
                $status = $mustReissue ? 'ready-for-reissue' : 'reused';
                $actionType = $mustReissue ? 'marked-for-reissue' : 'updated-for-correction';
                $actionPayload = [
                    'case_id' => $case->id,
                    'correction_process_id' => $correctionProcessId,
                    'relationship_type' => $link->relationship_type,
                    'child_process_id' => $link->child_process_id,
                ];

                DB::table('tz_rewind_links')
                    ->where('id', $link->id)
                    ->update([
                        'status' => $status,
                        'action_required' => $mustReissue ? 'reissue' : 'resume',
                        'held_reason' => $mustReissue ? 'Must be reissued from corrected parent.' : 'Can resume from corrected parent.',
                        'updated_at' => now(),
                    ]);

                DB::table('titan_rewind_actions')->insert([
                    'company_id' => $case->company_id,
                    'team_id' => $case->team_id,
                    'user_id' => $case->user_id,
                    'case_id' => $case->id,
                    'fix_id' => null,
                    'action_type' => $actionType,
                    'target_type' => $link->child_entity_type,
                    'target_id' => $link->child_entity_id,
                    'before_json' => json_encode(['link_id' => $link->id, 'status' => $link->status ?? 'held']),
                    'after_json' => json_encode($actionPayload),
                    'executed_by_type' => $actor['type'] ?? 'user',
                    'executed_by_id' => $actor['id'] ?? null,
                    'executed_at' => now(),
                    'success' => true,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                if ($mustReissue) {
                    $reissued[] = $link->child_process_id;
                } else {
                    $reused[] = $link->child_process_id;
                }
            }

            $this->audit->appendEvent([
                'company_id' => $case->company_id,
                'team_id' => $case->team_id,
                'user_id' => $case->user_id,
                'case_id' => $case->id,
                'event_type' => 'rollback_completed',
                'entity_type' => $case->entity_type,
                'entity_id' => $case->entity_id,
                'actor_type' => $actor['type'] ?? 'user',
                'actor_id' => $actor['id'] ?? null,
                'payload_json' => [
                    'correction_process_id' => $correctionProcessId,
                    'reused' => $reused,
                    'reissued' => $reissued,
                ],
                'idempotency_key' => 'rollback_completed:' . $case->id . ':' . $correctionProcessId,
            ]);

            $notice = $this->notifications->queueCaseNotification(
                $case,
                'rewind-rollback-complete',
                'Rollback completed. Downstream items were either resumed or marked for reissue.',
                ['correction_process_id' => $correctionProcessId, 'reused' => $reused, 'reissued' => $reissued]
            );

            return [
                'status' => 'rollback-complete',
                'case_id' => $case->id,
                'correction_process_id' => $correctionProcessId,
                'reused_processes' => $reused,
                'reissued_processes' => $reissued,
                'notifications' => $notice,
            ];
        });
    }
}
