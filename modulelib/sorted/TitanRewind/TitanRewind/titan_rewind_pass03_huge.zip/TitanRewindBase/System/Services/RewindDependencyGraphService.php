<?php

namespace App\Extensions\TitanRewind\System\Services;

use Illuminate\Support\Facades\DB;

class RewindDependencyGraphService
{
    public function build(array $context): array
    {
        $companyId = $context['company_id'];
        $processId = $context['process_id'] ?? null;
        $entityType = $context['entity_type'] ?? null;
        $entityId = $context['entity_id'] ?? null;

        $existingLinks = collect();
        if ($processId && DB::getSchemaBuilder()->hasTable('tz_rewind_links')) {
            $existingLinks = DB::table('tz_rewind_links')
                ->where('company_id', $companyId)
                ->where('parent_process_id', $processId)
                ->get();
        }

        if ($existingLinks->isNotEmpty()) {
            return [
                'root' => compact('processId', 'entityType', 'entityId'),
                'nodes' => $existingLinks->map(fn ($link) => [
                    'process_id' => $link->child_process_id,
                    'entity_type' => $link->child_entity_type,
                    'entity_id' => $link->child_entity_id,
                    'depth' => (int) ($link->depth ?? 1),
                    'relationship_type' => $link->relationship_type,
                    'action_required' => $link->action_required,
                    'must_reissue' => (bool) $link->must_reissue,
                    'can_reuse' => (bool) $link->can_reuse,
                    'origin' => 'existing-link',
                ])->values()->all(),
            ];
        }

        $rules = config('titan-rewind.domain_rules', []);
        $nodes = [];
        $visited = [];
        $walk = function (string $type, int $depth = 1) use (&$walk, &$nodes, &$visited, $entityId, $rules) {
            if (isset($visited[$type])) {
                return;
            }
            $visited[$type] = true;
            $rule = $rules[$type] ?? ['children' => [], 'default_reuse' => true];
            foreach ($rule['children'] as $childType) {
                $childRule = $rules[$childType] ?? ['children' => [], 'default_reuse' => true];
                $mustReissue = !($childRule['default_reuse'] ?? true);
                $nodes[] = [
                    'process_id' => null,
                    'entity_type' => $childType,
                    'entity_id' => null,
                    'depth' => $depth,
                    'relationship_type' => 'domain-rule',
                    'action_required' => $mustReissue ? 'reissue' : 'reuse',
                    'must_reissue' => $mustReissue,
                    'can_reuse' => !$mustReissue,
                    'parent_entity_type' => $type,
                    'parent_entity_id' => $entityId,
                    'origin' => 'domain-rule',
                ];
                $walk($childType, $depth + 1);
            }
        };

        if ($entityType) {
            $walk($entityType);
        }

        return [
            'root' => compact('processId', 'entityType', 'entityId'),
            'nodes' => $nodes,
        ];
    }
}
