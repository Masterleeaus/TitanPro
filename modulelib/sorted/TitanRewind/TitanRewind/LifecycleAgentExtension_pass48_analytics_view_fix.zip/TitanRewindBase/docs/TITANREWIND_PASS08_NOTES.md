# TitanRewind Pass 08

- Added `tz_rewind_snapshots` persistence for root/downstream before/after evidence.
- Added `RewindSnapshot` model and `RewindSnapshotService`.
- Captured initiation snapshots from impact analysis and rollback completion snapshots from resolved links.
- Exposed snapshots through API route `api.titanrewind.cases.snapshots`.
- Added snapshot counts and listing to the case detail view.
- Fixed `submitCorrection()` response bug where external transaction plan variables were undefined.
