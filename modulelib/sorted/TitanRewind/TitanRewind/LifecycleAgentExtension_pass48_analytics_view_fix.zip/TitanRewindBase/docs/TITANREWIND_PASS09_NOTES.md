# TitanRewind Pass 09 Notes

## Completed
- Added company-scoped signal/process lifecycle integration service.
- Promoted rewind state changes back into `tz_processes` / `tz_process_states`.
- Emitted Pulse rollback hook actions and companion rewind signals.
- Added API/web lifecycle promotion endpoints and signal candidate endpoint.
- Enforced permission-aware access checks in web and API controllers.
- Fixed rollback completion payload bug where `snapshot_count` was referenced before capture.
- Expanded manifest/config with menu, permissions, signal, pulse, and lifecycle integration metadata.
- Updated queue command to flush notifications and pulse rollback hooks together.

## Final state
Titan Rewind now behaves as a production-grade correction and rollback core that can sit directly behind Titan Signal and ahead of Pulse orchestration.
