<?php

use App\Extensions\TitanRewind\System\Http\Controllers\TitanRewindApiController;
use Illuminate\Support\Facades\Route;

Route::middleware(['api', 'auth'])->prefix('api/titanrewind')->name('api.titanrewind.')->group(function () {
    Route::get('/cases', [TitanRewindApiController::class, 'index'])->name('cases.index');
    Route::post('/cases/initiate', [TitanRewindApiController::class, 'initiate'])->name('cases.initiate');
    Route::get('/cases/candidates', [TitanRewindApiController::class, 'candidates'])->name('cases.candidates');
    Route::get('/cases/{case}/history', [TitanRewindApiController::class, 'history'])->name('cases.history');
    Route::get('/cases/{case}/replay', [TitanRewindApiController::class, 'replay'])->name('cases.replay');
    Route::get('/cases/{case}/snapshots', [TitanRewindApiController::class, 'snapshots'])->name('cases.snapshots');
    Route::post('/cases/{case}/promote-lifecycle', [TitanRewindApiController::class, 'promoteLifecycle'])->name('cases.promoteLifecycle');
});
