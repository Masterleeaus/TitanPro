# TitanRewind Pass 04 Notes

## Added in this pass
- process bridge service that reads real `tz_processes`, `tz_process_states`, `tz_signals`, and dependency data when present
- rollback planner service that stages reuse vs reissue by depth and creates a payment refund/reissue plan
- manual review dashboard route and richer case index metrics
- plan JSON endpoint for downstream orchestration/UIs
- notification queue flushing in the console command
- show view now exposes rollback plan and process snapshot

## Architecture shift
Pass 04 moves TitanRewind from a case-centric recovery UI into a bridge layer that can read Titan Signal state directly and produce staged rollback plans for deeper orchestration.

## Remaining priorities
1. patch reusable downstream entities directly in domain adapters
2. implement real payment refund adapters
3. emit rewind state changes back into Titan Signal
4. add admin-side dashboards and approval lanes
