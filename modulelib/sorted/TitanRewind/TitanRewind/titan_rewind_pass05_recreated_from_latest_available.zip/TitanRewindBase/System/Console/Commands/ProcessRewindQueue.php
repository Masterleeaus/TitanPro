<?php

namespace App\Extensions\TitanRewind\System\Console\Commands;

use Illuminate\Console\Command;
use App\Extensions\TitanRewind\System\Services\RewindFixService;
use App\Extensions\TitanRewind\System\Services\RewindNotificationService;

class ProcessRewindQueue extends Command
{
    protected $signature = 'titanrewind:process {--limit=50 : Max fixes to process}';
    protected $description = 'Process TitanRewind queued fixes and notification dispatch records.';

    public function handle(RewindFixService $fixService, RewindNotificationService $notifications): int
    {
        $limit = (int)$this->option('limit');
        $processedFixes = $fixService->processQueue($limit);
        $processedNotifications = $notifications->flushQueuedNotifications($limit);
        $this->info("TitanRewind: processed {$processedFixes} queued fix(es), {$processedNotifications} queued notification(s).");
        return self::SUCCESS;
    }
}
