Trust Vault support files
