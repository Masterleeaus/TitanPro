Connect Core support files
