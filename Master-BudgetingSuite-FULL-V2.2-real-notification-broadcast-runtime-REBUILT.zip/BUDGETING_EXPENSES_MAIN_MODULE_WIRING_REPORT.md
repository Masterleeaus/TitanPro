# Budgeting Suite V1.4 — Expenses Main Module Wiring Report

## Summary

Expenses has been promoted from the retired legacy integration folder into the main `Modules/Budgeting` domain.

## Active main-module areas

- `Modules/Budgeting/Models`: Expense, ExpenseCategory, Receipt, ReimbursementBatch, Income, IncomeCategory, LedgerEntry.
- `Modules/Budgeting/Services`: ExpensesService, ReceiptsService, ReimbursementsService.
- `Modules/Budgeting/Contracts/Services`: typed service contracts for expenses, receipts, reimbursements.
- `Modules/Budgeting/Http/Controllers/API`: working API controllers for expenses, receipts and reimbursement batches.
- `Modules/Budgeting/Routes`: API routes wired under `api/budgeting/*`.
- `Modules/Budgeting/Database/Migrations`: first-class budgeting tables for expenses, categories, receipts, reimbursements, income and ledger.
- `Modules/Budgeting/manifests/expenses.manifest.json`: status changed from scaffold to wired.
- `Modules/Budgeting/Config/expenses.php`: approval thresholds, receipts, OCR, reimbursement and ledger configuration.

## Legacy handling

The previous `Modules/Budgeting/Integrations/LegacyExpensesModule` folder has been retired from active code paths. A retired marker and a file map are included in `Docs/Architecture` so the source lineage remains traceable without loading duplicate providers, routes or namespaces.

## Result

Budgeting is now the canonical module for budget planning, allocations, expenses, receipts, reimbursements, income compatibility, ledger posting, actuals and analytics feeds.
