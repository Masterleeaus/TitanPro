<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\Reimbursements;

use Tests\TestCase;

final class ReimbursementsFeatureTest extends TestCase
{
    public function test_reimbursements_scaffold_is_available(): void
    {
        $this->assertTrue(true);
    }
}
