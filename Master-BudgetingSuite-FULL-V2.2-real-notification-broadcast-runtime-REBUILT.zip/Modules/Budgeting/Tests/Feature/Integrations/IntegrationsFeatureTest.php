<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\Integrations;

use Tests\TestCase;

final class IntegrationsFeatureTest extends TestCase
{
    public function test_integrations_scaffold_is_available(): void
    {
        $this->assertTrue(true);
    }
}
