<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\ApprovalThresholds;

use Tests\TestCase;

final class ApprovalThresholdsFeatureTest extends TestCase
{
    public function test_approvalthresholds_scaffold_is_available(): void
    {
        $this->assertTrue(true);
    }
}
