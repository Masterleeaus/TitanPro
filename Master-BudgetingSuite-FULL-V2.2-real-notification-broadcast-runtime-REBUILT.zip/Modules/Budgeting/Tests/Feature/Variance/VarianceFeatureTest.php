<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\Variance;

use Tests\TestCase;

final class VarianceFeatureTest extends TestCase
{
    public function test_variance_scaffold_is_available(): void
    {
        $this->assertTrue(true);
    }
}
