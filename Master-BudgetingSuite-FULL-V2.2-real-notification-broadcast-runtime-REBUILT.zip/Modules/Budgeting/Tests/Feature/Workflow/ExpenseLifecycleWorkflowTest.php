<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\Workflow;

use Modules\Budgeting\Services\Workflow\ApprovalWorkflowService;
use Modules\Budgeting\Support\DTOs\ExpenseSubmissionData;
use PHPUnit\Framework\TestCase;

final class ExpenseLifecycleWorkflowTest extends TestCase
{
    public function test_small_expense_can_auto_approve(): void
    {
        $service = new ApprovalWorkflowService();
        $decision = $service->evaluateExpense(ExpenseSubmissionData::fromArray([
            'amount' => 25,
            'description' => 'Taxi fare',
        ]));

        self::assertFalse($decision->requiresApproval);
    }
}
