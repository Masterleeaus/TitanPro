<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\AnalyticsFeeds;

use Tests\TestCase;

final class AnalyticsFeedsFeatureTest extends TestCase
{
    public function test_analyticsfeeds_scaffold_is_available(): void
    {
        $this->assertTrue(true);
    }
}
