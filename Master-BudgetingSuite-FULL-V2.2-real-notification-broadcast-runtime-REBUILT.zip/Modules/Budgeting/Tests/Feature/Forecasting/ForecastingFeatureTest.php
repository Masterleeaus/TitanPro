<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\Forecasting;

use Tests\TestCase;

final class ForecastingFeatureTest extends TestCase
{
    public function test_forecasting_scaffold_is_available(): void
    {
        $this->assertTrue(true);
    }
}
