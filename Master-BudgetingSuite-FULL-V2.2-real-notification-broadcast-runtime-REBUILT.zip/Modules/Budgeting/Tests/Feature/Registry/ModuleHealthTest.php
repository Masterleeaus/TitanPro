<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\Registry;

use Modules\Budgeting\Services\Registry\ModuleHealthService;
use PHPUnit\Framework\TestCase;

final class ModuleHealthTest extends TestCase
{
    public function test_health_summary_has_status(): void
    {
        $summary = (new ModuleHealthService())->summary();
        self::assertArrayHasKey('status', $summary);
    }
}
