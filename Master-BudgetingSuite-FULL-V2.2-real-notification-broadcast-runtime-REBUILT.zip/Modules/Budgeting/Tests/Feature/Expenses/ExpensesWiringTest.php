<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\Expenses;

use Tests\TestCase;

class ExpensesWiringTest extends TestCase
{
    public function test_expense_routes_are_defined(): void
    {
        $this->assertTrue(file_exists(base_path('Modules/Budgeting/Routes/expenses.php')));
    }

    public function test_legacy_expenses_namespace_is_not_active_provider(): void
    {
        $module = json_decode(file_get_contents(base_path('Modules/Budgeting/module.json')), true);
        $this->assertNotContains('Modules\\Expenses\\Providers\\ModuleServiceProvider', $module['providers'] ?? []);
    }
}
