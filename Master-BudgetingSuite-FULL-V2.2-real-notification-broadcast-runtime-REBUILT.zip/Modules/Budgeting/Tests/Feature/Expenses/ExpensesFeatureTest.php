<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\Expenses;

use Tests\TestCase;

final class ExpensesFeatureTest extends TestCase
{
    public function test_expenses_scaffold_is_available(): void
    {
        $this->assertTrue(true);
    }
}
