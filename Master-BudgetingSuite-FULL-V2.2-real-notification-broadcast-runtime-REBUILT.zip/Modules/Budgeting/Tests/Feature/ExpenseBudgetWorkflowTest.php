<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature;

use Modules\Budgeting\Models\Expense;
use Modules\Budgeting\Services\BudgetWorkflowService;
use Tests\TestCase;

class ExpenseBudgetWorkflowTest extends TestCase
{
    public function test_expense_can_be_submitted_and_posted_to_actuals(): void
    {
        $expense = Expense::query()->create([
            'title' => 'Test expense',
            'amount' => 100,
            'currency' => 'AUD',
            'expense_date' => now(),
            'status' => Expense::STATUS_DRAFT,
        ]);

        $workflow = app(BudgetWorkflowService::class);
        $submitted = $workflow->submitExpense($expense);

        $this->assertContains($submitted->status, [Expense::STATUS_PENDING, Expense::STATUS_APPROVED]);
    }
}
