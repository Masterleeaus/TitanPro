<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\BudgetActuals;

use Tests\TestCase;

final class BudgetActualsFeatureTest extends TestCase
{
    public function test_budgetactuals_scaffold_is_available(): void
    {
        $this->assertTrue(true);
    }
}
