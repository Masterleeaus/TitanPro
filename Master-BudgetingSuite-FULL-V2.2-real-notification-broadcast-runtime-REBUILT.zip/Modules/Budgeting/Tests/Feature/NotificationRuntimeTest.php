<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature;

use Modules\Budgeting\Services\Notifications\BudgetingNotificationDispatcher;
use Modules\Budgeting\Services\Notifications\NotificationRuntimeService;

final class NotificationRuntimeTest
{
    public function testExpenseSubmittedBuildsNotificationPayload(): void
    {
        $service = new NotificationRuntimeService(new BudgetingNotificationDispatcher());
        $payload = $service->notifyExpenseSubmitted(['id' => 123, 'amount' => 45.67]);

        assert($payload['event'] === 'expense.submitted');
        assert(in_array('in_app', $payload['channels'], true));
    }
}
