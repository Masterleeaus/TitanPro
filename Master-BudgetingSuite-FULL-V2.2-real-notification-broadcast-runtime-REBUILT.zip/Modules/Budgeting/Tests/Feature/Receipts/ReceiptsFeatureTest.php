<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\Receipts;

use Tests\TestCase;

final class ReceiptsFeatureTest extends TestCase
{
    public function test_receipts_scaffold_is_available(): void
    {
        $this->assertTrue(true);
    }
}
