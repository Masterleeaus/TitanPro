<?php

declare(strict_types=1);

namespace Modules\Budgeting\Tests\Feature\Reporting;

use Tests\TestCase;

final class ReportingFeatureTest extends TestCase
{
    public function test_reporting_scaffold_is_available(): void
    {
        $this->assertTrue(true);
    }
}
