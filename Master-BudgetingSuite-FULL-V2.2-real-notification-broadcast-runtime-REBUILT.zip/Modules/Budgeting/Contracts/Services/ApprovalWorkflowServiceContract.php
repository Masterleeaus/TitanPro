<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

use Modules\Budgeting\Support\DTOs\ApprovalDecisionData;
use Modules\Budgeting\Support\DTOs\ExpenseSubmissionData;

interface ApprovalWorkflowServiceContract
{
    public function evaluateExpense(ExpenseSubmissionData $expense): ApprovalDecisionData;

    public function approve(string|int $expenseId, string|int $approverId, ?string $note = null): array;

    public function reject(string|int $expenseId, string|int $approverId, string $reason): array;
}
