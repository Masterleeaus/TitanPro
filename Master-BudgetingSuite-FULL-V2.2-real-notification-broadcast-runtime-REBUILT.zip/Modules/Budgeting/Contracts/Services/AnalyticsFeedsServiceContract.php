<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

interface AnalyticsFeedsServiceContract
{
    public function publishBudgetFeed(array $payload): array;
    public function publishExpenseFeed(array $payload): array;
    public function buildKpiSnapshot(array $payload): array;
    public function refreshForecastingDataset(array $payload): array;
}
