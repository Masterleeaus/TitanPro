<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

interface ForecastingServiceContract
{
    public function generateScenario(array $payload): array;
    public function compareScenario(array $payload): array;
    public function applyRecommendation(array $payload): array;
    public function trainModel(array $payload): array;
}
