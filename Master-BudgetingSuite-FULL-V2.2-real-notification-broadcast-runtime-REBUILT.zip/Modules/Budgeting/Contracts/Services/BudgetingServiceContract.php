<?php

namespace Modules\Budgeting\Contracts\Services;

class BudgetingServiceContract
{
    // TODO: Implement Budgeting BudgetingServiceContract.
}
