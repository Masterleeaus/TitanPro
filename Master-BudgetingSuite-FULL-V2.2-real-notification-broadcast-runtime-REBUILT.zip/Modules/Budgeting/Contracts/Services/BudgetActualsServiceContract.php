<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

interface BudgetActualsServiceContract
{
    public function post(array $payload): array;
    public function syncFromLedger(array $payload): array;
    public function reconcile(array $payload): array;
    public function lockPeriod(array $payload): array;
}
