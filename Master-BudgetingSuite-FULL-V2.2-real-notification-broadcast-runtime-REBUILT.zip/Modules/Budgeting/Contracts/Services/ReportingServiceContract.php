<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

interface ReportingServiceContract
{
    public function budgetVsActual(array $payload): array;
    public function spendTrend(array $payload): array;
    public function reimbursement(array $payload): array;
    public function approvalSla(array $payload): array;
}
