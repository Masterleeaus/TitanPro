<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

interface PermissionRegistryContract
{
    public function permissions(): array;

    public function roles(): array;

    public function matrix(): array;
}
