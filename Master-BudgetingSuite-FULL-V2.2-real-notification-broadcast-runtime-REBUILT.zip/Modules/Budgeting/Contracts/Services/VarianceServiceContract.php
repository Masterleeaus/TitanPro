<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

interface VarianceServiceContract
{
    public function calculate(array $payload): array;
    public function explain(array $payload): array;
    public function flagAnomalies(array $payload): array;
    public function adjust(array $payload): array;
}
