<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

interface DashboardServiceContract
{
    public function budgetVsActual(array $filters = []): array;

    public function expenseOperations(array $filters = []): array;

    public function approvalSla(array $filters = []): array;
}
