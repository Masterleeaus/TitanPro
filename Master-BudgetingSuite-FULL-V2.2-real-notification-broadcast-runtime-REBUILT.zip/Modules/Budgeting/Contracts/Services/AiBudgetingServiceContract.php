<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

interface AiBudgetingServiceContract
{
    public function prepareForecast(array $budgetContext): array;

    public function classifyExpense(array $expense): array;

    public function extractReceipt(array $receiptPayload): array;

    public function inspectVariance(array $varianceContext): array;
}
