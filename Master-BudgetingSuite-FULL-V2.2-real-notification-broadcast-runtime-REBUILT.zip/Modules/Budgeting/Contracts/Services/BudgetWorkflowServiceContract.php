<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

use Modules\Budgeting\Models\Expense;
use Modules\Budgeting\Models\BudgetActual;
use Modules\Budgeting\Models\BudgetVariance;

interface BudgetWorkflowServiceContract
{
    public function submitExpense(Expense|int $expense): Expense;
    public function approveExpense(Expense|int $expense, ?int $approverId = null): Expense;
    public function rejectExpense(Expense|int $expense, ?int $rejectedBy = null, ?string $reason = null): Expense;
    public function postExpense(Expense|int $expense): BudgetActual;
    public function recalculateVarianceForExpense(Expense|int $expense): ?BudgetVariance;
}
