<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

interface IntegrationsServiceContract
{
    public function syncBankTransactions(array $payload): array;
    public function syncAccountingActuals(array $payload): array;
    public function syncPayrollCommitments(array $payload): array;
    public function sendWebhookEvent(array $payload): array;
}
