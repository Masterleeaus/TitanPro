<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

use Illuminate\Database\Eloquent\Model;
use Modules\Budgeting\Models\BudgetAuditRevision;

interface AuditRevisionServiceContract
{
    public function record(Model $subject, string $event, array $before = [], array $after = [], array $metadata = [], ?int $actorId = null): BudgetAuditRevision;
}
