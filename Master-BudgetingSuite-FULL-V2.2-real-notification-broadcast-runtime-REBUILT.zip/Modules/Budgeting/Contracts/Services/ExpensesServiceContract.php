<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

use Modules\Budgeting\Models\Expense;
use Modules\Budgeting\Models\LedgerEntry;

interface ExpensesServiceContract
{
    public function create(array $payload): Expense;
    public function submit(Expense|int $expense): Expense;
    public function approve(Expense|int $expense, ?int $approverId = null): Expense;
    public function reject(Expense|int $expense, ?int $rejectedBy = null, ?string $reason = null): Expense;
    public function reimburse(Expense|int $expense): Expense;
    public function postToLedger(Expense|int $expense): LedgerEntry;
}
