<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

interface NotificationRuntimeServiceContract
{
    public function notifyExpenseSubmitted(array $expense, array $channels = []): array;

    public function notifyExpenseApprovalChanged(array $expense, string $status, array $channels = []): array;

    public function notifyVarianceAlert(array $variance, array $channels = []): array;

    public function notifyForecastReady(array $forecast, array $channels = []): array;
}
