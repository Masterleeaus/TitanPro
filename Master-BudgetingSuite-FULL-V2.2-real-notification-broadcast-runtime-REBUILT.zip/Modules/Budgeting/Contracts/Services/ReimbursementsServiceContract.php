<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

use Modules\Budgeting\Models\ReimbursementBatch;

interface ReimbursementsServiceContract
{
    public function createBatch(array $expenseIds, array $payload = []): ReimbursementBatch;
    public function approveBatch(ReimbursementBatch|int $batch, ?int $approvedBy = null): ReimbursementBatch;
    public function markPaid(ReimbursementBatch|int $batch, ?int $paidBy = null): ReimbursementBatch;
}
