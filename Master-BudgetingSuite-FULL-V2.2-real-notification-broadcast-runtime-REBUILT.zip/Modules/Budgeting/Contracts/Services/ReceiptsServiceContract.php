<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

use Illuminate\Http\UploadedFile;
use Modules\Budgeting\Models\Expense;
use Modules\Budgeting\Models\Receipt;

interface ReceiptsServiceContract
{
    public function attach(Expense|int $expense, UploadedFile|string $file, array $metadata = []): Receipt;
    public function markExtracted(Receipt|int $receipt, array $data, ?string $ocrText = null, ?float $confidence = null): Receipt;
}
