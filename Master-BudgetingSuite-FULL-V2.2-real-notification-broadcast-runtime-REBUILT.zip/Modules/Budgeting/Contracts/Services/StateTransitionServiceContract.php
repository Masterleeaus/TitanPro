<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

use Illuminate\Database\Eloquent\Model;
use Modules\Budgeting\Models\BudgetStateTransition;
use Modules\Budgeting\Support\DTOs\StateTransitionData;

interface StateTransitionServiceContract
{
    public function record(Model $subject, StateTransitionData $data): BudgetStateTransition;

    public function canTransition(string $fromState, string $toState, array $allowedTransitions): bool;
}
