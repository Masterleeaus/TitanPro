<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

interface ApprovalThresholdsServiceContract
{
    public function evaluate(array $payload): array;
    public function resolveChain(array $payload): array;
    public function escalate(array $payload): array;
    public function delegate(array $payload): array;
}
