<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

interface ModuleHealthServiceContract
{
    public function checks(): array;

    public function summary(): array;
}
