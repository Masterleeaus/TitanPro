<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Services;

use Modules\Budgeting\Models\Expense;

interface ExpenseBudgetLinkerContract
{
    public function link(Expense|int $expense, ?int $budgetId = null, ?int $allocationId = null, ?int $categoryId = null): Expense;
    public function inferLinks(array $payload): array;
}
