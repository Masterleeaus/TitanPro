<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\AI;

interface BudgetingAiGatewayContract
{
    public function recommend(array $context): array;

    public function forecast(array $context): array;

    public function extractReceipt(array $payload): array;

    public function categorizeExpense(array $expense): array;

    public function detectAnomalies(array $actuals, array $policy = []): array;

    public function summarizeVariance(array $variance): array;
}
