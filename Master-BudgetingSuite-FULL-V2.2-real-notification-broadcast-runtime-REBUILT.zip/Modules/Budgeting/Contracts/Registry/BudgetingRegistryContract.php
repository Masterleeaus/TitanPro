<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Registry;

interface BudgetingRegistryContract
{
    public function metadata(): array;
    public function health(): array;
    public function dependencies(): array;
}
