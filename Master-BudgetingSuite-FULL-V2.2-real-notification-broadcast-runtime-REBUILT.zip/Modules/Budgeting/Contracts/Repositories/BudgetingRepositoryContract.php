<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Repositories;

use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;

interface BudgetingRepositoryContract
{
    public function query(array $filters = []): Builder;

    public function paginate(array $filters = [], int $perPage = 25): LengthAwarePaginator;
}
