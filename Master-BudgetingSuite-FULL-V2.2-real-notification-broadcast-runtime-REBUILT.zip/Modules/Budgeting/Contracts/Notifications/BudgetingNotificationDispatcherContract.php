<?php

declare(strict_types=1);

namespace Modules\Budgeting\Contracts\Notifications;

interface BudgetingNotificationDispatcherContract
{
    public function dispatch(string $event, array $payload = []): void;
}
