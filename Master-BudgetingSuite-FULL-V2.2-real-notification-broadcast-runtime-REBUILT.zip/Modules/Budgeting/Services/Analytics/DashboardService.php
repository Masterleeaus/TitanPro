<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Analytics;

use Modules\Budgeting\Contracts\Services\DashboardServiceContract;

final class DashboardService implements DashboardServiceContract
{
    public function budgetVsActual(array $filters = []): array
    {
        return [
            'filters' => $filters,
            'cards' => [
                'budgeted' => 0.0,
                'committed' => 0.0,
                'actual' => 0.0,
                'remaining' => 0.0,
                'variance' => 0.0,
            ],
            'series' => [],
            'breakdowns' => [
                'by_category' => [],
                'by_cost_centre' => [],
                'by_month' => [],
            ],
        ];
    }

    public function expenseOperations(array $filters = []): array
    {
        return [
            'filters' => $filters,
            'queues' => [
                'draft' => 0,
                'submitted' => 0,
                'pending_approval' => 0,
                'approved' => 0,
                'reimbursable' => 0,
                'missing_receipt' => 0,
            ],
            'risk' => [
                'duplicate_candidates' => 0,
                'policy_exceptions' => 0,
                'anomaly_flags' => 0,
            ],
        ];
    }

    public function approvalSla(array $filters = []): array
    {
        return [
            'filters' => $filters,
            'average_hours' => 0.0,
            'breached' => 0,
            'by_chain' => [],
        ];
    }
}
