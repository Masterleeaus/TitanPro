<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Receipts;

final class ReceiptsService
{
    // Scaffold stub: implement domain behaviour here.

}
