<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Modules\Budgeting\Contracts\Services\BudgetActualsServiceContract;
use Modules\Budgeting\Models\BudgetActual;

class BudgetActualsService implements BudgetActualsServiceContract
{

    public function recordExpense(\Modules\Budgeting\Models\Expense $expense): \Modules\Budgeting\Models\BudgetActual
    {
        return \Modules\Budgeting\Models\BudgetActual::query()->updateOrCreate([
            'tenant_id' => $expense->tenant_id,
            'source_type' => \Modules\Budgeting\Models\Expense::class,
            'source_id' => $expense->getKey(),
        ], [
            'budget_id' => $expense->budget_id,
            'allocation_id' => $expense->allocation_id,
            'category_id' => $expense->category_id,
            'actual_date' => $expense->expense_date,
            'amount' => $expense->amount,
            'currency' => $expense->currency,
            'description' => $expense->title,
            'metadata' => array_merge($expense->metadata ?? [], ['expense_id' => $expense->getKey()]),
            'status' => 'posted',
        ]);
    }

    private function normalisePayload(array $payload, string $operation): array
    {
        return [
            'tenant_id' => $payload['tenant_id'] ?? null,
            'status' => $payload['status'] ?? $this->statusFor($operation),
            'payload' => array_merge($payload, ['operation' => $operation]),
        ];
    }

    private function statusFor(string $operation): string
    {
        return match (true) {
            str_contains($operation, 'approve'), str_contains($operation, 'post'), str_contains($operation, 'paid') => 'approved',
            str_contains($operation, 'reject') => 'rejected',
            str_contains($operation, 'submit'), str_contains($operation, 'escalate') => 'pending',
            default => 'draft',
        };
    }

    public function post(array $payload): array
    {
        $record = BudgetActual::create($this->normalisePayload($payload, 'post'));

        return $record->toArray();
    }
    public function syncFromLedger(array $payload): array
    {
        $record = BudgetActual::create($this->normalisePayload($payload, 'syncFromLedger'));

        return $record->toArray();
    }
    public function reconcile(array $payload): array
    {
        $record = BudgetActual::create($this->normalisePayload($payload, 'reconcile'));

        return $record->toArray();
    }
    public function lockPeriod(array $payload): array
    {
        $record = BudgetActual::create($this->normalisePayload($payload, 'lockPeriod'));

        return $record->toArray();
    }
}
