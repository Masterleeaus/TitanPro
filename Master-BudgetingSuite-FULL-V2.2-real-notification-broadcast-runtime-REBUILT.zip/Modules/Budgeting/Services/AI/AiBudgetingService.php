<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\AI;

use Modules\Budgeting\Contracts\AI\BudgetingAiGatewayContract;
use Modules\Budgeting\Contracts\Services\AiBudgetingServiceContract;

final class AiBudgetingService implements AiBudgetingServiceContract
{
    public function __construct(private readonly BudgetingAiGatewayContract $gateway)
    {
    }

    public function prepareForecast(array $budgetContext): array
    {
        return [
            'forecast' => $this->gateway->forecast($budgetContext),
            'recommendations' => $this->gateway->recommend($budgetContext),
        ];
    }

    public function classifyExpense(array $expense): array
    {
        return $this->gateway->categorizeExpense($expense);
    }

    public function extractReceipt(array $receiptPayload): array
    {
        return $this->gateway->extractReceipt($receiptPayload);
    }

    public function inspectVariance(array $varianceContext): array
    {
        return [
            'summary' => $this->gateway->summarizeVariance($varianceContext),
            'anomalies' => $this->gateway->detectAnomalies($varianceContext['actuals'] ?? [], $varianceContext['policy'] ?? []),
        ];
    }
}
