<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\AI;

use Modules\Budgeting\Contracts\AI\BudgetingAiGatewayContract;

final class BudgetingAiGateway implements BudgetingAiGatewayContract
{
    public function recommend(array $context): array
    {
        $variance = (float) ($context['variance_percent'] ?? 0);
        $recommendations = [];

        if ($variance > 10) {
            $recommendations[] = 'Review spend drivers and freeze non-essential discretionary spend.';
        }

        if (($context['unapproved_expense_count'] ?? 0) > 0) {
            $recommendations[] = 'Clear pending expense approvals before refreshing the forecast baseline.';
        }

        return [
            'engine' => 'deterministic-budgeting-ai-gateway',
            'recommendations' => $recommendations,
            'context_hash' => $this->fingerprint($context),
        ];
    }

    public function forecast(array $context): array
    {
        $actual = (float) ($context['actual_spend'] ?? 0);
        $remainingPeriods = max(1, (int) ($context['remaining_periods'] ?? 1));
        $trend = (float) ($context['trend_factor'] ?? 1.0);

        return [
            'engine' => 'deterministic-budgeting-ai-gateway',
            'projected_spend' => round($actual * $trend * $remainingPeriods, 2),
            'confidence' => $actual > 0 ? 'medium' : 'low',
            'assumptions' => [
                'actual_spend' => $actual,
                'remaining_periods' => $remainingPeriods,
                'trend_factor' => $trend,
            ],
            'context_hash' => $this->fingerprint($context),
        ];
    }

    public function extractReceipt(array $payload): array
    {
        $text = strtolower((string) ($payload['text'] ?? ''));
        preg_match('/(total|amount)\s*[:$ ]\s*([0-9]+(?:\.[0-9]{2})?)/i', (string) ($payload['text'] ?? ''), $amountMatch);

        return [
            'engine' => 'deterministic-budgeting-ai-gateway',
            'merchant' => $payload['merchant'] ?? $this->guessMerchant($text),
            'amount' => isset($amountMatch[2]) ? (float) $amountMatch[2] : ($payload['amount'] ?? null),
            'currency' => $payload['currency'] ?? 'AUD',
            'confidence' => isset($amountMatch[2]) ? 'medium' : 'low',
            'payload_hash' => $this->fingerprint($payload),
        ];
    }

    public function categorizeExpense(array $expense): array
    {
        $description = strtolower((string) ($expense['description'] ?? $expense['merchant'] ?? ''));
        $category = 'uncategorised';

        foreach ([
            'travel' => ['uber', 'taxi', 'flight', 'hotel', 'parking'],
            'meals' => ['restaurant', 'cafe', 'coffee', 'lunch', 'dinner'],
            'software' => ['subscription', 'saas', 'cloud', 'hosting', 'github'],
            'office' => ['stationery', 'office', 'printer', 'paper'],
        ] as $candidate => $keywords) {
            foreach ($keywords as $keyword) {
                if (str_contains($description, $keyword)) {
                    $category = $candidate;
                    break 2;
                }
            }
        }

        return [
            'engine' => 'deterministic-budgeting-ai-gateway',
            'category' => $category,
            'confidence' => $category === 'uncategorised' ? 'low' : 'medium',
            'expense_hash' => $this->fingerprint($expense),
        ];
    }

    public function detectAnomalies(array $actuals, array $policy = []): array
    {
        $threshold = (float) ($policy['variance_threshold_percent'] ?? 15);
        $findings = [];

        foreach ($actuals as $row) {
            $budget = max(0.01, (float) ($row['budget_amount'] ?? 0.01));
            $actual = (float) ($row['actual_amount'] ?? 0);
            $variance = (($actual - $budget) / $budget) * 100;

            if (abs($variance) >= $threshold) {
                $findings[] = [
                    'key' => $row['key'] ?? $row['category'] ?? 'unknown',
                    'variance_percent' => round($variance, 2),
                    'severity' => abs($variance) >= ($threshold * 2) ? 'high' : 'medium',
                ];
            }
        }

        return ['engine' => 'deterministic-budgeting-ai-gateway', 'findings' => $findings];
    }

    public function summarizeVariance(array $variance): array
    {
        $amount = (float) ($variance['variance_amount'] ?? 0);
        return [
            'engine' => 'deterministic-budgeting-ai-gateway',
            'summary' => $amount >= 0
                ? 'Actual spend is above budget and requires review.'
                : 'Actual spend is below budget; consider reallocation or preserving contingency.',
            'severity' => abs($amount) > (float) ($variance['materiality_threshold'] ?? 1000) ? 'material' : 'informational',
        ];
    }

    private function fingerprint(array $payload): string
    {
        return substr(hash('sha256', json_encode($payload, JSON_THROW_ON_ERROR)), 0, 16);
    }

    private function guessMerchant(string $text): ?string
    {
        $line = trim(strtok($text, "\n") ?: '');
        return $line !== '' ? title_case($line) : null;
    }
}

if (! function_exists('Modules\\Budgeting\\Services\\AI\\title_case')) {
    function title_case(string $value): string
    {
        return ucwords(strtolower($value));
    }
}
