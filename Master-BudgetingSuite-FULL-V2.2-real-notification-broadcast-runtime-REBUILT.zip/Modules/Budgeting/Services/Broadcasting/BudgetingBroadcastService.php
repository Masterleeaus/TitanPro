<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Broadcasting;

use Modules\Budgeting\Broadcasting\Events\ExpenseApprovalStatusBroadcast;

final class BudgetingBroadcastService
{
    public function expenseApprovalChanged(array $expense, string $status): array
    {
        $event = new ExpenseApprovalStatusBroadcast($expense, $status);

        if (function_exists('event')) {
            event($event);
        }

        return $event->broadcastWith();
    }
}
