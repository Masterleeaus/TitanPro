<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\ApprovalThresholds;

final class ApprovalThresholdsService
{
    // Scaffold stub: implement domain behaviour here.

}
