<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Illuminate\Support\Arr;
use Modules\Budgeting\Contracts\Services\ExpensesServiceContract;
use Modules\Budgeting\Models\Expense;
use Modules\Budgeting\Models\LedgerEntry;

class ExpensesService implements ExpensesServiceContract
{
    public function create(array $payload): Expense
    {
        $payload['currency'] = $payload['currency'] ?? config('budgeting-expenses.currency', config('budgeting.currency', 'AUD'));
        $payload['status'] = $payload['status'] ?? Expense::STATUS_DRAFT;
        $payload['expense_date'] = $payload['expense_date'] ?? Arr::get($payload, 'date');
        return Expense::query()->create($payload);
    }

    public function submit(Expense|int $expense): Expense
    {
        $expense = $this->resolve($expense);
        $expense->forceFill(['status' => Expense::STATUS_SUBMITTED, 'submitted_at' => now()])->save();
        return $expense->refresh();
    }

    public function approve(Expense|int $expense, ?int $approverId = null): Expense
    {
        $expense = $this->resolve($expense);
        $expense->forceFill(['status' => Expense::STATUS_APPROVED, 'approved_by' => $approverId, 'approved_at' => now()])->save();
        return $expense->refresh();
    }

    public function reject(Expense|int $expense, ?int $rejectedBy = null, ?string $reason = null): Expense
    {
        $expense = $this->resolve($expense);
        $expense->forceFill(['status' => Expense::STATUS_REJECTED, 'rejected_by' => $rejectedBy, 'rejected_at' => now(), 'rejection_reason' => $reason])->save();
        return $expense->refresh();
    }

    public function reimburse(Expense|int $expense): Expense
    {
        $expense = $this->resolve($expense);
        $expense->forceFill(['status' => Expense::STATUS_REIMBURSED, 'reimbursed_at' => now()])->save();
        return $expense->refresh();
    }

    public function postToLedger(Expense|int $expense): LedgerEntry
    {
        $expense = $this->resolve($expense);
        $entry = LedgerEntry::query()->create([
            'tenant_id' => $expense->tenant_id,
            'source_type' => Expense::class,
            'source_id' => $expense->getKey(),
            'entry_type' => 'expense',
            'category' => optional($expense->category)->slug,
            'amount' => -abs((float) $expense->amount),
            'currency' => $expense->currency,
            'posted_at' => now(),
            'metadata' => ['budget_id' => $expense->budget_id, 'allocation_id' => $expense->allocation_id],
            'status' => 'posted',
        ]);
        $expense->forceFill(['status' => Expense::STATUS_POSTED, 'posted_at' => now()])->save();
        return $entry;
    }

    protected function resolve(Expense|int $expense): Expense
    {
        return $expense instanceof Expense ? $expense : Expense::query()->findOrFail($expense);
    }
}
