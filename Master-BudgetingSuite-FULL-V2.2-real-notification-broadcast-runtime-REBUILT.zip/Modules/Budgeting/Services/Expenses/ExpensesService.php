<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Expenses;

final class ExpensesService
{
    // Scaffold stub: implement domain behaviour here.

}
