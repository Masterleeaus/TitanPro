<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Modules\Budgeting\Contracts\Services\ExpenseBudgetLinkerContract;
use Modules\Budgeting\Models\Expense;

class ExpenseBudgetLinker implements ExpenseBudgetLinkerContract
{
    public function link(Expense|int $expense, ?int $budgetId = null, ?int $allocationId = null, ?int $categoryId = null): Expense
    {
        $expense = $expense instanceof Expense ? $expense : Expense::query()->findOrFail($expense);
        $expense->forceFill(array_filter([
            'budget_id' => $budgetId,
            'allocation_id' => $allocationId,
            'category_id' => $categoryId,
        ], static fn ($value) => $value !== null))->save();

        return $expense->refresh();
    }

    public function inferLinks(array $payload): array
    {
        return [
            'budget_id' => $payload['budget_id'] ?? $payload['metadata']['budget_id'] ?? null,
            'allocation_id' => $payload['allocation_id'] ?? $payload['metadata']['allocation_id'] ?? null,
            'category_id' => $payload['category_id'] ?? $payload['expense_category_id'] ?? null,
        ];
    }
}
