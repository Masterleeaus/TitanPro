<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Illuminate\Database\Eloquent\Model;
use Modules\Budgeting\Contracts\Services\AuditRevisionServiceContract;
use Modules\Budgeting\Models\BudgetAuditRevision;

class AuditRevisionService implements AuditRevisionServiceContract
{
    public function record(Model $subject, string $event, array $before = [], array $after = [], array $metadata = [], ?int $actorId = null): BudgetAuditRevision
    {
        return BudgetAuditRevision::query()->create([
            'tenant_id' => $subject->getAttribute('tenant_id'),
            'auditable_type' => $subject::class,
            'auditable_id' => $subject->getKey(),
            'actor_id' => $actorId,
            'event' => $event,
            'before' => $before,
            'after' => $after,
            'metadata' => $metadata,
            'occurred_at' => now(),
        ]);
    }
}
