<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Modules\Budgeting\Contracts\Services\ApprovalThresholdsServiceContract;
use Modules\Budgeting\Models\ApprovalThreshold;

class ApprovalThresholdsService implements ApprovalThresholdsServiceContract
{

    public function evaluateExpense(\Modules\Budgeting\Models\Expense $expense): array
    {
        $limit = (float) config('budgeting-expenses.auto_approve_limit', 0);
        $amount = (float) $expense->amount;

        return [
            'auto_approve' => $limit > 0 && $amount <= $limit,
            'limit' => $limit,
            'amount' => $amount,
            'requires_approval' => !($limit > 0 && $amount <= $limit),
            'reason' => $limit > 0 && $amount <= $limit ? 'within_auto_approval_limit' : 'threshold_or_manual_approval_required',
        ];
    }

    private function normalisePayload(array $payload, string $operation): array
    {
        return [
            'tenant_id' => $payload['tenant_id'] ?? null,
            'status' => $payload['status'] ?? $this->statusFor($operation),
            'payload' => array_merge($payload, ['operation' => $operation]),
        ];
    }

    private function statusFor(string $operation): string
    {
        return match (true) {
            str_contains($operation, 'approve'), str_contains($operation, 'post'), str_contains($operation, 'paid') => 'approved',
            str_contains($operation, 'reject') => 'rejected',
            str_contains($operation, 'submit'), str_contains($operation, 'escalate') => 'pending',
            default => 'draft',
        };
    }

    public function evaluate(array $payload): array
    {
        $record = ApprovalThreshold::create($this->normalisePayload($payload, 'evaluate'));

        return $record->toArray();
    }
    public function resolveChain(array $payload): array
    {
        $record = ApprovalThreshold::create($this->normalisePayload($payload, 'resolveChain'));

        return $record->toArray();
    }
    public function escalate(array $payload): array
    {
        $record = ApprovalThreshold::create($this->normalisePayload($payload, 'escalate'));

        return $record->toArray();
    }
    public function delegate(array $payload): array
    {
        $record = ApprovalThreshold::create($this->normalisePayload($payload, 'delegate'));

        return $record->toArray();
    }
}
