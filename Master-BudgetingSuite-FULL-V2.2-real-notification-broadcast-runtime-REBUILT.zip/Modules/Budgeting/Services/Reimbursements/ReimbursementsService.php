<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Reimbursements;

final class ReimbursementsService
{
    // Scaffold stub: implement domain behaviour here.

}
