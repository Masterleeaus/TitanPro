<?php

namespace Modules\Budgeting\Services\Automation;

use Modules\Budgeting\Automation\Rules\BudgetThresholdRule;

class AutomationEngine
{
    public function evaluate(float $amount, float $threshold): bool
    {
        return (new BudgetThresholdRule())->shouldEscalate($amount, $threshold);
    }
}
