<?php

namespace Modules\Budgeting\Services\ExpenseEngine;

class ExpenseEngine
{
    // TODO: Implement Budgeting ExpenseEngine.
}
