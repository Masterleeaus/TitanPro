<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Illuminate\Support\Str;
use Modules\Budgeting\Contracts\Services\ReimbursementsServiceContract;
use Modules\Budgeting\Models\Expense;
use Modules\Budgeting\Models\ReimbursementBatch;

class ReimbursementsService implements ReimbursementsServiceContract
{
    public function createBatch(array $expenseIds, array $payload = []): ReimbursementBatch
    {
        $expenses = Expense::query()->whereIn('id', $expenseIds)->get();
        $total = (float) $expenses->sum('amount');
        $batch = ReimbursementBatch::query()->create([
            'tenant_id' => $payload['tenant_id'] ?? optional($expenses->first())->tenant_id,
            'batch_number' => $payload['batch_number'] ?? config('budgeting-expenses.reimbursements.batch_prefix', 'RB') . '-' . now()->format('Ymd') . '-' . Str::upper(Str::random(6)),
            'total_amount' => $total,
            'currency' => $payload['currency'] ?? optional($expenses->first())->currency ?? config('budgeting.currency', 'AUD'),
            'payload' => $payload,
            'status' => 'draft',
        ]);
        foreach ($expenses as $expense) {
            $batch->expenses()->attach($expense->getKey(), ['amount' => $expense->amount, 'status' => 'queued']);
        }
        return $batch->refresh();
    }

    public function approveBatch(ReimbursementBatch|int $batch, ?int $approvedBy = null): ReimbursementBatch
    {
        $batch = $this->resolve($batch);
        $batch->forceFill(['status' => 'approved', 'approved_by' => $approvedBy, 'approved_at' => now()])->save();
        return $batch->refresh();
    }

    public function markPaid(ReimbursementBatch|int $batch, ?int $paidBy = null): ReimbursementBatch
    {
        $batch = $this->resolve($batch);
        $batch->forceFill(['status' => 'paid', 'paid_by' => $paidBy, 'paid_at' => now()])->save();
        foreach ($batch->expenses as $expense) {
            $batch->expenses()->updateExistingPivot($expense->getKey(), ['status' => 'paid']);
            $expense->forceFill(['status' => Expense::STATUS_REIMBURSED, 'reimbursed_at' => now()])->save();
        }
        return $batch->refresh();
    }

    protected function resolve(ReimbursementBatch|int $batch): ReimbursementBatch
    {
        return $batch instanceof ReimbursementBatch ? $batch : ReimbursementBatch::query()->findOrFail($batch);
    }
}
