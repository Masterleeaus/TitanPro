<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Forecasting;

final class ForecastingService
{
    // Scaffold stub: implement domain behaviour here.

}
