<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Illuminate\Database\Eloquent\Model;
use Modules\Budgeting\Contracts\Services\StateTransitionServiceContract;
use Modules\Budgeting\Models\BudgetStateTransition;
use Modules\Budgeting\Support\DTOs\StateTransitionData;

class StateTransitionService implements StateTransitionServiceContract
{
    public function record(Model $subject, StateTransitionData $data): BudgetStateTransition
    {
        return BudgetStateTransition::query()->create([
            'tenant_id' => $data->tenantId,
            'transitionable_type' => $subject::class,
            'transitionable_id' => $subject->getKey(),
            'workflow' => $data->workflow,
            'from_state' => $data->fromState,
            'to_state' => $data->toState,
            'actor_id' => $data->actorId,
            'reason' => $data->reason,
            'context' => $data->context,
            'occurred_at' => now(),
        ]);
    }

    public function canTransition(string $fromState, string $toState, array $allowedTransitions): bool
    {
        return in_array($toState, $allowedTransitions[$fromState] ?? [], true);
    }
}
