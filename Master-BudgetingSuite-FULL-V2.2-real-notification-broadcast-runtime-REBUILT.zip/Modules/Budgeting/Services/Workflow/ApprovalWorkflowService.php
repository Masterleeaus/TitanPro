<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Workflow;

use Modules\Budgeting\Contracts\Services\ApprovalWorkflowServiceContract;
use Modules\Budgeting\Support\DTOs\ApprovalDecisionData;
use Modules\Budgeting\Support\DTOs\ExpenseSubmissionData;

final class ApprovalWorkflowService implements ApprovalWorkflowServiceContract
{
    public function evaluateExpense(ExpenseSubmissionData $expense): ApprovalDecisionData
    {
        $thresholds = config('budgeting.workflows.expense_approval.thresholds', [
            ['limit' => 250, 'chain' => null, 'approvers' => []],
            ['limit' => 1000, 'chain' => 'manager', 'approvers' => ['manager']],
            ['limit' => 5000, 'chain' => 'finance', 'approvers' => ['manager', 'finance']],
            ['limit' => PHP_FLOAT_MAX, 'chain' => 'executive', 'approvers' => ['manager', 'finance', 'executive']],
        ]);

        foreach ($thresholds as $threshold) {
            if ($expense->amount <= (float) $threshold['limit']) {
                $approvers = (array) ($threshold['approvers'] ?? []);
                return new ApprovalDecisionData(
                    requiresApproval: $approvers !== [],
                    chainCode: $threshold['chain'] ?? null,
                    approvers: $approvers,
                    reason: $approvers === [] ? 'amount_under_auto_approve_limit' : 'matched_threshold_chain',
                    threshold: $threshold,
                );
            }
        }

        return new ApprovalDecisionData(true, 'executive', ['manager', 'finance', 'executive'], 'fallback_threshold');
    }

    public function approve(string|int $expenseId, string|int $approverId, ?string $note = null): array
    {
        return [
            'expense_id' => $expenseId,
            'approver_id' => $approverId,
            'status' => 'approved',
            'note' => $note,
            'next' => 'post_to_actuals',
        ];
    }

    public function reject(string|int $expenseId, string|int $approverId, string $reason): array
    {
        return [
            'expense_id' => $expenseId,
            'approver_id' => $approverId,
            'status' => 'rejected',
            'reason' => $reason,
            'next' => 'notify_submitter',
        ];
    }
}
