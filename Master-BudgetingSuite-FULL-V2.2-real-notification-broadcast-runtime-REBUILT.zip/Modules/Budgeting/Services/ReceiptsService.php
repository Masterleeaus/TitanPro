<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Modules\Budgeting\Contracts\Services\ReceiptsServiceContract;
use Modules\Budgeting\Models\Expense;
use Modules\Budgeting\Models\Receipt;

class ReceiptsService implements ReceiptsServiceContract
{
    public function attach(Expense|int $expense, UploadedFile|string $file, array $metadata = []): Receipt
    {
        $expense = $expense instanceof Expense ? $expense : Expense::query()->findOrFail($expense);
        $disk = $metadata['disk'] ?? config('budgeting-expenses.receipts.disk', 'public');
        $path = is_string($file) ? $file : $file->store(config('budgeting-expenses.receipts.path', 'budgeting/receipts'), $disk);

        return Receipt::query()->create([
            'tenant_id' => $expense->tenant_id,
            'expense_id' => $expense->getKey(),
            'disk' => $disk,
            'path' => $path,
            'mime_type' => is_string($file) ? ($metadata['mime_type'] ?? null) : $file->getMimeType(),
            'size' => is_string($file) ? ($metadata['size'] ?? 0) : $file->getSize(),
            'metadata' => $metadata,
            'status' => 'uploaded',
        ]);
    }

    public function markExtracted(Receipt|int $receipt, array $data, ?string $ocrText = null, ?float $confidence = null): Receipt
    {
        $receipt = $receipt instanceof Receipt ? $receipt : Receipt::query()->findOrFail($receipt);
        $receipt->forceFill(['extracted_data' => $data, 'ocr_text' => $ocrText, 'confidence' => $confidence, 'status' => 'extracted'])->save();
        return $receipt->refresh();
    }
}
