<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\AnalyticsFeeds;

final class AnalyticsFeedsService
{
    // Scaffold stub: implement domain behaviour here.

}
