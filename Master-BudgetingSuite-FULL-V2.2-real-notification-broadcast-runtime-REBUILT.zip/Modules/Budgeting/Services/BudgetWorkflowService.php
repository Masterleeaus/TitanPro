<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Illuminate\Support\Facades\DB;
use Modules\Budgeting\Contracts\Services\BudgetWorkflowServiceContract;
use Modules\Budgeting\Events\Domain\ExpenseApproved;
use Modules\Budgeting\Events\Domain\ExpensePostedToActuals;
use Modules\Budgeting\Events\Domain\ExpenseRejected;
use Modules\Budgeting\Events\Domain\ExpenseSubmitted;
use Modules\Budgeting\Models\BudgetActual;
use Modules\Budgeting\Models\BudgetVariance;
use Modules\Budgeting\Models\Expense;

class BudgetWorkflowService implements BudgetWorkflowServiceContract
{
    public function __construct(
        protected ExpensesService $expenses,
        protected BudgetActualsService $actuals,
        protected VarianceService $variance,
        protected ApprovalThresholdsService $thresholds,
    ) {}

    public function submitExpense(Expense|int $expense): Expense
    {
        return DB::transaction(function () use ($expense): Expense {
            $expense = $this->expenses->submit($expense);
            $decision = $this->thresholds->evaluateExpense($expense);
            $expense->forceFill([
                'status' => $decision['auto_approve'] ? Expense::STATUS_APPROVED : Expense::STATUS_PENDING,
                'metadata' => array_merge($expense->metadata ?? [], ['approval_decision' => $decision]),
            ])->save();

            event(new ExpenseSubmitted($expense->refresh(), $decision));
            return $expense->refresh();
        });
    }

    public function approveExpense(Expense|int $expense, ?int $approverId = null): Expense
    {
        return DB::transaction(function () use ($expense, $approverId): Expense {
            $expense = $this->expenses->approve($expense, $approverId);
            event(new ExpenseApproved($expense));
            return $expense;
        });
    }

    public function rejectExpense(Expense|int $expense, ?int $rejectedBy = null, ?string $reason = null): Expense
    {
        return DB::transaction(function () use ($expense, $rejectedBy, $reason): Expense {
            $expense = $this->expenses->reject($expense, $rejectedBy, $reason);
            event(new ExpenseRejected($expense, $reason));
            return $expense;
        });
    }

    public function postExpense(Expense|int $expense): BudgetActual
    {
        return DB::transaction(function () use ($expense): BudgetActual {
            $expense = $expense instanceof Expense ? $expense : Expense::query()->findOrFail($expense);
            $actual = $this->actuals->recordExpense($expense);
            $this->expenses->postToLedger($expense);
            $this->recalculateVarianceForExpense($expense);
            event(new ExpensePostedToActuals($expense->refresh(), $actual));
            return $actual;
        });
    }

    public function recalculateVarianceForExpense(Expense|int $expense): ?BudgetVariance
    {
        $expense = $expense instanceof Expense ? $expense : Expense::query()->findOrFail($expense);
        if (! $expense->budget_id) {
            return null;
        }

        return $this->variance->calculate([
            'tenant_id' => $expense->tenant_id,
            'budget_id' => $expense->budget_id,
            'allocation_id' => $expense->allocation_id,
            'category_id' => $expense->category_id,
            'period_start' => optional($expense->expense_date)->startOfMonth()?->toDateString(),
            'period_end' => optional($expense->expense_date)->endOfMonth()?->toDateString(),
        ]);
    }
}
