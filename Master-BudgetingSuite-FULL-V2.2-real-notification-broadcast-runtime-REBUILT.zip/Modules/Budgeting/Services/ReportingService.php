<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Modules\Budgeting\Contracts\Services\ReportingServiceContract;
use Modules\Budgeting\Models\KpiSnapshot;

class ReportingService implements ReportingServiceContract
{
    private function normalisePayload(array $payload, string $operation): array
    {
        return [
            'tenant_id' => $payload['tenant_id'] ?? null,
            'status' => $payload['status'] ?? $this->statusFor($operation),
            'payload' => array_merge($payload, ['operation' => $operation]),
        ];
    }

    private function statusFor(string $operation): string
    {
        return match (true) {
            str_contains($operation, 'approve'), str_contains($operation, 'post'), str_contains($operation, 'paid') => 'approved',
            str_contains($operation, 'reject') => 'rejected',
            str_contains($operation, 'submit'), str_contains($operation, 'escalate') => 'pending',
            default => 'draft',
        };
    }

    public function budgetVsActual(array $payload): array
    {
        $record = KpiSnapshot::create($this->normalisePayload($payload, 'budgetVsActual'));

        return $record->toArray();
    }
    public function spendTrend(array $payload): array
    {
        $record = KpiSnapshot::create($this->normalisePayload($payload, 'spendTrend'));

        return $record->toArray();
    }
    public function reimbursement(array $payload): array
    {
        $record = KpiSnapshot::create($this->normalisePayload($payload, 'reimbursement'));

        return $record->toArray();
    }
    public function approvalSla(array $payload): array
    {
        $record = KpiSnapshot::create($this->normalisePayload($payload, 'approvalSla'));

        return $record->toArray();
    }
}
