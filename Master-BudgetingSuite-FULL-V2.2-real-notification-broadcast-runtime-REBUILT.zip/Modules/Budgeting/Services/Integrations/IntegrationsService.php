<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Integrations;

final class IntegrationsService
{
    // Scaffold stub: implement domain behaviour here.

}
