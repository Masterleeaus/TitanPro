<?php

namespace Modules\Budgeting\Services\VarianceEngine;

class VarianceEngine
{
    // TODO: Implement Budgeting VarianceEngine.
}
