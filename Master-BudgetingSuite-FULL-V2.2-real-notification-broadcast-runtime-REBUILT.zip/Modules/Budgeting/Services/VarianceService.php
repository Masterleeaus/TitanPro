<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Modules\Budgeting\Contracts\Services\VarianceServiceContract;
use Modules\Budgeting\Models\BudgetVariance;

class VarianceService implements VarianceServiceContract
{
    private function normalisePayload(array $payload, string $operation): array
    {
        return [
            'tenant_id' => $payload['tenant_id'] ?? null,
            'status' => $payload['status'] ?? $this->statusFor($operation),
            'payload' => array_merge($payload, ['operation' => $operation]),
        ];
    }

    private function statusFor(string $operation): string
    {
        return match (true) {
            str_contains($operation, 'approve'), str_contains($operation, 'post'), str_contains($operation, 'paid') => 'approved',
            str_contains($operation, 'reject') => 'rejected',
            str_contains($operation, 'submit'), str_contains($operation, 'escalate') => 'pending',
            default => 'draft',
        };
    }

    public function calculate(array $payload): array
    {
        $record = BudgetVariance::create($this->normalisePayload($payload, 'calculate'));

        return $record->toArray();
    }
    public function explain(array $payload): array
    {
        $record = BudgetVariance::create($this->normalisePayload($payload, 'explain'));

        return $record->toArray();
    }
    public function flagAnomalies(array $payload): array
    {
        $record = BudgetVariance::create($this->normalisePayload($payload, 'flagAnomalies'));

        return $record->toArray();
    }
    public function adjust(array $payload): array
    {
        $record = BudgetVariance::create($this->normalisePayload($payload, 'adjust'));

        return $record->toArray();
    }
}
