<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Modules\Budgeting\Contracts\Services\AnalyticsFeedsServiceContract;
use Modules\Budgeting\Models\KpiSnapshot;

class AnalyticsFeedsService implements AnalyticsFeedsServiceContract
{
    private function normalisePayload(array $payload, string $operation): array
    {
        return [
            'tenant_id' => $payload['tenant_id'] ?? null,
            'status' => $payload['status'] ?? $this->statusFor($operation),
            'payload' => array_merge($payload, ['operation' => $operation]),
        ];
    }

    private function statusFor(string $operation): string
    {
        return match (true) {
            str_contains($operation, 'approve'), str_contains($operation, 'post'), str_contains($operation, 'paid') => 'approved',
            str_contains($operation, 'reject') => 'rejected',
            str_contains($operation, 'submit'), str_contains($operation, 'escalate') => 'pending',
            default => 'draft',
        };
    }

    public function publishBudgetFeed(array $payload): array
    {
        $record = KpiSnapshot::create($this->normalisePayload($payload, 'publishBudgetFeed'));

        return $record->toArray();
    }
    public function publishExpenseFeed(array $payload): array
    {
        $record = KpiSnapshot::create($this->normalisePayload($payload, 'publishExpenseFeed'));

        return $record->toArray();
    }
    public function buildKpiSnapshot(array $payload): array
    {
        $record = KpiSnapshot::create($this->normalisePayload($payload, 'buildKpiSnapshot'));

        return $record->toArray();
    }
    public function refreshForecastingDataset(array $payload): array
    {
        $record = KpiSnapshot::create($this->normalisePayload($payload, 'refreshForecastingDataset'));

        return $record->toArray();
    }
}
