<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Variance;

final class VarianceService
{
    // Scaffold stub: implement domain behaviour here.

}
