<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Modules\Budgeting\Contracts\Services\IntegrationsServiceContract;
use Modules\Budgeting\Models\IntegrationRun;

class IntegrationsService implements IntegrationsServiceContract
{
    private function normalisePayload(array $payload, string $operation): array
    {
        return [
            'tenant_id' => $payload['tenant_id'] ?? null,
            'status' => $payload['status'] ?? $this->statusFor($operation),
            'payload' => array_merge($payload, ['operation' => $operation]),
        ];
    }

    private function statusFor(string $operation): string
    {
        return match (true) {
            str_contains($operation, 'approve'), str_contains($operation, 'post'), str_contains($operation, 'paid') => 'approved',
            str_contains($operation, 'reject') => 'rejected',
            str_contains($operation, 'submit'), str_contains($operation, 'escalate') => 'pending',
            default => 'draft',
        };
    }

    public function syncBankTransactions(array $payload): array
    {
        $record = IntegrationRun::create($this->normalisePayload($payload, 'syncBankTransactions'));

        return $record->toArray();
    }
    public function syncAccountingActuals(array $payload): array
    {
        $record = IntegrationRun::create($this->normalisePayload($payload, 'syncAccountingActuals'));

        return $record->toArray();
    }
    public function syncPayrollCommitments(array $payload): array
    {
        $record = IntegrationRun::create($this->normalisePayload($payload, 'syncPayrollCommitments'));

        return $record->toArray();
    }
    public function sendWebhookEvent(array $payload): array
    {
        $record = IntegrationRun::create($this->normalisePayload($payload, 'sendWebhookEvent'));

        return $record->toArray();
    }
}
