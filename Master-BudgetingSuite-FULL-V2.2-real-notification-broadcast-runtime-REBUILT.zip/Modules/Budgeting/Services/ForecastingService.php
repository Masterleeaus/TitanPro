<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services;

use Modules\Budgeting\Contracts\Services\ForecastingServiceContract;
use Modules\Budgeting\Models\ForecastScenario;

class ForecastingService implements ForecastingServiceContract
{
    private function normalisePayload(array $payload, string $operation): array
    {
        return [
            'tenant_id' => $payload['tenant_id'] ?? null,
            'status' => $payload['status'] ?? $this->statusFor($operation),
            'payload' => array_merge($payload, ['operation' => $operation]),
        ];
    }

    private function statusFor(string $operation): string
    {
        return match (true) {
            str_contains($operation, 'approve'), str_contains($operation, 'post'), str_contains($operation, 'paid') => 'approved',
            str_contains($operation, 'reject') => 'rejected',
            str_contains($operation, 'submit'), str_contains($operation, 'escalate') => 'pending',
            default => 'draft',
        };
    }

    public function generateScenario(array $payload): array
    {
        $record = ForecastScenario::create($this->normalisePayload($payload, 'generateScenario'));

        return $record->toArray();
    }
    public function compareScenario(array $payload): array
    {
        $record = ForecastScenario::create($this->normalisePayload($payload, 'compareScenario'));

        return $record->toArray();
    }
    public function applyRecommendation(array $payload): array
    {
        $record = ForecastScenario::create($this->normalisePayload($payload, 'applyRecommendation'));

        return $record->toArray();
    }
    public function trainModel(array $payload): array
    {
        $record = ForecastScenario::create($this->normalisePayload($payload, 'trainModel'));

        return $record->toArray();
    }
}
