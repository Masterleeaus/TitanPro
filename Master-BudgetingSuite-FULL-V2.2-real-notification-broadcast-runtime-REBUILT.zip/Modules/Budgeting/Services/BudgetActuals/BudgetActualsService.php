<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\BudgetActuals;

final class BudgetActualsService
{
    // Scaffold stub: implement domain behaviour here.

}
