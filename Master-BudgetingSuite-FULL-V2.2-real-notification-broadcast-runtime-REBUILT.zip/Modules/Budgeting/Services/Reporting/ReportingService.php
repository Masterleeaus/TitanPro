<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Reporting;

final class ReportingService
{
    // Scaffold stub: implement domain behaviour here.

}
