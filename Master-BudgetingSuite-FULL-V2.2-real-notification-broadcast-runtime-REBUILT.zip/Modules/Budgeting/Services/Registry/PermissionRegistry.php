<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Registry;

use Modules\Budgeting\Contracts\Services\PermissionRegistryContract;

final class PermissionRegistry implements PermissionRegistryContract
{
    public function permissions(): array
    {
        return config('budgeting.permissions.permissions', []);
    }

    public function roles(): array
    {
        return config('budgeting.permissions.roles', []);
    }

    public function matrix(): array
    {
        return [
            'owner' => ['budgeting.*'],
            'finance_admin' => ['budgeting.budgets.*', 'budgeting.expenses.*', 'budgeting.actuals.*', 'budgeting.reimbursements.*'],
            'manager' => ['budgeting.expenses.approve', 'budgeting.analytics.view'],
            'employee' => ['budgeting.expenses.create', 'budgeting.expenses.view_own'],
            'auditor' => ['budgeting.audit.view', 'budgeting.analytics.view'],
        ];
    }
}
