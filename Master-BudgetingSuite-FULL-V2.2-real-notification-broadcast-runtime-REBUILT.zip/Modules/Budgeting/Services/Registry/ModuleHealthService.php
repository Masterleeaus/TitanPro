<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Registry;

use Modules\Budgeting\Contracts\Services\ModuleHealthServiceContract;

final class ModuleHealthService implements ModuleHealthServiceContract
{
    public function checks(): array
    {
        $base = dirname(__DIR__, 2);
        $required = [
            'module.json',
            'manifests/module.manifest.json',
            'manifests/permissions.manifest.json',
            'Routes/api.php',
            'Routes/expenses.php',
            'Database/Migrations',
            'Services/ExpensesService.php',
            'Services/BudgetActualsService.php',
            'Services/VarianceService.php',
        ];

        return array_map(fn (string $path): array => [
            'name' => $path,
            'status' => file_exists($base . DIRECTORY_SEPARATOR . $path) ? 'pass' : 'fail',
            'path' => $path,
        ], $required);
    }

    public function summary(): array
    {
        $checks = $this->checks();
        $failed = array_values(array_filter($checks, fn (array $check): bool => $check['status'] !== 'pass'));

        return [
            'module' => 'Budgeting',
            'status' => $failed === [] ? 'healthy' : 'degraded',
            'checks' => count($checks),
            'failed' => count($failed),
            'failures' => $failed,
        ];
    }
}
