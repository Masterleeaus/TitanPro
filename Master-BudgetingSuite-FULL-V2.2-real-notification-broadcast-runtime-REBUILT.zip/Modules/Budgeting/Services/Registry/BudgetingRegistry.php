<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Registry;

use Modules\Budgeting\Contracts\Registry\BudgetingRegistryContract;

final class BudgetingRegistry implements BudgetingRegistryContract
{
    public function metadata(): array
    {
        return ['module' => 'budgeting', 'capabilities' => ['budgets','expenses','approvals','forecasting','automation']];
    }

    public function health(): array
    {
        return ['status' => 'scaffolded'];
    }

    public function dependencies(): array
    {
        return ['laravel', 'filament'];
    }
}
