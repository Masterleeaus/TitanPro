<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Notifications;

use Modules\Budgeting\Contracts\Notifications\BudgetingNotificationDispatcherContract;
use Modules\Budgeting\Contracts\Services\NotificationRuntimeServiceContract;

final class NotificationRuntimeService implements NotificationRuntimeServiceContract
{
    public function __construct(
        private readonly BudgetingNotificationDispatcherContract $dispatcher,
    ) {}

    public function notifyExpenseSubmitted(array $expense, array $channels = []): array
    {
        return $this->emit('expense.submitted', $expense, $channels ?: ['in_app', 'mail']);
    }

    public function notifyExpenseApprovalChanged(array $expense, string $status, array $channels = []): array
    {
        return $this->emit('expense.approval_changed', $expense + ['status' => $status], $channels ?: ['in_app', 'mail', 'broadcast']);
    }

    public function notifyVarianceAlert(array $variance, array $channels = []): array
    {
        return $this->emit('variance.alert', $variance, $channels ?: ['in_app', 'slack', 'broadcast']);
    }

    public function notifyForecastReady(array $forecast, array $channels = []): array
    {
        return $this->emit('forecast.ready', $forecast, $channels ?: ['in_app', 'mail']);
    }

    private function emit(string $event, array $payload, array $channels): array
    {
        $message = [
            'event' => $event,
            'channels' => array_values(array_unique($channels)),
            'payload' => $payload,
            'queued' => true,
        ];

        $this->dispatcher->dispatch($event, $message);

        return $message;
    }
}
