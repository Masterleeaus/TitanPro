<?php

declare(strict_types=1);

namespace Modules\Budgeting\Services\Notifications;

use Modules\Budgeting\Contracts\Notifications\BudgetingNotificationDispatcherContract;

final class BudgetingNotificationDispatcher implements BudgetingNotificationDispatcherContract
{
    /** @var list<array{event:string,payload:array}> */
    private array $dispatched = [];

    public function dispatch(string $event, array $payload = []): void
    {
        $this->dispatched[] = [
            'event' => $event,
            'payload' => $payload,
        ];

        if (function_exists('event')) {
            event('budgeting.notification.dispatched', [$event, $payload]);
        }
    }

    public function dispatched(): array
    {
        return $this->dispatched;
    }
}
