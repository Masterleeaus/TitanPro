<?php

declare(strict_types=1);

namespace Modules\Budgeting\Providers;

use Illuminate\Support\ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Reserved for Budgeting module bindings.
    }

    public function boot(): void
    {
        // Reserved for Budgeting module boot logic.
    }
}
