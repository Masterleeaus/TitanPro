<?php

declare(strict_types=1);

namespace Modules\Budgeting\Providers;

use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Modules\Budgeting\Events\Domain\ExpenseApproved;
use Modules\Budgeting\Events\Domain\ExpensePostedToActuals;
use Modules\Budgeting\Events\Domain\ExpenseRejected;
use Modules\Budgeting\Events\Domain\ExpenseSubmitted;
use Modules\Budgeting\Listeners\Audit\RecordExpenseLifecycleAudit;
use Modules\Budgeting\Listeners\Domain\PostApprovedExpenseToActuals;

class EventServiceProvider extends ServiceProvider
{
    protected $listen = [
        ExpenseSubmitted::class => [RecordExpenseLifecycleAudit::class],
        ExpenseApproved::class => [PostApprovedExpenseToActuals::class, RecordExpenseLifecycleAudit::class],
        ExpenseRejected::class => [RecordExpenseLifecycleAudit::class],
        ExpensePostedToActuals::class => [RecordExpenseLifecycleAudit::class],
    ];
}
