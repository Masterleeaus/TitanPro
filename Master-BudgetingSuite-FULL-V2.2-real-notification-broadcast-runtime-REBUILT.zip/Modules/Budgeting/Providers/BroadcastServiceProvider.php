<?php

namespace Modules\Budgeting\Providers;

use Illuminate\Support\ServiceProvider;

class BroadcastServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Register Budgeting bindings.
    }

    public function boot(): void
    {
        // Boot Budgeting services.
    }
}
