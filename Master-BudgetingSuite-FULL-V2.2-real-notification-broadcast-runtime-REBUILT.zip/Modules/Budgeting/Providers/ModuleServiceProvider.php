<?php

declare(strict_types=1);

namespace Modules\Budgeting\Providers;

use Illuminate\Support\ServiceProvider;

class ModuleServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../Config/config.php', 'budgeting');
        $this->mergeConfigFrom(__DIR__ . '/../Config/expenses.php', 'budgeting-expenses');
        $this->mergeConfigFrom(__DIR__ . '/../Config/ai.php', 'budgeting-ai');
        $this->app->bind(\Modules\Budgeting\Contracts\Services\BudgetWorkflowServiceContract::class, \Modules\Budgeting\Services\BudgetWorkflowService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\ExpenseBudgetLinkerContract::class, \Modules\Budgeting\Services\ExpenseBudgetLinker::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\ExpensesServiceContract::class, \Modules\Budgeting\Services\ExpensesService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\ReceiptsServiceContract::class, \Modules\Budgeting\Services\ReceiptsService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\ReimbursementsServiceContract::class, \Modules\Budgeting\Services\ReimbursementsService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\BudgetActualsServiceContract::class, \Modules\Budgeting\Services\BudgetActualsService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\VarianceServiceContract::class, \Modules\Budgeting\Services\VarianceService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\ApprovalThresholdsServiceContract::class, \Modules\Budgeting\Services\ApprovalThresholdsService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\ForecastingServiceContract::class, \Modules\Budgeting\Services\ForecastingService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\AnalyticsFeedsServiceContract::class, \Modules\Budgeting\Services\AnalyticsFeedsService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\ReportingServiceContract::class, \Modules\Budgeting\Services\ReportingService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\IntegrationsServiceContract::class, \Modules\Budgeting\Services\IntegrationsService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\ApprovalWorkflowServiceContract::class, \Modules\Budgeting\Services\Workflow\ApprovalWorkflowService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\DashboardServiceContract::class, \Modules\Budgeting\Services\Analytics\DashboardService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\PermissionRegistryContract::class, \Modules\Budgeting\Services\Registry\PermissionRegistry::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\ModuleHealthServiceContract::class, \Modules\Budgeting\Services\Registry\ModuleHealthService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\StateTransitionServiceContract::class, \Modules\Budgeting\Services\StateTransitionService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\AuditRevisionServiceContract::class, \Modules\Budgeting\Services\AuditRevisionService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\AI\BudgetingAiGatewayContract::class, \Modules\Budgeting\Services\AI\BudgetingAiGateway::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\AiBudgetingServiceContract::class, \Modules\Budgeting\Services\AI\AiBudgetingService::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Notifications\BudgetingNotificationDispatcherContract::class, \Modules\Budgeting\Services\Notifications\BudgetingNotificationDispatcher::class);
        $this->app->bind(\Modules\Budgeting\Contracts\Services\NotificationRuntimeServiceContract::class, \Modules\Budgeting\Services\Notifications\NotificationRuntimeService::class);
    }

    public function boot(): void
    {
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');
        $this->loadViewsFrom(__DIR__ . '/../Resources/Views', 'Budgeting');
        $this->loadTranslationsFrom(__DIR__ . '/../Resources/Lang', 'Budgeting');

        foreach (['ai', 'notifications', 'channels'] as $routeFile) {
            $path = __DIR__ . '/../Routes/' . $routeFile . '.php';
            if (file_exists($path)) {
                $this->loadRoutesFrom($path);
            }
        }
    }
}
