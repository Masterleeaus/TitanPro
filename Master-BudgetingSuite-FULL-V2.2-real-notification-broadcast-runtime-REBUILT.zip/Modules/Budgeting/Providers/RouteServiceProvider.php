<?php

declare(strict_types=1);

namespace Modules\Budgeting\Providers;

use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        parent::boot();

        $this->routes(function (): void {
            foreach (['api', 'web', 'ai', 'notifications', 'channels', 'internal', 'webhook', 'workflow', 'admin'] as $routeFile) {
                $path = __DIR__ . '/../Routes/' . $routeFile . '.php';
                if (! file_exists($path)) {
                    continue;
                }
                match ($routeFile) {
                    'web', 'admin' => Route::middleware('web')->group($path),
                    'api', 'ai', 'notifications', 'internal', 'webhook', 'workflow' => Route::middleware('api')->group($path),
                    'channels' => Route::middleware('web')->group($path),
                    default => Route::group([], $path),
                };
            }
        });
    }
}
