<?php

declare(strict_types=1);

namespace Modules\Budgeting\Providers;

use Illuminate\Support\ServiceProvider;
use Modules\Budgeting\Support\Filament\BudgetingFilamentRegistry;

class FilamentServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('budgeting.filament.registry', static fn (): array => [
            'resources' => BudgetingFilamentRegistry::resources(),
            'pages' => BudgetingFilamentRegistry::pages(),
            'widgets' => BudgetingFilamentRegistry::widgets(),
            'navigation' => BudgetingFilamentRegistry::navigation(),
        ]);
    }

    public function boot(): void
    {
        if (function_exists('config')) {
            config()->set('budgeting.filament.resources', BudgetingFilamentRegistry::resources());
            config()->set('budgeting.filament.pages', BudgetingFilamentRegistry::pages());
            config()->set('budgeting.filament.widgets', BudgetingFilamentRegistry::widgets());
            config()->set('budgeting.filament.navigation', BudgetingFilamentRegistry::navigation());
        }
    }
}
