<?php

// Scaffold installer hook for proposed Budgeting features.
