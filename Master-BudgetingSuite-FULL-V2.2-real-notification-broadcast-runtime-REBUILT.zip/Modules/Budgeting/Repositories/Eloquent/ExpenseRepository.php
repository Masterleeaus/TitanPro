<?php

declare(strict_types=1);

namespace Modules\Budgeting\Repositories\Eloquent;

use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Modules\Budgeting\Contracts\Repositories\BudgetingRepositoryContract;
use Modules\Budgeting\Models\Expense;

class ExpenseRepository implements BudgetingRepositoryContract
{
    public function query(array $filters = []): Builder
    {
        return Expense::query()
            ->when($filters['tenant_id'] ?? null, fn (Builder $query, $value) => $query->where('tenant_id', $value))
            ->when($filters['budget_id'] ?? null, fn (Builder $query, $value) => $query->where('budget_id', $value))
            ->when($filters['period_id'] ?? null, fn (Builder $query, $value) => $query->where('period_id', $value))
            ->when($filters['account_id'] ?? null, fn (Builder $query, $value) => $query->where('account_id', $value))
            ->when($filters['cost_centre_id'] ?? null, fn (Builder $query, $value) => $query->where('cost_centre_id', $value))
            ->when($filters['status'] ?? null, fn (Builder $query, $value) => $query->where('status', $value));
    }

    public function paginate(array $filters = [], int $perPage = 25): LengthAwarePaginator
    {
        return $this->query($filters)->latest('expense_date')->paginate($perPage);
    }
}
