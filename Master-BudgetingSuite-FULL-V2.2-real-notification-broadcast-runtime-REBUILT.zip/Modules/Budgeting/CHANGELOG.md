# Budgeting Module Changelog

## Unreleased
- Added full Titan module scaffold.
## 1.9.1-real-canonical-structure
- Added full canonical Titan module skeleton directories and marker files.
- Added AI, Notifications, Registry contracts and services for next implementation passes.
- Added GraphQL/OpenAPI/docs scaffolds.
