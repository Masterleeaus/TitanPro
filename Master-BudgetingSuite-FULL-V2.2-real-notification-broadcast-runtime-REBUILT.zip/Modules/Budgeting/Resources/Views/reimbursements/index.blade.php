<x-layout>
    <h1>Budgeting Reimbursements</h1>
    <p>Reimbursement batches are now managed as part of the Budgeting module.</p>
</x-layout>
