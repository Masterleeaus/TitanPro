<x-layout>
    <h1>Budgeting Expenses</h1>
    <p>Expenses are now managed as part of the Budgeting module.</p>
</x-layout>
