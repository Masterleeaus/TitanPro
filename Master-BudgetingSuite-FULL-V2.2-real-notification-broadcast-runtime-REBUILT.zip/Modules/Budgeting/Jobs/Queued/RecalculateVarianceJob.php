<?php

declare(strict_types=1);

namespace Modules\Budgeting\Jobs\Queued;

final class RecalculateVarianceJob
{
    // Scaffold stub: implement domain behaviour here.

}
