<?php

declare(strict_types=1);

namespace Modules\Budgeting\Jobs\Queued;

final class GenerateForecastScenarioJob
{
    // Scaffold stub: implement domain behaviour here.

}
