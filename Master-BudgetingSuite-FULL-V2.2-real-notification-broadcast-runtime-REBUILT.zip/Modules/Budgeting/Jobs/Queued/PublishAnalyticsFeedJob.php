<?php

declare(strict_types=1);

namespace Modules\Budgeting\Jobs\Queued;

final class PublishAnalyticsFeedJob
{
    // Scaffold stub: implement domain behaviour here.

}
