<?php

declare(strict_types=1);

namespace Modules\Budgeting\Jobs\Queued;

final class RefreshBudgetActualsJob
{
    // Scaffold stub: implement domain behaviour here.

}
