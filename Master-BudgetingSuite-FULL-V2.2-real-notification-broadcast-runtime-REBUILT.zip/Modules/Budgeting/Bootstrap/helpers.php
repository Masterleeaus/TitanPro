<?php

/**
 * Bootstrap helpers scaffold for the Budgeting module.
 * Implement domain-specific behaviour here.
 */
