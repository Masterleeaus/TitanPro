<?php

/**
 * Bootstrap module scaffold for the Budgeting module.
 * Implement domain-specific behaviour here.
 */
