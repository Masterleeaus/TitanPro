<?php

/**
 * Bootstrap startup scaffold for the Budgeting module.
 * Implement domain-specific behaviour here.
 */
