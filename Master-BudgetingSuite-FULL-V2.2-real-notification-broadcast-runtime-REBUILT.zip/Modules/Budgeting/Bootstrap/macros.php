<?php

/**
 * Bootstrap macros scaffold for the Budgeting module.
 * Implement domain-specific behaviour here.
 */
