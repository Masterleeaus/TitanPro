<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        foreach (['budget_expenses', 'budget_actuals', 'budget_variances', 'budget_forecast_scenarios', 'budget_kpi_snapshots'] as $tableName) {
            if (! Schema::hasTable($tableName)) {
                continue;
            }

            Schema::table($tableName, function (Blueprint $table) use ($tableName): void {
                if (! Schema::hasColumn($tableName, 'period_id')) {
                    $table->foreignId('period_id')->nullable()->after('tenant_id')->constrained('budget_periods')->nullOnDelete();
                }
                if (! Schema::hasColumn($tableName, 'account_id')) {
                    $table->foreignId('account_id')->nullable()->after('period_id')->constrained('budget_accounts')->nullOnDelete();
                }
                if (! Schema::hasColumn($tableName, 'cost_centre_id')) {
                    $table->foreignId('cost_centre_id')->nullable()->after('account_id')->constrained('budget_cost_centres')->nullOnDelete();
                }
            });
        }
    }

    public function down(): void
    {
        foreach (['budget_expenses', 'budget_actuals', 'budget_variances', 'budget_forecast_scenarios', 'budget_kpi_snapshots'] as $tableName) {
            if (! Schema::hasTable($tableName)) {
                continue;
            }

            Schema::table($tableName, function (Blueprint $table) use ($tableName): void {
                foreach (['period_id', 'account_id', 'cost_centre_id'] as $column) {
                    if (Schema::hasColumn($tableName, $column)) {
                        $table->dropConstrainedForeignId($column);
                    }
                }
            });
        }
    }
};
