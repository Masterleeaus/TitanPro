<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('budget_income_categories', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->index();
            $table->string('name');
            $table->string('slug')->nullable()->index();
            $table->text('description')->nullable();
            $table->date('date')->nullable();
            $table->json('metadata')->nullable();
            $table->string('status')->default('active')->index();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('budget_income', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->index();
            $table->foreignId('category_id')->nullable()->index();
            $table->string('title')->nullable();
            $table->text('description')->nullable();
            $table->decimal('amount', 14, 2)->default(0);
            $table->string('currency', 3)->default('AUD');
            $table->date('income_date')->nullable()->index();
            $table->json('payload')->nullable();
            $table->json('metadata')->nullable();
            $table->string('status')->default('posted')->index();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('budget_ledger', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->index();
            $table->string('source_type')->index();
            $table->unsignedBigInteger('source_id')->index();
            $table->string('entry_type')->index();
            $table->string('category')->nullable()->index();
            $table->decimal('amount', 14, 2)->default(0);
            $table->string('currency', 3)->default('AUD');
            $table->decimal('balance', 14, 2)->nullable();
            $table->timestamp('posted_at')->nullable()->index();
            $table->json('metadata')->nullable();
            $table->string('status')->default('posted')->index();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['source_type', 'source_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('budget_ledger');
        Schema::dropIfExists('budget_income');
        Schema::dropIfExists('budget_income_categories');
    }
};
