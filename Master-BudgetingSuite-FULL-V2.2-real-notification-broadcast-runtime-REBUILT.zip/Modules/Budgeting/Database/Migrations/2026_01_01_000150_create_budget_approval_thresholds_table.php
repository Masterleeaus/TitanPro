<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('budget_approval_thresholds', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->index();
            $table->string('name')->index();
            $table->string('role')->nullable();
            $table->decimal('minimum_amount', 14, 2)->default(0);
            $table->decimal('maximum_amount', 14, 2)->nullable();
            $table->unsignedInteger('level')->default(1);
            $table->boolean('active')->default(true);
            $table->json('payload')->nullable();
            $table->json('metadata')->nullable();
            $table->string('status')->default('draft')->index();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('budget_approval_thresholds');
    }
};
