<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('budget_expenses', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->index();
            $table->foreignId('budget_id')->nullable()->index();
            $table->foreignId('allocation_id')->nullable()->index();
            $table->foreignId('actual_id')->nullable()->index();
            $table->foreignId('category_id')->nullable()->index();
            $table->foreignId('employee_id')->nullable()->index();
            $table->string('vendor')->nullable()->index();
            $table->string('title')->nullable();
            $table->text('description')->nullable();
            $table->text('notes')->nullable();
            $table->decimal('amount', 14, 2)->default(0);
            $table->string('currency', 3)->default('AUD');
            $table->date('expense_date')->nullable()->index();
            $table->timestamp('submitted_at')->nullable();
            $table->foreignId('approved_by')->nullable()->index();
            $table->timestamp('approved_at')->nullable();
            $table->foreignId('rejected_by')->nullable()->index();
            $table->timestamp('rejected_at')->nullable();
            $table->text('rejection_reason')->nullable();
            $table->timestamp('reimbursed_at')->nullable();
            $table->timestamp('posted_at')->nullable();
            $table->json('payload')->nullable();
            $table->json('metadata')->nullable();
            $table->string('status')->default('draft')->index();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['tenant_id', 'budget_id', 'status']);
            $table->index(['tenant_id', 'category_id', 'expense_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('budget_expenses');
    }
};
