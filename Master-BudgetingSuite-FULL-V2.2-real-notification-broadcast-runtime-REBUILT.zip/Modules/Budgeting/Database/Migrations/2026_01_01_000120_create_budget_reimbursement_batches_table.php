<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('budget_reimbursement_batches', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->index();
            $table->string('batch_number')->nullable()->index();
            $table->decimal('total_amount', 14, 2)->default(0);
            $table->string('currency', 3)->default('AUD');
            $table->foreignId('approved_by')->nullable()->index();
            $table->timestamp('approved_at')->nullable();
            $table->foreignId('paid_by')->nullable()->index();
            $table->timestamp('paid_at')->nullable();
            $table->json('payload')->nullable();
            $table->json('metadata')->nullable();
            $table->string('status')->default('draft')->index();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('budget_reimbursement_expense', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('reimbursement_batch_id')->index();
            $table->foreignId('expense_id')->index();
            $table->decimal('amount', 14, 2)->default(0);
            $table->string('status')->default('queued')->index();
            $table->timestamps();
            $table->unique(['reimbursement_batch_id', 'expense_id'], 'budget_reimbursement_expense_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('budget_reimbursement_expense');
        Schema::dropIfExists('budget_reimbursement_batches');
    }
};
