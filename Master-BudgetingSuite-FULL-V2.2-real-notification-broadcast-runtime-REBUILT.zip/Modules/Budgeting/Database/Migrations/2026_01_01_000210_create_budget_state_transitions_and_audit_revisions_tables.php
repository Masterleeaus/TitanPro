<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('budget_state_transitions', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->index();
            $table->morphs('transitionable');
            $table->string('workflow')->index();
            $table->string('from_state')->nullable()->index();
            $table->string('to_state')->index();
            $table->foreignId('actor_id')->nullable()->index();
            $table->text('reason')->nullable();
            $table->json('context')->nullable();
            $table->timestamp('occurred_at')->useCurrent()->index();
            $table->timestamps();
            $table->index(['tenant_id', 'workflow', 'to_state']);
        });

        Schema::create('budget_audit_revisions', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->index();
            $table->morphs('auditable');
            $table->foreignId('actor_id')->nullable()->index();
            $table->string('event')->index();
            $table->json('before')->nullable();
            $table->json('after')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamp('occurred_at')->useCurrent()->index();
            $table->timestamps();
            $table->index(['tenant_id', 'event', 'occurred_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('budget_audit_revisions');
        Schema::dropIfExists('budget_state_transitions');
    }
};
