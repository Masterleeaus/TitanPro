<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('budget_receipts', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->index();
            $table->foreignId('expense_id')->nullable()->index();
            $table->string('disk')->default('local');
            $table->string('path');
            $table->string('mime_type')->nullable();
            $table->unsignedBigInteger('size')->default(0);
            $table->longText('ocr_text')->nullable();
            $table->json('extracted_data')->nullable();
            $table->decimal('confidence', 5, 2)->nullable();
            $table->json('payload')->nullable();
            $table->json('metadata')->nullable();
            $table->string('status')->default('uploaded')->index();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['expense_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('budget_receipts');
    }
};
