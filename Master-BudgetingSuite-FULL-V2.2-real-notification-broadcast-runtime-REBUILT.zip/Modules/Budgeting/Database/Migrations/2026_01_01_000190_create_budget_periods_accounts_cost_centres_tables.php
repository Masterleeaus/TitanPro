<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('budget_periods', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->index();
            $table->string('name');
            $table->date('starts_at')->index();
            $table->date('ends_at')->index();
            $table->string('status')->default('open')->index();
            $table->boolean('is_locked')->default(false)->index();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['tenant_id', 'name']);
            $table->index(['tenant_id', 'starts_at', 'ends_at']);
        });

        Schema::create('budget_accounts', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->index();
            $table->string('code')->index();
            $table->string('name');
            $table->string('type')->default('expense')->index();
            $table->foreignId('parent_id')->nullable()->constrained('budget_accounts')->nullOnDelete();
            $table->boolean('is_active')->default(true)->index();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['tenant_id', 'code']);
        });

        Schema::create('budget_cost_centres', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->index();
            $table->string('code')->index();
            $table->string('name');
            $table->foreignId('manager_id')->nullable()->index();
            $table->foreignId('parent_id')->nullable()->constrained('budget_cost_centres')->nullOnDelete();
            $table->boolean('is_active')->default(true)->index();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['tenant_id', 'code']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('budget_cost_centres');
        Schema::dropIfExists('budget_accounts');
        Schema::dropIfExists('budget_periods');
    }
};
