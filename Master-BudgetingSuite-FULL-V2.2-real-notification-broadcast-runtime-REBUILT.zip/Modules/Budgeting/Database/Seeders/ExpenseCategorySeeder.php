<?php

declare(strict_types=1);

namespace Modules\Budgeting\Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\Budgeting\Models\ExpenseCategory;

class ExpenseCategorySeeder extends Seeder
{
    public function run(): void
    {
        foreach (['Travel', 'Meals', 'Software', 'Office Supplies', 'Contractors', 'Training'] as $name) {
            ExpenseCategory::query()->firstOrCreate(['slug' => str($name)->slug()->toString()], ['name' => $name, 'status' => 'active']);
        }
    }
}
