<?php

declare(strict_types=1);

namespace Modules\Budgeting\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class BudgetingPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        if (! Schema::hasTable('permissions')) {
            return;
        }

        foreach (json_decode(file_get_contents(__DIR__ . '/../../Permissions/Matrix/expenses.permissions.json'), true)['permissions'] as $permission) {
            DB::table('permissions')->updateOrInsert(['name' => $permission], ['title' => str($permission)->replace('.', ' ')->title()->toString()]);
        }
    }
}
