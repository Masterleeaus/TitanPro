<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

use Modules\Budgeting\Models\Base\BudgetingModel;

class Expense extends BudgetingModel
{
    protected $table = 'budget_expenses';

    public const STATUS_DRAFT = 'draft';
    public const STATUS_SUBMITTED = 'submitted';
    public const STATUS_PENDING = 'pending';
    public const STATUS_APPROVED = 'approved';
    public const STATUS_REJECTED = 'rejected';
    public const STATUS_REIMBURSED = 'reimbursed';
    public const STATUS_POSTED = 'posted';

    protected $fillable = [
        'tenant_id', 'period_id', 'account_id', 'cost_centre_id', 'budget_id', 'allocation_id', 'actual_id', 'category_id', 'employee_id', 'vendor',
        'title', 'description', 'notes', 'amount', 'currency', 'expense_date', 'submitted_at',
        'approved_by', 'approved_at', 'rejected_by', 'rejected_at', 'rejection_reason', 'reimbursed_at',
        'posted_at', 'payload', 'metadata', 'status',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'expense_date' => 'date',
        'submitted_at' => 'datetime',
        'approved_at' => 'datetime',
        'rejected_at' => 'datetime',
        'reimbursed_at' => 'datetime',
        'posted_at' => 'datetime',
        'payload' => 'array',
        'metadata' => 'array',
    ];

    public function category()
    {
        return $this->belongsTo(ExpenseCategory::class, 'category_id');
    }

    public function receipts()
    {
        return $this->hasMany(Receipt::class, 'expense_id');
    }

    public function reimbursements()
    {
        return $this->belongsToMany(ReimbursementBatch::class, 'budget_reimbursement_expense', 'expense_id', 'reimbursement_batch_id')
            ->withPivot(['amount', 'status'])
            ->withTimestamps();
    }

    public function actual()
    {
        return $this->hasOne(BudgetActual::class, 'source_id')->where('source_type', self::class);
    }

    public function variances()
    {
        return $this->hasMany(BudgetVariance::class, 'budget_id', 'budget_id');
    }


    public function period()
    {
        return $this->belongsTo(BudgetPeriod::class, 'period_id');
    }

    public function account()
    {
        return $this->belongsTo(BudgetAccount::class, 'account_id');
    }

    public function costCentre()
    {
        return $this->belongsTo(BudgetCostCentre::class, 'cost_centre_id');
    }

    public function stateTransitions()
    {
        return $this->morphMany(BudgetStateTransition::class, 'transitionable');
    }

    public function auditRevisions()
    {
        return $this->morphMany(BudgetAuditRevision::class, 'auditable');
    }
}
