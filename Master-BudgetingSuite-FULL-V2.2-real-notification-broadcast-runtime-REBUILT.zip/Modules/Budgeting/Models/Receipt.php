<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

use Modules\Budgeting\Models\Base\BudgetingModel;

class Receipt extends BudgetingModel
{
    protected $table = 'budget_receipts';

    protected $fillable = [
        'tenant_id', 'expense_id', 'disk', 'path', 'mime_type', 'size', 'ocr_text', 'extracted_data',
        'confidence', 'payload', 'metadata', 'status',
    ];

    protected $casts = [
        'size' => 'integer',
        'confidence' => 'decimal:2',
        'extracted_data' => 'array',
        'payload' => 'array',
        'metadata' => 'array',
    ];

    public function expense()
    {
        return $this->belongsTo(Expense::class, 'expense_id');
    }
}
