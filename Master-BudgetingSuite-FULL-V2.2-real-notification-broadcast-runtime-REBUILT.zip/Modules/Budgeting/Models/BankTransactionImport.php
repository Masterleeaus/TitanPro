<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

final class BankTransactionImport
{
    protected array $fillable = [];

}
