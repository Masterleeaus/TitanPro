<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models\Base;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

abstract class BudgetingModel extends Model
{
    use SoftDeletes;

    protected $guarded = ['id'];

    protected $casts = [
        'payload' => 'array',
        'metadata' => 'array',
        'occurred_at' => 'datetime',
        'approved_at' => 'datetime',
        'submitted_at' => 'datetime',
        'paid_at' => 'datetime',
        'posted_at' => 'datetime',
    ];

    public function scopeForTenant($query, mixed $tenantId)
    {
        return $query->where('tenant_id', $tenantId);
    }
}
