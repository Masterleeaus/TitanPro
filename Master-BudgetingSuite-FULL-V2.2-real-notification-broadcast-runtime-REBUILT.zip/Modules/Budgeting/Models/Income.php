<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

use Modules\Budgeting\Models\Base\BudgetingModel;

class Income extends BudgetingModel
{
    protected $table = 'budget_income';
    protected $fillable = ['tenant_id', 'category_id', 'title', 'description', 'amount', 'currency', 'income_date', 'payload', 'metadata', 'status'];
    protected $casts = ['amount' => 'decimal:2', 'income_date' => 'date', 'payload' => 'array', 'metadata' => 'array'];

    public function category()
    {
        return $this->belongsTo(IncomeCategory::class, 'category_id');
    }
}
