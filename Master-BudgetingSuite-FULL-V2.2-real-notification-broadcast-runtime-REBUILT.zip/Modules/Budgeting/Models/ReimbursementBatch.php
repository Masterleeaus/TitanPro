<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

use Modules\Budgeting\Models\Base\BudgetingModel;

class ReimbursementBatch extends BudgetingModel
{
    protected $table = 'budget_reimbursement_batches';

    protected $fillable = [
        'tenant_id', 'batch_number', 'total_amount', 'currency', 'approved_by', 'approved_at',
        'paid_by', 'paid_at', 'payload', 'metadata', 'status',
    ];

    protected $casts = [
        'total_amount' => 'decimal:2',
        'approved_at' => 'datetime',
        'paid_at' => 'datetime',
        'payload' => 'array',
        'metadata' => 'array',
    ];

    public function expenses()
    {
        return $this->belongsToMany(Expense::class, 'budget_reimbursement_expense', 'reimbursement_batch_id', 'expense_id')
            ->withPivot(['amount', 'status'])
            ->withTimestamps();
    }
}
