<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

class Reimbursement extends ReimbursementBatch
{
    // Backward-compatible alias for older scaffold references.
}
