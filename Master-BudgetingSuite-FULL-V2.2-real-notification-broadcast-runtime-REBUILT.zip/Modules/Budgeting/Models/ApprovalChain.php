<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

final class ApprovalChain
{
    protected array $fillable = [];

}
