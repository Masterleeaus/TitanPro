<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

use Modules\Budgeting\Models\Base\BudgetingModel;

class ForecastScenario extends BudgetingModel
{
    protected $table = 'budget_forecast_scenarios';

    public const STATUS_DRAFT = 'draft';
    public const STATUS_PENDING = 'pending';
    public const STATUS_APPROVED = 'approved';
    public const STATUS_REJECTED = 'rejected';
    public const STATUS_POSTED = 'posted';
}
