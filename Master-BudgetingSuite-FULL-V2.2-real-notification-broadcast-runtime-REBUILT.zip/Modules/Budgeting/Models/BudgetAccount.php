<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

use Modules\Budgeting\Models\Base\BudgetingModel;

class BudgetAccount extends BudgetingModel
{
    protected $table = 'budget_accounts';

    protected $casts = [
        'metadata' => 'array',
        'context' => 'array',
        'before' => 'array',
        'after' => 'array',
        'starts_at' => 'date',
        'ends_at' => 'date',
        'occurred_at' => 'datetime',
        'is_locked' => 'boolean',
        'is_active' => 'boolean',
    ];

}
