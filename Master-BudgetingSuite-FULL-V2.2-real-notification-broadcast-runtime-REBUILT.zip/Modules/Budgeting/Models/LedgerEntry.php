<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

use Modules\Budgeting\Models\Base\BudgetingModel;

class LedgerEntry extends BudgetingModel
{
    protected $table = 'budget_ledger';
    protected $fillable = ['tenant_id', 'source_type', 'source_id', 'entry_type', 'category', 'amount', 'currency', 'balance', 'posted_at', 'metadata', 'status'];
    protected $casts = ['amount' => 'decimal:2', 'balance' => 'decimal:2', 'posted_at' => 'datetime', 'metadata' => 'array'];
}
