<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

use Modules\Budgeting\Models\Base\BudgetingModel;

class IncomeCategory extends BudgetingModel
{
    protected $table = 'budget_income_categories';
    protected $fillable = ['tenant_id', 'name', 'slug', 'description', 'date', 'metadata', 'status'];
    protected $casts = ['date' => 'date', 'metadata' => 'array'];

    public function incomes()
    {
        return $this->hasMany(Income::class, 'category_id');
    }
}
