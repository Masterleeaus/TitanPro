<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

use Modules\Budgeting\Models\Base\BudgetingModel;

class BudgetActual extends BudgetingModel
{
    protected $table = 'budget_actuals';

    public const STATUS_DRAFT = 'draft';
    public const STATUS_PENDING = 'pending';
    public const STATUS_APPROVED = 'approved';
    public const STATUS_REJECTED = 'rejected';
    public const STATUS_POSTED = 'posted';

    public function expense()
    {
        return $this->belongsTo(Expense::class, 'source_id')->where('source_type', Expense::class);
    }

}
