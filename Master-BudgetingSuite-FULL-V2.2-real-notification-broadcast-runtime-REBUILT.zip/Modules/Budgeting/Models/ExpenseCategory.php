<?php

declare(strict_types=1);

namespace Modules\Budgeting\Models;

use Modules\Budgeting\Models\Base\BudgetingModel;

class ExpenseCategory extends BudgetingModel
{
    protected $table = 'budget_expense_categories';

    protected $fillable = ['tenant_id', 'name', 'slug', 'description', 'date', 'metadata', 'status'];

    protected $casts = ['date' => 'date', 'metadata' => 'array'];

    public function expenses()
    {
        return $this->hasMany(Expense::class, 'category_id');
    }
}
