<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Route;
use Modules\Budgeting\Http\Controllers\API\ExpensesController;

Route::prefix('api/budgeting/expenses')->middleware(['api'])->group(function (): void {
    Route::get('/', [ExpensesController::class, 'index']);
    Route::post('/', [ExpensesController::class, 'store']);
    Route::get('{expense}', [ExpensesController::class, 'show']);
    Route::post('{expense}/submit', [ExpensesController::class, 'submit']);
    Route::post('{expense}/approve', [ExpensesController::class, 'approve']);
    Route::post('{expense}/reject', [ExpensesController::class, 'reject']);
    Route::post('{expense}/post', [ExpensesController::class, 'post']);
    Route::post('{expense}/link-budget', [ExpensesController::class, 'link']);
});
