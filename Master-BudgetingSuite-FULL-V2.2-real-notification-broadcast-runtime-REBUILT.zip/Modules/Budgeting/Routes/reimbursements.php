<?php

declare(strict_types=1);

// Reimbursement API routes are registered from Routes/expenses.php so finance workflow routes stay together.
