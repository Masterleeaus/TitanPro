<?php

use Illuminate\Support\Facades\Route;

// Budgeting webhook routes.
