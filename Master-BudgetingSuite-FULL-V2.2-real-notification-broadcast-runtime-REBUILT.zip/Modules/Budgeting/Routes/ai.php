<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Route;
use Modules\Budgeting\Http\Controllers\API\AiBudgetingController;

Route::prefix('budgeting/ai')->name('budgeting.ai.')->group(function (): void {
    Route::post('forecast', [AiBudgetingController::class, 'forecast'])->name('forecast');
    Route::post('expenses/classify', [AiBudgetingController::class, 'classifyExpense'])->name('expenses.classify');
    Route::post('receipts/extract', [AiBudgetingController::class, 'extractReceipt'])->name('receipts.extract');
    Route::post('variance/inspect', [AiBudgetingController::class, 'inspectVariance'])->name('variance.inspect');
});
