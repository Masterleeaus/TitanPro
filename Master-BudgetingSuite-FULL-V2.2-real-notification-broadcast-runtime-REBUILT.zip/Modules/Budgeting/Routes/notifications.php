<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Route;
use Modules\Budgeting\Http\Controllers\API\NotificationController;

Route::prefix('api/budgeting/notifications')->middleware(['api'])->group(function (): void {
    Route::post('expenses/submitted', [NotificationController::class, 'expenseSubmitted']);
    Route::post('expenses/approval-changed', [NotificationController::class, 'expenseApprovalChanged']);
    Route::post('variance/alert', [NotificationController::class, 'varianceAlert']);
    Route::post('forecast/ready', [NotificationController::class, 'forecastReady']);
});
