<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Route;
use Modules\Budgeting\Http\Controllers\API\BudgetActualsController;
use Modules\Budgeting\Http\Controllers\API\VarianceController;

Route::prefix('api/budgeting')->middleware(['api'])->group(function (): void {
    Route::get('actuals', [BudgetActualsController::class, 'index']);
    Route::post('actuals', [BudgetActualsController::class, 'store']);
    Route::get('variance', [VarianceController::class, 'index']);
    Route::post('variance/calculate', [VarianceController::class, 'calculate']);
});
