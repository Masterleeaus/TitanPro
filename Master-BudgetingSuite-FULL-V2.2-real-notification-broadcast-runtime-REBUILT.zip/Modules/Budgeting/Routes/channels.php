<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Broadcast;
use Modules\Budgeting\Broadcasting\Channels\BudgetingChannel;

Broadcast::channel('budgeting.expenses', [BudgetingChannel::class, 'join']);
Broadcast::channel('budgeting.approvals', [BudgetingChannel::class, 'join']);
Broadcast::channel('budgeting.variance', [BudgetingChannel::class, 'join']);
