<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Route;

Route::middleware(['web', 'auth', 'can:budgeting.access'])->prefix('budgeting')->name('budgeting.')->group(function (): void {
    Route::view('/', 'Budgeting::index')->name('index');
    Route::view('/expenses', 'Budgeting::expenses.index')->name('expenses.index');
    Route::view('/reimbursements', 'Budgeting::reimbursements.index')->name('reimbursements.index');
});
