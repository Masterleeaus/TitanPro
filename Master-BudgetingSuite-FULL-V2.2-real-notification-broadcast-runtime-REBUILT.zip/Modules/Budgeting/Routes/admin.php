<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Route;
use Modules\Budgeting\Http\Controllers\Admin\BudgetingAdminController;

Route::middleware(['web', 'auth', 'can:budgeting.access'])
    ->prefix('budgeting/admin')
    ->name('budgeting.admin.')
    ->group(function (): void {
        Route::get('/', [BudgetingAdminController::class, 'dashboard'])->name('dashboard');
        Route::get('/expenses', [BudgetingAdminController::class, 'expenses'])->name('expenses');
        Route::get('/approvals', [BudgetingAdminController::class, 'approvals'])->name('approvals');
        Route::get('/actuals', [BudgetingAdminController::class, 'actuals'])->name('actuals');
        Route::get('/variances', [BudgetingAdminController::class, 'variances'])->name('variances');
        Route::get('/forecasts', [BudgetingAdminController::class, 'forecasts'])->name('forecasts');
        Route::get('/reimbursements', [BudgetingAdminController::class, 'reimbursements'])->name('reimbursements');
        Route::get('/receipts', [BudgetingAdminController::class, 'receipts'])->name('receipts');
    });
