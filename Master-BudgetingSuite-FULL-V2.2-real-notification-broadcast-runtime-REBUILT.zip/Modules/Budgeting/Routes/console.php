<?php

use Illuminate\Support\Facades\Route;

// Budgeting console routes.
