<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Route;
use Modules\Budgeting\Http\Controllers\API\BudgetingController;

Route::prefix('api/budgeting')->middleware(['api'])->group(function (): void {
    Route::post('forecast/scenarios', [BudgetingController::class, 'forecast']);
    Route::post('reports/budget-vs-actual', [BudgetingController::class, 'budgetVsActual']);
});

require __DIR__ . '/actuals.php';
require __DIR__ . '/expenses.php';
require __DIR__ . '/receipts.php';
require __DIR__ . '/reimbursements.php';

require __DIR__ . '/workflow-api.php';
