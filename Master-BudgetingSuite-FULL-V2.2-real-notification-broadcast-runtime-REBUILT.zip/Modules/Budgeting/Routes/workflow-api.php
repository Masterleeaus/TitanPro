<?php

declare(strict_types=1);

use Illuminate\Support\Facades\Route;
use Modules\Budgeting\Http\Controllers\API\BudgetingWorkflowController;

Route::prefix('api/budgeting')->middleware(['api'])->group(function (): void {
    Route::post('workflow/expenses/submit', [BudgetingWorkflowController::class, 'submitExpense']);
    Route::get('dashboards', [BudgetingWorkflowController::class, 'dashboards']);
    Route::get('health', [BudgetingWorkflowController::class, 'health']);
});
