<?php

declare(strict_types=1);

// Receipt API routes are registered from Routes/expenses.php so expense-scoped upload routes stay together.
