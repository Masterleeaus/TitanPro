<?php

use Illuminate\Support\Facades\Route;

// Budgeting workflow routes.
