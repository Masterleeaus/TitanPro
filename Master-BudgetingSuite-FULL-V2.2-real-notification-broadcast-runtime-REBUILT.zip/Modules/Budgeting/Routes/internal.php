<?php

use Illuminate\Support\Facades\Route;

// Budgeting internal routes.
