<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class RunExpenseWorkflowRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'employee_id' => ['nullable'],
            'budget_id' => ['nullable'],
            'category_id' => ['nullable'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'currency' => ['nullable', 'string', 'size:3'],
            'description' => ['required', 'string', 'max:500'],
            'merchant' => ['nullable', 'string', 'max:255'],
            'expense_date' => ['nullable', 'date'],
            'metadata' => ['nullable', 'array'],
        ];
    }
}
