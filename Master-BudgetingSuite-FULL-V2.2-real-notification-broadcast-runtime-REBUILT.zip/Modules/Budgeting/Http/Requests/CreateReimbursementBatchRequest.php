<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Requests;

final class CreateReimbursementBatchRequest
{
    // Scaffold stub: implement domain behaviour here.

}
