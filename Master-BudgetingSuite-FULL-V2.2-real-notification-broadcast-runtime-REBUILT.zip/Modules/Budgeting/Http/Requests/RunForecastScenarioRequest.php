<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Requests;

final class RunForecastScenarioRequest
{
    // Scaffold stub: implement domain behaviour here.

}
