<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\Webhooks;

final class WebhookController
{
    // Scaffold stub: implement domain behaviour here.

}
