<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\API;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Modules\Budgeting\Contracts\Services\NotificationRuntimeServiceContract;

final class NotificationController
{
    public function __construct(
        private readonly NotificationRuntimeServiceContract $notifications,
    ) {}

    public function expenseSubmitted(Request $request): JsonResponse
    {
        return response()->json($this->notifications->notifyExpenseSubmitted($request->all()));
    }

    public function expenseApprovalChanged(Request $request): JsonResponse
    {
        return response()->json($this->notifications->notifyExpenseApprovalChanged(
            $request->input('expense', []),
            (string) $request->input('status', 'submitted'),
            $request->input('channels', [])
        ));
    }

    public function varianceAlert(Request $request): JsonResponse
    {
        return response()->json($this->notifications->notifyVarianceAlert($request->all()));
    }

    public function forecastReady(Request $request): JsonResponse
    {
        return response()->json($this->notifications->notifyForecastReady($request->all()));
    }
}
