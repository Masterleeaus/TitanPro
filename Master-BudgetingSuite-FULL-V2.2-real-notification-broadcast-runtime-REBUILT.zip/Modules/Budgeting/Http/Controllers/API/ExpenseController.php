<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\API;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Budgeting\Contracts\Services\ExpensesServiceContract;
use Modules\Budgeting\Http\Resources\ExpenseResource;
use Modules\Budgeting\Models\Expense;

final class ExpenseController extends Controller
{
    public function __construct(private readonly ExpensesServiceContract $expenses) {}

    public function index(Request $request): JsonResponse
    {
        $rows = Expense::query()
            ->with(['category', 'receipts'])
            ->when($request->query('status'), fn ($q, $status) => $q->where('status', $status))
            ->when($request->query('budget_id'), fn ($q, $budgetId) => $q->where('budget_id', $budgetId))
            ->latest('id')
            ->paginate((int) $request->query('per_page', 25));

        return response()->json(ExpenseResource::collection($rows)->response()->getData(true));
    }

    public function store(Request $request): JsonResponse
    {
        $expense = $this->expenses->create($request->validate([
            'tenant_id' => ['nullable', 'integer'],
            'budget_id' => ['nullable', 'integer'],
            'allocation_id' => ['nullable', 'integer'],
            'category_id' => ['nullable', 'integer'],
            'employee_id' => ['nullable', 'integer'],
            'vendor' => ['nullable', 'string', 'max:255'],
            'title' => ['nullable', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'notes' => ['nullable', 'string'],
            'amount' => ['required', 'numeric', 'min:0'],
            'currency' => ['nullable', 'string', 'size:3'],
            'expense_date' => ['nullable', 'date'],
            'metadata' => ['nullable', 'array'],
        ]));

        return response()->json(new ExpenseResource($expense), 201);
    }

    public function show(int $expense): JsonResponse
    {
        return response()->json(new ExpenseResource(Expense::query()->with(['category', 'receipts', 'reimbursements'])->findOrFail($expense)));
    }

    public function submit(int $expense): JsonResponse
    {
        return response()->json(new ExpenseResource($this->expenses->submit($expense)));
    }

    public function approve(Request $request, int $expense): JsonResponse
    {
        return response()->json(new ExpenseResource($this->expenses->approve($expense, optional($request->user())->id)));
    }

    public function reject(Request $request, int $expense): JsonResponse
    {
        return response()->json(new ExpenseResource($this->expenses->reject($expense, optional($request->user())->id, $request->string('reason')->toString())));
    }

    public function reimburse(int $expense): JsonResponse
    {
        return response()->json(new ExpenseResource($this->expenses->reimburse($expense)));
    }

    public function post(int $expense): JsonResponse
    {
        return response()->json(['data' => $this->expenses->postToLedger($expense)]);
    }
}
