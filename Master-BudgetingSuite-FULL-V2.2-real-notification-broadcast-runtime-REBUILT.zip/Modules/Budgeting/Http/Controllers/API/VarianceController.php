<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\API;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Budgeting\Models\BudgetVariance;
use Modules\Budgeting\Services\VarianceService;

class VarianceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = BudgetVariance::query()->latest('period_start')->latest('id');
        foreach (['tenant_id', 'budget_id', 'allocation_id', 'category_id'] as $filter) {
            if ($request->filled($filter)) {
                $query->where($filter, $request->input($filter));
            }
        }
        return response()->json(['data' => $query->paginate((int) $request->input('per_page', 25))]);
    }

    public function calculate(Request $request, VarianceService $variance): JsonResponse
    {
        return response()->json(['data' => $variance->calculate($request->all())]);
    }
}
