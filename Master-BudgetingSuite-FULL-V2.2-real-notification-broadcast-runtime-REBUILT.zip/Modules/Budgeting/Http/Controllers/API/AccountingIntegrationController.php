<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\API;

final class AccountingIntegrationController
{
    // Scaffold stub: implement domain behaviour here.

}
