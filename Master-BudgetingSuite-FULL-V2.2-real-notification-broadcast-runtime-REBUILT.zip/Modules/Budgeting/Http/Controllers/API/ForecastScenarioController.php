<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\API;

final class ForecastScenarioController
{
    // Scaffold stub: implement domain behaviour here.

}
