<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\API;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Budgeting\Services\BudgetWorkflowService;
use Modules\Budgeting\Services\ExpenseBudgetLinker;
use Modules\Budgeting\Services\ExpensesService;

class ExpensesController extends Controller
{
    public function __construct(
        protected ExpensesService $expenses,
        protected BudgetWorkflowService $workflow,
        protected ExpenseBudgetLinker $linker,
    ) {}

    public function index(Request $request): JsonResponse
    {
        $query = \Modules\Budgeting\Models\Expense::query()->latest('expense_date')->latest('id');
        foreach (['tenant_id', 'budget_id', 'allocation_id', 'category_id', 'status'] as $filter) {
            if ($request->filled($filter)) {
                $query->where($filter, $request->input($filter));
            }
        }
        return response()->json(['data' => $query->paginate((int) $request->input('per_page', 25))]);
    }

    public function store(Request $request): JsonResponse
    {
        $payload = $request->validate([
            'tenant_id' => ['nullable', 'integer'],
            'budget_id' => ['nullable', 'integer'],
            'allocation_id' => ['nullable', 'integer'],
            'category_id' => ['nullable', 'integer'],
            'title' => ['required', 'string', 'max:255'],
            'amount' => ['required', 'numeric'],
            'currency' => ['nullable', 'string', 'size:3'],
            'expense_date' => ['nullable', 'date'],
            'vendor' => ['nullable', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'metadata' => ['nullable', 'array'],
        ]);
        $payload = array_merge($payload, $this->linker->inferLinks($payload));
        return response()->json(['data' => $this->expenses->create($payload)], 201);
    }

    public function show(int $expense): JsonResponse
    {
        return response()->json(['data' => \Modules\Budgeting\Models\Expense::query()->with(['category', 'receipts'])->findOrFail($expense)]);
    }

    public function submit(int $expense): JsonResponse
    {
        return response()->json(['data' => $this->workflow->submitExpense($expense)]);
    }

    public function approve(Request $request, int $expense): JsonResponse
    {
        return response()->json(['data' => $this->workflow->approveExpense($expense, $request->integer('approver_id') ?: null)]);
    }

    public function reject(Request $request, int $expense): JsonResponse
    {
        return response()->json(['data' => $this->workflow->rejectExpense($expense, $request->integer('rejected_by') ?: null, $request->string('reason')->toString() ?: null)]);
    }

    public function post(int $expense): JsonResponse
    {
        return response()->json(['data' => $this->workflow->postExpense($expense)]);
    }

    public function link(Request $request, int $expense): JsonResponse
    {
        return response()->json(['data' => $this->linker->link($expense, $request->integer('budget_id') ?: null, $request->integer('allocation_id') ?: null, $request->integer('category_id') ?: null)]);
    }
}
