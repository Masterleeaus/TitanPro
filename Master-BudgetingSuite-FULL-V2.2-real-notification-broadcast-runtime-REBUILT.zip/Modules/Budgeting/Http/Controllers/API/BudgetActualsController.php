<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\API;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Budgeting\Models\BudgetActual;
use Modules\Budgeting\Services\BudgetActualsService;

class BudgetActualsController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = BudgetActual::query()->latest('actual_date')->latest('id');
        foreach (['tenant_id', 'budget_id', 'allocation_id', 'category_id', 'source_type', 'status'] as $filter) {
            if ($request->filled($filter)) {
                $query->where($filter, $request->input($filter));
            }
        }
        return response()->json(['data' => $query->paginate((int) $request->input('per_page', 25))]);
    }

    public function store(Request $request, BudgetActualsService $actuals): JsonResponse
    {
        return response()->json(['data' => $actuals->record($request->all())], 201);
    }
}
