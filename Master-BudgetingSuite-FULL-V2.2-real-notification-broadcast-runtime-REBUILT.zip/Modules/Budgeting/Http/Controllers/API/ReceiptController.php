<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\API;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Budgeting\Contracts\Services\ReceiptsServiceContract;
use Modules\Budgeting\Http\Resources\ReceiptResource;
use Modules\Budgeting\Models\Receipt;

final class ReceiptController extends Controller
{
    public function __construct(private readonly ReceiptsServiceContract $receipts) {}

    public function index(Request $request): JsonResponse
    {
        $rows = Receipt::query()
            ->with('expense')
            ->when($request->query('expense_id'), fn ($q, $expenseId) => $q->where('expense_id', $expenseId))
            ->latest('id')
            ->paginate((int) $request->query('per_page', 25));
        return response()->json(ReceiptResource::collection($rows)->response()->getData(true));
    }

    public function store(Request $request, int $expense): JsonResponse
    {
        $request->validate(['file' => ['required', 'file', 'max:20480']]);
        return response()->json(new ReceiptResource($this->receipts->attach($expense, $request->file('file'))), 201);
    }

    public function extract(Request $request, int $receipt): JsonResponse
    {
        $data = $request->input('extracted_data', []);
        $ocrText = $request->input('ocr_text');
        $confidence = $request->input('confidence');
        return response()->json(new ReceiptResource($this->receipts->markExtracted($receipt, $data, $ocrText, $confidence === null ? null : (float) $confidence)));
    }
}
