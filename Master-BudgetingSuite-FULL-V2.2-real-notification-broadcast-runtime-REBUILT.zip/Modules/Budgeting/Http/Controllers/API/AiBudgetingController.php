<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\API;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Budgeting\Contracts\Services\AiBudgetingServiceContract;

final class AiBudgetingController extends Controller
{
    public function __construct(private readonly AiBudgetingServiceContract $ai)
    {
    }

    public function forecast(Request $request): JsonResponse
    {
        return response()->json($this->ai->prepareForecast($request->all()));
    }

    public function classifyExpense(Request $request): JsonResponse
    {
        return response()->json($this->ai->classifyExpense($request->all()));
    }

    public function extractReceipt(Request $request): JsonResponse
    {
        return response()->json($this->ai->extractReceipt($request->all()));
    }

    public function inspectVariance(Request $request): JsonResponse
    {
        return response()->json($this->ai->inspectVariance($request->all()));
    }
}
