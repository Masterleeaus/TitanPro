<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\API;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Budgeting\Services\BudgetActualsService;
use Modules\Budgeting\Services\ExpensesService;
use Modules\Budgeting\Services\ForecastingService;
use Modules\Budgeting\Services\ReportingService;
use Modules\Budgeting\Services\VarianceService;

class BudgetingController extends Controller
{
    public function createExpense(Request $request, ExpensesService $service): JsonResponse
    {
        return response()->json(['data' => $service->create($request->all())], 201);
    }

    public function submitExpense(Request $request, ExpensesService $service): JsonResponse
    {
        return response()->json(['data' => $service->submit($request->all())]);
    }

    public function postActual(Request $request, BudgetActualsService $service): JsonResponse
    {
        return response()->json(['data' => $service->post($request->all())], 201);
    }

    public function calculateVariance(Request $request, VarianceService $service): JsonResponse
    {
        return response()->json(['data' => $service->calculate($request->all())]);
    }

    public function forecast(Request $request, ForecastingService $service): JsonResponse
    {
        return response()->json(['data' => $service->generateScenario($request->all())]);
    }

    public function budgetVsActual(Request $request, ReportingService $service): JsonResponse
    {
        return response()->json(['data' => $service->budgetVsActual($request->all())]);
    }
}
