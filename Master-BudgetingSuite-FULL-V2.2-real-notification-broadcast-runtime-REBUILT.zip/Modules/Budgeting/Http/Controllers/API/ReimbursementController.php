<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\API;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Budgeting\Contracts\Services\ReimbursementsServiceContract;
use Modules\Budgeting\Http\Resources\ReimbursementResource;
use Modules\Budgeting\Models\ReimbursementBatch;

final class ReimbursementController extends Controller
{
    public function __construct(private readonly ReimbursementsServiceContract $reimbursements) {}

    public function index(Request $request): JsonResponse
    {
        $rows = ReimbursementBatch::query()->with('expenses')->latest('id')->paginate((int) $request->query('per_page', 25));
        return response()->json(ReimbursementResource::collection($rows)->response()->getData(true));
    }

    public function store(Request $request): JsonResponse
    {
        $payload = $request->validate(['expense_ids' => ['required', 'array'], 'expense_ids.*' => ['integer'], 'tenant_id' => ['nullable', 'integer'], 'currency' => ['nullable', 'string', 'size:3']]);
        return response()->json(new ReimbursementResource($this->reimbursements->createBatch($payload['expense_ids'], $payload)), 201);
    }

    public function approve(Request $request, int $batch): JsonResponse
    {
        return response()->json(new ReimbursementResource($this->reimbursements->approveBatch($batch, optional($request->user())->id)));
    }

    public function paid(Request $request, int $batch): JsonResponse
    {
        return response()->json(new ReimbursementResource($this->reimbursements->markPaid($batch, optional($request->user())->id)));
    }
}
