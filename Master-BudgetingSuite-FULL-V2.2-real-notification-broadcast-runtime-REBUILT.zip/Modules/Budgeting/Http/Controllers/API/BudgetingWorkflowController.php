<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\API;

use Illuminate\Routing\Controller;
use Modules\Budgeting\Actions\Registry\RunBudgetingHealthCheckAction;
use Modules\Budgeting\Actions\Reporting\BuildDashboardPayloadAction;
use Modules\Budgeting\Actions\Workflow\RunExpenseApprovalWorkflowAction;
use Modules\Budgeting\Http\Requests\RunExpenseWorkflowRequest;

final class BudgetingWorkflowController extends Controller
{
    public function submitExpense(RunExpenseWorkflowRequest $request, RunExpenseApprovalWorkflowAction $action)
    {
        return response()->json($action($request->validated()));
    }

    public function dashboards(BuildDashboardPayloadAction $action)
    {
        return response()->json($action(request()->all()));
    }

    public function health(RunBudgetingHealthCheckAction $action)
    {
        return response()->json($action());
    }
}
