<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Controllers\Admin;

use Illuminate\Routing\Controller;
use Modules\Budgeting\Support\Filament\BudgetingFilamentRegistry;

final class BudgetingAdminController extends Controller
{
    public function dashboard(): array { return $this->screen('dashboard'); }
    public function expenses(): array { return $this->screen('expenses'); }
    public function approvals(): array { return $this->screen('approvals'); }
    public function actuals(): array { return $this->screen('actuals'); }
    public function variances(): array { return $this->screen('variances'); }
    public function forecasts(): array { return $this->screen('forecasts'); }
    public function reimbursements(): array { return $this->screen('reimbursements'); }
    public function receipts(): array { return $this->screen('receipts'); }

    private function screen(string $screen): array
    {
        return [
            'module' => 'Budgeting',
            'screen' => $screen,
            'resources' => BudgetingFilamentRegistry::resources(),
            'pages' => BudgetingFilamentRegistry::pages(),
            'widgets' => BudgetingFilamentRegistry::widgets(),
            'navigation' => BudgetingFilamentRegistry::navigation(),
        ];
    }
}
