<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ExpenseResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'tenant_id' => $this->tenant_id,
            'budget_id' => $this->budget_id,
            'allocation_id' => $this->allocation_id,
            'category_id' => $this->category_id,
            'category' => $this->whenLoaded('category'),
            'vendor' => $this->vendor,
            'title' => $this->title,
            'description' => $this->description,
            'amount' => $this->amount,
            'currency' => $this->currency,
            'expense_date' => optional($this->expense_date)->toDateString(),
            'status' => $this->status,
            'submitted_at' => optional($this->submitted_at)->toISOString(),
            'approved_at' => optional($this->approved_at)->toISOString(),
            'reimbursed_at' => optional($this->reimbursed_at)->toISOString(),
            'receipts' => ReceiptResource::collection($this->whenLoaded('receipts')),
            'metadata' => $this->metadata,
        ];
    }
}
