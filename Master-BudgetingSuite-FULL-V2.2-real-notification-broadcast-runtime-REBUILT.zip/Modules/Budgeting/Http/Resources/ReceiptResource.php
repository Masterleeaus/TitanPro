<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ReceiptResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'expense_id' => $this->expense_id,
            'disk' => $this->disk,
            'path' => $this->path,
            'mime_type' => $this->mime_type,
            'size' => $this->size,
            'status' => $this->status,
            'ocr_text' => $this->ocr_text,
            'extracted_data' => $this->extracted_data,
            'confidence' => $this->confidence,
        ];
    }
}
