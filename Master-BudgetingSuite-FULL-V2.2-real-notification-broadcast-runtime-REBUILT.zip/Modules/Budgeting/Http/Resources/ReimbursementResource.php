<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ReimbursementResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'batch_number' => $this->batch_number,
            'total_amount' => $this->total_amount,
            'currency' => $this->currency,
            'status' => $this->status,
            'approved_at' => optional($this->approved_at)->toISOString(),
            'paid_at' => optional($this->paid_at)->toISOString(),
            'expenses' => ExpenseResource::collection($this->whenLoaded('expenses')),
        ];
    }
}
