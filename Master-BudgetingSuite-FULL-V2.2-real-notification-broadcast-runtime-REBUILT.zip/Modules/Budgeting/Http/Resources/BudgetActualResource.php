<?php

declare(strict_types=1);

namespace Modules\Budgeting\Http\Resources;

final class BudgetActualResource
{
    // Scaffold stub: implement domain behaviour here.

}
