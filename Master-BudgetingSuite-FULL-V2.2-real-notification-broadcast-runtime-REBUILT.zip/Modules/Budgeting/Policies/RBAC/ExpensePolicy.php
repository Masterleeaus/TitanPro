<?php

declare(strict_types=1);

namespace Modules\Budgeting\Policies\RBAC;

final class ExpensePolicy
{
    // Scaffold stub: implement domain behaviour here.

}
