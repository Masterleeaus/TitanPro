<?php

declare(strict_types=1);

namespace Modules\Budgeting\Policies\RBAC;

final class VariancePolicy
{
    // Scaffold stub: implement domain behaviour here.

}
