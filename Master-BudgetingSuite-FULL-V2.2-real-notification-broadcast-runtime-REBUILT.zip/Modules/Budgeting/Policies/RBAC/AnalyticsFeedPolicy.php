<?php

declare(strict_types=1);

namespace Modules\Budgeting\Policies\RBAC;

final class AnalyticsFeedPolicy
{
    // Scaffold stub: implement domain behaviour here.

}
