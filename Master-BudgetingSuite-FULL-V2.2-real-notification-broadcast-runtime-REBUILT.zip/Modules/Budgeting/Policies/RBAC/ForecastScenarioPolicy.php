<?php

declare(strict_types=1);

namespace Modules\Budgeting\Policies\RBAC;

final class ForecastScenarioPolicy
{
    // Scaffold stub: implement domain behaviour here.

}
