<?php

namespace Modules\Budgeting\Console\Commands;

class BudgetingDoctorCommand
{
    // TODO: Implement Budgeting BudgetingDoctorCommand.
}
