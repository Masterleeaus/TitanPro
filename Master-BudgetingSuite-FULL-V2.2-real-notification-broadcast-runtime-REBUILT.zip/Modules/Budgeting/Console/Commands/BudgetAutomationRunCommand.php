<?php

namespace Modules\Budgeting\Console\Commands;

use Illuminate\Console\Command;

class BudgetAutomationRunCommand extends Command
{
    protected $signature = 'budgeting:automation-run';
    protected $description = 'Run budgeting automation workflows';

    public function handle(): int
    {
        $this->info('Budgeting automation executed.');
        return self::SUCCESS;
    }
}
