<?php

declare(strict_types=1);

namespace Modules\Budgeting\Console\Commands;

use Illuminate\Console\Command;
use Modules\Budgeting\Contracts\Services\ModuleHealthServiceContract;

final class BudgetingHealthCommand extends Command
{
    protected $signature = 'budgeting:health';
    protected $description = 'Run Budgeting module health checks.';

    public function handle(ModuleHealthServiceContract $health): int
    {
        $summary = $health->summary();
        $this->line(json_encode($summary, JSON_PRETTY_PRINT));
        return $summary['status'] === 'healthy' ? self::SUCCESS : self::FAILURE;
    }
}
