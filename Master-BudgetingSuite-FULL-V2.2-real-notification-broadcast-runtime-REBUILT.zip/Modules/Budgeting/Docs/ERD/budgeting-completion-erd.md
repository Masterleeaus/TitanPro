# Budgeting Completion ERD

Tables: budget_expenses, budget_receipts, budget_reimbursements, budget_actuals, budget_variances, budget_forecast_scenarios, budget_kpi_snapshots.
