# Budgeting Realtime Events

Broadcast scaffolds are provided for approval status changes and dashboard refresh streams.

## Channels

- `budgeting.expenses`
- `budgeting.approvals`
- `budgeting.variance`

## Event

`ExpenseApprovalStatusBroadcast` exposes `broadcastOn`, `broadcastAs`, and `broadcastWith` for Laravel Echo compatible consumers.
