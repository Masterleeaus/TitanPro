# Budgeting API Surface

OpenAPI scaffold is available at `API/OpenAPI/openapi.yaml`.
