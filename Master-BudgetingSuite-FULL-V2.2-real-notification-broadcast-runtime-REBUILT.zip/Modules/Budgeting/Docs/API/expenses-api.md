# Expenses API

Scaffold API contract for expense capture, approval, receipts, reimbursements, and actuals reconciliation.
