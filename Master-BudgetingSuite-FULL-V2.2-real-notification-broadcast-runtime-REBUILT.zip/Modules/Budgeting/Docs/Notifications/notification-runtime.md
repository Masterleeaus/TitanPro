# Budgeting Notification Runtime

This pass wires the notification layer into Budgeting with in-app, mail, Slack, and broadcast dispatch surfaces.

## Events

- `expense.submitted`
- `expense.approval_changed`
- `variance.alert`
- `forecast.ready`

## API

- `POST /api/budgeting/notifications/expenses/submitted`
- `POST /api/budgeting/notifications/expenses/approval-changed`
- `POST /api/budgeting/notifications/variance/alert`
- `POST /api/budgeting/notifications/forecast/ready`
