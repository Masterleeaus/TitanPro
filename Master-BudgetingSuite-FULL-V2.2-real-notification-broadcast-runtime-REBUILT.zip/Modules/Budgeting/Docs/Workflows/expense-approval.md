# Expense Approval Workflow

Draft → Submitted → Approved/Rejected → Reimbursed.
