# Budgeting Database Normalization

Pass 14 introduces canonical accounting dimensions for period, account and cost centre. These dimensions are attached to expenses, actuals, variances, forecast scenarios and KPI snapshots so reporting can aggregate consistently across the full module.

## Added tables

- `budget_periods`
- `budget_accounts`
- `budget_cost_centres`
- `budget_state_transitions`
- `budget_audit_revisions`

## Runtime wiring

- `StateTransitionService` records workflow movement against any model.
- `AuditRevisionService` stores before/after revision payloads.
- `ExpenseRepository` centralises tenant, period, account, cost centre, budget and status filters.

## Migration safety

The normalization migration checks whether each target table and column exists before modifying existing tables, which allows partial module installs and iterative upgrades.
