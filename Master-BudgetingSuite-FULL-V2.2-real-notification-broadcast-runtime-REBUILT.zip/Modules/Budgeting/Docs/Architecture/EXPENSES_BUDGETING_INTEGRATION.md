# Expenses ↔ Budgeting Integration

V1.5 promotes Expenses into the Budgeting domain and wires the lifecycle as a single financial control loop.

```text
Expense draft → submit → threshold decision → approval/rejection → ledger post → budget actual → variance refresh → analytics feed
```

## Core services

- `ExpenseBudgetLinker` resolves budget/allocation/category references from payloads.
- `BudgetWorkflowService` orchestrates submit, approve, reject, post, actuals, ledger and variance.
- `BudgetActualsService::recordExpense()` creates an idempotent actual from an expense.
- `VarianceService::calculate()` is called after posting when a budget is linked.

## API surface

- `POST /api/budgeting/expenses`
- `POST /api/budgeting/expenses/{expense}/submit`
- `POST /api/budgeting/expenses/{expense}/approve`
- `POST /api/budgeting/expenses/{expense}/reject`
- `POST /api/budgeting/expenses/{expense}/post`
- `POST /api/budgeting/expenses/{expense}/link-budget`
- `GET|POST /api/budgeting/actuals`
- `GET|POST /api/budgeting/variance`
