# Expenses moved into Budgeting main module

Expenses is now a first-class Budgeting domain, not a nested integration.

## Moved capabilities

- Legacy expense categories -> `budget_expense_categories`
- Legacy expenses -> `budget_expenses`
- Legacy receipts -> `budget_receipts`
- Legacy approvals -> `ExpensesService::submit/approve/reject`
- Legacy reimburse action -> `ExpensesService::reimburse` plus `ReimbursementsService`
- Legacy income -> `budget_income` and `budget_income_categories`
- Legacy ledger -> `budget_ledger`

## Active namespace

All active code now lives under:

```text
Modules/Budgeting
Modules/Budgeting/Models
Modules/Budgeting/Services
Modules/Budgeting/Http/Controllers/API
Modules/Budgeting/Routes
Modules/Budgeting/manifests
```

## Legacy status

The old `Modules/Expenses` style namespace has been retired from active providers and replaced by `Modules\Budgeting` bindings and routes.
