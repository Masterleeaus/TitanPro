# Budgeting AI Layer

AI scaffold covers agents, prompts, tools, providers, embeddings, memory, forecasting, OCR, extraction, recommendation, summarization, and guardrails.
