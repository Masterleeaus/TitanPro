# Budgeting AI Runtime

This pass wires the AI layer into executable module services instead of placeholder folders.

## Runtime contracts

- `BudgetingAiGatewayContract` provides forecast, recommendation, receipt extraction, classification, anomaly detection and variance summarisation methods.
- `AiBudgetingServiceContract` exposes stable module use-cases for controllers, actions, jobs and automation rules.

## Deterministic fallback

The default gateway is deterministic and local. It is safe for development and test environments because it does not require an external LLM provider. External providers can be added behind the same gateway contract.

## Endpoints

- `POST /budgeting/ai/forecast`
- `POST /budgeting/ai/expenses/classify`
- `POST /budgeting/ai/receipts/extract`
- `POST /budgeting/ai/variance/inspect`

## Guardrail rule

AI can suggest classifications, forecasts and budget actions, but direct budget mutations must remain behind workflow approval actions.
