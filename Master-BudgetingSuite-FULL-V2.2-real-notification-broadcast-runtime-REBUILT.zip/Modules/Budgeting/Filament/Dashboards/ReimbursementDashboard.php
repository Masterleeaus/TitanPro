<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Dashboards;

final class ReimbursementDashboard
{
    // Scaffold stub: implement domain behaviour here.

}
