<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Dashboards;

final class ForecastingDashboard
{
    // Scaffold stub: implement domain behaviour here.

}
