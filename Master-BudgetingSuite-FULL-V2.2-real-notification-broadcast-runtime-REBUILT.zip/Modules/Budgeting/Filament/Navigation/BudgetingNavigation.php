<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Navigation;

use Modules\Budgeting\Support\Filament\BudgetingFilamentRegistry;

final class BudgetingNavigation
{
    public static function items(): array
    {
        return BudgetingFilamentRegistry::navigation();
    }
}
