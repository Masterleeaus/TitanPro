<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Widgets;

final class SpendTrendWidget
{
    public static string $title = 'Spend Trend';
    public static string $metric = 'spend_trend';

    public function data(array $payload = []): array
    {
        return [
            'title' => self::$title,
            'metric' => self::$metric,
            'value' => $payload[self::$metric] ?? null,
            'trend' => $payload[self::$metric . '_trend'] ?? [],
            'status' => $payload[self::$metric . '_status'] ?? 'unknown',
        ];
    }
}
