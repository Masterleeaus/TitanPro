<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Widgets;

final class ApprovalSlaWidget
{
    public static string $title = 'Approval SLA';
    public static string $metric = 'approval_sla';

    public function data(array $payload = []): array
    {
        return [
            'title' => self::$title,
            'metric' => self::$metric,
            'value' => $payload[self::$metric] ?? null,
            'trend' => $payload[self::$metric . '_trend'] ?? [],
            'status' => $payload[self::$metric . '_status'] ?? 'unknown',
        ];
    }
}
