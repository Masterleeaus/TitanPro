<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Widgets;

final class ForecastAccuracyWidget
{
    public static string $title = 'Forecast Accuracy';
    public static string $metric = 'forecast_accuracy';

    public function data(array $payload = []): array
    {
        return [
            'title' => self::$title,
            'metric' => self::$metric,
            'value' => $payload[self::$metric] ?? null,
            'trend' => $payload[self::$metric . '_trend'] ?? [],
            'status' => $payload[self::$metric . '_status'] ?? 'unknown',
        ];
    }
}
