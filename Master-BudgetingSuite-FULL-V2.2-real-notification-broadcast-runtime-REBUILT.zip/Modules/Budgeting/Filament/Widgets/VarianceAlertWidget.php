<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Widgets;

final class VarianceAlertWidget
{
    public static string $title = 'Variance Alerts';
    public static string $metric = 'variance_alerts';

    public function data(array $payload = []): array
    {
        return [
            'title' => self::$title,
            'metric' => self::$metric,
            'value' => $payload[self::$metric] ?? null,
            'trend' => $payload[self::$metric . '_trend'] ?? [],
            'status' => $payload[self::$metric . '_status'] ?? 'unknown',
        ];
    }
}
