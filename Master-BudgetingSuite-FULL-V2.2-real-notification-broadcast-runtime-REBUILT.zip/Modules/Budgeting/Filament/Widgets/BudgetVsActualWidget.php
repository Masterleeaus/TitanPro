<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Widgets;

final class BudgetVsActualWidget
{
    public static string $title = 'Budget vs Actual';
    public static string $metric = 'budget_vs_actual';

    public function data(array $payload = []): array
    {
        return [
            'title' => self::$title,
            'metric' => self::$metric,
            'value' => $payload[self::$metric] ?? null,
            'trend' => $payload[self::$metric . '_trend'] ?? [],
            'status' => $payload[self::$metric . '_status'] ?? 'unknown',
        ];
    }
}
