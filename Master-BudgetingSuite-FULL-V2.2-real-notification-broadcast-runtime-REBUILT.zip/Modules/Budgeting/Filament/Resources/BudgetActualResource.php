<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Resources;

use Modules\Budgeting\Models\BudgetActual;

final class BudgetActualResource
{
    public static string $model = BudgetActual::class;
    public static string $navigationGroup = 'Finance / Budgeting';
    public static string $navigationIcon = 'heroicon-o-scale';
    public static string $slug = 'actuals';

    public static function formSchema(): array
    {
        return [['name' => 'budget_id', 'type' => 'relationship', 'relationship' => 'budget', 'required' => true], ['name' => 'source_type', 'type' => 'text'], ['name' => 'source_id', 'type' => 'number'], ['name' => 'period', 'type' => 'month', 'required' => true], ['name' => 'actual_amount', 'type' => 'money', 'required' => true], ['name' => 'currency', 'type' => 'select', 'default' => 'AUD'], ['name' => 'status', 'type' => 'select', 'options' => ['draft', 'posted', 'locked']]];
    }

    public static function tableColumns(): array
    {
        return ['id', 'budget_id', 'period', 'actual_amount', 'currency', 'source_type', 'source_id', 'status', 'created_at'];
    }

    public static function tableFilters(): array
    {
        return ['period', 'status', 'budget_id', 'currency'];
    }

    public static function rowActions(): array
    {
        return ['view', 'edit', 'reconcile', 'lock-period'];
    }

    public static function bulkActions(): array
    {
        return ['export', 'delete-selected'];
    }
}
