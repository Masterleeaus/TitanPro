<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Resources;

use Modules\Budgeting\Models\BudgetVariance;

final class BudgetVarianceResource
{
    public static string $model = BudgetVariance::class;
    public static string $navigationGroup = 'Finance / Budgeting';
    public static string $navigationIcon = 'heroicon-o-chart-bar-square';
    public static string $slug = 'variances';

    public static function formSchema(): array
    {
        return [['name' => 'budget_id', 'type' => 'relationship', 'relationship' => 'budget', 'required' => true], ['name' => 'period', 'type' => 'month', 'required' => true], ['name' => 'planned_amount', 'type' => 'money'], ['name' => 'actual_amount', 'type' => 'money'], ['name' => 'variance_amount', 'type' => 'money'], ['name' => 'variance_percent', 'type' => 'number'], ['name' => 'status', 'type' => 'select', 'options' => ['normal', 'watch', 'critical', 'resolved']], ['name' => 'explanation', 'type' => 'textarea']];
    }

    public static function tableColumns(): array
    {
        return ['id', 'budget_id', 'period', 'planned_amount', 'actual_amount', 'variance_amount', 'variance_percent', 'status', 'created_at'];
    }

    public static function tableFilters(): array
    {
        return ['period', 'status', 'budget_id'];
    }

    public static function rowActions(): array
    {
        return ['view', 'edit', 'explain', 'flag-anomaly', 'create-adjustment'];
    }

    public static function bulkActions(): array
    {
        return ['export', 'delete-selected'];
    }
}
