<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Resources;

use Modules\Budgeting\Models\Expense;

final class ExpenseResource
{
    public static string $model = Expense::class;
    public static string $navigationGroup = 'Finance / Budgeting';
    public static string $navigationIcon = 'heroicon-o-banknotes';
    public static string $slug = 'expenses';

    public static function formSchema(): array
    {
        return [['name' => 'title', 'type' => 'text', 'required' => true], ['name' => 'amount', 'type' => 'money', 'required' => true], ['name' => 'currency', 'type' => 'select', 'default' => 'AUD'], ['name' => 'expense_date', 'type' => 'date', 'required' => true], ['name' => 'budget_id', 'type' => 'relationship', 'relationship' => 'budget'], ['name' => 'allocation_id', 'type' => 'relationship', 'relationship' => 'allocation'], ['name' => 'category_id', 'type' => 'relationship', 'relationship' => 'category'], ['name' => 'vendor', 'type' => 'text'], ['name' => 'description', 'type' => 'textarea'], ['name' => 'status', 'type' => 'select', 'options' => ['draft', 'submitted', 'pending', 'approved', 'rejected', 'reimbursed', 'posted']]];
    }

    public static function tableColumns(): array
    {
        return ['id', 'title', 'vendor', 'amount', 'currency', 'expense_date', 'status', 'budget_id', 'allocation_id', 'category_id', 'submitted_at', 'approved_at'];
    }

    public static function tableFilters(): array
    {
        return ['status', 'currency', 'expense_date', 'budget_id', 'allocation_id', 'category_id'];
    }

    public static function rowActions(): array
    {
        return ['view', 'edit', 'submit', 'approve', 'reject', 'attach-receipt', 'post-to-ledger', 'reimburse'];
    }

    public static function bulkActions(): array
    {
        return ['export', 'delete-selected'];
    }
}
