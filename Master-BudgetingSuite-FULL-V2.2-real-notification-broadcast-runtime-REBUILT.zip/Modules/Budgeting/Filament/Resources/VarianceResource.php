<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Resources;

final class VarianceResource
{
    // Scaffold stub: implement domain behaviour here.

}
