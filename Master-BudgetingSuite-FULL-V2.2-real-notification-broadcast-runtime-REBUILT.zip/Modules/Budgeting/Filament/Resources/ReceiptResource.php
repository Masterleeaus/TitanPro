<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Resources;

use Modules\Budgeting\Models\Receipt;

final class ReceiptResource
{
    public static string $model = Receipt::class;
    public static string $navigationGroup = 'Finance / Budgeting';
    public static string $navigationIcon = 'heroicon-o-document-text';
    public static string $slug = 'receipts';

    public static function formSchema(): array
    {
        return [['name' => 'expense_id', 'type' => 'relationship', 'relationship' => 'expense', 'required' => true], ['name' => 'file_path', 'type' => 'file', 'required' => true], ['name' => 'ocr_status', 'type' => 'select', 'options' => ['pending', 'processing', 'completed', 'failed']], ['name' => 'extracted_total', 'type' => 'money'], ['name' => 'extracted_vendor', 'type' => 'text'], ['name' => 'metadata', 'type' => 'keyValue']];
    }

    public static function tableColumns(): array
    {
        return ['id', 'expense_id', 'file_path', 'ocr_status', 'extracted_vendor', 'extracted_total', 'created_at'];
    }

    public static function tableFilters(): array
    {
        return ['ocr_status', 'expense_id', 'created_at'];
    }

    public static function rowActions(): array
    {
        return ['view', 'edit', 'run-ocr', 'match-expense', 'delete'];
    }

    public static function bulkActions(): array
    {
        return ['export', 'delete-selected'];
    }
}
