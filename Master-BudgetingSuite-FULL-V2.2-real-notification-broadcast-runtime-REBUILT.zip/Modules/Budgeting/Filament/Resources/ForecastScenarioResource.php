<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Resources;

use Modules\Budgeting\Models\ForecastScenario;

final class ForecastScenarioResource
{
    public static string $model = ForecastScenario::class;
    public static string $navigationGroup = 'Finance / Budgeting';
    public static string $navigationIcon = 'heroicon-o-presentation-chart-line';
    public static string $slug = 'forecast-scenarios';

    public static function formSchema(): array
    {
        return [['name' => 'name', 'type' => 'text', 'required' => true], ['name' => 'budget_id', 'type' => 'relationship', 'relationship' => 'budget'], ['name' => 'scenario_type', 'type' => 'select', 'options' => ['baseline', 'optimistic', 'pessimistic', 'custom']], ['name' => 'period_start', 'type' => 'date'], ['name' => 'period_end', 'type' => 'date'], ['name' => 'confidence_score', 'type' => 'number'], ['name' => 'payload', 'type' => 'keyValue']];
    }

    public static function tableColumns(): array
    {
        return ['id', 'name', 'budget_id', 'scenario_type', 'period_start', 'period_end', 'confidence_score', 'created_at'];
    }

    public static function tableFilters(): array
    {
        return ['scenario_type', 'budget_id', 'period_start'];
    }

    public static function rowActions(): array
    {
        return ['view', 'edit', 'compare', 'apply-recommendation', 'archive'];
    }

    public static function bulkActions(): array
    {
        return ['export', 'delete-selected'];
    }
}
