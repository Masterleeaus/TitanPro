<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Resources;

use Modules\Budgeting\Models\ReimbursementBatch;

final class ReimbursementBatchResource
{
    public static string $model = ReimbursementBatch::class;
    public static string $navigationGroup = 'Finance / Budgeting';
    public static string $navigationIcon = 'heroicon-o-credit-card';
    public static string $slug = 'reimbursements';

    public static function formSchema(): array
    {
        return [['name' => 'batch_number', 'type' => 'text', 'required' => true], ['name' => 'status', 'type' => 'select', 'options' => ['draft', 'pending_approval', 'approved', 'paid', 'cancelled']], ['name' => 'currency', 'type' => 'select', 'default' => 'AUD'], ['name' => 'total_amount', 'type' => 'money'], ['name' => 'payment_reference', 'type' => 'text'], ['name' => 'paid_at', 'type' => 'datetime']];
    }

    public static function tableColumns(): array
    {
        return ['id', 'batch_number', 'status', 'total_amount', 'currency', 'expense_count', 'payment_reference', 'paid_at', 'created_at'];
    }

    public static function tableFilters(): array
    {
        return ['status', 'currency', 'paid_at'];
    }

    public static function rowActions(): array
    {
        return ['view', 'edit', 'approve', 'export', 'mark-paid'];
    }

    public static function bulkActions(): array
    {
        return ['export', 'delete-selected'];
    }
}
