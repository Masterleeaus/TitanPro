<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Resources;

use Modules\Budgeting\Models\ApprovalThreshold;

final class ApprovalThresholdResource
{
    public static string $model = ApprovalThreshold::class;
    public static string $navigationGroup = 'Finance / Budgeting';
    public static string $navigationIcon = 'heroicon-o-shield-check';
    public static string $slug = 'approval-thresholds';

    public static function formSchema(): array
    {
        return [['name' => 'name', 'type' => 'text', 'required' => true], ['name' => 'min_amount', 'type' => 'money'], ['name' => 'max_amount', 'type' => 'money'], ['name' => 'currency', 'type' => 'select', 'default' => 'AUD'], ['name' => 'approver_role', 'type' => 'text', 'required' => true], ['name' => 'sla_hours', 'type' => 'number'], ['name' => 'active', 'type' => 'toggle']];
    }

    public static function tableColumns(): array
    {
        return ['id', 'name', 'min_amount', 'max_amount', 'currency', 'approver_role', 'sla_hours', 'active', 'updated_at'];
    }

    public static function tableFilters(): array
    {
        return ['active', 'currency', 'approver_role'];
    }

    public static function rowActions(): array
    {
        return ['view', 'edit', 'duplicate', 'disable'];
    }

    public static function bulkActions(): array
    {
        return ['export', 'delete-selected'];
    }
}
