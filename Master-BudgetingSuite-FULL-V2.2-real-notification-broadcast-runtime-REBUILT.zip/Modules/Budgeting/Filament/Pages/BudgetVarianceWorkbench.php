<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Pages;

use Modules\Budgeting\Contracts\Services\DashboardServiceContract;

final class BudgetVarianceWorkbench
{
    public static string $route = '/budgeting/admin/variances';
    public static string $title = 'Budget Variance Workbench';
    public static string $permission = 'budgeting.variance.view';

    public function __construct(private readonly ?DashboardServiceContract $dashboard = null)
    {
    }

    public function payload(array $filters = []): array
    {
        return [
            'title' => self::$title,
            'route' => self::$route,
            'permission' => self::$permission,
            'filters' => $filters,
            'widgets' => ['BudgetVsActualWidget', 'VarianceAlertWidget', 'SpendTrendWidget'],
            'actions' => ['recalculate', 'explain-selected', 'create-adjustment'],
        ];
    }
}
