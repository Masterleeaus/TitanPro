<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Pages;

use Modules\Budgeting\Contracts\Services\DashboardServiceContract;

final class ExpenseApprovalQueue
{
    public static string $route = '/budgeting/admin/approvals';
    public static string $title = 'Expense Approval Queue';
    public static string $permission = 'budgeting.approvals.view';

    public function __construct(private readonly ?DashboardServiceContract $dashboard = null)
    {
    }

    public function payload(array $filters = []): array
    {
        return [
            'title' => self::$title,
            'route' => self::$route,
            'permission' => self::$permission,
            'filters' => $filters,
            'widgets' => ['ApprovalSlaWidget', 'ReceiptBacklogWidget'],
            'actions' => ['approve-selected', 'reject-selected', 'delegate', 'escalate'],
        ];
    }
}
