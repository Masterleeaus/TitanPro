<?php

declare(strict_types=1);

namespace Modules\Budgeting\Filament\Pages;

use Modules\Budgeting\Contracts\Services\DashboardServiceContract;

final class BudgetingDashboard
{
    public static string $route = '/budgeting/admin';
    public static string $title = 'Budgeting Dashboard';
    public static string $permission = 'budgeting.view';

    public function __construct(private readonly ?DashboardServiceContract $dashboard = null)
    {
    }

    public function payload(array $filters = []): array
    {
        return [
            'title' => self::$title,
            'route' => self::$route,
            'permission' => self::$permission,
            'filters' => $filters,
            'widgets' => ['BudgetVsActualWidget', 'SpendTrendWidget', 'VarianceAlertWidget', 'ApprovalSlaWidget', 'ReceiptBacklogWidget', 'ForecastAccuracyWidget'],
            'actions' => ['refresh-kpis', 'export-dashboard'],
        ];
    }
}
