<?php

declare(strict_types=1);

namespace Modules\Budgeting\Broadcasting\Channels;

final class BudgetingChannel
{
    public function join(mixed $user, string $scope = 'expenses'): bool
    {
        if (is_object($user) && method_exists($user, 'can')) {
            return (bool) $user->can('budgeting.access');
        }

        return true;
    }
}
