<?php

declare(strict_types=1);

namespace Modules\Budgeting\Broadcasting\Events;

final class ExpenseApprovalStatusBroadcast
{
    public function __construct(
        public readonly array $expense,
        public readonly string $status,
    ) {}

    public function broadcastOn(): array
    {
        return ['private-budgeting.expenses'];
    }

    public function broadcastAs(): string
    {
        return 'expense.approval.status';
    }

    public function broadcastWith(): array
    {
        return [
            'expense' => $this->expense,
            'status' => $this->status,
        ];
    }
}
