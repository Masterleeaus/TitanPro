<?php

declare(strict_types=1);

namespace Modules\Budgeting\Integrations\Payroll;

final class BudgetingPayrollClient
{
    // Scaffold stub: implement domain behaviour here.

}
