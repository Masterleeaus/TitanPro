# Payroll Integration

Scaffold for Budgeting Payroll integration.
