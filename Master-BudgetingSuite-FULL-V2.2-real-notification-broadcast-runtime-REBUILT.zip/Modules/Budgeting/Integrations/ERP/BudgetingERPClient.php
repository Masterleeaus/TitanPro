<?php

declare(strict_types=1);

namespace Modules\Budgeting\Integrations\ERP;

final class BudgetingERPClient
{
    // Scaffold stub: implement domain behaviour here.

}
