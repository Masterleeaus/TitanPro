# ERP Integration

Scaffold for Budgeting ERP integration.
