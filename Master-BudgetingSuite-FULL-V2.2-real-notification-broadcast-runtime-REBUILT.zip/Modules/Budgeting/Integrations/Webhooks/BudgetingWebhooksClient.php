<?php

declare(strict_types=1);

namespace Modules\Budgeting\Integrations\Webhooks;

final class BudgetingWebhooksClient
{
    // Scaffold stub: implement domain behaviour here.

}
