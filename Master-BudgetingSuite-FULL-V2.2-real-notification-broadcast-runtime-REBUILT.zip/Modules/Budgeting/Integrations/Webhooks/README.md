# Webhooks Integration

Scaffold for Budgeting Webhooks integration.
