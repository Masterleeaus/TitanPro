Legacy Expenses module was moved into the main Budgeting module in V1.4. See Docs/Architecture/expenses-main-module-migration.md and legacy-expenses-file-map.json.
