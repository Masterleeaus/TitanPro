<?php

declare(strict_types=1);

namespace Modules\Budgeting\Integrations\Accounting;

final class BudgetingAccountingClient
{
    // Scaffold stub: implement domain behaviour here.

}
