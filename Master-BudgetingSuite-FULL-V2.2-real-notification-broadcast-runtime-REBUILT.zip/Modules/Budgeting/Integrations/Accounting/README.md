# Accounting Integration

Scaffold for Budgeting Accounting integration.
