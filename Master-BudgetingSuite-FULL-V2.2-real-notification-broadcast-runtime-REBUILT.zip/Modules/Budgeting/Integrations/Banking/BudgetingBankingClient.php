<?php

declare(strict_types=1);

namespace Modules\Budgeting\Integrations\Banking;

final class BudgetingBankingClient
{
    // Scaffold stub: implement domain behaviour here.

}
