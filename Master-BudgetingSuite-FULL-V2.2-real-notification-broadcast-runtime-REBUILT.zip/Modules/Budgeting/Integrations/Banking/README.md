# Banking Integration

Scaffold for Budgeting Banking integration.
