<?php

declare(strict_types=1);

return [
    'expense' => [
        'draft' => ['submitted'],
        'submitted' => ['pending_approval', 'approved', 'rejected'],
        'pending_approval' => ['approved', 'rejected'],
        'approved' => ['posted', 'reimbursed'],
        'posted' => ['locked'],
        'reimbursed' => ['locked'],
        'rejected' => ['draft', 'archived'],
        'locked' => ['archived'],
    ],
    'actual' => [
        'draft' => ['posted'],
        'posted' => ['locked'],
        'locked' => [],
    ],
];
