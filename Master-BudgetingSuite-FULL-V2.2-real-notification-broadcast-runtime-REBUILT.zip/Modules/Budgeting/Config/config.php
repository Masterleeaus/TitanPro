<?php

declare(strict_types=1);

return [
    'name' => 'Budgeting',
    'version' => '1.3.0',
    'currency' => env('BUDGETING_DEFAULT_CURRENCY', 'AUD'),
    'fiscal_year_start_month' => (int) env('BUDGETING_FISCAL_YEAR_START_MONTH', 7),
    'tables' => [
        'expenses' => 'budget_expenses',
        'receipts' => 'budget_receipts',
        'reimbursements' => 'budget_reimbursements',
        'actuals' => 'budget_actuals',
        'variances' => 'budget_variances',
        'approval_thresholds' => 'budget_approval_thresholds',
        'forecast_scenarios' => 'budget_forecast_scenarios',
        'kpi_snapshots' => 'budget_kpi_snapshots',
        'integration_runs' => 'budget_integration_runs',
    ],
    'approval' => [
        'auto_approve_below' => (float) env('BUDGETING_AUTO_APPROVE_BELOW', 100),
        'manager_threshold' => (float) env('BUDGETING_MANAGER_THRESHOLD', 1000),
        'finance_threshold' => (float) env('BUDGETING_FINANCE_THRESHOLD', 5000),
        'executive_threshold' => (float) env('BUDGETING_EXECUTIVE_THRESHOLD', 25000),
    ],
    'variance' => [
        'warning_percent' => (float) env('BUDGETING_VARIANCE_WARNING_PERCENT', 10),
        'critical_percent' => (float) env('BUDGETING_VARIANCE_CRITICAL_PERCENT', 20),
    ],
    'receipts' => [
        'required_above' => (float) env('BUDGETING_RECEIPT_REQUIRED_ABOVE', 75),
        'storage_disk' => env('BUDGETING_RECEIPT_DISK', 'local'),
    ],
];
