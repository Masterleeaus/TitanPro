<?php

return [
    'module' => 'Budgeting',
    'enabled' => true,
    'gateway' => env('BUDGETING_AI_GATEWAY', 'deterministic'),
    'features' => [
        'forecasting' => true,
        'expense_classification' => true,
        'receipt_extraction' => true,
        'variance_inspection' => true,
        'recommendations' => true,
    ],
    'guardrails' => [
        'redact_sensitive_finance_values' => false,
        'require_human_approval_for_budget_changes' => true,
        'max_recommendation_count' => 10,
    ],
    'thresholds' => [
        'variance_anomaly_percent' => 15,
        'low_confidence_cutoff' => 0.55,
    ],
];
