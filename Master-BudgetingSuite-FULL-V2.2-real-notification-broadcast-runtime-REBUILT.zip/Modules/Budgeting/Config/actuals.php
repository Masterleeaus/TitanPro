<?php

return ['enabled' => true, 'variance_threshold_percent' => 10];
