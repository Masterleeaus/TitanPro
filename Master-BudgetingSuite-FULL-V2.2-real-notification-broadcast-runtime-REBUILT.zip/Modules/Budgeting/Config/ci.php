<?php

return ['phpunit' => true, 'pint' => true, 'phpstan' => true, 'package_zip' => true];
