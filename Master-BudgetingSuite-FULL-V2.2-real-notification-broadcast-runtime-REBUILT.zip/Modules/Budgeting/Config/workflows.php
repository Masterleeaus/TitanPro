<?php

declare(strict_types=1);

return [
    'budget_approval' => [
        'enabled' => true,
        'states' => ['draft', 'submitted', 'review', 'approved', 'locked', 'archived'],
    ],
    'expense_approval' => [
        'enabled' => true,
        'sla_hours' => 48,
        'thresholds' => [
            ['limit' => 250, 'chain' => null, 'approvers' => []],
            ['limit' => 1000, 'chain' => 'manager', 'approvers' => ['manager']],
            ['limit' => 5000, 'chain' => 'finance', 'approvers' => ['manager', 'finance']],
            ['limit' => 999999999, 'chain' => 'executive', 'approvers' => ['manager', 'finance', 'executive']],
        ],
    ],
    'reimbursement' => [
        'states' => ['queued', 'batched', 'approved', 'exported', 'paid', 'failed'],
    ],
    'actuals' => [
        'lock_after_days' => 7,
        'allow_adjustments' => true,
    ],
];
