<?php

declare(strict_types=1);

return [
    'roles' => [
        'owner',
        'finance_admin',
        'budget_manager',
        'manager',
        'employee',
        'auditor',
    ],
    'permissions' => [
        'budgeting.*',
        'budgeting.budgets.view',
        'budgeting.budgets.create',
        'budgeting.budgets.update',
        'budgeting.budgets.approve',
        'budgeting.allocations.manage',
        'budgeting.expenses.view',
        'budgeting.expenses.view_own',
        'budgeting.expenses.create',
        'budgeting.expenses.submit',
        'budgeting.expenses.approve',
        'budgeting.expenses.reject',
        'budgeting.expenses.reimburse',
        'budgeting.receipts.manage',
        'budgeting.actuals.post',
        'budgeting.actuals.lock',
        'budgeting.variance.view',
        'budgeting.forecasts.run',
        'budgeting.analytics.view',
        'budgeting.integrations.sync',
        'budgeting.audit.view',
    ],
];
