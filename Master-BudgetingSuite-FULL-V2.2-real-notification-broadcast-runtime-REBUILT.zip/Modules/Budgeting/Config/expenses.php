<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'currency' => env('BUDGETING_CURRENCY', 'AUD'),
    'legacy_tables' => [
        'expense' => 'budget_expenses',
        'expense_category' => 'budget_expense_categories',
        'income' => 'budget_income',
        'income_category' => 'budget_income_categories',
        'ledger' => 'budget_ledger',
        'expense_receipts' => 'budget_receipts',
    ],
    'approvals' => [
        'enabled' => true,
        'default_status' => 'draft',
        'submitted_status' => 'submitted',
        'approved_status' => 'approved',
        'rejected_status' => 'rejected',
        'reimbursed_status' => 'reimbursed',
        'thresholds' => [
            ['amount' => 250, 'role' => 'team_lead'],
            ['amount' => 1000, 'role' => 'finance_manager'],
            ['amount' => 5000, 'role' => 'cfo'],
        ],
    ],
    'receipts' => [
        'enabled' => true,
        'disk' => env('BUDGETING_RECEIPTS_DISK', 'public'),
        'path' => env('BUDGETING_RECEIPTS_PATH', 'budgeting/receipts'),
        'ocr' => env('BUDGETING_RECEIPT_OCR', true),
        'required_over_amount' => 75,
    ],
    'reimbursements' => [
        'enabled' => true,
        'batch_prefix' => 'RB',
        'auto_batch_approved_expenses' => false,
    ],
    'ledger' => [
        'enabled' => true,
        'post_approved_expenses' => true,
        'post_income' => true,
    ],
    'auto_post_approved_expenses' => env('BUDGETING_EXPENSES_AUTO_POST', true),
    'auto_approve_limit' => (float) env('BUDGETING_EXPENSES_AUTO_APPROVE_LIMIT', 0),
    'budget_linking' => [
        'infer_from_payload' => true,
        'require_budget_before_posting' => false,
    ],
];
