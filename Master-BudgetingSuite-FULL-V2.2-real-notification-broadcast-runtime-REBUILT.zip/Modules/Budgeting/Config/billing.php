<?php

return [
    'module' => 'Budgeting',
    'enabled' => true,
];
