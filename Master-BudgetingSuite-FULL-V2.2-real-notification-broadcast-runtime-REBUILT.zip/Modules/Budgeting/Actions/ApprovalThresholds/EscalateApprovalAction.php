<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\ApprovalThresholds;

use Modules\Budgeting\Services\ApprovalThresholdsService;

class EscalateApprovalAction
{
    public function __construct(private readonly ApprovalThresholdsService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->escalate($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
