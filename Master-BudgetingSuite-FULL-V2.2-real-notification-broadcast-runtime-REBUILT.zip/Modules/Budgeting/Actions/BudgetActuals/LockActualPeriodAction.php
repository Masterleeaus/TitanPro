<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\BudgetActuals;

use Modules\Budgeting\Services\BudgetActualsService;

class LockActualPeriodAction
{
    public function __construct(private readonly BudgetActualsService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->lockPeriod($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
