<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Workflow;

use Modules\Budgeting\Contracts\Services\ApprovalWorkflowServiceContract;
use Modules\Budgeting\Support\DTOs\ExpenseSubmissionData;

final readonly class RunExpenseApprovalWorkflowAction
{
    public function __construct(private ApprovalWorkflowServiceContract $workflow) {}

    public function __invoke(array $payload): array
    {
        $expense = ExpenseSubmissionData::fromArray($payload);
        $decision = $this->workflow->evaluateExpense($expense);

        return [
            'expense' => $expense->toArray(),
            'decision' => $decision->toArray(),
            'status' => $decision->requiresApproval ? 'pending_approval' : 'approved',
        ];
    }
}
