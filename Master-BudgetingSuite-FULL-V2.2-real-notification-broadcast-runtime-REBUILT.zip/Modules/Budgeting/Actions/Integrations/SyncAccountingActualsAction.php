<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Integrations;

use Modules\Budgeting\Services\IntegrationsService;

class SyncAccountingActualsAction
{
    public function __construct(private readonly IntegrationsService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->syncAccountingActuals($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
