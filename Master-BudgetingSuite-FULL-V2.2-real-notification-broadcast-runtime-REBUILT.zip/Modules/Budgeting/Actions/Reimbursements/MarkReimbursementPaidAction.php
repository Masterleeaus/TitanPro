<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Reimbursements;

use Modules\Budgeting\Services\ReimbursementsService;

class MarkReimbursementPaidAction
{
    public function __construct(private readonly ReimbursementsService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->markPaid($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
