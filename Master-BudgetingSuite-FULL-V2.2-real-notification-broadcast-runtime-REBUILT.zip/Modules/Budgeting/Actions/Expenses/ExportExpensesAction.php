<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Expenses;

final class ExportExpensesAction
{
    // Scaffold stub: implement domain behaviour here.

}
