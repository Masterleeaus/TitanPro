<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Expenses;

use Modules\Budgeting\Services\ExpensesService;

class LinkExpenseToBudgetAction
{
    public function __construct(private readonly ExpensesService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->linkToBudget($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
