<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Expenses;

final class AttachReceiptAction
{
    // Scaffold stub: implement domain behaviour here.

}
