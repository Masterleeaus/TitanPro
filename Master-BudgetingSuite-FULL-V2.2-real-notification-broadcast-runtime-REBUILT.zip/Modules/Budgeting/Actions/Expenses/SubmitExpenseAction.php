<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Expenses;

use Modules\Budgeting\Services\ExpensesService;

class SubmitExpenseAction
{
    public function __construct(private readonly ExpensesService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->submit($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
