<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Reporting;

use Modules\Budgeting\Services\ReportingService;

class GenerateSpendTrendReportAction
{
    public function __construct(private readonly ReportingService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->spendTrend($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
