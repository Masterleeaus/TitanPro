<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Reporting;

use Modules\Budgeting\Services\ReportingService;

class GenerateReimbursementReportAction
{
    public function __construct(private readonly ReportingService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->reimbursement($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
