<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Reporting;

use Modules\Budgeting\Contracts\Services\DashboardServiceContract;

final readonly class BuildDashboardPayloadAction
{
    public function __construct(private DashboardServiceContract $dashboards) {}

    public function __invoke(array $filters = []): array
    {
        return [
            'budget_vs_actual' => $this->dashboards->budgetVsActual($filters),
            'expense_operations' => $this->dashboards->expenseOperations($filters),
            'approval_sla' => $this->dashboards->approvalSla($filters),
        ];
    }
}
