<?php

namespace Modules\Budgeting\Actions\Budgets;

class CreateBudgetAction
{
    // TODO: Implement Budgeting CreateBudgetAction.
}
