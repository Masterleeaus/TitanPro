<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Variance;

use Modules\Budgeting\Services\VarianceService;

class CreateVarianceAdjustmentAction
{
    public function __construct(private readonly VarianceService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->adjust($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
