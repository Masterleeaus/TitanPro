<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Variance;

use Modules\Budgeting\Services\VarianceService;

class FlagVarianceAnomalyAction
{
    public function __construct(private readonly VarianceService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->flagAnomalies($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
