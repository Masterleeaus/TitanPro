<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Registry;

use Modules\Budgeting\Contracts\Services\ModuleHealthServiceContract;

final readonly class RunBudgetingHealthCheckAction
{
    public function __construct(private ModuleHealthServiceContract $health) {}

    public function __invoke(): array
    {
        return $this->health->summary();
    }
}
