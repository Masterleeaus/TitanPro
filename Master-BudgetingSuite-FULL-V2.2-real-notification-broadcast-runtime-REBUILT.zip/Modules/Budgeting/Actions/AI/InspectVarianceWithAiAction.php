<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\AI;

use Modules\Budgeting\Contracts\Services\AiBudgetingServiceContract;

final class InspectVarianceWithAiAction
{
    public function __construct(private readonly AiBudgetingServiceContract $ai)
    {
    }

    public function execute(array $payload): array
    {
        return $this->ai->inspectVariance($payload);
    }
}
