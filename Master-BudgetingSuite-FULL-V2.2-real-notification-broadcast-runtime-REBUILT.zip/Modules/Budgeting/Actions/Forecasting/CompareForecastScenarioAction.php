<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Forecasting;

use Modules\Budgeting\Services\ForecastingService;

class CompareForecastScenarioAction
{
    public function __construct(private readonly ForecastingService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->compareScenario($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
