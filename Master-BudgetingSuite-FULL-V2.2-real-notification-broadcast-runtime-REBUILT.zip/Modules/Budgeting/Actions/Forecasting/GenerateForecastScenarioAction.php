<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Forecasting;

use Modules\Budgeting\Services\ForecastingService;

class GenerateForecastScenarioAction
{
    public function __construct(private readonly ForecastingService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->generateScenario($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
