<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\AnalyticsFeeds;

use Modules\Budgeting\Services\AnalyticsFeedsService;

class PublishExpenseAnalyticsFeedAction
{
    public function __construct(private readonly AnalyticsFeedsService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->publishExpenseFeed($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
