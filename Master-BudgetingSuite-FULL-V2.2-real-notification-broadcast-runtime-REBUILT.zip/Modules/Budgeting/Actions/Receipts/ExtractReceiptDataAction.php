<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Receipts;

use Modules\Budgeting\Services\ReceiptsService;

class ExtractReceiptDataAction
{
    public function __construct(private readonly ReceiptsService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->extract($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
