<?php

declare(strict_types=1);

namespace Modules\Budgeting\Actions\Receipts;

use Modules\Budgeting\Services\ReceiptsService;

class ValidateReceiptAction
{
    public function __construct(private readonly ReceiptsService $service) {}

    public function handle(array $payload): array
    {
        return $this->service->validate($payload);
    }

    public function __invoke(array $payload): array
    {
        return $this->handle($payload);
    }
}
