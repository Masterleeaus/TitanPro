<?php

declare(strict_types=1);

namespace Modules\Budgeting\Entities\Core;

final class ApprovalThresholdEntity
{
    // Scaffold stub: implement domain behaviour here.

}
