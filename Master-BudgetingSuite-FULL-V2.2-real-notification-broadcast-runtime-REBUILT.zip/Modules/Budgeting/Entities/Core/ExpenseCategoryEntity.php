<?php

declare(strict_types=1);

namespace Modules\Budgeting\Entities\Core;

final class ExpenseCategoryEntity
{
    // Scaffold stub: implement domain behaviour here.

}
