<?php

declare(strict_types=1);

namespace Modules\Budgeting\Entities\Core;

final class ForecastScenarioEntity
{
    // Scaffold stub: implement domain behaviour here.

}
