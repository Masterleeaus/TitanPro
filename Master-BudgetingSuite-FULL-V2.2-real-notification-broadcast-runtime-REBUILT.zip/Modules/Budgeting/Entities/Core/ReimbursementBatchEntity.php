<?php

declare(strict_types=1);

namespace Modules\Budgeting\Entities\Core;

final class ReimbursementBatchEntity
{
    // Scaffold stub: implement domain behaviour here.

}
