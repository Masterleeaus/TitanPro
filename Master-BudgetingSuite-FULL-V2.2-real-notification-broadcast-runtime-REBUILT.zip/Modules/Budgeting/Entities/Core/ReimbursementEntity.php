<?php

declare(strict_types=1);

namespace Modules\Budgeting\Entities\Core;

final class ReimbursementEntity
{
    // Scaffold stub: implement domain behaviour here.

}
