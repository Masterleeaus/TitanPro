<?php

declare(strict_types=1);

namespace Modules\Budgeting\Notifications\Slack;

final class VarianceAlertSlackNotification
{
    public function toSlack(array $variance): array
    {
        return [
            'text' => 'Budget variance alert',
            'fields' => [
                'budget_id' => $variance['budget_id'] ?? null,
                'amount' => $variance['amount'] ?? null,
                'percentage' => $variance['percentage'] ?? null,
            ],
        ];
    }
}
