<?php

declare(strict_types=1);

namespace Modules\Budgeting\Notifications\Mail;

final class ExpenseApprovalMailNotification
{
    public function toMail(array $expense, string $status = 'submitted'): array
    {
        return [
            'subject' => 'Budgeting expense ' . $status,
            'lines' => [
                'Expense reference: ' . ($expense['reference'] ?? $expense['id'] ?? 'unassigned'),
                'Amount: ' . ($expense['amount'] ?? 'unknown'),
                'Status: ' . $status,
            ],
        ];
    }
}
