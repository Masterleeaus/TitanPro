<?php

declare(strict_types=1);

namespace Modules\Budgeting\Notifications\InApp;

final class VarianceAlertNotification
{
    // Scaffold stub: implement domain behaviour here.

}
