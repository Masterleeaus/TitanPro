<?php

declare(strict_types=1);

namespace Modules\Budgeting\Notifications\InApp;

final class BudgetingInAppNotification
{
    public function make(string $type, string $title, array $payload = []): array
    {
        return [
            'type' => $type,
            'title' => $title,
            'payload' => $payload,
            'read' => false,
            'created_at' => date('c'),
        ];
    }
}
