<?php

declare(strict_types=1);

namespace Modules\Budgeting\Listeners\Audit;

class RecordExpenseLifecycleAudit
{
    public function handle(object $event): void
    {
        logger()->info('budgeting.expense.lifecycle', [
            'event' => class_basename($event),
            'expense_id' => property_exists($event, 'expense') ? $event->expense->getKey() : null,
        ]);
    }
}
