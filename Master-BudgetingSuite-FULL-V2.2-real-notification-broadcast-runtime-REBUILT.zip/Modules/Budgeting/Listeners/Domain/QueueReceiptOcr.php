<?php

declare(strict_types=1);

namespace Modules\Budgeting\Listeners\Domain;

final class QueueReceiptOcr
{
    // Scaffold stub: implement domain behaviour here.

}
