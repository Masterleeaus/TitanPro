<?php

declare(strict_types=1);

namespace Modules\Budgeting\Listeners\Domain;

use Modules\Budgeting\Events\Domain\ExpenseApproved;
use Modules\Budgeting\Services\BudgetWorkflowService;

class PostApprovedExpenseToActuals
{
    public function __construct(protected BudgetWorkflowService $workflow) {}

    public function handle(ExpenseApproved $event): void
    {
        if (config('budgeting-expenses.auto_post_approved_expenses', true)) {
            $this->workflow->postExpense($event->expense);
        }
    }
}
