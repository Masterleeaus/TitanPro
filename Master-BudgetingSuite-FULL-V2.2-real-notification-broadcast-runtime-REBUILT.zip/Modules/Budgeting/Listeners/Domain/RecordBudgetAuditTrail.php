<?php

declare(strict_types=1);

namespace Modules\Budgeting\Listeners\Domain;

final class RecordBudgetAuditTrail
{
    // Scaffold stub: implement domain behaviour here.

}
