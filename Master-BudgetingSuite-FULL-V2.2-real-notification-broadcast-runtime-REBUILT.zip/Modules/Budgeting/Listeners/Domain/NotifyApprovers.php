<?php

declare(strict_types=1);

namespace Modules\Budgeting\Listeners\Domain;

final class NotifyApprovers
{
    // Scaffold stub: implement domain behaviour here.

}
