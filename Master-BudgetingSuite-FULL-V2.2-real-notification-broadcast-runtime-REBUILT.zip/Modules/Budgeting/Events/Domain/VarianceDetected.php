<?php

declare(strict_types=1);

namespace Modules\Budgeting\Events\Domain;

final class VarianceDetected
{
    // Scaffold stub: implement domain behaviour here.

}
