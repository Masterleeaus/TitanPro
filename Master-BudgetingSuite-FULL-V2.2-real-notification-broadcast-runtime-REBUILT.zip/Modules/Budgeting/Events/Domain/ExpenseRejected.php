<?php

declare(strict_types=1);

namespace Modules\Budgeting\Events\Domain;

class ExpenseRejected
{
    public function __construct(public \Modules\Budgeting\Models\Expense $expense, public ?string $reason = null) {}
}
