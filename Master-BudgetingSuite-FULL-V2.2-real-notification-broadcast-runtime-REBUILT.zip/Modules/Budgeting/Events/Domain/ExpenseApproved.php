<?php

declare(strict_types=1);

namespace Modules\Budgeting\Events\Domain;

class ExpenseApproved
{
    public function __construct(public \Modules\Budgeting\Models\Expense $expense) {}
}
