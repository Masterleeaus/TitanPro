<?php

declare(strict_types=1);

namespace Modules\Budgeting\Events\Domain;

class ExpensePostedToActuals
{
    public function __construct(public \Modules\Budgeting\Models\Expense $expense, public \Modules\Budgeting\Models\BudgetActual $actual) {}
}
