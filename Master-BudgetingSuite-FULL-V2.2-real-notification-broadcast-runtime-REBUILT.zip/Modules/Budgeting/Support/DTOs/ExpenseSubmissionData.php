<?php

declare(strict_types=1);

namespace Modules\Budgeting\Support\DTOs;

final readonly class ExpenseSubmissionData
{
    public function __construct(
        public int|string|null $employeeId,
        public int|string|null $budgetId,
        public int|string|null $categoryId,
        public float $amount,
        public string $currency,
        public string $description,
        public ?string $merchant = null,
        public ?string $expenseDate = null,
        public array $metadata = [],
    ) {}

    public static function fromArray(array $payload): self
    {
        return new self(
            employeeId: $payload['employee_id'] ?? null,
            budgetId: $payload['budget_id'] ?? null,
            categoryId: $payload['category_id'] ?? null,
            amount: (float) ($payload['amount'] ?? 0),
            currency: (string) ($payload['currency'] ?? 'AUD'),
            description: (string) ($payload['description'] ?? ''),
            merchant: $payload['merchant'] ?? null,
            expenseDate: $payload['expense_date'] ?? null,
            metadata: (array) ($payload['metadata'] ?? []),
        );
    }

    public function toArray(): array
    {
        return get_object_vars($this);
    }
}
