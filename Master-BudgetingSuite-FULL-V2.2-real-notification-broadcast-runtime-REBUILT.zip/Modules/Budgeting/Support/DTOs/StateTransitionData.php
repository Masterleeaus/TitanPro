<?php

declare(strict_types=1);

namespace Modules\Budgeting\Support\DTOs;

final readonly class StateTransitionData
{
    public function __construct(
        public string $workflow,
        public ?string $fromState,
        public string $toState,
        public ?int $tenantId = null,
        public ?int $actorId = null,
        public ?string $reason = null,
        public array $context = [],
    ) {
    }
}
