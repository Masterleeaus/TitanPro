<?php

declare(strict_types=1);

namespace Modules\Budgeting\Support\DTOs;

final readonly class BudgetActualSnapshot
{
    public function __construct(
        public int|string|null $budgetId,
        public string $period,
        public float $budgeted,
        public float $committed,
        public float $actual,
        public float $remaining,
        public float $variance,
        public float $variancePercent,
    ) {}

    public function toArray(): array
    {
        return get_object_vars($this);
    }
}
