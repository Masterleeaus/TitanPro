<?php

declare(strict_types=1);

namespace Modules\Budgeting\Support\DTOs;

final readonly class ApprovalDecisionData
{
    public function __construct(
        public bool $requiresApproval,
        public ?string $chainCode,
        public array $approvers,
        public string $reason,
        public array $threshold = [],
    ) {}

    public function toArray(): array
    {
        return [
            'requires_approval' => $this->requiresApproval,
            'chain_code' => $this->chainCode,
            'approvers' => $this->approvers,
            'reason' => $this->reason,
            'threshold' => $this->threshold,
        ];
    }
}
