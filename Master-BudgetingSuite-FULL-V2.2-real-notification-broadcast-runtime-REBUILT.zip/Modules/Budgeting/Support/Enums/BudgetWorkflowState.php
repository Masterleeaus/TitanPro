<?php

declare(strict_types=1);

namespace Modules\Budgeting\Support\Enums;

enum BudgetWorkflowState: string
{
    case Draft = 'draft';
    case Submitted = 'submitted';
    case PendingApproval = 'pending_approval';
    case Approved = 'approved';
    case Rejected = 'rejected';
    case Posted = 'posted';
    case Locked = 'locked';
    case Archived = 'archived';
}
