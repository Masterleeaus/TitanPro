<?php

declare(strict_types=1);

namespace Modules\Budgeting\Support\Enums;

enum BudgetVarianceSeverity: string
{
    case Info = 'info';
    case Watch = 'watch';
    case Warning = 'warning';
    case Critical = 'critical';

    public static function fromPercent(float $percent): self
    {
        return match (true) {
            abs($percent) >= 25.0 => self::Critical,
            abs($percent) >= 15.0 => self::Warning,
            abs($percent) >= 7.5 => self::Watch,
            default => self::Info,
        };
    }
}
