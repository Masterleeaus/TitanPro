<?php

declare(strict_types=1);

namespace Modules\Budgeting\Support\Filament;

final class BudgetingFilamentRegistry
{
    public static function resources(): array
    {
        return [
            \Modules\Budgeting\Filament\Resources\ExpenseResource::class,
            \Modules\Budgeting\Filament\Resources\ReceiptResource::class,
            \Modules\Budgeting\Filament\Resources\BudgetActualResource::class,
            \Modules\Budgeting\Filament\Resources\BudgetVarianceResource::class,
            \Modules\Budgeting\Filament\Resources\ApprovalThresholdResource::class,
            \Modules\Budgeting\Filament\Resources\ReimbursementBatchResource::class,
            \Modules\Budgeting\Filament\Resources\ForecastScenarioResource::class,
        ];
    }

    public static function pages(): array
    {
        return [
            \Modules\Budgeting\Filament\Pages\BudgetingDashboard::class,
            \Modules\Budgeting\Filament\Pages\ExpenseApprovalQueue::class,
            \Modules\Budgeting\Filament\Pages\BudgetVarianceWorkbench::class,
        ];
    }

    public static function widgets(): array
    {
        return [
            \Modules\Budgeting\Filament\Widgets\BudgetVsActualWidget::class,
            \Modules\Budgeting\Filament\Widgets\SpendTrendWidget::class,
            \Modules\Budgeting\Filament\Widgets\VarianceAlertWidget::class,
            \Modules\Budgeting\Filament\Widgets\ApprovalSlaWidget::class,
            \Modules\Budgeting\Filament\Widgets\ReceiptBacklogWidget::class,
            \Modules\Budgeting\Filament\Widgets\ForecastAccuracyWidget::class,
        ];
    }

    public static function navigation(): array
    {
        return [
            ['label' => 'Budgeting Dashboard', 'route' => 'budgeting.admin.dashboard', 'permission' => 'budgeting.view'],
            ['label' => 'Expenses', 'route' => 'budgeting.admin.expenses', 'permission' => 'budgeting.expenses.view'],
            ['label' => 'Approvals', 'route' => 'budgeting.admin.approvals', 'permission' => 'budgeting.approvals.view'],
            ['label' => 'Budget vs Actual', 'route' => 'budgeting.admin.actuals', 'permission' => 'budgeting.actuals.view'],
            ['label' => 'Variance Workbench', 'route' => 'budgeting.admin.variances', 'permission' => 'budgeting.variance.view'],
            ['label' => 'Forecasting', 'route' => 'budgeting.admin.forecasts', 'permission' => 'budgeting.forecasting.view'],
            ['label' => 'Reimbursements', 'route' => 'budgeting.admin.reimbursements', 'permission' => 'budgeting.reimbursements.view'],
            ['label' => 'Receipts OCR', 'route' => 'budgeting.admin.receipts', 'permission' => 'budgeting.receipts.view'],
        ];
    }
}
