<?php

namespace Modules\Budgeting\Automation\Rules;

class BudgetThresholdRule
{
    public function shouldEscalate(float $amount, float $threshold): bool
    {
        return $amount >= $threshold;
    }
}
