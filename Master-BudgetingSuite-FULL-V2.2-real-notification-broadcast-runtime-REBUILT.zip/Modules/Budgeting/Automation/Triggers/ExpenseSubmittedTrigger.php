<?php

namespace Modules\Budgeting\Automation\Triggers;

class ExpenseSubmittedTrigger
{
    public function event(): string
    {
        return 'budgeting.expense.submitted';
    }
}
