<?php

namespace Modules\Budgeting\Automation\Actions;

class DispatchApprovalAction
{
    public function execute(array $expense): array
    {
        return [
            'status' => 'queued_for_approval',
            'expense_id' => $expense['id'] ?? null,
        ];
    }
}
