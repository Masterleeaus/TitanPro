<?php

namespace Modules\BookingModule\Providers;

use Illuminate\Support\ServiceProvider;

class FilamentServiceProvider extends ServiceProvider
{
    public function register(): void {}
    public function boot(): void {}
}
