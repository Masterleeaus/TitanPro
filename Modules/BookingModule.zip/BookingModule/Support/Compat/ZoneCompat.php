<?php

namespace Modules\BookingModule\Support\Compat;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ZoneCompat
 *
 * A lightweight compatibility stub used when the ZoneManagement module is
 * disabled.  It maps to a `zones` table with no additional behaviour.  When
 * ZoneManagement is installed the real Zone model will take precedence and
 * this stub will be ignored.
 */
class ZoneCompat extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'zones';

    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    public $timestamps = false;
}