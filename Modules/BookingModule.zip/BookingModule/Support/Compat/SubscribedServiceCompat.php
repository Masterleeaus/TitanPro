<?php

namespace Modules\BookingModule\Support\Compat;

use Illuminate\Database\Eloquent\Model;

/**
 * Class SubscribedServiceCompat
 *
 * A lightweight compatibility stub used when the ProviderManagement module
 * is disabled.  It represents the `subscribed_services` table without any
 * behaviour.  The real SubscribedService class from ProviderManagement
 * provides additional relationships and logic when that module is available.
 */
class SubscribedServiceCompat extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'subscribed_services';

    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    public $timestamps = false;
}