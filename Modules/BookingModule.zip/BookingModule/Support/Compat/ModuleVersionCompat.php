<?php

namespace Modules\BookingModule\Support\Compat;

/**
 * Safe wrapper for host-app module version checks.
 *
 * Older Worksuite builds expose App\Models\Module::validateVersion(), while
 * newer or customised SaaS builds may not ship that model at all. BookingModule
 * migrations should never fail simply because the host app removed that helper.
 */
class ModuleVersionCompat
{
    public static function validate(string $moduleName): void
    {
        $moduleClass = '\\App\\Models\\Module';

        if (class_exists($moduleClass) && method_exists($moduleClass, 'validateVersion')) {
            try {
                $moduleClass::validateVersion($moduleName);
            } catch (\Throwable $e) {
                // Do not block migrations. Version validation is advisory.
            }
        }
    }
}
