<?php

namespace Modules\BookingModule\Support\Compat;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ProviderCompat
 *
 * A lightweight compatibility stub used when the ProviderManagement module
 * is not installed.  It defines a bare Eloquent model pointing at the
 * `providers` table.  If the ProviderManagement module is present the
 * real class will be used instead and this stub will be ignored.
 */
class ProviderCompat extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'providers';
    
    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    public $timestamps = false;
}