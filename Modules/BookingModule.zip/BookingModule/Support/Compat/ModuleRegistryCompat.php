<?php

namespace Modules\BookingModule\Support\Compat;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Safe module registry helper for host apps that do not expose App\Models\Module.
 */
class ModuleRegistryCompat
{
    public static function firstOrCreate(string $moduleName): object
    {
        $moduleClass = '\\App\\Models\\Module';

        if (class_exists($moduleClass)) {
            try {
                return $moduleClass::withoutGlobalScopes()->firstOrCreate(['module_name' => $moduleName]);
            } catch (\Throwable $e) {
                try {
                    return $moduleClass::firstOrCreate(['module_name' => $moduleName]);
                } catch (\Throwable $ignored) {
                    // Fall through to database fallback.
                }
            }
        }

        if (Schema::hasTable('modules')) {
            $row = DB::table('modules')->where('module_name', $moduleName)->first();

            if (! $row) {
                $data = ['module_name' => $moduleName];

                if (Schema::hasColumn('modules', 'created_at')) {
                    $data['created_at'] = now();
                }

                if (Schema::hasColumn('modules', 'updated_at')) {
                    $data['updated_at'] = now();
                }

                $id = DB::table('modules')->insertGetId($data);
                $row = DB::table('modules')->where('id', $id)->first();
            }

            return (object) [
                'id' => $row->id ?? null,
                'module_name' => $row->module_name ?? $moduleName,
            ];
        }

        return (object) [
            'id' => null,
            'module_name' => $moduleName,
        ];
    }

    public static function delete(string $moduleName): void
    {
        $moduleClass = '\\App\\Models\\Module';

        if (class_exists($moduleClass)) {
            try {
                $moduleClass::withoutGlobalScopes()->where('module_name', $moduleName)->delete();
                return;
            } catch (\Throwable $e) {
                try {
                    $moduleClass::where('module_name', $moduleName)->delete();
                    return;
                } catch (\Throwable $ignored) {
                    // Fall through to database fallback.
                }
            }
        }

        if (Schema::hasTable('modules')) {
            DB::table('modules')->where('module_name', $moduleName)->delete();
        }
    }
}
