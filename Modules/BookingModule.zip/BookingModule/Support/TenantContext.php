<?php
namespace Modules\BookingModule\Support;
use Illuminate\Support\Facades\Auth;
class TenantContext { public function companyId(): mixed { return Auth::check() ? (Auth::user()->company_id ?? null) : null; } }
