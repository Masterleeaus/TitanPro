<?php
if (! function_exists('bookingmodule_tenant_id')) { function bookingmodule_tenant_id(): mixed { return app(\Modules\BookingModule\Support\TenantContext::class)->companyId(); } }
