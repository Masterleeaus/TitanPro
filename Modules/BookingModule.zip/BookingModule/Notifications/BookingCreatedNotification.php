<?php
namespace Modules\BookingModule\Notifications;
use Illuminate\Notifications\Notification;
class BookingCreatedNotification extends Notification { public function via($notifiable): array { return ['database']; } public function toArray($notifiable): array { return ['type'=>'booking.created']; } }
