<?php
namespace Modules\BookingModule\Presenters;
use Modules\BookingModule\Entities\Booking;
class BookingPresenter { public function present(Booking $booking): array { return ['id'=>$booking->getKey(),'status'=>$booking->booking_status,'amount'=>$booking->total_booking_amount,'scheduled_for'=>$booking->service_schedule]; } }
