<?php
use Illuminate\Support\Facades\Route;
use Modules\BookingModule\Http\Controllers\Admin\BookingModuleAdminController;
Route::middleware(['web','auth'])->prefix('account/bookingmodule')->as('bookingmodule.admin.')->group(function () { Route::get('/', [BookingModuleAdminController::class, 'commandCenter'])->name('command-center'); });
