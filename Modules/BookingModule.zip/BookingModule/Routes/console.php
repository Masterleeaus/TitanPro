<?php
use Illuminate\Support\Facades\Artisan;
Artisan::command('bookingmodule:health', fn() => $this->info('BookingModule health route registered'))->purpose('Check BookingModule console route registration');
