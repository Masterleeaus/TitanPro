<?php
use Illuminate\Support\Facades\Route;
use Modules\BookingModule\Http\Controllers\Api\BookingModuleApiController;
use Modules\BookingModule\Http\Controllers\Api\ModuleAgentController;
Route::prefix('bookingmodule')->as('bookingmodule.')->group(function () {
    Route::post('bookings', [BookingModuleApiController::class, 'store'])->name('bookings.store');
    Route::get('bookings/{id}', [BookingModuleApiController::class, 'show'])->name('bookings.show');
    Route::post('agent', ModuleAgentController::class)->name('agent.invoke');
});
$legacy = __DIR__.'/api/v1/api.php'; if (file_exists($legacy)) { require $legacy; }
