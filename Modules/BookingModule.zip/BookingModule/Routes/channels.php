<?php
use Illuminate\Support\Facades\Broadcast;
Broadcast::channel('bookingmodule.{companyId}', fn($user, $companyId) => (string)($user->company_id ?? '') === (string)$companyId);
