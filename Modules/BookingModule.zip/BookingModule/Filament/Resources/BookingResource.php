<?php
namespace Modules\BookingModule\Filament\Resources;
use Filament\Resources\Resource;
use Modules\BookingModule\Entities\Booking;
class BookingResource extends Resource { protected static ?string $model = Booking::class; protected static ?string $navigationLabel = 'Bookings'; public static function getPages(): array { return []; } }
