<?php
namespace Modules\BookingModule\Filament;
use Filament\Contracts\Plugin;
use Filament\Panel;
class BookingModulePlugin implements Plugin { public function getId(): string { return 'bookingmodule'; } public function register(Panel $panel): void { } public function boot(Panel $panel): void { } public static function make(): self { return new self(); } }
