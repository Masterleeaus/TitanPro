<?php
namespace Modules\BookingModule\Filament\Pages;
class BookingModuleDashboard extends BookingModulePage { protected static ?string $title = 'Booking Dashboard'; }
