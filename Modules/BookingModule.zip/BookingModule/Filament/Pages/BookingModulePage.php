<?php
namespace Modules\BookingModule\Filament\Pages;
use Filament\Pages\Page;
class BookingModulePage extends Page { protected static ?string $navigationLabel = 'Bookings'; protected static ?string $title = 'Booking Command Center'; protected static string $view = 'bookingmodule::filament.pages.bookingmodule-page'; }
