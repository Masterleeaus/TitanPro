<?php
namespace Modules\BookingModule\Jobs;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
class ProcessBookingJob implements ShouldQueue { use Queueable; public function __construct(public readonly string|int $bookingId) {} public function handle(): void { event('bookingmodule.processing', [$this->bookingId]); } }
