<?php
namespace Modules\BookingModule\Observers;
use Modules\BookingModule\Entities\Booking;
class BookingObserver { public function creating(Booking $booking): void { if (empty($booking->booking_status)) { $booking->booking_status = 'pending'; } } }
