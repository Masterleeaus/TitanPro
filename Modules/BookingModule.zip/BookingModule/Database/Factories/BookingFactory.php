<?php
namespace Modules\BookingModule\Database\Factories;
use Illuminate\Database\Eloquent\Factories\Factory;
use Modules\BookingModule\Entities\Booking;
class BookingFactory extends Factory { protected $model = Booking::class; public function definition(): array { return ['booking_status'=>'pending','payment_method'=>'cash_after_service','total_booking_amount'=>0]; } }
