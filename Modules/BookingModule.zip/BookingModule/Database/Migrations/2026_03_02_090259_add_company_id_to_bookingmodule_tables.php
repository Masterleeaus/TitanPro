<?php

use Illuminate\Database\Migrations\Migration;

/**
 * Placeholder migration.  This file has been superseded by a later migration with
 * a unique timestamp.  It remains only to preserve migration order.  No
 * operations are performed here.
 */
return new class extends Migration {
    public function up(): void {}
    public function down(): void {}
};
