<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Modules\BookingModule\Entities\BookingModuleSetting;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        \Modules\BookingModule\Support\Compat\ModuleVersionCompat::validate(BookingModuleSetting::MODULE_NAME);

        if (! Schema::hasTable('bookings')) {
            return;
        }
        if (!Schema::hasColumn('bookings', 'total_campaign_discount_amount')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->decimal('total_campaign_discount_amount',24,3)->default(0);
                $table->decimal('total_coupon_discount_amount',24,3)->default(0);
                $table->string('coupon_code')->nullable();
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('', function (Blueprint $table) {

        });
    }
};
