<?php

use Illuminate\Database\Migrations\Migration;

/**
 * This migration has been superseded by earlier company_id migrations.  It is kept
 * as a placeholder to avoid filename conflicts but performs no operations.
 */
return new class extends Migration {
    public function up(): void
    {
        // intentionally left blank
    }

    public function down(): void
    {
        // intentionally left blank
    }
};
