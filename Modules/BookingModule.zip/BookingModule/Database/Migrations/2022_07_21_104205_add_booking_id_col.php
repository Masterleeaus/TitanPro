<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Modules\BookingModule\Entities\BookingModuleSetting;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        \Modules\BookingModule\Support\Compat\ModuleVersionCompat::validate(BookingModuleSetting::MODULE_NAME);

        if (! Schema::hasTable('bookings')) {
            return;
        }
        if (!Schema::hasColumn('bookings', 'readable_id')) {
            Schema::table('bookings', function (Blueprint $table) {
                // SQLite cannot add a NOT NULL column with a NULL default to an
                // existing table. Keep this nullable for install/upgrade safety;
                // application code can populate readable_id after insert.
                $table->bigInteger('readable_id')->nullable()->after('id');
            });

            // Backfill existing rows with their primary key as a safe readable id.
            try {
                \Illuminate\Support\Facades\DB::table('bookings')
                    ->whereNull('readable_id')
                    ->orderBy('id')
                    ->select('id')
                    ->chunkById(100, function ($rows) {
                        foreach ($rows as $row) {
                            \Illuminate\Support\Facades\DB::table('bookings')
                                ->where('id', $row->id)
                                ->update(['readable_id' => $row->id]);
                        }
                    });
            } catch (\Throwable $e) {
                // Backfill is best-effort and should never block migrations.
            }
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('', function (Blueprint $table) {

        });
    }
};
