<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Add the company_id column to all BookingModule tables if they are missing.
     *
     * This migration uses nullable columns and indexes to avoid breaking existing
     * data in production.  If a table does not exist or already contains the
     * company_id column it will be skipped.  This idempotent behaviour mirrors
     * Laravel's default migration philosophy and allows the migration to be
     * executed safely multiple times.
     */
    public function up(): void
    {
        $tables = [
            'booking_additional_information',
            'booking_details',
            'booking_details_amounts',
            'booking_ignores',
            'booking_offline_payments',
            'booking_partial_payments',
            'booking_repeat_details',
            'booking_repeat_histories',
            'booking_repeats',
            'booking_schedule_histories',
            'booking_status_histories',
            'bookings',
            'subscription_booking_types',
            'subscription_subscriber_bookings',
        ];
        foreach ($tables as $table) {
            if (!Schema::hasTable($table) || Schema::hasColumn($table, 'company_id')) {
                // Skip tables that do not exist or already have the column
                continue;
            }
            Schema::table($table, function (Blueprint $table) {
                $table->unsignedBigInteger('company_id')->nullable()->index();
            });
        }
    }

    /**
     * Reverse the migration.
     *
     * The down method intentionally does nothing.  Dropping columns on
     * production databases can be destructive and is not required for this
     * module.
     */
    public function down(): void
    {
        // intentionally left blank
    }
};
