<?php
namespace Modules\BookingModule\Services;
class ModuleAgentControlService { public function __construct(private readonly ModuleAgentBindingService $bindings) {} public function handle(array $payload): array { return ['ok'=>true,'tools'=>$this->bindings->tools(),'input'=>$payload]; } }
