<?php
namespace Modules\BookingModule\Services;
class ModuleAgentBindingService { public function tools(): array { return ['bookingmodule.create_record'=>'Modules\\BookingModule\\Actions\\CreateBookingAction','bookingmodule.lookup_record'=>'Modules\\BookingModule\\Actions\\LookupBookingAction']; } }
