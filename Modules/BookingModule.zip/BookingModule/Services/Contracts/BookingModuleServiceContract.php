<?php
namespace Modules\BookingModule\Services\Contracts;
use Illuminate\Database\Eloquent\Collection;
use Modules\BookingModule\Entities\Booking;
interface BookingModuleServiceContract
{
    public function createBooking(array $data): Booking;
    public function updateBooking(Booking $booking, array $data): Booking;
    public function deleteBooking(Booking $booking): bool;
    public function lookupBooking(string|int $id): ?Booking;
    public function recentBookings(int $limit = 25): Collection;
}
