<?php
namespace Modules\BookingModule\Services;
use Illuminate\Database\Eloquent\Collection;
use Modules\BookingModule\Entities\Booking;
use Modules\BookingModule\Repositories\BookingRepository;
use Modules\BookingModule\Services\Contracts\BookingModuleServiceContract;
class BookingModuleService implements BookingModuleServiceContract
{
    public function __construct(private readonly BookingRepository $bookings) {}
    public function createBooking(array $data): Booking { return $this->bookings->create($data); }
    public function updateBooking(Booking $booking, array $data): Booking { return $this->bookings->update($booking, $data); }
    public function deleteBooking(Booking $booking): bool { return $this->bookings->delete($booking); }
    public function lookupBooking(string|int $id): ?Booking { return $this->bookings->find($id); }
    public function recentBookings(int $limit = 25): Collection { return $this->bookings->recent($limit); }
}
