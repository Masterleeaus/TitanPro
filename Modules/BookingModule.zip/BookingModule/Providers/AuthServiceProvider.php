<?php

namespace Modules\BookingModule\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Modules\BookingModule\Entities\Appointment;
use Modules\BookingModule\Entities\Booking;
use Modules\BookingModule\Entities\Schedule;
use Modules\BookingModule\Policies\AppointmentPolicy;
use Modules\BookingModule\Policies\BookingPolicy;
use Modules\BookingModule\Policies\SchedulePolicy;

class AuthServiceProvider extends ServiceProvider
{
    protected $policies = [
        Booking::class => BookingPolicy::class,
        Appointment::class => AppointmentPolicy::class,
        Schedule::class    => SchedulePolicy::class,
    ];

    public function boot(): void
    {
        $this->registerPolicies();
    }
}
