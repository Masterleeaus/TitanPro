<?php

namespace Modules\BookingModule\Providers;

use Modules\BookingModule\Console\ActivateModuleCommand;
use Modules\BookingModule\Console\DispatchBookingRemindersCommand;
use Modules\BookingModule\Console\PruneBookingReminderLogsCommand;
use Illuminate\Support\ServiceProvider;
use Illuminate\Database\Eloquent\Factory;
use Modules\BookingModule\Services\BookingFSMService;
use Modules\BookingModule\Services\BookingAutoInvoiceService;
use Modules\BookingModule\Services\BookingModuleService;
use Modules\BookingModule\Services\Contracts\BookingModuleServiceContract;

class BookingModuleServiceProvider extends ServiceProvider
{
    /**
     * @var string $moduleName
     */
    protected $moduleName = 'BookingModule';

    /**
     * @var string $moduleNameLower
     */
    protected $moduleNameLower = 'bookingmodule';

    /**
     * Boot the application events.
     *
     * @return void
     */
    public function boot()
    {
        if ($this->app->runningInConsole()) {
            $this->commands([
                ActivateModuleCommand::class,
                DispatchBookingRemindersCommand::class,
                PruneBookingReminderLogsCommand::class,
            ]);
        }

        $this->registerTranslations();
        $this->registerConfig();
        $this->registerViews();
        if (class_exists(\Modules\BookingModule\Entities\Appointment::class) && class_exists(\Modules\BookingModule\Observers\AppointmentObserver::class)) { \Modules\BookingModule\Entities\Appointment::observe(\Modules\BookingModule\Observers\AppointmentObserver::class); }
        if (class_exists(\Modules\BookingModule\Entities\Schedule::class) && class_exists(\Modules\BookingModule\Observers\ScheduleObserver::class)) { \Modules\BookingModule\Entities\Schedule::observe(\Modules\BookingModule\Observers\ScheduleObserver::class); }
        if (class_exists(\Modules\BookingModule\Entities\Schedule::class) && class_exists(\Modules\BookingModule\Observers\ScheduleBookingObserver::class)) { \Modules\BookingModule\Entities\Schedule::observe(\Modules\BookingModule\Observers\ScheduleBookingObserver::class); }
        if (isset($this->app['router']) && class_exists(\Modules\BookingModule\Http\Middleware\PublicBookingHoneypot::class)) { $this->app['router']->aliasMiddleware('appointment.public.honeypot', \Modules\BookingModule\Http\Middleware\PublicBookingHoneypot::class); }
        $this->loadMigrationsFrom(module_path($this->moduleName, 'Database/Migrations'));
    }

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        $this->app->register(RouteServiceProvider::class);
        if (class_exists(\Modules\BookingModule\Providers\AuthServiceProvider::class)) { $this->app->register(\Modules\BookingModule\Providers\AuthServiceProvider::class); }
        if (class_exists(\Modules\BookingModule\Providers\EventServiceProvider::class)) { $this->app->register(\Modules\BookingModule\Providers\EventServiceProvider::class); }
        if (class_exists(\Modules\BookingModule\Providers\FilamentServiceProvider::class)) { $this->app->register(\Modules\BookingModule\Providers\FilamentServiceProvider::class); }

        // Register compatibility aliases for optional upstream modules.  Some
        // Worksuite installations may disable ProviderManagement or ZoneManagement
        // modules entirely.  Without aliasing missing classes to lightweight
        // stubs, the BookingModule will throw a fatal error when it attempts
        // to type-hint or resolve those classes via the container.  See
        // Support/Compat for the stub implementations.
        $this->registerCompatAliases();

        // Bind FSM services as singletons.
        $this->app->singleton(BookingFSMService::class);
        $this->app->singleton(BookingAutoInvoiceService::class);
        $this->app->bind(BookingModuleServiceContract::class, BookingModuleService::class);
        $this->app->singleton(\Modules\BookingModule\Services\ModuleAgentBindingService::class);
        $this->app->singleton(\Modules\BookingModule\Services\ModuleAgentControlService::class);
    }

    /**
     * Register class aliases to compat stubs for missing upstream modules.
     *
     * When the ProviderManagement or ZoneManagement packages are disabled,
     * the core classes (Provider, SubscribedService, Zone) do not exist.  To
     * prevent binding resolution exceptions during controller or model
     * instantiation, we alias those class names to simple Eloquent models
     * defined in Modules\BookingModule\Support\Compat.  If the real
     * classes exist they will be used instead, preserving full
     * functionality.
     */
    protected function registerCompatAliases(): void
    {
        $aliases = [
            \Modules\ProviderManagement\Entities\Provider::class          => \Modules\BookingModule\Support\Compat\ProviderCompat::class,
            \Modules\ProviderManagement\Entities\SubscribedService::class => \Modules\BookingModule\Support\Compat\SubscribedServiceCompat::class,
            \Modules\ZoneManagement\Entities\Zone::class                 => \Modules\BookingModule\Support\Compat\ZoneCompat::class,
        ];

        foreach ($aliases as $original => $replacement) {
            // If the original class does not exist but the replacement does,
            // create a class alias so Laravel's service container can resolve it.
            if (!class_exists($original) && class_exists($replacement)) {
                class_alias($replacement, $original);
            }
        }
    }

    /**
     * Register config.
     *
     * @return void
     */
    protected function registerConfig()
    {
        foreach (['config','auto_assign','automation','dispatch','legacy_import','notifications','permissions','module','navigation'] as $cfg) {
            $cfgPath = module_path($this->moduleName, 'Config/' . $cfg . '.php');
            if (file_exists($cfgPath)) {
                $this->publishes([$cfgPath => config_path($this->moduleNameLower . '_' . $cfg . '.php')], 'config');
                $this->mergeConfigFrom($cfgPath, $this->moduleNameLower . '.' . $cfg);
            }
        }
    }

    /**
     * Register views.
     *
     * @return void
     */
    public function registerViews()
    {
        $viewPath = resource_path('views/modules/' . $this->moduleNameLower);

        $sourcePath = module_path($this->moduleName, 'Resources/views');

        $this->publishes([
            $sourcePath => $viewPath
        ], ['views', $this->moduleNameLower . '-module-views']);

        $this->loadViewsFrom(array_merge($this->getPublishableViewPaths(), [$sourcePath]), $this->moduleNameLower);
    }

    /**
     * Register translations.
     *
     * @return void
     */
    public function registerTranslations()
    {
        $langPath = resource_path('lang/modules/' . $this->moduleNameLower);

        if (is_dir($langPath)) {
            $this->loadTranslationsFrom($langPath, $this->moduleNameLower);
        } else {
            $this->loadTranslationsFrom(module_path($this->moduleName, 'Resources/lang'), $this->moduleNameLower);
        }
    }

    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return [];
    }

    private function getPublishableViewPaths(): array
    {
        $paths = [];
        foreach ((array) \Config::get('view.paths', []) as $path) {
            if (is_dir($path . '/modules/' . $this->moduleNameLower)) {
                $paths[] = $path . '/modules/' . $this->moduleNameLower;
            }
        }
        return $paths;
    }
}
