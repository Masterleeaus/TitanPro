<?php

namespace Modules\BookingModule\Providers;

use Illuminate\Support\Facades\Route;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;

class RouteServiceProvider extends ServiceProvider
{
    protected $moduleNamespace = 'Modules\\BookingModule\\Http\\Controllers';

    public function boot(): void
    {
        parent::boot();
    }

    public function map(): void
    {
        $this->mapApiRoutes();
        $this->mapWebRoutes();
        $this->mapAdminRoutes();
        $this->mapChannelRoutes();
        $this->mapConsoleRoutes();
    }

    protected function mapWebRoutes(): void
    {
        Route::middleware('web')->namespace($this->moduleNamespace)->group(module_path('BookingModule', '/Routes/web.php'));
    }

    protected function mapApiRoutes(): void
    {
        Route::prefix('api/v1')->middleware('api')->namespace($this->moduleNamespace)->group(module_path('BookingModule', '/Routes/api.php'));
    }

    protected function mapAdminRoutes(): void
    {
        $path = module_path('BookingModule', '/Routes/admin.php');
        if (file_exists($path)) { Route::middleware('web')->namespace($this->moduleNamespace)->group($path); }
    }

    protected function mapChannelRoutes(): void
    {
        $path = module_path('BookingModule', '/Routes/channels.php');
        if (file_exists($path)) { require $path; }
    }

    protected function mapConsoleRoutes(): void
    {
        $path = module_path('BookingModule', '/Routes/console.php');
        if ($this->app->runningInConsole() && file_exists($path)) { require $path; }
    }
}
