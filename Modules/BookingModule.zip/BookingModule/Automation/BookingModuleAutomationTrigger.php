<?php
namespace Modules\BookingModule\Automation;
class BookingModuleAutomationTrigger { public function triggers(): array { return ['booking.created','booking.completed','booking.cancelled']; } }
