<?php
namespace Modules\BookingModule\Models;
class Booking extends \Modules\BookingModule\Entities\Booking {}
