<?php
namespace Modules\BookingModule\Listeners;
use Modules\BookingModule\Events\BookingCreated;
class SendBookingCreatedNotification { public function handle(BookingCreated $event): void { report_if(false, $event); } }
