# BookingModule Health Report

- Healthy: yes
- Panels: `*`
- Namespace: `Modules\BookingModule\`

- [WARNING] missing_discovery_directory: Missing optional discovery directory.
- [WARNING] missing_discovery_directory: Missing optional discovery directory.
