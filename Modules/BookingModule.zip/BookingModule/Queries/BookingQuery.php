<?php
namespace Modules\BookingModule\Queries;
use Illuminate\Database\Eloquent\Builder;
use Modules\BookingModule\Entities\Booking;
class BookingQuery
{
    public function base(): Builder { return Booking::query(); }
    public function byStatus(?string $status): Builder { return $status ? $this->base()->where('booking_status', $status) : $this->base(); }
}
