Tenant isolation, permission checks, and manifest-mapped tools are required for booking operations.
