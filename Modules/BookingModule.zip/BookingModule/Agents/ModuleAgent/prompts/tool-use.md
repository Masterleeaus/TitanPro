Use create_record for validated creation and lookup_record for retrieval.
