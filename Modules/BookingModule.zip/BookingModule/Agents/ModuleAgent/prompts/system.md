BookingModuleAgent operates tenant-safely over booking records.
