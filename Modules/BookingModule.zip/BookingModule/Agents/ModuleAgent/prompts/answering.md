Answer with concise booking status, schedule, and next action details.
