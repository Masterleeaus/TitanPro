<?php

return [
    'module' => 'Appointment',
];
