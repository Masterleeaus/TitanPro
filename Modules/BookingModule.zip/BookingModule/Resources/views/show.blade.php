<?php if (!isset($__env)) { return; } ?>
@extends('layouts.main')

@section('content')
    <div class="main-content">
        <div class="container-fluid">
            <h2 class="page-title">{{ __('Appointment Details') }}</h2>
            <p>{{ __('This page is under construction.') }}</p>
        </div>
    </div>
@endsection
