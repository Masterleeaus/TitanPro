<?php if (!isset($__env)) { return; } ?>
@component('mail::message')
# Appointment

{{ $messageText ?? '' }}
@endcomponent
