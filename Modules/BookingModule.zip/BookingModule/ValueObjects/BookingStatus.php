<?php
namespace Modules\BookingModule\ValueObjects;
final class BookingStatus { public const PENDING='pending'; public const ACCEPTED='accepted'; public const ONGOING='ongoing'; public const COMPLETED='completed'; public const CANCELLED='cancelled'; public static function all(): array { return [self::PENDING,self::ACCEPTED,self::ONGOING,self::COMPLETED,self::CANCELLED]; } }
