<?php
namespace Modules\BookingModule\Actions;
use Modules\BookingModule\Data\BookingData;
use Modules\BookingModule\Entities\Booking;
use Modules\BookingModule\Services\Contracts\BookingModuleServiceContract;
class CreateBookingAction { public function __construct(private readonly BookingModuleServiceContract $service) {} public function execute(array|BookingData $data): Booking { return $this->service->createBooking($data instanceof BookingData ? $data->toArray() : $data); } }
