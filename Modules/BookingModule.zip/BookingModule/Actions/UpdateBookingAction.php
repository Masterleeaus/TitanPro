<?php
namespace Modules\BookingModule\Actions;
use Modules\BookingModule\Data\BookingData;
use Modules\BookingModule\Entities\Booking;
use Modules\BookingModule\Services\Contracts\BookingModuleServiceContract;
class UpdateBookingAction { public function __construct(private readonly BookingModuleServiceContract $service) {} public function execute(Booking $booking, array|BookingData $data): Booking { return $this->service->updateBooking($booking, $data instanceof BookingData ? $data->toArray() : $data); } }
