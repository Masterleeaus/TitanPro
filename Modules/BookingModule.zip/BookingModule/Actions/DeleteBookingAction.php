<?php
namespace Modules\BookingModule\Actions;
use Modules\BookingModule\Entities\Booking;
use Modules\BookingModule\Services\Contracts\BookingModuleServiceContract;
class DeleteBookingAction { public function __construct(private readonly BookingModuleServiceContract $service) {} public function execute(Booking $booking): bool { return $this->service->deleteBooking($booking); } }
