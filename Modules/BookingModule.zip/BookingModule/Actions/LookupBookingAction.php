<?php
namespace Modules\BookingModule\Actions;
use Modules\BookingModule\Entities\Booking;
use Modules\BookingModule\Services\Contracts\BookingModuleServiceContract;
class LookupBookingAction { public function __construct(private readonly BookingModuleServiceContract $service) {} public function execute(string|int $id): ?Booking { return $this->service->lookupBooking($id); } }
