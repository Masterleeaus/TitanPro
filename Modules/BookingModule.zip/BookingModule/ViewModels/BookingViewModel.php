<?php
namespace Modules\BookingModule\ViewModels;
use Modules\BookingModule\Entities\Booking;
class BookingViewModel { public function __construct(private readonly Booking $booking) {} public function toArray(): array { return $this->booking->toArray(); } }
