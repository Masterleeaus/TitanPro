<?php
namespace Modules\BookingModule\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
class UpdateBookingRequest extends FormRequest { public function authorize(): bool { return true; } public function rules(): array { return ['booking_status'=>['nullable','string'],'payment_method'=>['nullable','string'],'service_schedule'=>['nullable']]; } }
