<?php
namespace Modules\BookingModule\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
class StoreBookingRequest extends FormRequest { public function authorize(): bool { return true; } public function rules(): array { return ['customer_id'=>['nullable'],'provider_id'=>['nullable'],'booking_status'=>['nullable','string'],'payment_method'=>['nullable','string'],'service_schedule'=>['nullable']]; } }
