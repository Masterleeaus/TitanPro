<?php
namespace Modules\BookingModule\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
class EnsureBookingModuleEnabled { public function handle(Request $request, Closure $next) { abort_unless(config('bookingmodule.module.enabled', true), 404); return $next($request); } }
