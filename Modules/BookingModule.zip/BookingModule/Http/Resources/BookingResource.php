<?php
namespace Modules\BookingModule\Http\Resources;
use Illuminate\Http\Resources\Json\JsonResource;
class BookingResource extends JsonResource { public function toArray($request): array { return ['id'=>$this->getKey(),'status'=>$this->booking_status,'amount'=>$this->total_booking_amount,'scheduled_for'=>$this->service_schedule]; } }
