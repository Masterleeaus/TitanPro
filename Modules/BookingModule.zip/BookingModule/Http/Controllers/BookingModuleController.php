<?php
namespace Modules\BookingModule\Http\Controllers;
use Illuminate\Routing\Controller;
use Modules\BookingModule\Services\Contracts\BookingModuleServiceContract;
class BookingModuleController extends Controller { public function index(BookingModuleServiceContract $service) { return response()->json(['data'=>$service->recentBookings(25)]); } }
