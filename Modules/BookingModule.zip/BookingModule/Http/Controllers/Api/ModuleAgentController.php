<?php
namespace Modules\BookingModule\Http\Controllers\Api;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\BookingModule\Services\ModuleAgentControlService;
class ModuleAgentController extends Controller { public function __invoke(Request $request, ModuleAgentControlService $service) { return response()->json($service->handle($request->all())); } }
