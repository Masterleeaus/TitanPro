<?php
namespace Modules\BookingModule\Http\Controllers\Api;
use Illuminate\Routing\Controller;
use Modules\BookingModule\Actions\LookupBookingAction;
use Modules\BookingModule\Http\Requests\StoreBookingRequest;
use Modules\BookingModule\Actions\CreateBookingAction;
class BookingModuleApiController extends Controller { public function store(StoreBookingRequest $request, CreateBookingAction $action) { return response()->json(['data'=>$action->execute($request->validated())], 201); } public function show(string|int $id, LookupBookingAction $action) { return response()->json(['data'=>$action->execute($id)]); } }
