<?php
namespace Modules\BookingModule\Http\Controllers\Admin;
use Illuminate\Routing\Controller;
use Modules\BookingModule\Services\Contracts\BookingModuleServiceContract;
class BookingModuleAdminController extends Controller { public function commandCenter(BookingModuleServiceContract $service) { return view()->exists('bookingmodule::admin.command-center') ? view('bookingmodule::admin.command-center', ['bookings'=>$service->recentBookings(10)]) : response()->json(['bookings'=>$service->recentBookings(10)]); } }
