<?php
namespace Modules\BookingModule\Policies;
use Modules\BookingModule\Entities\Booking;
class BookingPolicy
{
    public function view($user, Booking $booking): bool { return $this->can($user, 'view_booking'); }
    public function create($user): bool { return $this->can($user, 'add_booking'); }
    public function update($user, Booking $booking): bool { return $this->can($user, 'edit_booking'); }
    public function delete($user, Booking $booking): bool { return $this->can($user, 'delete_booking'); }
    private function can($user, string $permission): bool { return method_exists($user, 'can') ? (bool) $user->can($permission) : false; }
}
