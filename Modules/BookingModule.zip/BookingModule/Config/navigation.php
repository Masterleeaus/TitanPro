<?php
return [
    'sidebar' => [
        ['label' => 'Bookings', 'route' => 'bookingmodule.admin.command-center', 'permission' => 'view_booking', 'icon' => 'heroicon-o-calendar-days'],
    ],
];
