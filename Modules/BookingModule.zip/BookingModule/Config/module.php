<?php
return [
    'name' => 'BookingModule',
    'alias' => 'bookingmodule',
    'enabled' => env('BOOKINGMODULE_ENABLED', true),
    'primary_model' => Modules\BookingModule\Entities\Booking::class,
    'tenant_key' => 'company_id',
];
