<?php
namespace Modules\BookingModule\Repositories;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Modules\BookingModule\Entities\Booking;
class BookingRepository
{
    public function query(): Builder { return Booking::query(); }
    public function find(string|int $id): ?Booking { return $this->query()->whereKey($id)->first(); }
    public function create(array $data): Booking { return Booking::query()->create($data); }
    public function update(Booking $booking, array $data): Booking { $booking->fill($data); $booking->save(); return $booking->refresh(); }
    public function delete(Booking $booking): bool { return (bool) $booking->delete(); }
    public function recent(int $limit = 25): Collection { return $this->query()->latest()->limit($limit)->get(); }
}
