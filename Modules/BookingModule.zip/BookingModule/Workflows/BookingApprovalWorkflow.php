<?php
namespace Modules\BookingModule\Workflows;
use Modules\BookingModule\Entities\Booking;
class BookingApprovalWorkflow { public function approve(Booking $booking): Booking { $booking->booking_status = 'accepted'; $booking->save(); return $booking; } }
