# BookingModule

Tenant-safe booking, appointment, dispatch, and AI-control module for Titan/Worksuite-style Laravel applications.
