<?php
namespace Modules\BookingModule\Mail;
use Illuminate\Mail\Mailable;
class BookingCreatedMail extends Mailable { public function build(): self { return $this->subject('Booking created')->view('bookingmodule::mail.booking-created'); } }
