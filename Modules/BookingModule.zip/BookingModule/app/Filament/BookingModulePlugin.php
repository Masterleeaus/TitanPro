<?php

namespace Modules\BookingModule\Filament;

use Coolsam\Modules\Concerns\ModuleFilamentPlugin;
use Filament\Contracts\Plugin;
use Filament\Panel;

class BookingModulePlugin implements Plugin
{
    use ModuleFilamentPlugin;

    public function getModuleName(): string
    {
        return 'BookingModule';
    }

    public function getId(): string
    {
        return 'bookingmodule';
    }

    public function boot(Panel $panel): void
    {
        [->getId(), 'bookingmodule'];
    }
}
