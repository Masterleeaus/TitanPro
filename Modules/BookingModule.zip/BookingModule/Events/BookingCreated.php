<?php
namespace Modules\BookingModule\Events;
use Modules\BookingModule\Entities\Booking;
class BookingCreated { public function __construct(public readonly Booking $booking) {} }
