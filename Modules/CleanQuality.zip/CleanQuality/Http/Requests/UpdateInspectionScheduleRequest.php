<?php

namespace Modules\CleanQuality\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateInspectionScheduleRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array { return []; }
}
