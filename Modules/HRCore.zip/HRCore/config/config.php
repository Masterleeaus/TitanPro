<?php

return [
    'name' => 'HRCore',
];
