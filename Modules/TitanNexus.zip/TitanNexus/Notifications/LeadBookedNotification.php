<?php class LeadBookedNotification {}
