<?php class CampaignAlertNotification {}
