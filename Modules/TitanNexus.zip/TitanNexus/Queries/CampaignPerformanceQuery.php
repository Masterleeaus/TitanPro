<?php class CampaignPerformanceQuery {}
