<?php class FollowupEmail {}
