<?php class ActiveCampaignScope {}
