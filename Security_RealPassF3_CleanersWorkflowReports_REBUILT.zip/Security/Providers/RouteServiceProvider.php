<?php

namespace Modules\Security\Providers;

use Illuminate\Support\Facades\Route;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The module namespace to assume when generating URLs to actions.
     *
     * @var string
     */
    protected $moduleNamespace = 'Modules\Security\Http\Controllers';

    /**
     * Called before routes are registered.
     *
     * Register any model bindings or pattern based filters.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();
    }

    /**
     * Define the routes for the application.
     *
     * @return void
     */
    public function map()
    {
        $this->mapApiRoutes();

        $this->mapWebRoutes();

        $this->mapSettingRoutes();
        $this->mapOptionalWebRoutes();
        $this->mapInternalRoutes();
        $this->mapChannelRoutes();
    }

    /**
     * Define the "web" routes for the application.
     *
     * These routes all receive session state, CSRF protection, etc.
     *
     * @return void
     */
    protected function mapWebRoutes()
    {
        Route::middleware('web')
            ->namespace($this->moduleNamespace)
            ->group(module_path('Security', 'Routes/web.php'));
    }

    /**
     * Define the "web" routes for the application.
     *
     * These routes all receive session state, CSRF protection, etc.
     *
     * @return void
     */
    protected function mapSettingRoutes()
    {
        if (file_exists(module_path('Security', 'Routes/web-settings.php'))) {
            Route::middleware('web')
                ->namespace($this->moduleNamespace)
                ->group(module_path('Security', 'Routes/web-settings.php'));
        }
    }


    /**
     * Define optional blueprint web/admin/workflow/AI/webhook routes when present.
     */
    protected function mapOptionalWebRoutes()
    {
        foreach (['admin.php', 'workflow.php', 'ai.php', 'webhook.php'] as $routeFile) {
            $path = module_path('Security', 'Routes/' . $routeFile);
            if (file_exists($path)) {
                Route::middleware('web')
                    ->namespace($this->moduleNamespace)
                    ->group($path);
            }
        }
    }

    /**
     * Define internal routes separately so they can be protected later.
     */
    protected function mapInternalRoutes()
    {
        $path = module_path('Security', 'Routes/internal.php');
        if (file_exists($path)) {
            Route::prefix('internal/security')
                ->middleware('web')
                ->namespace($this->moduleNamespace . '\Internal')
                ->group($path);
        }
    }


    /**
     * Define broadcast channels when the channel route file exists.
     */
    protected function mapChannelRoutes(): void
    {
        $path = module_path('Security', 'Routes/channels.php');
        if (file_exists($path)) {
            require $path;
        }
    }

    /**
     * Define the "api" routes for the application.
     *
     * These routes are typically stateless.
     *
     * @return void
     */
    protected function mapApiRoutes()
    {
        Route::prefix('api')
            ->middleware('api')
            ->namespace($this->moduleNamespace)
            ->group(module_path('Security', 'Routes/api.php'));
    }
}
